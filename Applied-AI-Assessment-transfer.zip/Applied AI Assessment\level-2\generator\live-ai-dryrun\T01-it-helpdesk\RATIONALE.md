# Rationale / Design Decisions

## Architecture

Flask + SQLite, a plain-Python agent module, and a small vanilla-JS review UI. No
framework for the "agent" part: the brief asks for specific agent *behavior*
(classify → check duplicates via a tool → pull more context via a tool if uncertain →
decide → act via tools), and a transparent, testable Python function (`app/agent.py:
process_ticket`) demonstrates that behavior more clearly — and more verifiably — than
routing everything through an LLM tool-calling loop that I'd have to fake the model
side of anyway. Every tool call and every action is still logged to the database
exactly as if it came out of a real tool-calling loop, so swapping in a real
orchestration framework later is a matter of replacing the control flow in one file.

## The "in-house LLM"

No API key was available in the environment (checked `ANTHROPIC_API_KEY` / `OPENAI_API_KEY` — neither
was set). `app/llm_stub.py` implements a deterministic, keyword-scored classifier behind
the exact contract a real model call would have: `classify(body_text, *,
requester_tier=None, extra_context=None) -> ClassificationResult(category, confidence,
reasoning)`. Swapping in a real model means replacing the body of `classify()` with a
prompted API call and leaving every caller untouched — that boundary is the main thing
I optimized for, not classification accuracy. This is called out again in the module
docstring.

## Key judgment calls on underspecified parts of the brief

- **"Genuine duplicate."** I treat a new ticket as a genuine duplicate only if the
  *best-matching still-open* prior ticket from the same requester clears a similarity
  threshold (blended sequence-similarity + token-containment, to catch a terse restate
  like "Laptop won't turn on." duplicating a longer open ticket about the same laptop).
  A closed historical ticket about the same symptom is surfaced as related history but
  does **not** trigger auto-close — the requester's problem clearly isn't resolved if
  they're filing again, closed-precedent notwithstanding.
- **"Specific, checkable discrepancy."** I only run the billing-check/courtesy-resolution
  path when the ticket body contains an explicit dollar figure (regex-extracted). A
  ticket like "I believe there was a billing error" has nothing to check against a
  record, so it's routed to Billing for manual handling instead of silently skipped or
  incorrectly auto-resolved.
- **"Small threshold" for autonomous resolution.** I set this at $50. The seed data
  splits cleanly around it ($15/$20 confirmed-and-small → auto-resolved; $200
  confirmed-but-large → held for human approval; $40 claimed-but-unconfirmed → held
  regardless of size). This is a policy knob, not a hardcoded assumption — it lives as
  one constant in `app/tools.py`.
- **Billing claim that doesn't match the record** (e.g. claimed $40, record shows $0)
  is treated as *not* confirmed, flagged for human review, and never auto-resolved —
  a mismatch could equally be requester error or something worth investigating, and
  autonomously refunding an unconfirmed number felt like the wrong default.
- **Uncertain-classification trigger.** Confidence is a function of how dominant the
  top-scoring category is versus the runner-up. When it's below threshold I pull a
  second, simulated tool (`get_additional_context`) and re-classify with that folded
  in. The clearest example in the seed data is HD-3035 ("can't log into the VPN... locked
  after repeated failed logins... worried someone else tried") — legitimately
  ambiguous between Network/VPN and Security Incident, and the extra "context" (a
  simulated account-security audit log) is what tips it.
- **`get_additional_context` is simulated.** The seed data doesn't include an
  account-security/audit-log system, so there's nothing real for this tool to query. I
  built a small deterministic stand-in (same style as the classifier stub) so the
  agent's second pass has something concrete to react to, rather than skipping this
  requirement. This is the one place I'd flag most clearly as "not a real integration"
  if reviewing this myself.
- **Historical (`open`/`closed`) tickets in the seed CSV** are loaded so duplicate-
  search can see them, but are *not* re-run through the agent pipeline — only `new`
  tickets are. Re-triaging an already-escalated, already-open hardware ticket doesn't
  make sense for an agent meant to handle an incoming request stream.
- **VIP tier** is treated as an automatic human-attention flag regardless of the
  ticket's actual content (e.g. HD-3025's trivial wallpaper question) — a
  service-tier policy decision, not a classification one, and easy to disagree with.
  I'd sanity-check this with a real stakeholder before shipping it as-is.

## Places I questioned or corrected an AI-assistant-style suggestion

While drafting the duplicate-detection tool, a pure `difflib.SequenceMatcher` ratio
(the "obvious" first approach) badly under-scored the real duplicate case in the seed
data (HD-3010 vs HD-3007) because the longer, earlier ticket has a lot of extra
troubleshooting narrative the terse new one doesn't repeat — ratio came out ~0.36
against a naive 0.6 threshold. Rather than just lower the threshold (which would
start false-positiving on genuinely different tickets that happen to share a few
words), I added a token-containment component and blended the two, then re-verified
against both the genuine-duplicate case and the closed-ticket-should-not-count case
with actual tests before trusting the threshold.

## Known limitations / what I'd do with more time

- The classifier is bag-of-keywords, not a model — it will misfire on phrasing it
  hasn't seen (e.g. it has no real language understanding, just weighted substring
  matches). Documented as the explicit swap point.
- No auth/RBAC on the review UI or API — anyone who can reach the Flask app can
  override anything. Fine for a take-home, not for production.
- Duplicate search and billing lookup are O(n) scans with no indexing beyond SQLite's
  primary keys; fine at this data volume, would need real search infra at scale.
- The override endpoint supports category and status overrides but not, say,
  overriding a courtesy-resolution amount directly — a human who disagrees with a
  resolution can reopen the ticket and act manually, but there's no dedicated "reverse
  this refund" action.
- With more time: real LLM integration behind the existing `llm_stub` contract with a
  proper eval set; a real duplicate-search approach (embeddings) instead of blended
  string similarity; webhook/email ingestion instead of batch CSV; pagination and
  filtering in the UI once ticket volume grows past a couple dozen.
