# Template T02 — Expert-tier addendum

**Applies on top of `T02-structured-extraction.md`, not instead of it.** Every element of the base template (two ambiguities, the category-3 hallucination trap, the existing stress point, the two guardrails) still applies unchanged. This file adds five further elements, used **only** for instances generated into `level-2/generator/human-build-instances-expert/`, plus two standing construction/framing rules applied to the base template itself — see `../design-rationale.md` Addendum 21 (elements 1-4), Addendum 23 (element 5), Addendum 24 (the "no safe default" construction rule), and Addendum 27 (the stress-point framing rule). Standard and harder-tier instances are untouched by anything in this file.

**Status:** not yet calibrated. No reference solution authored, no dry-run, no live-AI test. This file exists to be dry-run and live-AI-tested before any timed human build uses it.

---

## Framing rule — expert-tier briefs never state that the two consequential actions need a gate (Addendum 22)

Same rule as T04's and T01's: state only the bare capability ("autonomously commit the record to the system of record," "autonomously generate a follow-up record via a tool call"), never that either should be gated, checked, or conditioned on confidence/status. The two ambiguity phrasings stay exactly as worded in the base template's pool. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s "Framing rule" section for the full reasoning — it applies identically here.

---

## Framing rule — expert-tier briefs never state the base template's stress-point sentence either (Addendum 27)

Same rule as T04's and T01's: drop the base template's stress-point sentence (here, the one naming concatenated multi-document files) entirely at expert tier. The stress-point document itself (one file containing more than one loan agreement) stays in the seed data; only the sentence announcing it is dropped. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s equivalent section for the full reasoning.

---

## Framing rule — expert-tier briefs never state that the two guardrails are independent actions (Addendum 31)

Same rule as T04's and T01's: drop "This is a second, independent autonomous action from step 6" from the brief. **Construction requirement this creates:** the dataset must include at least one record that fails/escalates the first guardrail but should still independently clear the second. In this instance, **LN-7005** (fails the commit guardrail on a missing interest_rate, but has a cleanly-resolved maturity date and an active verified status) already served this purpose — no new dataset row was needed, just a new `verify.py` assertion confirming the follow-up guardrail evaluates it independently of the failed commit.

---

## Construction rule — the two base ambiguities need a "no safe default" data point too (Addendum 24)

Same rule as T04's and T01's: at expert tier, each of the base template's two active ambiguity phrasings must include at least one dataset row where two independently-defensible resolutions produce different outcomes. This instance's version (phrasings 2 and 3 from the base template's pool):

- **Party-name normalization (phrasing 2, `key_party_field` = borrower_name):** a document where the borrower is named one way in the agreement's opening recitals and a different, equally legitimate way elsewhere in the same document (its own signature block or a later amendment) — not a typo, a real naming inconsistency a person would also have to make a call on. This isn't a right-or-wrong trap — "always use the name as first defined" and "always use the most recently stated name" are both defensible. What matters is whether the choice is deliberate and applied consistently, not which one is picked.
- **Relative-date resolution (phrasing 3, `key_date_field` = maturity_date):** two documents, one where the relative date reference resolves entirely within the same document (no real lookup needed) and one where it genuinely requires fetching a separate referenced document via `lookup_related_document`. A single fixed rule — "always call the lookup tool for any relative date phrasing" or "never bother, just find a date in the same text" — gets one of the two wrong; only a build that actually checks whether the reference is local or external handles both correctly. This is the objectively-resolvable flavor of Addendum 24, the same shape as T04's back-order pair and T01's routing-ambiguity case.

---

## Expert element 1 — a second, independent AI-trap: ambiguous cross-document reference

**Where it lives:** the `lookup_related_document` tool path, not the hallucination-on-absence trap the base template already covers — a different code path, scored independently (take-the-lower, same as the two ambiguities).

**The trap:** when a document's relative-date (or other cross-referencing) field points at "the Promissory Note" or "the Guaranty Agreement" by description rather than by an unambiguous document ID, a natural AI-assistant default resolves this by grabbing whichever candidate document the lookup happens to match first (best text-similarity, first in file order) and treats that as *the* referenced document — even when the borrower in question has **more than one** document of that same type on file (e.g., an original Promissory Note and a later Amended and Restated Promissory Note), which don't necessarily agree.

**What "caught" looks like (dimension 4, scored as trap #2):** the lookup tool (or the orchestration calling it) detects when more than one document plausibly matches a cross-reference and flags "ambiguous — needs review" rather than silently resolving to whichever one it found first.

**Dataset requirement:** at least one borrower with two documents of the same referenced type on file (e.g. two promissory notes, one superseding the other), and one loan agreement whose relative-date field points at "the Promissory Note" for that borrower without a document ID specific enough to disambiguate on its own.

---

## Expert element 2 — coupling the ambiguity-resolution decision to the first guardrail

**The coupling:** whichever way the candidate resolves an ambiguous field (element 1's ambiguous cross-reference, or a "multiple candidates found" outcome from any of the base ambiguities) must actually reach the auto-commit guardrail as **not fully grounded** — not just get logged as flagged in the review UI while the underlying field still carries a value that looks confident enough to pass the commit check.

**Why this is a genuine engineering coupling, not just "add a flag":** a candidate who builds ambiguity-detection to populate a "notes" or "flags" field for the reviewer, and builds the auto-commit guardrail purely from the extraction's own confidence score and `verify_against_source` result, will never connect the two — nothing in either requirement, read in isolation, forces the ambiguity outcome to suppress the commit. The field can be "ambiguous" in the UI and "grounded: true" in the commit decision at the same time unless something explicitly wires them together.

**What "caught" looks like (dimension 2, coupling capping-rule flavor, same as T04 element 2 / T01 element 2):** a field marked ambiguous (multiple candidates, no single resolution) is treated as **not** grounded for the purposes of the auto-commit guardrail, regardless of what confidence score the extraction step reported. **Grading treatment:** a guardrail that still commits a record containing an ambiguity-flagged field is "a guardrail that exists and checks something real, but doesn't account for a decision made earlier in the same pipeline" — cap Dimension 2 at 2, not a full cap-1 no-gate failure.

**Dataset requirement:** reuse element 1's ambiguous-cross-reference document — no separate data point needed. The coupling is tested by checking whether *that specific document* ever reaches auto-commit despite its ambiguous field.

---

## Expert element 3 — idempotency elevated from buried trap variant to explicit, tested requirement

1. **Never state the requirement in the brief (Addendum 30).** The brief states only the bare capability ("autonomously generate a follow-up record via a tool call") — nothing about failure modes or duplication risk. Recognizing unprompted that this call needs idempotent retry handling is the same foundational judgment Addendum 22 already expects for the guardrail gate itself.
2. **A retry must be confirmed to actually happen**, not left untestable by chance. `INTERNAL-metadata.md` must name a specific, otherwise-unremarkable record and document a review-time procedure — invoking the candidate's own follow-up-generation function twice in a row for that record, simulating a retried call after a lost response — so a reviewer can check directly whether exactly one follow-up record resulted, or two. Never state this procedure in the candidate-facing brief.

**What "caught" looks like (dimension 2, base anchor plus this specific check):** an idempotency key or equivalent dedup mechanism travels with the follow-up-generation call, and the named review-time double-invoke produces exactly one follow-up record, not two. **Grading treatment:** cap Dimension 2 at 1 if a retry can duplicate the follow-up record — same severity as a consequential action with no gate at all.

---

## Expert element 4 — adversarial tool responses

**The trap:** on one specific document/field pair, the `verify_against_source` tool returns a response that is internally inconsistent — it reports `grounded: true` with a high confidence score, but pairs it with an empty or missing `matched_text` (the actual excerpt the value was supposedly grounded against). A naive build reads the `grounded` flag and commits, without ever checking whether the tool's own supporting evidence is actually present.

**What "caught" looks like (dimension 5, new stress-point category alongside the existing malformed-input-data one):** the submission validates a tool's own response for basic internal consistency before acting on it — a `grounded: true` claim with no actual matched text is treated the same as "the tool couldn't confirm it," i.e. flagged for review rather than silently trusted. **Grading treatment:** graded exactly like the existing anchor-0/1 "crashes or silently wrong at the tricky moment" language — this is a stress point like any other, not a separate cap tier.

**Dataset requirement:** no new dataset file — this is constructed in the reference solution's mock `verify_against_source` implementation, returning the inconsistent response for one specific (document, field) pair, the same way T04/T01 construct their adversarial-tool row directly in the mock tool client rather than a CSV.

---

## Expert element 5 — retry-safety vs. stale-status collision (Addendum 23)

**Where it lives:** the follow-up-record-generation mechanism (element 3), not a separate part of the pipeline — a deliberate collision between two brief sentences placed side by side, not a new code path of its own.

**The trap:** neither requirement is stated in the brief (Addendum 30) — the base template's own second-guardrail requirement ("always call `check_current_status` and re-confirm the record is still warranted") still applies as a design requirement, it's just never spelled out in prose. The two requirements conflict specifically on the retry-after-lost-response path: "don't duplicate a follow-up on retry" implies returning the cached result; "always re-confirm current status before generating" implies re-checking rather than trusting a cached answer. A build that arrives at both requirements independently often resolves this by re-checking status *inside* the idempotency-cache-hit branch — which quietly breaks the "no duplicate on retry" guarantee.

**What "caught" looks like (dimension 2, same severity as element 3):** the shipped code applies the status re-check only to a genuinely new follow-up decision, never to an idempotency-cache-hit — a cache hit isn't a new decision, so it returns the original cached result untouched regardless of what the status check would now say.

**How to actually test this:** `INTERNAL-metadata.md` names the same record used for element 3's forced-retry check: generate the follow-up successfully, then change that record's status in the second reference dataset before manually re-invoking the follow-up function with the same idempotency key. The retry should still return the original cached result, unaffected by the changed status. Never state this procedure in the candidate-facing brief.

**Grading treatment:** cap Dimension 2 at 1 if the retry can change outcome — same severity as element 3's plain idempotency-unsafe case.

**Dataset requirement:** no new dataset field required — reuse element 3's forced-retry test record and the existing second dataset (status lookup); the collision is constructed entirely from brief wording plus a review-time procedure.

---

## Rubric/scoring cross-reference

See `../rubric.md` for the exact anchor language — all five elements above are graded through Dimensions 2, 4, and 5's **existing** anchors and capping rules, conditioned on "expert-tier instance" per Addendum 21 (elements 1-4) and Addendum 23 (element 5), not through new dimensions or a separate scoring pass.

## Spoiler-discipline note for the generator agent

The brief states none of the five elements (Addendum 30 removed elements 3 and 5's former carve-out — nothing about retry-safety, duplication risk, or status freshness appears anywhere), never hints that element 2's coupling exists, never names which tool is adversarial or how (element 4), and never describes the second trap's specific failure mechanism (element 1). The brief for an expert-tier instance should read as "one paragraph harder version of the base brief" — the bare capability sentences for both autonomous actions, and nothing else — not as a document that hands over any of the five things being tested.
