# P12 — Usage by model, case-insensitive

| Field | Value |
|---|---|
| **ID** | P12 |
| **Difficulty** | Medium |
| **Bug pattern** | Grouping key not normalised |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 9–12 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

Several services write to a shared call log, and they disagree about capitalisation — the same model appears as `ada-002`, `Ada-002` and `ADA-002`.

The usage report lists the same model several times, once per spelling, splitting its true usage across the rows.

### Required behaviour

Return `(model, total_tokens)` grouped **case-insensitively**, with model names reported in **lower case**, sorted by model name ascending.

### Schema

```sql
CREATE TABLE call_log (
    id     INTEGER PRIMARY KEY,
    model  TEXT NOT NULL,     -- casing is inconsistent across upstream producers
    tokens INTEGER NOT NULL
);
```

---

## Fixture — `P12.sql`

```sql
CREATE TABLE call_log (
    id     INTEGER PRIMARY KEY,
    model  TEXT NOT NULL,
    tokens INTEGER NOT NULL
);

INSERT INTO call_log (id, model, tokens) VALUES
    (1,'Ada-002',100),
    (2,'ada-002',200);   -- same model, different casing
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def usage_by_model(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (model, total_tokens) grouped case-insensitively,
    with model names in lower case, sorted by model name ascending.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute("SELECT model, tokens FROM call_log ORDER BY id").fetchall()
    finally:
        conn.close()

    totals = {}
    for model, tokens in rows:
        totals[model] = totals.get(model, 0) + tokens
    return sorted(totals.items())
```

### Java

```java
import java.sql.*;
import java.util.*;

public class UsageRollup {

    // --- boilerplate: do not modify ---
    public static class ModelTotal {
        public final String model;
        public final int totalTokens;

        public ModelTotal(String model, int totalTokens) {
            this.model = model;
            this.totalTokens = totalTokens;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (model, totalTokens) grouped case-insensitively,
     * with model names in lower case, sorted by model name ascending.
     */
    public static List<ModelTotal> usageByModel(String dbPath) throws SQLException {
        Map<String, Integer> totals = new HashMap<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT model, tokens FROM call_log ORDER BY id")) {
            while (rs.next()) {
                String model = rs.getString("model");
                int tokens = rs.getInt("tokens");
                totals.merge(model, tokens, Integer::sum);
            }
        }

        List<ModelTotal> out = new ArrayList<>();
        totals.keySet().stream().sorted().forEach(k -> out.add(new ModelTotal(k, totals.get(k))));
        return out;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record ModelTotal(string Model, int TotalTokens);

public static class UsageRollup
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Model, TotalTokens) grouped case-insensitively,
    /// with model names in lower case, sorted by model name ascending.
    /// </summary>
    public static List<ModelTotal> UsageByModel(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<(string Model, int Tokens)>(
            "SELECT model, tokens FROM call_log ORDER BY id").ToList();

        var totals = new Dictionary<string, int>();
        foreach (var (model, tokens) in rows)
        {
            totals[model] = totals.GetValueOrDefault(model) + tokens;
        }

        return totals.OrderBy(kv => kv.Key)
                     .Select(kv => new ModelTotal(kv.Key, kv.Value))
                     .ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `Ada-002` 100, `ada-002` 200 | `[("ada-002", 300)]` | **Discriminator** — broken returns two entries |
| T2 | `ada-002` 100, `text-3-large` 50 — already lower case | `[("ada-002",100), ("text-3-large",50)]` | Guard — nothing to normalise |
| T3 | `ADA-002` 10, `Ada-002` 20, `ada-002` 30 | `[("ada-002", 60)]` | **Discriminator** — broken returns three entries |
| T4 | Single row, `rerank-v1` 42 | `[("rerank-v1", 42)]` | Guard |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO call_log (id, model, tokens) VALUES (1,'ada-002',100),(2,'text-3-large',50);
-- T3
INSERT INTO call_log (id, model, tokens) VALUES (1,'ADA-002',10),(2,'Ada-002',20),(3,'ada-002',30);
-- T4
INSERT INTO call_log (id, model, tokens) VALUES (1,'rerank-v1',42);
```

---

## Reference solution

Normalise the key before using it.

**Python:**

```diff
  for model, tokens in rows:
-     totals[model] = totals.get(model, 0) + tokens
+     key = model.lower()
+     totals[key] = totals.get(key, 0) + tokens
```

**Java:**

```diff
- totals.merge(model, tokens, Integer::sum);
+ totals.merge(model.toLowerCase(), tokens, Integer::sum);
```

**C#:**

```diff
- totals[model] = totals.GetValueOrDefault(model) + tokens;
+ var key = model.ToLowerInvariant();
+ totals[key] = totals.GetValueOrDefault(key) + tokens;
```

### Why

The map key is the raw string, and string keys compare case-sensitively in all three languages. Each spelling therefore opens its own bucket, and a model's usage is divided between however many spellings exist upstream. Nothing errors; the report is simply longer and every row understated.

Normalising at the point the key is *constructed* is the fix. Normalising only at output would merge the display names while leaving the buckets separate, producing duplicate rows with the same label — which usually looks worse than the original bug.

The specification asks for lower case explicitly, so `toUpperCase` is not an equivalent choice here even though it groups identically.

> **C# note:** prefer `ToLowerInvariant()` over `ToLower()`. Culture-sensitive lowercasing differs by locale — most famously Turkish, where `I` does not lower to `i` — so a culture-aware call can group differently depending on where the process runs. The same reasoning applies to `toLowerCase(Locale.ROOT)` in Java.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Normalising to upper case | T1, T3 — output labels are `ADA-002`, not `ada-002` |
| Lower-casing only when emitting the result, not when keying | T1, T3 — duplicate rows with identical labels |
| Adding `COLLATE NOCASE` to the SQL but leaving host grouping raw | T1, T3 — rows still arrive with mixed casing |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is split groups, not a crash
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Output names are lower case after the fix, matching the stated requirement
- [ ] Java `HashMap` iteration is unordered — confirm the sort is what produces the final ordering, not map insertion order
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
