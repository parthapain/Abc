"""Loan agreement extraction agent — application package."""
