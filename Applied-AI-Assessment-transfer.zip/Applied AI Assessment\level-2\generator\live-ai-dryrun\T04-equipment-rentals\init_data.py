"""
Load the seed CSVs (equipment_catalog.csv, rental_orders.csv, alt_yard_inventory.csv)
into the SQLite database. Safe to re-run: catalog/alt-yard rows are upserted, and
orders are inserted only if not already present (so re-running does not wipe out
agent runs / overrides already recorded for existing orders).

Usage:
    python init_data.py            # load if not already loaded
    python init_data.py --reset    # wipe the DB and reload everything fresh
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import db

BASE = Path(__file__).parent


def read_csv(name: str) -> list[dict]:
    with open(BASE / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main(reset: bool = False):
    db.init_db(reset=reset)

    catalog_rows = read_csv("equipment_catalog.csv")
    alt_yard_rows = read_csv("alt_yard_inventory.csv")
    order_rows = read_csv("rental_orders.csv")

    db.load_catalog_rows(catalog_rows)
    db.load_alt_yard_rows(alt_yard_rows)

    for row in order_rows:
        db.upsert_order(
            order_id=row["order_id"],
            client_name=row["client_name"],
            client_type=row["client_type"],
            submitted_at=row["submitted_at"],
            raw_description=row["line_items_description"],
        )

    print(f"Loaded {len(catalog_rows)} catalog items, {len(alt_yard_rows)} alt-yard rows, "
          f"{len(order_rows)} orders into {db.DB_PATH}")


if __name__ == "__main__":
    main(reset="--reset" in sys.argv)
