"""Flask review UI.

Lets a human reviewer see, for every committed loan: the extracted fields
side-by-side with the source document text, correct any field, and see the
autonomous commit status, the agent's decision trail, and any maturity
follow-up record already generated.

Run with:  python -m app.web   (serves on http://127.0.0.1:5000)
"""
from __future__ import annotations

import json

from flask import Flask, redirect, render_template, request, url_for

from . import db

app = Flask(__name__)

EDITABLE_FIELDS = ["borrower_name", "principal_amount", "interest_rate", "maturity_date"]


@app.route("/")
def index():
    with db.get_conn() as conn:
        loans = db.all_loans(conn)
        followups = db.all_followups(conn)
    followup_by_loan = {}
    for f in followups:
        followup_by_loan.setdefault(f["loan_number"], []).append(f)
    return render_template("index.html", loans=loans, followup_by_loan=followup_by_loan)


@app.route("/loan/<loan_number>")
def loan_detail(loan_number: str):
    with db.get_conn() as conn:
        loan = db.get_loan(conn, loan_number)
        if loan is None:
            return f"No such loan: {loan_number}", 404
        agent_log = db.log_for(conn, loan_number)
        corrections = db.corrections_for(conn, loan_number)
        followups = db.followups_for(conn, loan_number)
    review_notes = json.loads(loan["review_notes"]) if loan["review_notes"] else []
    return render_template(
        "review.html",
        loan=loan,
        review_notes=review_notes,
        agent_log=agent_log,
        corrections=corrections,
        followups=followups,
        editable_fields=EDITABLE_FIELDS,
    )


@app.route("/loan/<loan_number>/correct", methods=["POST"])
def correct_field(loan_number: str):
    field_name = request.form["field_name"]
    new_value = request.form["new_value"]
    if field_name not in EDITABLE_FIELDS:
        return "Invalid field", 400
    with db.get_conn() as conn:
        db.apply_correction(conn, loan_number, field_name, new_value)
    return redirect(url_for("loan_detail", loan_number=loan_number))


@app.route("/loan/<loan_number>/mark_reviewed", methods=["POST"])
def mark_reviewed(loan_number: str):
    with db.get_conn() as conn:
        db.mark_reviewed(conn, loan_number)
    return redirect(url_for("loan_detail", loan_number=loan_number))


if __name__ == "__main__":
    db.init_db()
    app.run(debug=True)
