"""Pytest fixtures: every test gets a fresh, isolated SQLite DB file."""
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import database as db  # noqa: E402


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    db_path = tmp_path / "test_helpdesk.db"
    monkeypatch.setattr(db, "DB_PATH", str(db_path))
    # Drop any cached thread-local connection from a previous test.
    if hasattr(db._local, "conn"):
        db._local.conn.close()
        del db._local.conn
    db.init_db(reset=True)
    yield db
    if hasattr(db._local, "conn"):
        db._local.conn.close()
        del db._local.conn
