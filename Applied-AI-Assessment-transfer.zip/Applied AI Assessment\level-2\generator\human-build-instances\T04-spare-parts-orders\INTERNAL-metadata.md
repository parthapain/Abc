# Internal notes — T04 (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app — the whole point is to see what they do without being told where the tricky parts are.

## What's tricky about this dataset, in plain terms

**1. Several orders include items that are completely out of stock.**
Some examples: **ORD-8017** (one out-of-stock item, nothing else), **ORD-8032** (a mix of an in-stock item and an out-of-stock item in the same order), and more scattered through the list — any item from the catalog showing `0` in the `in_stock` column is out of stock. The brief just says "handle back-ordered items sensibly," without saying whether to ship the available part now and hold back the rest, or hold the whole order together. A good build should pick one, say why, and apply it consistently.

**2. One order is empty — no items listed at all.**
**ORD-8046** has nothing in its items field. Does the app crash, silently create a blank/garbage record, or clearly flag "we can't process this, missing information"?

**3. A few orders are for the exact same low-stock item, arriving close together.**
**ORD-8061, ORD-8062, ORD-8063** all ask for the same low-stock coolant pump motor within a few minutes of each other. If the app doesn't carefully track what's already been promised to earlier orders, it risks promising the same limited stock to more than one customer.

**4. The really important thing to check isn't in the data — it's in the code.**
The brief asks for "error handling and retry" around actually dispatching an order. A very common shortcut is: if the dispatch call fails, just try again — without checking whether it actually failed, or whether it succeeded but the confirmation got lost (which would mean retrying ships the same order twice). Also check whether the app treats "this item is genuinely out of stock" the same as "this was just a temporary hiccup" — those should be handled differently; retrying an out-of-stock item forever doesn't help.

## What to check once the build is done

- Did the whole thing — checking inventory, reconciling the order, the auto-dispatch rule, retry/error handling, the review screen, saving to a database — actually get built in the time given?
- If a dispatch attempt fails and the app retries, could that risk shipping the same order twice?
- Does the app tell apart "this failed for good" (like: out of stock) from "this failed for now, try again" (like: a timeout)?
- Does the empty order (ORD-8046) get handled without crashing?
- Do the three near-simultaneous orders for the same scarce item (ORD-8061/8062/8063) get handled without over-promising stock that isn't there?

Write up what you find as a new section at the bottom of `../../grading/calibration-runs/T04-calibration-run.md`.
