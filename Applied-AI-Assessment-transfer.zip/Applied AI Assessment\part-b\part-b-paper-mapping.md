# Part B — Paper Mapping

**Launch set:** 12 problems across 6 papers, 2 per paper.
**Validation status:** all 12 pass the automated gate (`validation/harness.py`). Java and C# variants still require human review — see *What has and has not been machine-checked* below.

---

## Assembly constraints

Every paper must satisfy all four:

1. **One Medium + one High** — a single difficulty band across 2 questions cannot discriminate.
2. **One SQL-located + one host-located bug** — otherwise a candidate weak in SQL fails both questions on the same weakness, and mandatory-SQL-everywhere becomes a second hidden gate.
3. **No repeated bug pattern within a paper** — tests breadth rather than the same skill twice.
4. **No problem shared between papers** — a leak from an earlier slot cannot contaminate a later one.

---

## The 12 launch problems

| ID | Difficulty | Location | Bug pattern |
|---|---|---|---|
| P01 | Medium | SQL | `INNER JOIN` drops unmatched rows |
| P02 | Medium | SQL | `GROUP BY` at the wrong grain |
| P03 | Medium | SQL | Date boundary excludes the final day |
| P07 | Medium | host | Partial final batch discarded |
| P08 | Medium | host | Accumulator reset in the wrong scope |
| P09 | Medium | host | Integer division truncates a percentage |
| P13 | High | SQL | Aggregate filtered in `WHERE` instead of `HAVING` |
| P14 | High | SQL | Join fan-out double-counts an aggregate |
| P15 | High | SQL | `NOT IN` over a nullable column returns nothing |
| P19 | High | host | Pagination loop discards the last page |
| P20 | High | host | Cursor iterated twice; second pass is empty |
| P21 | High | host | Sort lacks a deterministic tiebreak |

Twelve distinct patterns across twelve problems — comfortably above the ≥10 requirement, and no pattern appears twice anywhere in the launch set.

---

## Paper assignments

| Paper | Question 1 | Question 2 | Difficulty | Location |
|---|---|---|---|---|
| **1** | P01 — chunk counts | P19 — paged export | M + H | SQL + host |
| **2** | P02 — token usage by model | P20 — usage summary | M + H | SQL + host |
| **3** | P03 — monthly ingestion | P21 — retrieval ranking | M + H | SQL + host |
| **4** | P07 — embedding batches | P13 — high-usage models | M + H | host + SQL |
| **5** | P08 — per-model totals | P14 — token and tag report | M + H | host + SQL |
| **6** | P09 — pipeline success rates | P15 — awaiting embedding | M + H | host + SQL |

Papers 1–3 open with the SQL-located bug; papers 4–6 open with the host-located one. This deliberate alternation means the *order* in which a candidate meets the two bug types is not constant across papers, so no single ordering advantage accrues to a particular slot.

### Balance check

| Property | Every paper | Verified |
|---|---|---|
| Medium questions | 1 | ✅ |
| High questions | 1 | ✅ |
| SQL-located bugs | 1 | ✅ |
| Host-located bugs | 1 | ✅ |
| Repeated pattern within a paper | 0 | ✅ |
| Problems shared with another paper | 0 | ✅ |

---

## Slot assignment — prefer per-candidate randomization

**Do not hard-map paper N to slot N if the platform offers anything better.**

Assigning one fixed paper per slot staggers leakage rather than preventing it. All six papers are burned by the end of Day 1, which systematically advantages Day 2 candidates, and it does nothing about collusion between candidates sitting the same room.

**Preferred:** randomize the paper per candidate from the pool of 6. A candidate who hears about a problem from an earlier sitting has only a 1-in-6 chance of meeting it.

**Fallback (fixed mapping), if per-candidate assignment is unsupported:**

| Day | Slot | Paper |
|---|---|---|
| 1 | Morning | 1 |
| 1 | Midday | 2 |
| 1 | Afternoon | 3 |
| 2 | Morning | 4 |
| 2 | Midday | 5 |
| 2 | Afternoon | 6 |

Under the fallback, run the leak check below between Day 1 and Day 2 — it is the only defence remaining.

Confirm platform capability via question 6 in [`hirepro-dependencies.md`](../hirepro-dependencies.md).

---

## Leak detection between days

After Day 1 closes and **before Day 2 opens**, compare per-problem solve rates across the three Day 1 slots.

A problem whose solve rate jumps sharply in a later slot — with no matching jump on the other problem in that paper — is the signature of a leak, not of a stronger cohort. Swap the affected problem for one from the contingency bank before Day 2.

This check is cheap and is the reason the contingency bank exists.

---

## Contingency bank — complete

Twelve further problems complete the 24-problem bank, holding the same 6/6/6/6 split. All pass the validation gate.

| ID | Difficulty | Location | Bug pattern |
|---|---|---|---|
| P04 | Medium | SQL | Equality comparison against `NULL` |
| P05 | Medium | SQL | Join emits duplicate rows (missing `DISTINCT`) |
| P06 | Medium | SQL | `AND` binds tighter than `OR` |
| P10 | Medium | host | Missing value treated as zero |
| P11 | Medium | host | Caught exception silently skips a row |
| P12 | Medium | host | Grouping key not normalised |
| P16 | High | SQL | Window function not partitioned |
| P17 | High | SQL | Subquery column silently bound to the outer table |
| P18 | High | SQL | Outer join downgraded by a `WHERE` clause |
| P22 | High | host | Map insert replaces instead of accumulating |
| P23 | High | host | Loop returns early instead of continuing |
| P24 | High | host | Exact equality on accumulated floating-point values |

**24 distinct bug patterns across 24 problems** — no pattern is used twice anywhere in the bank.

Purpose: immediate replacement for a leaked or defective problem mid-run, rotation stock so the next cycle does not reuse this cycle's papers, and slack if a problem fails peer review late.

### Substituting a contingency problem mid-run

Swap like for like, or the papers stop being comparable. A replacement must match the original's **difficulty and bug location**:

| If you must replace… | Draw from |
|---|---|
| A Medium SQL problem (P01–P03) | P04, P05, P06 |
| A Medium host problem (P07–P09) | P10, P11, P12 |
| A High SQL problem (P13–P15) | P16, P17, P18 |
| A High host problem (P19–P21) | P22, P23, P24 |

Also check the replacement's pattern does not duplicate the other question already in that paper.

### Full bank composition

| | Medium | High | Total |
|---|---|---|---|
| **SQL-located** | P01–P06 (6) | P13–P18 (6) | 12 |
| **Host-located** | P07–P12 (6) | P19–P24 (6) | 12 |
| **Total** | 12 | 12 | **24** |

---

## What has and has not been machine-checked

**Verified by execution** (`python validation/harness.py`):

- The reference solution passes every test case.
- The broken version fails every case marked *discriminator*.
- The broken version passes every case marked *guard* — proving breakage is specific to the intended bug rather than incidental.
- Every documented plausible-wrong-fix is caught by at least one case.

The gate has already earned its place. It caught three defects during authoring that reading the code would not have surfaced:

- **P03** documented `<=` on the next-month boundary as a wrong fix the suite catches. It is not — because `created_at` carries a time component, `'2024-04-01 00:00:00'` sorts after the bare string `'2024-04-01'`, making `<=` and `<` equivalent on any realistic row. The claim was removed.
- **P14** documented `SUM(DISTINCT ...)` as a trap. Every fixture happened to use distinct chunk sizes, so that fix silently passed the entire suite. A fixture with two equal-sized chunks was added, and it now fails as intended.
- **P06 was discarded and rewritten.** Its original bug was "`LIMIT` applied before `ORDER BY`" — a subquery with `LIMIT` wrapped by an outer `ORDER BY`. SQLite's query flattener removes the subquery and pushes the `ORDER BY` down, so the *broken* query returned the correct answer. The problem was unsound: candidates would have been asked to fix a query that already worked, and the hidden tests would have passed whether or not they changed anything. It was replaced with an `AND`/`OR` precedence bug, which is a semantic property no optimiser can rescue.

The third is the one to remember when authoring new problems: **a bug that depends on execution order rather than semantics may not survive the query planner.** Always confirm the broken version actually fails before writing the document.

**Not machine-checked — requires human review:**

- **Java and C# variants do not compile or run here** (no JDK or .NET SDK in the authoring environment). They are structurally parallel translations of the same query and algorithm, but compilation, translation fidelity, and idiom correctness are unverified.
- **Difficulty calibration.** Medium/High labels are authorial judgement, not measured.
- **Language parity.** The plan requires 2–3 engineers per language to attempt each problem, rejecting any variant more than 25% off the mean solve time. Nothing here substitutes for that.

Each problem file carries a reviewer checklist covering these.
