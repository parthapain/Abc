# P14 — Document token and tag report

| Field | Value |
|---|---|
| **ID** | P14 |
| **Difficulty** | High |
| **Bug pattern** | Join fan-out double-counts an aggregate |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Paper** | 5 (with P08) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A document catalogue shows, for each document, its total embedded token count and how many tags it carries.

Token totals are wrong — always too high, and always by a whole-number multiple. A document with two 100-token chunks and three tags reports 900 tokens instead of 300. Tag counts are correct.

### Required behaviour

Return `(title, total_tokens, tag_count)` for every document, ordered by `title` ascending.

- `total_tokens` is the sum of that document's chunk token counts, or `0` if it has no chunks.
- `tag_count` is how many tags the document has, or `0` if none.

Every document appears, whether or not it has chunks or tags.

### Schema

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE chunks (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    token_count INTEGER NOT NULL
);
CREATE TABLE tags (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    label       TEXT NOT NULL
);
```

---

## Fixture — `P14.sql`

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE chunks (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    token_count INTEGER NOT NULL
);
CREATE TABLE tags (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    label       TEXT NOT NULL
);

INSERT INTO documents (id, title) VALUES (1, 'Handbook');
INSERT INTO chunks (id, document_id, token_count) VALUES (1,1,100),(2,1,200);
INSERT INTO tags   (id, document_id, label)       VALUES (1,1,'hr'),(2,1,'policy'),(3,1,'2024');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def catalogue(db_path: str) -> List[Tuple[str, int, int]]:
    """
    Return (title, total_tokens, tag_count) for every document,
    ordered by title ascending. Documents with no chunks or no tags
    still appear, with zeros.
    """
    query = """
        SELECT d.title,
               COALESCE(SUM(c.token_count), 0) AS total_tokens,
               COUNT(DISTINCT t.id)            AS tag_count
        FROM documents d
        LEFT JOIN chunks c ON c.document_id = d.id
        LEFT JOIN tags   t ON t.document_id = d.id
        GROUP BY d.id, d.title
        ORDER BY d.title
    """
    conn = _connect(db_path)
    try:
        return [(title, tokens, tags) for title, tokens, tags in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class Catalogue {

    // --- boilerplate: do not modify ---
    public static class DocumentRow {
        public final String title;
        public final int totalTokens;
        public final int tagCount;

        public DocumentRow(String title, int totalTokens, int tagCount) {
            this.title = title;
            this.totalTokens = totalTokens;
            this.tagCount = tagCount;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (title, totalTokens, tagCount) for every document,
     * ordered by title ascending. Documents with no chunks or no tags
     * still appear, with zeros.
     */
    public static List<DocumentRow> catalogue(String dbPath) throws SQLException {
        String query =
            "SELECT d.title, " +
            "       COALESCE(SUM(c.token_count), 0) AS total_tokens, " +
            "       COUNT(DISTINCT t.id)            AS tag_count " +
            "FROM documents d " +
            "LEFT JOIN chunks c ON c.document_id = d.id " +
            "LEFT JOIN tags   t ON t.document_id = d.id " +
            "GROUP BY d.id, d.title " +
            "ORDER BY d.title";

        List<DocumentRow> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new DocumentRow(
                    rs.getString("title"),
                    rs.getInt("total_tokens"),
                    rs.getInt("tag_count")
                ));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record DocumentRow(string Title, int TotalTokens, int TagCount);

public static class Catalogue
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Title, TotalTokens, TagCount) for every document,
    /// ordered by title ascending. Documents with no chunks or no tags
    /// still appear, with zeros.
    /// </summary>
    public static List<DocumentRow> Build(string dbPath)
    {
        const string query = @"
            SELECT d.title                          AS Title,
                   COALESCE(SUM(c.token_count), 0)  AS TotalTokens,
                   COUNT(DISTINCT t.id)             AS TagCount
            FROM documents d
            LEFT JOIN chunks c ON c.document_id = d.id
            LEFT JOIN tags   t ON t.document_id = d.id
            GROUP BY d.id, d.title
            ORDER BY d.title";

        using var conn = Connect(dbPath);
        return conn.Query<DocumentRow>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 2 chunks (100, 200), 3 tags | `[("Handbook", 300, 3)]` | **Discriminator** — broken reports 900 |
| T2 | 2 chunks (100, 200), 1 tag | `[("Single Tag Doc", 300, 1)]` | Guard — one tag means no fan-out |
| T3 | 3 chunks (10, 20, 30), 2 tags | `[("Report", 60, 2)]` | **Discriminator** — broken reports 120 |
| T4 | 2 chunks, no tags | `[("Untagged", 300, 0)]` | Guard — a `LEFT JOIN` with no match yields one null row, so no fan-out |
| T5 | No chunks, no tags | `[("Empty Doc", 0, 0)]` | Guard |
| T6 | 2 chunks of **equal** size (150, 150), 2 tags | `[("Even Chunks", 300, 2)]` | **Discriminator** — broken reports 600; also the only case that catches `SUM(DISTINCT ...)` |

### Fixtures

```sql
-- T2
INSERT INTO documents (id, title) VALUES (1, 'Single Tag Doc');
INSERT INTO chunks (id, document_id, token_count) VALUES (1,1,100),(2,1,200);
INSERT INTO tags   (id, document_id, label)       VALUES (1,1,'only');

-- T3
INSERT INTO documents (id, title) VALUES (1, 'Report');
INSERT INTO chunks (id, document_id, token_count) VALUES (1,1,10),(2,1,20),(3,1,30);
INSERT INTO tags   (id, document_id, label)       VALUES (1,1,'a'),(2,1,'b');

-- T4
INSERT INTO documents (id, title) VALUES (1, 'Untagged');
INSERT INTO chunks (id, document_id, token_count) VALUES (1,1,100),(2,1,200);

-- T5
INSERT INTO documents (id, title) VALUES (1, 'Empty Doc');

-- T6
INSERT INTO documents (id, title) VALUES (1, 'Even Chunks');
INSERT INTO chunks (id, document_id, token_count) VALUES (1,1,150),(2,1,150);
INSERT INTO tags   (id, document_id, label)       VALUES (1,1,'a'),(2,1,'b');
```

---

## Reference solution

Aggregate each child table independently instead of joining both at once.

```diff
- SELECT d.title,
-        COALESCE(SUM(c.token_count), 0) AS total_tokens,
-        COUNT(DISTINCT t.id)            AS tag_count
- FROM documents d
- LEFT JOIN chunks c ON c.document_id = d.id
- LEFT JOIN tags   t ON t.document_id = d.id
- GROUP BY d.id, d.title
- ORDER BY d.title
+ SELECT d.title,
+        COALESCE((SELECT SUM(token_count) FROM chunks WHERE document_id = d.id), 0) AS total_tokens,
+        (SELECT COUNT(*) FROM tags WHERE document_id = d.id)                        AS tag_count
+ FROM documents d
+ ORDER BY d.title
```

A CTE-based rewrite that pre-aggregates `chunks` and `tags` separately, then joins the two summaries, is equally correct and should be accepted.

### Why

Joining a document to two independent child tables in one query produces the **cross product** of their rows. Two chunks and three tags give six rows, not five — and each chunk's `token_count` appears three times, once per tag. `SUM` faithfully adds all six values, so the total is inflated by exactly the number of tags.

`tag_count` escapes because it is already written as `COUNT(DISTINCT t.id)`, which collapses the duplicates. That asymmetry is the diagnostic clue: one aggregate over the fanned-out rows is protected and the other is not.

The multiplier is the number of rows in the *other* branch, which is why the error is always a clean whole-number multiple, and why it disappears whenever a document has exactly one tag (T2) or none at all (T4).

**Why `SUM(DISTINCT c.token_count)` is not the fix.** It appears to work on most data and is the most common wrong answer here. It deduplicates by *value*, not by row — so a document with two genuinely different 150-token chunks reports 150 instead of 300. T6 exists specifically to catch this.

> This trap was almost missed during authoring: every fixture originally used distinct chunk sizes, so `SUM(DISTINCT ...)` passed the entire suite. The validation harness flagged it, and T6 was added.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `SUM(DISTINCT c.token_count)` | T6 — reports 150 instead of 300 |
| Dividing the total by the tag count | T4, T5 — division by zero when there are no tags |
| Dropping the `tags` join and computing tag counts in host code | Acceptable if correct; verify against T4 and T5 |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T6
- [ ] Broken version **fails T1, T3 and T6**, and **passes T2, T4, T5**
- [ ] Failure is inflated token totals with correct tag counts, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] **T6 is present and uses equal chunk sizes** — without it `SUM(DISTINCT ...)` passes and the problem is unsound
- [ ] A correct CTE-based rewrite is accepted by the grader, not just the subquery form
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
