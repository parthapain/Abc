"""
Loads the three seed CSVs into the database and runs every request through the agent.

Usage:
    python ingest.py            # load + process (skips requests already in DB)
    python ingest.py --reset    # wipe the DB first, then load + process everything fresh
"""
import csv
import os
import sys

import db
import agent

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _read_csv(name):
    path = os.path.join(BASE_DIR, name)
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_reference_data():
    for row in _read_csv("booking_records.csv"):
        db.upsert_booking({
            "booking_ref": row["booking_ref"],
            "customer_name": row["customer_name"],
            "flight_route": row["flight_route"],
            "verified_category": row["verified_category"],
            "ticket_value": float(row["ticket_value"]),
            "credit_eligible": 1 if row["credit_eligible"].strip().lower() == "true" else 0,
            "credit_value": float(row["credit_value"]),
        })

    for row in _read_csv("rebooking_history.csv"):
        db.upsert_rebooking_history(row["customer_name"], int(row["rebookings_last_30_days"]))


def load_and_process_requests():
    rows = _read_csv("flight_requests.csv")
    for row in rows:
        req = {
            "request_id": row["request_id"],
            "customer_name": row["customer_name"],
            "customer_tier": row["customer_tier"],
            "booking_ref": row["booking_ref"],
            "submitted_at": row["submitted_at"],
            "request_text": row["request_text"],
        }
        existing = db.get_request(req["request_id"])
        if existing is not None:
            continue  # already ingested; don't reprocess (agent decisions shouldn't churn on re-run)
        db.insert_request(req)
        result = agent.process_request(req)
        print(f"{req['request_id']}: {result['status']}" + (f" ({'; '.join(result['reasons'])})" if result['reasons'] else ""))


def main():
    reset = "--reset" in sys.argv
    db.init_db(reset=reset)
    load_reference_data()
    load_and_process_requests()


if __name__ == "__main__":
    main()
