# Human-Build Instances — Calibration Step 4

**⚠️ Superseded by Addendum 20 (`../../design-rationale.md`):** these 4 instances (1 ambiguity, 1 guardrailed action each) were built against the shape every template used to require. Every template now requires 2 ambiguities and 2 independently-guardrailed actions by default — see `../human-build-instances-harder/` (also superseded as a separate "harder" tier, but its content is the closer match to the current default shape) and the 4 template docs in `../../templates/`. Kept here as an accurate historical record.

**Purpose:** every template's Calibration section (see `../../templates/T0{1,2,3,4}-*.md`) has three steps confirmed by dry-run (trap reproduces, ambiguity is genuinely two-way, guardrail-default trap reproduces) and one step still outstanding everywhere: **an actual timed human build.** This folder is that step — one concrete, ready-to-hand-to-a-person instance per template, generated the same way a real candidate's instance would be, so the timed build is a real test of the mandatory scope (agentic loop + tools + guardrail + ambiguity + trap + stress point, all at once), not a dry run of code someone already knows the punchline to.

**T01 goes first, and its result gates the rest** — see `../architecture.md`'s sequencing note. If T01's build blows the 24–48hr estimate, that's a scope problem affecting all four templates equally, and it's cheaper to find that out once than after all four have been built.

## What's in each instance folder

- `brief.md` — the exact candidate-facing brief. **This is the only thing to hand to the person doing the build.**
- one or more seed-dataset files — the data the brief's `$dataset_file` line refers to.
- `INTERNAL-metadata.md` — which ambiguity/trap/stress-point variant this instance carries, and what to check for afterward. **Never share this with whoever does the build** — it would defeat the point of testing whether the trap is discoverable unprompted, the same evidence-discipline reason it's never shown to a real candidate.

## Instance-to-calibration-run mapping

Each instance deliberately reuses the same domain flavor, ambiguity phrasing, and trap variant already exercised in that template's dry-run calibration (`../../grading/calibration-runs/T0{1,2,3,4}-calibration-run.md`), and adds a stress-point variant the dry-runs didn't get to (each dry-run explicitly left the stress point "not exercised"). This makes the human build a direct extension of the existing dry-run evidence, not a fresh, unrelated test — if the human's natural build reproduces the same trap/guardrail findings the simulated dry-run predicted, that's a real, independent confirmation; if it doesn't, that's worth knowing before trusting the dry-run findings any further.

| Instance | Domain flavor | Ambiguity | Trap | Stress point (new this run) |
|---|---|---|---|---|
| T01 | Support tickets | Phrasing #1 (prioritize appropriately) | Variant #1 (silent fallback classification) | Variant #1 (blank/empty body) |
| T02 | Insurance policy documents | Phrasing #3 (relative date resolution) | Variant #1 (hallucinated absent field) | Variant #2 (concatenated documents) |
| T03 | Warranty claims | Phrasing #3 (value threshold) | Variant #3 (inflated/unverified amount in request text) | Variant #3 (burst of near-duplicate requests) |
| T04 | Spare-parts orders | Phrasing #2 (back-ordered handling) | Variants #1–#3 (blind retry / permanent-vs-transient / no send-vs-lost-response distinction — confirmed to reproduce together from one natural prompt) | Variant #4 (malformed/incomplete order) |

## Running the build

1. Give the person **only** `brief.md` and the seed dataset(s) — nothing from `INTERNAL-metadata.md`, and don't mention that a specific trap or guardrail flaw is planted. The whole point is to see what a normal, un-primed build produces.
2. Start a real clock. Target 24–48 hours of actual working time (not wall-clock — note both if they're spread out).
3. Ask for the same submission shape a real candidate would give: a zip (or repo) with a `MANIFEST.md` pointing to the agentic/orchestration logic, tool definitions, guardrail check, and persistence code, plus the ~half-page written rationale.
4. When it's done, don't grade it yourself first — that's what the AI grader and the calibration-process exercise are for. Instead, check the four things the template's Calibration section says step 4 needs to confirm:
   - Did the mandatory scope (agentic loop + tools + context management + guardrail, on top of ambiguity/trap/stress-point) actually fit in the time given?
   - Did the trap reproduce the way the dry-run predicted, or differently, or not at all?
   - Did the guardrail-default finding from the dry-run show up in independently-written code too?
   - Did the planted stress point get handled, ignored, or cause a crash?
5. Record the result as a new "Human Build" section appended to that template's `../../grading/calibration-runs/T0{n}-calibration-run.md` (same pattern as each file's existing "Calibration Run #2" section), and update the template's own Status line and the generator's sequencing note once T01's result is in.

## A filename spoiler caught and fixed

T02's seed dataset files were originally named to describe the planted issue directly — e.g. `POL-3005-AND-3006-CONCATENATED.txt` for a stress-point document containing two policies pasted together. That's a spoiler even though it's not brief text: a candidate browsing the dataset folder would see the filename before opening the file, which hands them the answer to the exact thing being tested (whether the app notices and correctly splits a multi-document file). Filenames across both `T02-insurance-policies/` and `T02-loan-agreements/` (standard and harder sets) have been renamed to a neutral ID-pair scheme (`POL-3005-3006.txt`) that stays traceable for `INTERNAL-metadata.md` but is silent on the mechanism. The corresponding `INTERNAL-metadata.md` citations were updated to match. This rule — dataset filenames held to the same no-spoiler standard as brief prose — is now locked into `level2-use-case-generator.md`.

## A known gap this surfaced

`generate_instances.py` / `template_definitions.py` are **stale** — they only define T01/T02, and in their pre-rework, single-shot form (no agentic loop, no tools, no guardrail), plus a candidate disclosure line about interaction logging that's since been confirmed false and removed (see `../../dependencies/llm-gateway-logging.md`). These 4 instances were hand-assembled directly from the current, correct template files (`../../templates/T0{1,2,3,4}-*.md`) rather than through that script, since running it as-is would produce briefs that don't match any current design decision. The script and its template data need a rewrite to match the current mandatory agentic/tool/guardrail shape for all 4 templates before it's used for real 300+-scale generation — flagged here rather than fixed now, since it wasn't blocking these 4 one-off instances.
