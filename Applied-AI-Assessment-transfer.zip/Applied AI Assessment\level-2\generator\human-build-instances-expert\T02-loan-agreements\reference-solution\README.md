# Reference solution — T02 expert-tier, Commercial Loan Agreement Extraction

Run `python verify.py` from this directory. All 26 checks pass.

## What verify.py confirms

- All 11 primary loan agreements are discovered, including the two concatenated in `LN-7006-7007.txt`.
- The two base-template ambiguities (borrower-name normalization, relative-date resolution) both resolve, and the "no safe default" divergence pair (LN-7001 local vs. LN-7002 external lookup) both come out correct.
- Expert element 1: an ambiguous cross-document reference (LN-7004, two candidate Promissory Notes) is flagged, not silently resolved.
- Expert element 2: that same ambiguous field correctly withholds auto-commit — the coupling actually holds, not just a cosmetic flag.
- The base-template trap (LN-7005, absent interest_rate) is reported as missing, never invented.
- Expert element 4: an adversarial tool response (LN-7010's `verify_against_source` claiming grounded with no matched text) is not trusted at face value.
- The second guardrail (status-gated follow-up generation) is tested in all required directions: confirmed active, refinanced, paid off, and status not found at all.
- Expert elements 3 & 5: the follow-up-generation call is retry-safe (a forced lost-response retry produces exactly one record), and the idempotency-cache-hit path ignores a status change that happens between the original call and the retry.
- Addendum 31, guardrail independence: LN-7005 fails the commit guardrail (missing interest_rate) but still gets its maturity follow-up evaluated and generated independently.

## Key decisions

- **Borrower-name normalization (`USE_FIRST_DEFINED_BORROWER_NAME = True`, `orchestrator.py`):** when a document's recitals and its own signature block name the borrower differently, this solution trusts the recitals' spelling — the name the agreement itself defines the borrower by — over whichever form appears later. Either reading is defensible; what matters is that it's a named, isolated, one-line decision, not an accident of which mention the code happened to grab.
- **Relative-date resolution:** `_resolve_maturity()` checks whether the maturity clause is self-contained (a months-after-Closing-Date computation, with the Closing Date stated in the same document) before ever calling `lookup_related_document`. Only when the clause points outward with no local basis does it call the lookup tool — and if the lookup finds more than one candidate note for that borrower, it returns AMBIGUOUS rather than guessing.
- **Back-order-style composition mapping equivalent:** not applicable to this template — T02's two-guardrail shape doesn't have a direct back-order analog. The "no safe default" construction rule is instead satisfied by the local-vs-lookup maturity-date pair (LN-7001/LN-7002), which is the objectively-resolvable flavor of Addendum 24, and the borrower-name divergence (LN-7003), which is the no-right-answer flavor.
- **Adversarial tool response (element 4):** implemented directly in the mock `verify_against_source` (`extraction_tools.py`) rather than a CSV row, since the inconsistency is in a tool's *response shape* (a claimed grounding with no supporting text), not in seed data a candidate would read directly.
- **Idempotency + stale-status collision (elements 3 & 5):** `generate_followup()`'s idempotency cache check happens before anything else in the function — a cache hit returns immediately, without ever consulting the live status. The orchestrator's `process_followup()` checks status exactly once, before entering the retry loop, and never re-checks it on a retry — the retry loop only re-invokes the (already idempotency-protected) client call.
