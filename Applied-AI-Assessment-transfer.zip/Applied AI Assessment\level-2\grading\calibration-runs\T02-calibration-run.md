# T02 Calibration Run #1

Per `../../templates/T02-structured-extraction.md`'s Calibration section. **This is a parallel dry-run of steps 1–3, not a jump ahead of the sequencing rule** — T01's step 4 (an actual timed human build) is still outstanding, and nothing here counts as "T02 calibrated and safe to generate instances from." That gate still waits on T01, per `../../generator/architecture.md`'s sequencing note. What this run *does* establish: whether T02's trap, ambiguity, and guardrail hold up the same way T01's did, and whether the same compounding-failure pattern shows up here too — flagged as worth checking in T01's own calibration run.

**Instance used for this run:** domain flavor = insurance policy documents; ambiguity phrasing #3 (coverage end date stated by reference to another clause); trap variant #1 (LLM invents a plausible value for a genuinely absent field); stress-point variant #3 (garbled OCR text) — not exercised in this run, see Open Items.

**Method:** same as T01 — simulate the natural, incremental way a candidate would prompt a coding assistant, without mentioning the trap, and inspect the result.

---

## Step 1 — does the AI-trap reproduce?

**Prompt given (simulating the candidate):** *"Write a function that extracts these fields from a document using our LLM client `llm.complete(prompt)`: policy_number, policyholder_name, coverage_start_date, coverage_end_date, premium_amount."*

**Naive output:**
```python
def extract_fields(document_text: str) -> dict:
    prompt = f"""Extract the following fields from this document:
policy_number, policyholder_name, coverage_start_date, coverage_end_date, premium_amount

Document: {document_text}

Respond in JSON: {{"policy_number": "...", "policyholder_name": "...",
"coverage_start_date": "...", "coverage_end_date": "...",
"premium_amount": "...", "confidence": 0.0-1.0}}"""
    response = llm.complete(prompt)
    return json.loads(response)
```

**Tested against a document with no stated premium amount.** As expected for an LLM asked to fill a JSON schema with no explicit "say so if absent" instruction: it returns a plausible-looking number rather than a null/absent marker. **Verdict: trap reproduces exactly as described** — nothing in this natural first draft distinguishes "extracted" from "invented."

## Step 2 — is the ambiguity genuinely two-way?

Phrasing #3: *"Extract the coverage end date"* — tested against a sample document stating "coverage ends 12 months after the coverage start date" with no explicit end date. Two reasonable engineers plausibly differ: store the relative statement and compute the date at read-time (avoids drift if the start date is later corrected), vs. resolve to an absolute date at extraction time (simpler downstream, but stale if the start date changes later). **Confirmed genuinely two-way.**

## Step 3 — does the guardrail-default trap reproduce?

**Follow-up prompt:** *"Now make this agentic: call `verify_against_source(document_id, field, value)` to cross-check each extracted value against the source text, and call `lookup_related_document(reference)` when a value depends on another document. Then decide: if every field is fully verified, auto-commit the record via `commit_record(document_id, fields)`; otherwise flag for human review."*

**Naive output:**
```python
def process_document(document_id: str, document_text: str) -> dict:
    fields = extract_fields(document_text)

    verification_results = {}
    for field, value in fields.items():
        if field == "confidence":
            continue
        verification_results[field] = verify_against_source(document_id, field, value)

    all_verified = all(v.get("grounded", True) for v in verification_results.values())

    if all_verified and fields.get("confidence", 1.0) >= 0.8:
        commit_record(document_id, fields)
        return {"action": "auto_committed", "fields": fields}
    else:
        return {"action": "flagged_for_review", "fields": fields}


def verify_against_source(document_id: str, field: str, value: str) -> dict:
    document_text = get_document_text(document_id)
    try:
        prompt = f"""Does the following document support the value '{value}' for field '{field}'?
Document: {document_text}
Respond in JSON: {{"grounded": true/false, "reasoning": "..."}}"""
        response = llm.complete(prompt)
        return json.loads(response)
    except Exception as e:
        logger.error(f"Verification failed: {e}")
        return {}
```

**Verdict: reproduces, and the same compounding pattern found in T01 shows up here too — in a slightly different, arguably worse spot.**

1. **`all(v.get("grounded", True) ...)` defaults to treating an unverified field as grounded** — the exact same default-to-safe pattern from T01's `confidence` gap, just on a `grounded` key instead.
2. **The gap is one layer deeper than T01's:** here it's not the *extraction* call's failure handling that creates the hole — extraction has no try/except in this draft — it's the **verification tool's own** error handling. When `verify_against_source` hits any exception (a malformed LLM response, a timeout), it naturally returns `{}` rather than re-raising or returning an explicit failure marker. The caller's `.get("grounded", True)` then reads that empty dict as "grounded." **A hallucinated field that happens to trigger a verification-tool hiccup gets auto-committed precisely because verification failed to run — the opposite of what "verified" is supposed to mean.**
3. Secondary, lower-confidence risk worth flagging but not confirmed here: even when `verify_against_source` runs successfully, it's an LLM asking an LLM "does the document support this value" — a verifier prompted this way can be swayed by how confidently the extractor's value is phrased (a mild form of the same over-trust the whole assessment is designed to probe). Not confirmed by this run; flagged for a future run if it's worth a dedicated check.

**Recommendation:** same as T01 — fold the compounding finding into T02's reference solution and guardrail notes explicitly, since "verification-tool failure defaults to grounded" is a more specific, checkable claim than "a naive guardrail might not check verification properly."

## Step 4 — timeboxed build check

**Not done, and not attempted in this run** — T02's own timed build is second in the queue behind T01's (see sequencing note); running it before T01's is settled would tell us little, since T01's result is what determines whether the mandatory scope is even viable in 24–48hrs at all. No estimate is given here beyond noting T02's scope (extraction + 2 tools + guardrail + review UI + persistence) is comparable in size to T01's.

---

## Overall verdict

| Step | Result |
|---|---|
| 1. Trap reproduces | ✅ Confirmed |
| 2. Ambiguity genuinely two-way | ✅ Confirmed |
| 3. Guardrail-default trap reproduces | ✅ Confirmed — same compounding pattern as T01, this time via the verification tool's own error handling rather than the extraction call's |
| 4. Timeboxed build | ⏳ Not attempted — waits on T01's result |

**T02 is not calibrated** — 3 of 4 steps have real supporting evidence from this dry-run, but calibration isn't official until T01's step 4 clears and T02 gets its own timed build. This run's purpose was narrower: confirm the trap/ambiguity/guardrail hold up, and check for T01's compounding-failure pattern specifically — both came back positive.

## Follow-up actions this run identified

1. Fold the "verification-tool failure defaults to grounded" finding into T02's reference solution and AI-trap/guardrail notes, same as done for T01.
2. When T01's step 4 clears and T02's own timed build runs, re-check whether the LLM-verifying-LLM sycophancy risk (step 3's secondary note) is worth a dedicated fourth trap variant in a future revision — not urgent, not confirmed, just flagged.
3. Once both T01 and T02 are fully calibrated, check T03 and T04 for the same pattern — any place a tool's own failure path defaults to a permissive value is a candidate for the same class of bug (T03's `check_request_eligibility` and T04's `dispatch_fulfillment` both have an analogous shape).

---

## Calibration Run #2 — post-split re-validation (2026-09-12)

**Purpose:** same as T01's Run #2 (see `../calibration-runs/T01-calibration-run.md`) — confirm run #1's findings still hold as evidence after the rubric's Dimension 1 split, and resolve the new dimension/cap mapping. The same three prompts from run #1 were re-run verbatim; output is identical, since the split changes grading structure, not the brief or the trap. See run #1 above for the code.

**Dimension mapping, resolved:**
- Step 1's trap finding (LLM invents a plausible value for a genuinely absent field) → **Dimension 4** (was Dimension 3). Unchanged.
- Step 2's ambiguity finding (phrasing #3, relative-vs-absolute date resolution) → **Dimension 3** (was Dimension 2). Unchanged.
- Step 3's guardrail-compounding finding (`v.get("grounded", True)` on an empty dict returned by `verify_against_source`'s own exception handler) → **Dimension 2** (was folded into the old Dimension 1). **Confirmed this caps Dimension 2 at 1**, same reasoning as T01: the guardrail's check (`all_verified`) reads a verification-tool failure as success, which is functionally no gate at all on that failure path — not a case of "checks something, just weakly," since nothing about the actual grounding was ever confirmed.

**Anything new this pass surfaced:** no new code-level finding. Confirms the same gated-decision-vs-gated-parameter distinction settled in T01/T03/T04's Run #2 entries doesn't change T02's classification — T02's issue is a missing-field default (cap-1 per the recurring-pattern language already in `../../rubric.md` §2), not a gated-decision/ungated-parameter case like T03's.

**Verdict: T02's calibration status is unchanged.** 3 of 4 steps remain confirmed under the new numbering with no change in severity; step 4 remains blocked behind T01's, per the sequencing rule (unaffected by the rubric split).

---

## Calibration Run #3 — Addendum 20 second-guardrail dry-run (2026-09-13)

**Purpose:** T02's brief now requires a second, independent guardrailed action (an auto-generated renewal reminder gated on `renewal_status.csv`, see `../../templates/T02-structured-extraction.md`'s "Second guardrail" note). Dry-testing that specific addition.

**Prompt given (simulating the candidate):** *"For policies confirmed to be within 30 days of coverage_end_date, check the policy's current renewal/cancellation status via `check_renewal_status(policy_number)`, and if it's still active, auto-generate a renewal reminder via `generate_renewal_reminder(policy_number)`."*

**Naive output:**
```python
def check_renewal_status(policy_number: str):
    row = renewal_df[renewal_df["policy_number"] == policy_number]
    if row.empty:
        return None
    return row.iloc[0]["status"]

def maybe_generate_reminder(policy_number, coverage_end_date):
    if not within_30_days(coverage_end_date):
        return None
    status = check_renewal_status(policy_number)
    if status != "renewed" and status != "cancelled":
        generate_renewal_reminder(policy_number)
        return {"action": "reminder_generated"}
    return {"action": "skipped", "status": status}
```

**Verdict: confirmed exactly as hypothesized in the template.** Writing "still active" as a double-negative ("not renewed and not cancelled") rather than a positive check ("== active") is the natural way an assistant translates this requirement — and it means a **missing/unmatched status lookup returns `None`, and `None != "renewed" and None != "cancelled"` evaluates to `True`.** A policy that isn't found in `renewal_status.csv` at all (a data gap, a typo'd policy number) is silently treated as "still active" and gets a reminder generated, when the real status is actually unknown — the exact permissive-default-on-missing-lookup shape found repeatedly elsewhere in this project, reproducing here on a brand-new guardrail exactly as predicted.

**Ambiguity check (brief):** the second phrasing paired with this guardrail (policyholder full-name vs. shortened-name recognition, pool item #2) was re-tested against a full-name/short-name pair from the actual harder dataset (POL-4001/4002-style) — normalize-to-canonical-form vs. treat-as-distinct-unless-proven-same are both defensible. **Confirmed genuinely two-way.**

**T02's second guardrail is dry-run confirmed, not yet independently verified against a live AI assistant** — still needs a real model run before this template is trusted at the new shape.
