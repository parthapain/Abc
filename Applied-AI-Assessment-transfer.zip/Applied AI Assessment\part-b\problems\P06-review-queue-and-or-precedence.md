# P06 — Documents needing review

| Field | Value |
|---|---|
| **ID** | P06 |
| **Difficulty** | Medium |
| **Bug pattern** | `AND` binds tighter than `OR` |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

> **Authoring note.** This slot originally held a "`LIMIT` applied before `ORDER BY`" bug — a subquery with `LIMIT` wrapped by an outer `ORDER BY`. It was **discarded**: SQLite's query flattener removes the subquery and pushes the `ORDER BY` down, so the supposedly broken query returned the correct answer and the bug could not be reproduced at all. Operator precedence is a semantic property of the expression, so no optimiser can rescue it. See the paper mapping for how this was caught.

---

## Candidate-facing brief

### Scenario

A review queue shows the platform team's documents that are either in `draft` or awaiting `review`.

The queue is showing drafts belonging to **other teams**. Review items are correct; only drafts leak.

### Required behaviour

Return the `title` of every document that:

- has a status of `'draft'` **or** `'review'`, **and**
- belongs to the `'platform'` team,

ordered by `title` ascending.

### Schema

```sql
CREATE TABLE documents (
    id     INTEGER PRIMARY KEY,
    title  TEXT NOT NULL,
    status TEXT NOT NULL,   -- 'draft' | 'review' | 'published' | 'archived'
    team   TEXT NOT NULL
);
```

---

## Fixture — `P06.sql`

```sql
CREATE TABLE documents (
    id     INTEGER PRIMARY KEY,
    title  TEXT NOT NULL,
    status TEXT NOT NULL,
    team   TEXT NOT NULL
);

INSERT INTO documents (id, title, status, team) VALUES
    (1,'A','draft', 'platform'),
    (2,'B','review','platform'),
    (3,'C','draft', 'research');   -- another team's draft: must not appear
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def review_queue(db_path: str) -> List[str]:
    """
    Return titles of documents that are in draft OR review status,
    AND belong to the 'platform' team, ordered by title ascending.
    """
    query = """
        SELECT title
        FROM documents
        WHERE status = 'draft' OR status = 'review' AND team = 'platform'
        ORDER BY title
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class ReviewQueue {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return titles of documents that are in draft OR review status,
     * AND belong to the 'platform' team, ordered by title ascending.
     */
    public static List<String> reviewQueue(String dbPath) throws SQLException {
        String query =
            "SELECT title " +
            "FROM documents " +
            "WHERE status = 'draft' OR status = 'review' AND team = 'platform' " +
            "ORDER BY title";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(rs.getString("title"));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class ReviewQueue
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return titles of documents that are in draft OR review status,
    /// AND belong to the 'platform' team, ordered by title ascending.
    /// </summary>
    public static List<string> Build(string dbPath)
    {
        const string query = @"
            SELECT title
            FROM documents
            WHERE status = 'draft' OR status = 'review' AND team = 'platform'
            ORDER BY title";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | Platform draft, platform review, research draft | `["A", "B"]` | **Discriminator** — broken also returns `C` |
| T2 | Every document belongs to `platform` | `["A", "B"]` | Guard — team filter is vacuous, so precedence cannot matter |
| T3 | A single draft belonging to `research` | `[]` | **Discriminator** — broken returns it |
| T4 | Two reviews, one per team, no drafts anywhere | `["A"]` | Guard — with no drafts, both groupings agree |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO documents (id, title, status, team) VALUES
    (1,'A','draft','platform'),(2,'B','review','platform'),(3,'C','archived','platform');
-- T3
INSERT INTO documents (id, title, status, team) VALUES (1,'X','draft','research');
-- T4
INSERT INTO documents (id, title, status, team) VALUES
    (1,'A','review','platform'),(2,'B','review','research');
```

---

## Reference solution

Bracket the two status alternatives so the team filter applies to both.

```diff
- WHERE status = 'draft' OR status = 'review' AND team = 'platform'
+ WHERE (status = 'draft' OR status = 'review') AND team = 'platform'
```

`WHERE status IN ('draft','review') AND team = 'platform'` is equally correct and arguably clearer.

### Why

`AND` binds more tightly than `OR`, so the original parses as:

```sql
status = 'draft' OR (status = 'review' AND team = 'platform')
```

The team restriction attaches only to the `review` branch. Every draft in the organisation qualifies through the unguarded left-hand side, which is precisely the reported symptom: reviews are correct, drafts leak.

The two guard cases show why this survives testing. When every row belongs to the target team (T2) the restriction is vacuous and both readings agree; when there are no drafts at all (T4) the unguarded branch never fires. A fixture that happens to be single-team or review-only will pass a buggy query.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Bracketing the `AND` instead — `draft OR (review AND platform)` | T1, T3 — this *is* the original precedence, written explicitly |
| `status IN ('draft','review')` but dropping the team filter | T1, T3 — other teams' documents still appear |
| Adding a second `AND team = 'platform'` to only one branch | T1, T3 |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is extra rows, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Both the parenthesised and `IN (...)` fixes are accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
