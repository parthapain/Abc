import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import db  # noqa: E402


@pytest.fixture(autouse=True)
def isolated_db(monkeypatch, tmp_path):
    """Point db.DB_PATH at a throwaway file for every test so tests never touch the
    real flight_credits.db built from the seed CSVs."""
    test_db_path = os.path.join(tmp_path, "test.db")
    monkeypatch.setattr(db, "DB_PATH", test_db_path)
    db.init_db(reset=True)
    yield
    if os.path.exists(test_db_path):
        os.remove(test_db_path)
