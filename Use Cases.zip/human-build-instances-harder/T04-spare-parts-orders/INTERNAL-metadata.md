# Internal notes — T04 harder variant (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app.

**What's different from the standard version:** this brief asks for two underspecified things instead of one (catalog reconciliation, and back-order handling), and it asks for a second, separate autonomous action — auto-rerouting a line item to an alternate warehouse — with its own gate based on real alternate-stock and shipping-cost data.

## What's tricky about this dataset, in plain terms

**1. Two things are left vague on purpose: how to reconcile fuzzy catalog matches, and how to handle back-ordered items.**
A good build's written notes should pick specific answers for both, tied to something real in this data.

**2. The new second autonomous action is the main thing to watch — three orders test three different outcomes.**
Check `alt_warehouse_inventory.csv` alongside these:
- **ORD-9011**: the item is out of stock at the main warehouse, but the alternate warehouse has 12 in stock and shipping only costs $8. This one **should** get auto-rerouted.
- **ORD-9012**: also out of stock, and the alternate warehouse does have some — but shipping from there costs $95, more than a sensible threshold. This one should **not** auto-reroute; it should escalate instead.
- **ORD-9013**: out of stock everywhere, including the alternate warehouse (0 there too). This one should **not** auto-reroute either — there's nothing to reroute to.
A weak build might reroute an order just because *an* alternate-warehouse row exists, without actually checking the stock number or the shipping cost in it.

**3. Watch for the two autonomous actions getting mixed up.**
The brief asks for two separate gates: one for the usual auto-dispatch (step 6), and a separate one for auto-rerouting to an alternate warehouse (step 7). Make sure both exist independently.

**4. The usual issues are still here too**:
- **ORD-9014** mixes an in-stock item with an out-of-stock one in the same order (tests the back-order-handling ambiguity directly).
- **ORD-9015** has no items listed at all (malformed).
- **ORD-9016, ORD-9017, ORD-9018** are three orders for the same scarce item arriving close together.

## What to check once the build is done

- Are there genuinely *two* separate gated actions (auto-dispatch, and alternate-warehouse reroute), or did the build collapse them into one?
- Does the reroute action check both the alternate stock number *and* the shipping cost before firing?
- Do ORD-9012 (too costly) and ORD-9013 (also unavailable) correctly get escalated instead of auto-rerouted?
- Is the mixed-availability order (ORD-9014) handled deliberately, with the reasoning written down?
- Does the empty order (ORD-9015) get handled without crashing?
- Did everything — two ambiguities, two guardrails, real retry/reliability handling, the usual tools and review UI — actually fit in the time given?

Write up what you find as a new file, `T04-harder-build-run.md`, next to the standard version's calibration-run file.
