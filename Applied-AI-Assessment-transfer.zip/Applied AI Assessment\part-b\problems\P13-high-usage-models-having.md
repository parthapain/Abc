# P13 — High-usage models

| Field | Value |
|---|---|
| **ID** | P13 |
| **Difficulty** | High |
| **Bug pattern** | Aggregate filtered in `WHERE` instead of `HAVING` |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 13–17 min |
| **Paper** | 4 (with P07) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A capacity review flags models whose **total** token consumption exceeds 1,000, so the platform team knows where to negotiate quota.

The report is missing models the team knows are heavy users. The pattern: models that make a large number of small requests never appear, while models that make a few large ones do.

### Required behaviour

Return `(model_name, total_tokens)` for every model whose **total** token consumption across all its requests exceeds 1,000, ordered by `model_name` ascending.

The threshold applies to the model's total, not to any individual request.

### Schema

```sql
CREATE TABLE model_requests (
    id          INTEGER PRIMARY KEY,
    model_name  TEXT NOT NULL,
    token_count INTEGER NOT NULL
);
```

---

## Fixture — `P13.sql`

```sql
CREATE TABLE model_requests (
    id          INTEGER PRIMARY KEY,
    model_name  TEXT NOT NULL,
    token_count INTEGER NOT NULL
);

INSERT INTO model_requests (id, model_name, token_count) VALUES
    (1,'big-model',   1500),   -- one large request
    (2,'small-model',  400),   -- five small requests totalling 2000,
    (3,'small-model',  400),   -- none individually over the threshold
    (4,'small-model',  400),
    (5,'small-model',  400),
    (6,'small-model',  400);
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def high_usage_models(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (model_name, total_tokens) for models whose TOTAL token
    consumption exceeds 1000, ordered by model_name ascending.
    """
    query = """
        SELECT model_name, SUM(token_count) AS total_tokens
        FROM model_requests
        WHERE token_count > 1000
        GROUP BY model_name
        ORDER BY model_name
    """
    conn = _connect(db_path)
    try:
        return [(name, total) for name, total in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class CapacityReport {

    // --- boilerplate: do not modify ---
    public static class ModelUsage {
        public final String modelName;
        public final int totalTokens;

        public ModelUsage(String modelName, int totalTokens) {
            this.modelName = modelName;
            this.totalTokens = totalTokens;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (modelName, totalTokens) for models whose TOTAL token
     * consumption exceeds 1000, ordered by modelName ascending.
     */
    public static List<ModelUsage> highUsageModels(String dbPath) throws SQLException {
        String query =
            "SELECT model_name, SUM(token_count) AS total_tokens " +
            "FROM model_requests " +
            "WHERE token_count > 1000 " +
            "GROUP BY model_name " +
            "ORDER BY model_name";

        List<ModelUsage> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new ModelUsage(
                    rs.getString("model_name"),
                    rs.getInt("total_tokens")
                ));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record ModelUsage(string ModelName, int TotalTokens);

public static class CapacityReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (ModelName, TotalTokens) for models whose TOTAL token
    /// consumption exceeds 1000, ordered by ModelName ascending.
    /// </summary>
    public static List<ModelUsage> HighUsageModels(string dbPath)
    {
        const string query = @"
            SELECT model_name AS ModelName, SUM(token_count) AS TotalTokens
            FROM model_requests
            WHERE token_count > 1000
            GROUP BY model_name
            ORDER BY model_name";

        using var conn = Connect(dbPath);
        return conn.Query<ModelUsage>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `P13.sql` above | `[("big-model", 1500), ("small-model", 2000)]` | **Discriminator** — broken omits `small-model` entirely |
| T2 | `alpha` 1200+1300, `beta` 2000 — every row individually over 1000 | `[("alpha", 2500), ("beta", 2000)]` | Guard — filter and threshold coincide, both versions agree |
| T3 | `gamma`: three requests of 400 (total 1200) | `[("gamma", 1200)]` | **Discriminator** — broken returns `[]` |
| T4 | `tiny`: 100 + 200 (total 300) | `[]` | Guard — genuinely below threshold either way |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO model_requests (id, model_name, token_count) VALUES
    (1,'alpha',1200),(2,'alpha',1300),(3,'beta',2000);
-- T3
INSERT INTO model_requests (id, model_name, token_count) VALUES
    (1,'gamma',400),(2,'gamma',400),(3,'gamma',400);
-- T4
INSERT INTO model_requests (id, model_name, token_count) VALUES
    (1,'tiny',100),(2,'tiny',200);
```

---

## Reference solution

Move the threshold from a row filter to a group filter.

```diff
  SELECT model_name, SUM(token_count) AS total_tokens
  FROM model_requests
- WHERE token_count > 1000
  GROUP BY model_name
+ HAVING SUM(token_count) > 1000
  ORDER BY model_name
```

### Why

`WHERE` is evaluated **before** rows are grouped, so `token_count > 1000` discards individual requests, not models. Two things then go wrong at once:

1. A model whose requests are each under the threshold has every row discarded, so it forms no group at all and vanishes from the report — even when its total is far above 1,000.
2. For models that do survive, the reported total is computed only over the rows that passed the filter, so it understates their actual usage.

`HAVING` is evaluated **after** grouping, which is the only place a condition on `SUM(...)` can be expressed. The requirement is a statement about a model's total, and totals do not exist until the rows are grouped.

The guard case T2 is worth understanding: when every individual row happens to exceed the threshold, the row filter removes nothing and both queries agree. That coincidence is exactly what lets this defect survive a casual test with well-chosen data.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Adding `HAVING` but leaving the `WHERE` clause in place | T1, T3 — small-request models are still filtered out before grouping |
| Filtering the results in host code after the query returns | T1, T3 — the discarded rows never reach the host |
| Changing `WHERE token_count > 1000` to `WHERE token_count > 0` | T1 — `small-model` now appears but the threshold is no longer applied at all |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing groups and understated totals, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Confirm T2 genuinely passes in the broken version — it is the case that makes this High rather than Medium
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
