import db
import tools


def _make_booking(**overrides):
    b = {
        "booking_ref": "BK-1",
        "customer_name": "Jane Doe",
        "flight_route": "JFK-LHR",
        "verified_category": "AIRLINE_CANCELLED",
        "ticket_value": 300.0,
        "credit_eligible": 1,
        "credit_value": 300.0,
    }
    b.update(overrides)
    return b


def test_lookup_booking_found_and_missing():
    db.upsert_booking(_make_booking())
    assert tools.lookup_booking("BK-1") is not None
    assert tools.lookup_booking("BK-999") is None


def test_verify_supported_happy_path():
    booking = _make_booking()
    db.upsert_booking(booking)
    intent = {"action": "refund"}
    result = tools.verify_request_supported(intent, booking, "Jane Doe")
    assert result["supported"] is True
    assert result["reasons"] == []


def test_verify_flags_name_mismatch():
    booking = _make_booking(customer_name="Ingrid Solberg")
    intent = {"action": "refund"}
    result = tools.verify_request_supported(intent, booking, "Tobias Wren")
    assert result["supported"] is False
    assert any("does not match" in r for r in result["reasons"])


def test_verify_flags_not_eligible():
    booking = _make_booking(credit_eligible=0, credit_value=0.0)
    intent = {"action": "refund"}
    result = tools.verify_request_supported(intent, booking, "Jane Doe")
    assert result["supported"] is False


def test_verify_flags_negative_credit_value():
    booking = _make_booking(credit_value=-75.0)
    intent = {"action": "refund"}
    result = tools.verify_request_supported(intent, booking, "Jane Doe")
    assert result["supported"] is False
    assert any("non-positive" in r for r in result["reasons"])


def test_issue_refund_persists_action():
    db.insert_request({
        "request_id": "FR-1", "customer_name": "Jane Doe", "customer_tier": "Standard",
        "booking_ref": "BK-1", "submitted_at": "2026-01-01T00:00:00Z", "request_text": "refund please",
    })
    result = tools.issue_refund("FR-1", "BK-1", 300.0)
    assert result["status"] == "executed"
    actions = db.get_actions("FR-1")
    assert len(actions) == 1
    assert actions[0]["action_type"] == "refund"
    assert actions[0]["amount"] == 300.0


def test_schedule_rebooking_persists_action():
    db.insert_request({
        "request_id": "FR-2", "customer_name": "Jane Doe", "customer_tier": "Standard",
        "booking_ref": "BK-1", "submitted_at": "2026-01-01T00:00:00Z", "request_text": "rebook please",
    })
    result = tools.schedule_rebooking("FR-2", "BK-1", "JFK-LHR")
    assert result["status"] == "executed"
    actions = db.get_actions("FR-2")
    assert actions[0]["action_type"] == "rebooking"
    assert actions[0]["amount"] is None


def test_rebooking_history_defaults_to_zero_when_absent():
    assert tools.lookup_rebooking_history("Nobody Here") == 0
    db.upsert_rebooking_history("Known Person", 3)
    assert tools.lookup_rebooking_history("Known Person") == 3
