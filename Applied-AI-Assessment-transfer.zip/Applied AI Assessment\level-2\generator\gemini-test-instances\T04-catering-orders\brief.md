# Build Brief — Catering Order Fulfillment & Reliability

Your organization processes a continuous stream of catering orders — multi-item orders placed by corporate accounts and one-off event clients, fulfilled from a central kitchen/equipment warehouse and dispatched to a delivery service. Build an application that:

1. Ingests catering orders (seed datasets are provided — `catalog_inventory.csv`, `orders.csv`, and `alt_kitchen_inventory.csv`)
2. Uses the in-house LLM to interpret each one — including reconciling line items that don't map cleanly onto the catalog
3. Works as an agent, not a single call: check inventory availability via a tool, reconcile ambiguous items against the catalog via a tool, and only then decide how to proceed
4. **Handle back-ordered items sensibly.**
5. **Only auto-dispatch low-risk orders.**
6. For fully-available, low-risk orders, autonomously dispatch fulfillment via a tool call — gated by an explicit check; anything uncertain, back-ordered, or above a value/risk threshold is escalated to a human
7. **Separately, for orders where the primary kitchen/warehouse is out of stock on an item: look up alternate-kitchen stock via a tool, and if the alternate kitchen confirms availability within a reasonable shipping-cost threshold, autonomously reroute that line item to ship from the alternate kitchen via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate.
8. Provides a UI showing the agent's reasoning, any autonomous action taken (dispatches *and* any alternate-kitchen reroutes), and lets a human review and override
9. Persists orders, reconciliation decisions, dispatch actions (including any reroutes), and any overrides to a database

The fulfillment-dispatch call is realistic infrastructure: it can fail **transiently** (a timeout, a temporary service hiccup) or **permanently** (the item is genuinely unavailable, the destination is invalid) — your system needs to tell these apart and behave accordingly, rather than treating every failure the same way.

Some items in the seed dataset are permanently out of stock at the primary kitchen — your solution should handle these sensibly rather than crashing or silently corrupting the fulfillment record.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
