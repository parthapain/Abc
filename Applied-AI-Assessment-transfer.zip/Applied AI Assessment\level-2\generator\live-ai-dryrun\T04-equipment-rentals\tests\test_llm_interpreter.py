"""Unit tests for the deterministic line-item splitting + reconciliation logic."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from llm_interpreter import interpret_line_item, split_line_items

CATALOG = [
    {"sku": "EQ-101", "name": "Concrete Mixer - 3.5cu ft", "price_per_day": 85, "in_stock": 6},
    {"sku": "EQ-102", "name": "Concrete Mixer - 6cu ft", "price_per_day": 120, "in_stock": 0},
    {"sku": "EQ-103", "name": "Skid Steer Loader - Standard", "price_per_day": 375, "in_stock": 0},
    {"sku": "EQ-104", "name": "Folding Table - 8ft", "price_per_day": 18, "in_stock": 50},
    {"sku": "EQ-109", "name": "PA System - Basic", "price_per_day": 175, "in_stock": 8},
]


def test_split_basic_multi_item():
    items = split_line_items("3x Skid Steer Loader - Standard, 2x Folding Table - 8ft")
    assert items == [(3, "Skid Steer Loader - Standard"), (2, "Folding Table - 8ft")]


def test_split_single_item():
    items = split_line_items("1x PA System - Basic")
    assert items == [(1, "PA System - Basic")]


def test_split_handles_missing_qty_prefix_gracefully():
    items = split_line_items("Folding Table - 8ft")
    assert items == [(1, "Folding Table - 8ft")]


def test_reconcile_exact_match_is_confident():
    result = interpret_line_item("Skid Steer Loader - Standard", CATALOG)
    assert result.resolved_sku == "EQ-103"
    assert result.ambiguous is False
    assert result.confidence >= 0.92


def test_reconcile_ambiguous_product_family_flagged():
    # "Concrete Mixer" alone could mean EQ-101 or EQ-102 -- this is exactly the
    # "doesn't map cleanly" case called out in the brief.
    result = interpret_line_item("Concrete Mixer", CATALOG)
    assert result.ambiguous is True
    skus_considered = {c.sku for c in result.candidates}
    assert {"EQ-101", "EQ-102"}.issubset(skus_considered)


def test_reconcile_ambiguous_tie_break_prefers_in_stock_variant():
    # EQ-101 has stock, EQ-102 does not -- the tie-break heuristic should
    # default the guess to the one that's actually stocked.
    result = interpret_line_item("Concrete Mixer", CATALOG)
    assert result.resolved_sku == "EQ-101"


def test_reconcile_nonsense_text_returns_no_match():
    result = interpret_line_item("Inflatable Bounce House", CATALOG)
    assert result.resolved_sku is None
    assert result.ambiguous is True
