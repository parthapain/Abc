# Score Aggregation & Human-Review Cutoff

## Aggregation

Total = sum of the five dimension scores (0–20), equal-weighted by default. See `../rubric.md` for the note on optionally weighting dimension 4 (AI-output verification) higher — a decision for the team to make explicitly before grading begins, not mid-way through.

Every candidate is ranked by total score, regardless of whether they clear any cutoff. This ranking is what makes the cutoff mechanism below workable.

## Setting the cutoff

**No fixed headcount target** — the explicit instruction for this assessment is "very difficult category... no need to go easy," so the right number of candidates reaching human review is however many genuinely clear a high bar, not a number chosen to hit a quota.

**Recommended approach: set an absolute score threshold, not a percentile or fixed top-N.**

- A percentile (e.g., "top 15%") guarantees that number of people advance even if the whole cohort performed weakly — which directly contradicts "no need to go easy."
- An absolute bar (e.g., "15 or higher out of 20, with no single dimension below 2") only advances candidates who actually met the standard, whatever that turns out to be for this cohort.

**Where to set the absolute bar:** calibrate it using the calibration set (`calibration-process.md`) — the "clearly strong" calibration submission should comfortably clear it, the "confidently wrong" and "correct by luck" ones should not. Treat this as the working bar until real score distributions come in, then sanity-check it against them (see below) rather than treating it as fixed in stone before you've seen a single real submission.

## Reconciling the bar with reviewer bandwidth

3 reviewers, roughly 3–4 working days for this stage, at a realistic 30–45 minutes per candidate (the AI grader has already done a first pass, so a human isn't starting cold) — call it **100–150 candidate-reviews of total headroom** across the 3 of them.

This number is a **sanity check, not a target**:

- **If far fewer than 100–150 candidates clear the absolute bar:** good — that's the intended outcome of a genuinely hard assessment. Reviewers have room to go deeper per candidate than the 30–45 minute estimate.
- **If more clear the bar than reviewers can cover in the time available:** do **not** silently raise the bar after the fact to make the number smaller — that quietly changes the standard candidates were held to, after they've already been judged against it. Instead:
  1. Use the AI-graded ranking to have reviewers work top-down, prioritizing the highest scorers first.
  2. If time runs out before reaching the bottom of the qualified list, that's a scheduling problem to escalate (more reviewer time, extended timeline for this stage) — not a reason to have moved the bar.

## What a human reviewer actually receives, per candidate

- The AI grader's four dimension scores, total, and cited evidence per dimension (from `grading-prompt.md`'s output format)
- The AI grader's closing five-minute-summary paragraph
- Access to the full repo (final code snapshot — no commit history exists) and rationale, for spot-checking — a reviewer should treat the AI's scores as a first pass to verify, not a verdict to rubber-stamp, especially on any dimension where cited evidence looks thin. There is no interaction log and no commit history for a reviewer to check either — the human reviewers work from exactly the same two evidence sources as the AI grader.

## Live demonstration for shortlisted candidates

**Grading is static-only through the AI screen** — the AI grader assesses persistence/DB behavior and everything else from the submitted code, never by running it (see `../rubric.md` §4). This means nothing before the cutoff confirms the app actually works as the code implies; it's plausible for well-written-looking code to not actually run.

To close that gap without provisioning execution infrastructure for 300+ candidates, **only candidates who clear the absolute cutoff and reach the 3 human reviewers are asked for a short live demonstration** of their working application (a screen-share walkthrough, scheduled alongside or just before their human review slot).

**What it's for:** confirming the submission is real, working software — not scoring a new dimension. The AI-graded rubric scores stand as computed; the demo is a verification gate, not a re-grade.

**What a reviewer does with it:**
- If the app runs and behaves consistent with what the code and rationale claimed (including persisting data as described) — proceed with the AI-graded scores as-is.
- If the app doesn't run at all, or its actual behavior clearly contradicts what the static code review credited (e.g., Dimension 5 was scored assuming working persistence that turns out not to function) — treat this as a strong red flag. The reviewer should weight it heavily in their own judgment and flag it explicitly rather than silently averaging it into an otherwise-good score; this is the kind of finding that can override an AI-graded pass.

**Cost stays bounded by design:** this only ever applies to the ~100–150 candidates who reach reviewer bandwidth (see above), never to the full 300+, which is why it wasn't built into the AI-grading pass itself.

## Recording what happened

For the first real cohort, keep the actual score distribution and where the bar landed — this becomes the basis for whether the bar was calibrated well, and for setting it faster next cycle instead of re-deriving it from the calibration set alone.
