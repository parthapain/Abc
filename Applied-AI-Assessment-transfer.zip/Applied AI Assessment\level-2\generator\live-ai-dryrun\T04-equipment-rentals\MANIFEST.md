# MANIFEST

## Run it

```
pip install -r requirements.txt
streamlit run app.py
```

The app auto-initializes the SQLite database from the three seed CSVs on first
load (or run `python init_data.py --reset` yourself first). Use the sidebar
"Process all pending orders" button to run the agent over the seed orders.

Run the test suite with `pytest tests/ -v` (15 tests, no DB/network setup needed
— tests use a throwaway temp SQLite file).

## Where things live

| Concern | File |
|---|---|
| Agent / orchestration loop (the control flow that decides which tool to call next, and when to dispatch vs. hold for review) | `agent.py` — `process_order()` |
| Tool definitions (`reconcile_line_item`, `check_inventory`, `check_alt_yard`, `reroute_to_alt_yard`, `dispatch_order`) | `tools.py` |
| "In-house LLM" stand-in (line-item splitting + catalog reconciliation) | `llm_interpreter.py` |
| Persistence (SQLite schema + all read/write helpers) | `db.py` |
| Seed data loader | `init_data.py` |
| UI (order list, reasoning trace, autonomous-action log, human review/override controls) | `app.py` |
| Tests | `tests/test_llm_interpreter.py`, `tests/test_agent.py` |
| Written rationale | `RATIONALE.md` |

## Data model (SQLite, see `db.py` for full schema)

- `orders` — one row per ingested order + current status
- `line_items` — one row per parsed line item, with resolved SKU, confidence,
  and the primary/alt/backorder quantity split
- `reconciliation_decisions` — every reconciliation "tool call" the agent made
- `dispatch_actions` — every autonomous dispatch and alt-yard reroute (with a
  `source_yard` column distinguishing the two)
- `overrides` — every human override (reconciliation correction, manual
  dispatch, hold, reject), with old/new value and a note
- `agent_runs` — the full reasoning trace (JSON) + risk verdict for each agent
  pass over an order, shown in the UI's "Agent reasoning trace" panel
- `catalog`, `alt_yard_inventory` — durable copies of the seed CSVs so the app
  isn't re-reading files on every request (stock levels update in-DB as the
  agent dispatches/reroutes)
