"""
Streamlit UI for the Equipment Rental Fulfillment agent.

Shows: the list of ingested orders and their status, the agent's full
reasoning trace per order (every tool call it made and why), any autonomous
actions taken (dispatches and alt-yard reroutes), and a human review panel
that lets a reviewer override a reconciliation, force/undo a dispatch, or
place an order on hold -- all persisted to the database.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import json

import streamlit as st

import agent
import db
import init_data
import tools

st.set_page_config(page_title="Equipment Rental Fulfillment", layout="wide")

STATUS_LABELS = {
    "ingested": "Not yet processed",
    "processed_auto_dispatched": "Auto-dispatched",
    "processed_needs_review": "Needs human review",
    "dispatched_by_human": "Dispatched (human)",
    "held": "On hold",
    "rejected": "Rejected",
}
STATUS_COLORS = {
    "ingested": "gray",
    "processed_auto_dispatched": "green",
    "processed_needs_review": "orange",
    "dispatched_by_human": "blue",
    "held": "violet",
    "rejected": "red",
}


def ensure_db():
    if not db.DB_PATH.exists():
        init_data.main(reset=False)


def status_badge(status: str) -> str:
    color = STATUS_COLORS.get(status, "gray")
    label = STATUS_LABELS.get(status, status)
    return f":{color}[**{label}**]"


def render_trace(trace: list[dict]):
    for step in trace:
        if step["tool"] is None:
            st.markdown(f"- {step['note']}")
        else:
            with st.container(border=True):
                st.markdown(f"**Tool call: `{step['tool']}`**")
                cols = st.columns(2)
                with cols[0]:
                    st.caption("Input")
                    st.json(step["input"])
                with cols[1]:
                    st.caption("Output")
                    st.json(step["output"])
                if step.get("note"):
                    st.markdown(f"_{step['note']}_")


def render_order_detail(order_id: str):
    order = db.get_order(order_id)
    line_items = db.get_line_items(order_id)
    actions = db.get_dispatch_actions(order_id)
    overrides = db.get_overrides(order_id)
    run = db.get_latest_agent_run(order_id)

    st.subheader(f"{order_id} — {order['client_name']}")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Status", STATUS_LABELS.get(order["status"], order["status"]))
    c2.metric("Client type", order["client_type"])
    c3.metric("Est. value/day", f"${order['estimated_value']:,.2f}" if order["estimated_value"] else "—")
    c4.metric("Risk level", run["risk_level"].upper() if run else "—")
    st.caption(f"Raw request: \"{order['raw_description']}\"")

    if line_items:
        st.markdown("#### Line items")
        rows = []
        for li in line_items:
            rows.append({
                "raw text": li["raw_text"],
                "qty": li["requested_qty"],
                "resolved SKU": li["resolved_sku"] or "—",
                "resolved name": li["resolved_name"] or "(unresolved)",
                "confidence": f"{li['confidence']:.2f}" if li["confidence"] is not None else "—",
                "ambiguous?": "⚠️ yes" if li["ambiguous"] else "no",
                "from primary": li["fulfill_primary_qty"],
                "from alt yard": li["fulfill_alt_qty"],
                "backordered": li["backorder_qty"],
                "overridden SKU": li["override_sku"] or "",
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    if actions:
        st.markdown("#### Autonomous actions taken")
        arows = [{
            "type": a["action_type"], "sku": a["sku"], "qty": a["qty"],
            "source yard": a["source_yard"], "ship cost": f"${a['ship_cost']:.2f}",
            "when": a["created_at"], "reasoning": a["reasoning"],
        } for a in actions]
        st.dataframe(arows, use_container_width=True, hide_index=True)
    else:
        st.caption("No autonomous dispatch/reroute actions taken yet.")

    if run:
        with st.expander("Agent reasoning trace", expanded=False):
            if run["risk_reasons"]:
                reasons = json.loads(run["risk_reasons"])
                if reasons:
                    st.warning("Risk factors:\n" + "\n".join(f"- {r}" for r in reasons))
            render_trace(json.loads(run["reasoning_trace"]))

    if overrides:
        with st.expander(f"Override history ({len(overrides)})", expanded=False):
            orows = [{
                "type": o["override_type"], "old": o["old_value"], "new": o["new_value"],
                "note": o["note"], "actor": o["actor"], "when": o["created_at"],
            } for o in overrides]
            st.dataframe(orows, use_container_width=True, hide_index=True)

    st.markdown("#### Human review & override")
    rc1, rc2, rc3, rc4 = st.columns(4)

    with rc1:
        if order["status"] in ("processed_needs_review", "ingested"):
            if st.button("Approve & dispatch now", key=f"approve_{order_id}"):
                reason = "Manually approved by human reviewer after review of agent trace."
                fulfillable = [dict(li) for li in db.get_line_items(order_id)
                               if li["fulfill_primary_qty"] > 0 or li["fulfill_alt_qty"] > 0]
                tools.dispatch_order(order_id, fulfillable, reason)
                db.set_order_status(order_id, "dispatched_by_human")
                db.log_override(order_id, "dispatch", order["status"], "dispatched_by_human",
                                 note="Human approved dispatch of a high-risk / flagged order.")
                st.rerun()

    with rc2:
        if order["status"] not in ("held", "rejected"):
            if st.button("Put on hold", key=f"hold_{order_id}"):
                db.log_override(order_id, "hold", order["status"], "held",
                                 note="Human placed order on hold pending further info.")
                db.set_order_status(order_id, "held")
                st.rerun()

    with rc3:
        if order["status"] not in ("rejected",):
            if st.button("Reject order", key=f"reject_{order_id}"):
                db.log_override(order_id, "reject", order["status"], "rejected",
                                 note="Human rejected the order.")
                db.set_order_status(order_id, "rejected")
                st.rerun()

    with rc4:
        if st.button("Re-run agent", key=f"rerun_{order_id}"):
            agent.process_order(order_id)
            st.rerun()

    ambiguous_items = [li for li in line_items if li["ambiguous"]]
    if ambiguous_items:
        st.markdown("##### Override a reconciliation")
        catalog = db.get_catalog()
        catalog_options = {f"{c['sku']} — {c['name']}": c for c in catalog}
        li_options = {f"Line {li['line_no']}: \"{li['raw_text']}\"": li for li in ambiguous_items}
        chosen_li_label = st.selectbox("Ambiguous line item", list(li_options.keys()), key=f"li_sel_{order_id}")
        chosen_sku_label = st.selectbox("Correct catalog item", list(catalog_options.keys()), key=f"sku_sel_{order_id}")
        if st.button("Apply override", key=f"apply_override_{order_id}"):
            li = li_options[chosen_li_label]
            c = catalog_options[chosen_sku_label]
            db.log_override(order_id, "reconciliation", li["resolved_sku"], c["sku"],
                             note=f"Human corrected reconciliation for \"{li['raw_text']}\".",
                             line_item_id=li["id"])
            db.set_line_item_override_sku(li["id"], c["sku"], c["name"], c["price_per_day"])
            st.success("Override applied. Re-run the agent to recompute inventory/dispatch with the corrected item.")
            st.rerun()


def main():
    ensure_db()
    st.title("Equipment Rental Fulfillment & Reliability")
    st.caption(
        "Agent ingests rental requests, reconciles line items against the catalog, checks "
        "inventory, reroutes to the alternate yard when needed, and auto-dispatches only "
        "low-risk orders. Everything else is queued for human review below."
    )

    with st.sidebar:
        st.header("Controls")
        if st.button("Process all pending orders", type="primary"):
            with st.spinner("Running agent..."):
                results = agent.process_all_pending()
            st.success(f"Processed {len(results)} order(s).")
        st.divider()
        if st.button("Reset & reload seed data (destructive)"):
            init_data.main(reset=True)
            st.success("Database reset and seed data reloaded.")
            st.rerun()
        st.divider()
        st.caption("Primary yard stock")
        st.dataframe(
            [{"sku": c["sku"], "name": c["name"], "in_stock": c["in_stock"]} for c in db.get_catalog()],
            use_container_width=True, hide_index=True,
        )
        st.caption("Alternate yard stock")
        alt = db.get_conn if False else None  # noqa - placeholder to avoid unused import warnings
        with db.get_conn() as conn:
            alt_rows = conn.execute("SELECT * FROM alt_yard_inventory").fetchall()
        st.dataframe(
            [{"sku": r["sku"], "alt_stock": r["alt_stock"], "ship_cost": r["ship_cost"]} for r in alt_rows],
            use_container_width=True, hide_index=True,
        )

    orders = db.get_all_orders()
    st.markdown("### Orders")
    order_rows = []
    for o in orders:
        order_rows.append({
            "order_id": o["order_id"], "client": o["client_name"], "type": o["client_type"],
            "submitted": o["submitted_at"], "status": STATUS_LABELS.get(o["status"], o["status"]),
        })
    st.dataframe(order_rows, use_container_width=True, hide_index=True)

    st.markdown("### Order detail")
    order_id = st.selectbox("Select an order", [o["order_id"] for o in orders])
    if order_id:
        render_order_detail(order_id)


if __name__ == "__main__":
    main()
