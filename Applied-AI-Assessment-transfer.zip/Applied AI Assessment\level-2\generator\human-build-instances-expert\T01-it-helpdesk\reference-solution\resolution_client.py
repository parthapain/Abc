"""
Simulated courtesy-resolution service (the analog of T04's dispatch_client).

Real infrastructure characteristics on purpose:
- can fail transiently (timeout) or permanently (the record is genuinely invalid)
- occasionally reports a failure for a call that actually succeeded server-side
  (the idempotency trap this instance requires handling correctly)
"""
import random
import time
import pandas as pd


class TransientResolutionError(Exception):
    """Worth retrying — a timeout or temporary hiccup."""


class PermanentResolutionError(Exception):
    """Not worth retrying — the record is genuinely invalid."""


# server-side truth: idempotency_key -> resolution record, independent of
# whether the CALLER ever heard back about it.
_server_side_resolutions = {}

# Live verified discrepancy, separate from the static CSV, so a test can
# simulate the figure changing *after* a request was reviewed but before (or
# between) resolution attempts -- this is what the brief's "always re-confirm
# the current verified discrepancy" sentence refers to.
_live_discrepancy = pd.read_csv("license_billing_records.csv").set_index("requester_name")["verified_discrepancy"].to_dict()


def set_live_discrepancy(requester_name, amount):
    """Test-only hook: simulate the verified discrepancy changing between calls."""
    _live_discrepancy[requester_name] = amount


def issue_resolution(ticket_id, requester_name, amount, idempotency_key, force_lost_response=False):
    """
    idempotency_key must be the SAME value for logically-the-same resolution
    attempt across retries, so a retried call can recognize prior success.

    force_lost_response: test-only hook. When True, simulates the server
    having already completed the resolution on a PRIOR call, but the response
    to THAT call never reached the caller.
    """
    if idempotency_key in _server_side_resolutions:
        # Already actually happened server-side. Deliberately checked BEFORE
        # the live-discrepancy re-confirmation below -- a cache hit isn't a
        # new resolution decision, it's reporting what already happened.
        # Re-checking the discrepancy here would let a figure that changed
        # *after* the original resolution already succeeded silently
        # overturn an action that's already done.
        return _server_side_resolutions[idempotency_key]

    # Fresh resolution attempt only (never reached on a cache hit above):
    # this is where "always re-confirm the current discrepancy" applies.
    current = _live_discrepancy.get(requester_name)
    if current is None or current != amount:
        raise PermanentResolutionError(
            f"Verified discrepancy for {requester_name} changed before resolution could "
            f"complete (now {current}, expected {amount})."
        )

    if force_lost_response:
        result = {"status": "success", "resolution_id": f"RES-{ticket_id}-{int(time.time())}"}
        _server_side_resolutions[idempotency_key] = result
        raise TransientResolutionError("Connection timed out to billing API (response lost).")

    if random.random() < 0.1:
        raise TransientResolutionError("Connection timed out to billing API.")

    result = {"status": "success", "resolution_id": f"RES-{ticket_id}-{int(time.time())}"}
    _server_side_resolutions[idempotency_key] = result
    return result
