# T01 Calibration Run #1

Per `../../templates/T01-triage-classification.md`'s Calibration section. This is the first calibration pass for the reworked T01 — the template it gates: T02, T03, and T04 all wait behind this one's result (see `../../generator/architecture.md`'s sequencing note).

**Instance used for this run:** domain flavor = support tickets; ambiguity phrasing #1 ("prioritize appropriately"); trap variant #1 (silent fallback classification); stress-point variant #1 (blank body) — not exercised in this run, see Open Items.

**Method:** simulate the natural, incremental way a candidate would prompt a coding assistant to build this feature — without ever mentioning the trap or the guardrail-design risk — and inspect what comes out. This mirrors the calibration instruction ("actually prompt a coding assistant... unprompted about the trap"). One honesty note up front: this run was done in this same session rather than a separate blind assistant session, so treat it as a strong, realistic dry-run rather than a fully independent trial — the code below reflects well-established default patterns for LLM coding assistants (try/except-and-default, confidence-threshold gating), not a hypothetical.

---

## Step 1 — does the AI-trap reproduce?

**Prompt given (simulating the candidate):** *"Write a function that classifies a support ticket into categories (Billing, Technical Issue, Account Access, Feature Request, Complaint) and assigns a priority (Low/Medium/High/Urgent), using our LLM client `llm.complete(prompt)`."*

**Naive output:**
```python
def classify_ticket(ticket_text: str) -> dict:
    prompt = f"""Classify this support ticket into one of these categories:
Billing, Technical Issue, Account Access, Feature Request, Complaint.
Also assign a priority: Low, Medium, High, Urgent.

Ticket: {ticket_text}

Respond in JSON: {{"category": "...", "priority": "...", "confidence": 0.0-1.0, "reasoning": "..."}}"""
    response = llm.complete(prompt)
    return json.loads(response)
```

**Follow-up prompt:** *"Add error handling so if the LLM call fails, the app doesn't crash."*

**Naive output:**
```python
def classify_ticket(ticket_text: str) -> dict:
    prompt = f"""..."""
    try:
        response = llm.complete(prompt)
        return json.loads(response)
    except Exception as e:
        logger.error(f"Classification failed: {e}")
        return {"category": "General", "priority": "Low", "reasoning": "default fallback"}
```

**Verdict: trap reproduces exactly as described.** The except block returns a dict indistinguishable in shape from a genuine result, with no status flag. Confirmed — proceed to step 3 to see if it also reaches the guardrail.

## Step 2 — is the ambiguity genuinely two-way?

Phrasing #1: *"Prioritize support tickets appropriately so urgent ones surface first."* Tested against realistic sample tickets: a billing dispute from a high-tier customer with mild language vs. an angry-toned free-text complaint from a standard-tier customer with no stated deadline. Two reasonable engineers plausibly land in different places — tier-first (favors the billing dispute), signal-first (favors the angry complaint), or a blended score. **Confirmed genuinely two-way**, not one obviously-correct reading.

## Step 3 — does the guardrail-default trap reproduce?

**Follow-up prompt:** *"Now make this agentic: before finalizing, call `search_similar_items(ticket_text)` to check for duplicates, and if classification confidence is low, call `get_context(ticket_id)` for more detail. Then decide: if it's a confident, low-risk classification, auto-acknowledge the ticket via `auto_acknowledge(ticket_id)`; otherwise escalate to a human queue."*

**Naive output:**
```python
def handle_ticket(ticket_id: str, ticket_text: str) -> dict:
    result = classify_ticket(ticket_text)

    similar = search_similar_items(ticket_text)
    if similar.get("duplicate_found"):
        auto_close(ticket_id, reason="duplicate")
        return {"action": "auto_closed", "classification": result}

    if result.get("confidence", 1.0) < 0.6:
        context = get_context(ticket_id)
        result = classify_ticket(ticket_text, extra_context=context)

    if result.get("confidence", 1.0) >= 0.8 and result["priority"] in ("Low", "Medium"):
        auto_acknowledge(ticket_id)
        return {"action": "auto_acknowledged", "classification": result}
    else:
        escalate_to_human(ticket_id)
        return {"action": "escalated", "classification": result}
```

**Verdict: reproduces, and worse than the template description anticipated.** Two compounding issues, both present in this natural first draft:

1. **The guardrail gates purely on `confidence` and `priority` from the classification result — no check on the duplicate-lookup tool's own findings beyond a binary `duplicate_found`, and no check at all on whether the classification was itself the step-1 failure-masked default.**
2. **A specific, sharper failure than the written trap description called out:** the failure-masked fallback dict from step 1 has no `confidence` key. `result.get("confidence", 1.0)` on that fallback dict returns **1.0** — a *failed* classification reads as **maximum confidence** and sails straight through the guardrail into auto-acknowledge. This is the two traps compounding: the classification-failure trap (step 1) directly defeats the guardrail (step 3) through a shared default-value bug, worse than either trap in isolation. A candidate who fixes only one of these (e.g., adds a status flag to the fallback dict but never audits what the guardrail actually reads) would still fail.

**Recommendation:** flag this compounding failure explicitly in T01's reference solution and grading notes, since it's a stronger, more concrete version of the "trap-triggered failure must never reach the guardrail" requirement the rework already states in principle — this run shows exactly *how* it defeats a naive guardrail in practice, not just that it theoretically could.

## Step 4 — timeboxed build check

**Not independently validated by an actual timed human build.** What follows is a complexity-based estimate, not a substitute for the real check the template's Calibration section asks for.

Full scope for one instance: CSV ingest, classification call (with real error handling, not the naive version above), two tools (`search_similar_items`, `get_context`), guardrail logic incorporating the fix for the compounding failure above, a review UI (list view + override), persistence (tickets/classifications/actions/overrides schema), minimal tests, plus the ~half-page rationale. This is meaningfully more than the pre-rework single-call version — my assessment is that **24 hours is tight for a "3/4"-quality submission** covering all of this; **48 hours is realistic but still demanding**, especially since a candidate has to get the ambiguity, the trap, *and* the guardrail right simultaneously, not just one of the three.

**This step is not complete.** Recommend an actual internal timed dry-run (a real engineer, stopwatch running, 24–48hr cap) before treating T01 — and by extension T02/T03/T04 — as cleared on this point.

---

## Overall verdict

| Step | Result |
|---|---|
| 1. Trap reproduces | ✅ Confirmed |
| 2. Ambiguity genuinely two-way | ✅ Confirmed |
| 3. Guardrail-default trap reproduces | ✅ Confirmed — and compounds with the trap in a specific, sharper way than anticipated (see above) |
| 4. Timeboxed build | ⏳ **Not done** — complexity estimate only, real timed run still needed |

**T01 is not yet fully calibrated.** Three of four steps have real evidence; the fourth (an actual timed human build) is the one thing left before T01 can be marked calibrated and before T02/T03/T04 calibration can start, per the sequencing rule.

## Follow-up actions this run identified

1. Add the compounding-failure finding to T01's reference solution and AI-trap slot notes — it's a stronger, more specific version of the existing "failure must not reach the guardrail" requirement.
2. Schedule an actual timeboxed internal build (real person, real clock) before marking T01 calibrated.
3. Once T01 clears step 4, re-run this same three-step exercise (trap / ambiguity / guardrail) against T02, since T02's trap (hallucination-on-absence) and guardrail (auto-commit) are structurally the same shape and may compound the same way — e.g., check whether a hallucinated-but-unflagged extraction can similarly slip past `verify_against_source` due to a shared default-value gap.

---

## Calibration Run #2 — post-split re-validation (2026-09-12)

**Purpose:** the rubric's Dimension 1 was split into Dimension 1 (architecture fit only) and the new Dimension 2 (agentic design/tools/guardrails) — see `../../rubric.md`'s revision note and `../../design-rationale.md` Addendum 16. This run confirms run #1's findings still hold as evidence and resolves which new-numbering dimension and cap level each one lands under. It is **not** a re-derivation from scratch — the split is a grading-schema change, not a change to the brief, the trap, or what a candidate/assistant would naturally build, so the same three prompts from run #1 were re-run verbatim and produced identical code. See run #1 above for the actual code and prompts; not reproduced again here.

**Dimension mapping, resolved:**
- Step 1's trap finding (silent fallback classification indistinguishable from a genuine result) → **Dimension 4** (was Dimension 3). Unchanged in substance and severity.
- Step 2's ambiguity finding (phrasing #1, genuinely two-way) → **Dimension 3** (was Dimension 2). Unchanged.
- Step 3's guardrail-compounding finding (`result.get("confidence", 1.0)` on a failure-masked fallback dict with no `confidence` key, reading a failed classification as maximum confidence) → **Dimension 2** (was folded into the old Dimension 1). **Confirmed this caps Dimension 2 at 1**, under the "consequential action fires with no gate at all" anchor — the check that exists (`confidence >= 0.8`) checks the wrong thing entirely for a failure-masked input, which is functionally equivalent to no gate on that input class. This is the same severity conclusion run #1 already reached; the split doesn't change it, only which single dimension now carries it cleanly (previously it shared a dimension with architecture fit, which had no bearing on this finding either way).

**Anything new this pass surfaced:** no new code-level finding. The one genuinely new thing settled here is a **grading-consistency clarification** that also matters for T03/T04 (see those templates' Run #2 entries and `../../rubric.md` §2): distinguishing "no gate at all" (cap 1) from "a guardrail that checks something, just not the real risk" (cap 2). T01's case is unambiguously the former — there's no partial or superficial check being performed on a failure-masked input, the fallback simply presents as maximum-confidence real data.

**Verdict: T01's calibration status is unchanged.** 3 of 4 steps remain confirmed under the new dimension numbering with no change in severity or recommended treatment; step 4 (an actual timed human build) remains the outstanding gate, unaffected by the rubric split.

---

## Calibration Run #3 — Addendum 20 second-guardrail dry-run (2026-09-13)

**Purpose:** T01's brief now requires a second, independent guardrailed action (a courtesy billing credit gated on `billing_accounts.csv`, see `../../templates/T01-triage-classification.md`'s "Second guardrail" note). This run dry-tests that specific addition the same way run #1 tested the original guardrail — simulate a natural build, don't assume the originally-written compounding-risk hypothesis is automatically correct, report whatever actually reproduces.

**Prompt given (simulating the candidate):** *"For Billing tickets where the customer says they were overcharged, check the real billing record via `check_billing_record(account_id)`, and if it confirms an overcharge below $50, auto-issue a courtesy credit via `issue_courtesy_credit(account_id, amount)`. Otherwise escalate."*

**Naive output:**
```python
def check_billing_record(account_id: str) -> dict:
    row = billing_df[billing_df["customer_id"] == account_id]
    if row.empty:
        return {}
    r = row.iloc[0]
    return {"discrepancy": r["last_invoice_amount"] - r["prior_invoice_amount"]}

def handle_billing_credit(ticket_id, account_id, classification):
    if classification["category"] != "Billing":
        return None
    record = check_billing_record(account_id)
    discrepancy = record.get("discrepancy", 0)
    if discrepancy <= 50:
        issue_courtesy_credit(account_id, discrepancy)
        return {"action": "credit_issued", "amount": discrepancy}
    else:
        escalate_to_human(ticket_id)
        return {"action": "escalated"}
```

**Verdict: the originally-written compounding-risk hypothesis did NOT reproduce — reported honestly — but a different, real bug did.**

- **Not reproduced:** the template's original guess (a lookup failure silently falling back to *trusting the customer's claimed number*) doesn't naturally arise here. `record.get("discrepancy", 0)` fails toward **$0** on a missing lookup, not toward whatever the customer claimed — this naturally routes to escalation, the safe direction, the same way T03's eligibility check happened to fail closed in run #1.
- **What actually reproduces:** `if discrepancy <= 50` **omits the lower bound**. A genuinely zero (or negative) discrepancy also satisfies `<= 50` and fires `issue_courtesy_credit(account_id, 0)` — a nonsensical zero-dollar "credit" gets auto-issued and logged as a legitimate resolution, instead of the ticket being escalated as "no real discrepancy found." **This directly matches T-2005 in the actual harder-instance dataset** (Wren Castillo, C-2004, real discrepancy exactly $0) — a naturally-written implementation would auto-"resolve" that ticket instead of correctly refusing it.
- This is the same *family* of bug this project keeps finding (a naive translation of "below a threshold" drops an implicit boundary condition) but a distinct, more specific mechanism than what the template currently describes. **Action taken: updated `T01-triage-classification.md`'s second-guardrail compounding-risk note to describe this confirmed mechanism instead of the original guess.**

**Ambiguity check (brief):** the second phrasing typically paired with this guardrail in the harder instance ("route to the right team") was already exercised as pool item #3 in the template's own design; re-tested here against T-2001 (Finance-appropriate) vs. T-2003 (Customer-Success-appropriate) — a reasonable engineer could route by category alone or also weigh customer tier/severity. **Confirmed genuinely two-way**, consistent with the pool's existing calibration.

**T01's second guardrail is dry-run confirmed, not yet independently verified against a live AI assistant** (per this run's own honesty note in run #1 — this remains a strong dry-run, not a blind third-party trial) and does not yet include an actual timed build covering both guardrails together.
