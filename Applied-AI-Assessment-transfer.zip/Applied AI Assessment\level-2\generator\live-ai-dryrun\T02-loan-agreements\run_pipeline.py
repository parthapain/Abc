#!/usr/bin/env python
"""CLI entry point: ingest all seed documents, run the extraction agent, and
run the maturity-followup pass. Run this once to populate loans.db, then
start the review UI with app/web.py.

Usage:
    python run_pipeline.py [--reset] [--as-of YYYY-MM-DD] [--horizon-months N]
"""
from __future__ import annotations

import argparse
from datetime import date

from app import db
from app.agent import DEFAULT_APPROACHING_MONTHS, process_document, run_maturity_followups
from app.tools import load_all_agreements


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reset", action="store_true", help="drop and recreate all tables first")
    parser.add_argument(
        "--as-of", type=str, default=None,
        help="reference date (YYYY-MM-DD) for the 'approaching maturity' check; defaults to today",
    )
    parser.add_argument(
        "--horizon-months", type=int, default=DEFAULT_APPROACHING_MONTHS,
        help=f"months-ahead window counted as 'approaching maturity' (default {DEFAULT_APPROACHING_MONTHS})",
    )
    args = parser.parse_args()

    if args.reset:
        db.reset_db()
    else:
        db.init_db()

    agreements = load_all_agreements()
    print(f"Found {len(agreements)} loan agreement(s) to process.")

    with db.get_conn() as conn:
        for agreement in agreements:
            process_document(conn, agreement)
            print(f"  processed {agreement['loan_number']} (from {agreement['source_file']})")

        reference_date = date.fromisoformat(args.as_of) if args.as_of else date.today()
        run_maturity_followups(conn, reference_date=reference_date, approaching_months=args.horizon_months)

    with db.get_conn() as conn:
        loans = db.all_loans(conn)
        followups = db.all_followups(conn)
    review_count = sum(1 for l in loans if l["needs_review"])
    generated_count = sum(1 for f in followups if f["generated"])
    print(f"\nCommitted {len(loans)} loan record(s); {review_count} flagged for review.")
    print(f"Maturity follow-up pass (as of {args.as_of or date.today()}, {args.horizon_months}mo horizon): "
          f"{len(followups)} loan(s) evaluated, {generated_count} follow-up record(s) generated.")


if __name__ == "__main__":
    main()
