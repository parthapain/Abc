# P03 — Monthly ingestion report

| Field | Value |
|---|---|
| **ID** | P03 |
| **Difficulty** | Medium |
| **Bug pattern** | Date boundary excludes the final day |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 11–14 min |
| **Paper** | 3 (with P21) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A monthly report lists every document ingested in a given calendar month. Operations noticed the totals look slightly low, and traced it to documents **ingested on the last day of the month going missing** from the report.

### Required behaviour

Given a month start date such as `'2024-03-01'`, return the `document_name` of every event where `event_type` is `'ingested'` and `created_at` falls within that calendar month, ordered by `created_at` ascending.

The whole of the final day belongs to the month. An event at `2024-03-31 23:59:59` is in March; an event at `2024-04-01 00:00:00` is not.

### Schema

```sql
CREATE TABLE ingestion_events (
    id             INTEGER PRIMARY KEY,
    document_name  TEXT NOT NULL,
    created_at     TEXT NOT NULL,   -- 'YYYY-MM-DD HH:MM:SS'
    event_type     TEXT NOT NULL    -- 'ingested' | 'deleted'
);
```

---

## Fixture — `P03.sql`

```sql
CREATE TABLE ingestion_events (
    id             INTEGER PRIMARY KEY,
    document_name  TEXT NOT NULL,
    created_at     TEXT NOT NULL,
    event_type     TEXT NOT NULL
);

INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
    (1, 'policy.pdf',   '2024-03-15 10:00:00', 'ingested'),
    (2, 'contract.pdf', '2024-03-31 14:22:00', 'ingested'),  -- last day, mid-afternoon
    (3, 'february.pdf', '2024-02-28 09:00:00', 'ingested');  -- previous month
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def ingested_in_month(db_path: str, month_start: str) -> List[str]:
    """
    Return document_name for every 'ingested' event in the calendar month
    beginning at month_start ('YYYY-MM-DD'), ordered by created_at ascending.
    """
    query = """
        SELECT document_name
        FROM ingestion_events
        WHERE event_type = 'ingested'
          AND created_at BETWEEN ? AND date(?, '+1 month', '-1 day')
        ORDER BY created_at
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query, (month_start, month_start)).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class IngestionReport {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return documentName for every 'ingested' event in the calendar month
     * beginning at monthStart ('yyyy-MM-dd'), ordered by createdAt ascending.
     */
    public static List<String> ingestedInMonth(String dbPath, String monthStart) throws SQLException {
        String query =
            "SELECT document_name " +
            "FROM ingestion_events " +
            "WHERE event_type = 'ingested' " +
            "  AND created_at BETWEEN ? AND date(?, '+1 month', '-1 day') " +
            "ORDER BY created_at";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, monthStart);
            ps.setString(2, monthStart);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(rs.getString("document_name"));
                }
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class IngestionReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return documentName for every 'ingested' event in the calendar month
    /// beginning at monthStart ('yyyy-MM-dd'), ordered by createdAt ascending.
    /// </summary>
    public static List<string> IngestedInMonth(string dbPath, string monthStart)
    {
        const string query = @"
            SELECT document_name
            FROM ingestion_events
            WHERE event_type = 'ingested'
              AND created_at BETWEEN @start AND date(@start, '+1 month', '-1 day')
            ORDER BY created_at";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query, new { start = monthStart }).ToList();
    }
}
```

---

## Hidden test cases

All cases call the function with `month_start = '2024-03-01'`.

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `P03.sql` above | `["policy.pdf", "contract.pdf"]` | **Discriminator** — broken drops `contract.pdf` |
| T2 | Two events mid-month | `["alpha.pdf", "beta.pdf"]` | Guard — nothing near a boundary |
| T3 | One event at `2024-03-31 23:59:59` | `["lastsecond.pdf"]` | **Discriminator** — broken returns `[]` |
| T4 | March event, `2024-04-01 00:00:00` event, and a March `'deleted'` event | `["inmarch.pdf"]` | Guard — next month stays out; catches removal of the `event_type` filter |
| T5 | Empty table | `[]` | Guard |

### Fixture for T2

```sql
INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
    (1, 'alpha.pdf', '2024-03-05 08:00:00', 'ingested'),
    (2, 'beta.pdf',  '2024-03-18 16:30:00', 'ingested');
```

### Fixture for T3

```sql
INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
    (1, 'lastsecond.pdf', '2024-03-31 23:59:59', 'ingested');
```

### Fixture for T4

```sql
INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
    (1, 'inmarch.pdf',   '2024-03-10 12:00:00', 'ingested'),
    (2, 'nextmonth.pdf', '2024-04-01 00:00:00', 'ingested'),
    (3, 'removed.pdf',   '2024-03-11 12:00:00', 'deleted');
```

---

## Reference solution

Replace the closed `BETWEEN` range with a half-open range:

```diff
  WHERE event_type = 'ingested'
-   AND created_at BETWEEN ? AND date(?, '+1 month', '-1 day')
+   AND created_at >= ?
+   AND created_at <  date(?, '+1 month')
  ORDER BY created_at
```

### Why

`date('2024-03-01', '+1 month', '-1 day')` evaluates to the bare string `'2024-03-31'`. `created_at` values carry a time component, so `'2024-03-31 14:22:00'` compares as **greater than** `'2024-03-31'` and falls outside the `BETWEEN` range. Every event after midnight on the final day is silently lost — roughly one day in thirty of the month's data.

The half-open form `>= start AND < start + 1 month` is the general fix for timestamp ranges: it needs no knowledge of month length, no end-of-day sentinel value, and behaves correctly whatever time precision the column stores.

### A note for reviewers, not candidates

`created_at <= date(?, '+1 month')` is **not** a distinct wrong answer. Because `created_at` always carries a time component, `'2024-04-01 00:00:00'` sorts after the bare string `'2024-04-01'`, so `<=` and `<` behave identically on any realistic row. Do not mark it down, and do not present it to candidates as a trap — it isn't one.

*(This was caught by the validation harness during authoring: it had been documented as a wrong fix, and the harness proved the claim false.)*

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Appending `' 23:59:59'` to the end bound as a string | Works for second precision, fails on sub-second timestamps — flag in review even though T1–T5 pass |
| Dropping the `event_type` filter | T4 — `removed.pdf` appears |
| Widening to `date(created_at) <= ...` while dropping the lower bound | T1 — February document appears |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing rows, not a crash or date-parsing error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
