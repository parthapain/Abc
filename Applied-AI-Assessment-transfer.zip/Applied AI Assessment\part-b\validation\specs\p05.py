"""P05 — Models used by a team. Medium · SQL-located · missing DISTINCT over a join."""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "join emits duplicate rows"}

SCHEMA = """
CREATE TABLE teams (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE models (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE requests (
    id       INTEGER PRIMARY KEY,
    team_id  INTEGER NOT NULL REFERENCES teams(id),
    model_id INTEGER NOT NULL REFERENCES models(id)
);
"""

_BROKEN_SQL = """
    SELECT m.name
    FROM models m
    JOIN requests r ON r.model_id = m.id
    JOIN teams    t ON t.id = r.team_id
    WHERE t.name = 'platform'
    ORDER BY m.name
"""

_FIXED_SQL = _BROKEN_SQL.replace("SELECT m.name", "SELECT DISTINCT m.name")


def broken(conn):
    return [r[0] for r in conn.execute(_BROKEN_SQL).fetchall()]


def fixed(conn):
    return [r[0] for r in conn.execute(_FIXED_SQL).fetchall()]


WRONG_FIXES = {
    "dropped the team filter": lambda conn: [
        r[0]
        for r in conn.execute(
            _FIXED_SQL.replace("WHERE t.name = 'platform'", "")
        ).fetchall()
    ],
}

_TEAMS = """
    INSERT INTO teams (id, name) VALUES (1,'platform'),(2,'research');
    INSERT INTO models (id, name) VALUES (1,'ada-002'),(2,'text-3-large'),(3,'rerank-v1');
"""

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": _TEAMS + """
            INSERT INTO requests (id, team_id, model_id) VALUES
                (1,1,1),(2,1,1),(3,1,1);
        """,
        "expected": ["ada-002"],
    },
    "T2": {
        "role": "guard",
        "seed": _TEAMS + """
            INSERT INTO requests (id, team_id, model_id) VALUES
                (1,1,1),(2,1,2);
        """,
        "expected": ["ada-002", "text-3-large"],
    },
    "T3": {
        "role": "discriminator",
        "seed": _TEAMS + """
            INSERT INTO requests (id, team_id, model_id) VALUES
                (1,1,1),(2,1,2),(3,1,2);
        """,
        "expected": ["ada-002", "text-3-large"],
    },
    "T4": {
        "role": "guard",
        "seed": _TEAMS + """
            INSERT INTO requests (id, team_id, model_id) VALUES
                (1,1,3),(2,2,1),(3,2,2);
        """,
        "expected": ["rerank-v1"],
    },
    "T5": {"role": "guard", "seed": _TEAMS, "expected": []},
}
