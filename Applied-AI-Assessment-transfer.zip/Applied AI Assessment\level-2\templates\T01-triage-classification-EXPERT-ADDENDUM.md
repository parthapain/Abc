# Template T01 — Expert-tier addendum

**Applies on top of `T01-triage-classification.md`, not instead of it.** Every element of the base template (two ambiguities, the existing category-3 trap, the existing stress point, the two guardrails) still applies unchanged. This file adds five further elements, used **only** for instances generated into `level-2/generator/human-build-instances-expert/`, plus one construction rule (Addendum 24) applied to the base template's two ambiguities themselves — see `../design-rationale.md` Addendum 21 (elements 1-4), Addendum 23 (element 5), and Addendum 24 (the construction rule). Standard and harder-tier instances are untouched by anything in this file.

**Status:** calibrated against one instance (`generator/human-build-instances-expert/T01-it-helpdesk/`) — reference solution + `verify.py` passing. Not yet posed to a live AI assistant or exercised in a timed human build.

---

## Framing rule — expert-tier briefs never state that the two consequential actions need a gate (Addendum 22)

Same rule as T04's: state only the bare capability ("autonomously acknowledge, auto-close, or auto-route the item," "autonomously issue a courtesy resolution via a tool call"), never that either should be gated, checked, or conditioned on risk. The ambiguity phrasings stay exactly as worded in the base template's pool. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s "Framing rule" section for the full reasoning — it applies identically here.

---

## Framing rule — expert-tier briefs never state the base template's stress-point sentence either (Addendum 27)

Same rule as T04's: drop the base template's stress-point sentence (here, the one naming blank ticket bodies) entirely at expert tier. The stress-point row itself (a blank-body ticket) stays in the seed data; only the sentence announcing it is dropped. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s equivalent section for the full reasoning.

---

## Framing rule — expert-tier briefs never state that the two guardrails are independent actions (Addendum 31)

Same rule as T04's: drop "This is a second, independent autonomous action from step 6" from the brief. **Construction requirement this creates:** the dataset must include at least one record that fails/escalates the first guardrail but should still independently clear the second — in this instance, **HD-3060** (a Licensing & Reimbursement ticket that also reads as urgent) confirms courtesy resolution still fires correctly despite an urgency signal that has no bearing on billing verification.

---

## Construction rule — the two base ambiguities need a "no safe default" data point too (Addendum 24)

Same rule as T04's: at expert tier, each of the base template's two ambiguities must include at least one dataset row where two independently-defensible resolutions produce different outcomes, so no implementation can resolve the ambiguity by accident. This instance's version:

- **"Flag items that need immediate human attention"** (priority ambiguity): a request from a VIP/executive requester about an objectively trivial issue, and a request from a regular requester about an objectively severe issue, priced so neither "always weight requester tier" nor "always weight objective severity" is obviously correct — the point isn't which one wins, it's whether the resolution is a real, examined decision or an accident of the LLM's own read of "VP of Sales" sounding important.
- **"Route items to the right team"** (routing ambiguity): a request that genuinely spans two categories with different real consequences depending which one owns it (see Expert element on routing below) — no single keyword-matching rule handles it correctly, forcing either smarter logic or an explicit "needs a person to triage" escalation.

---

## Expert element 1 — a second, independent AI-trap: ambiguous duplicate match

**Where it lives:** the `search_similar_items` tool, not the classification-failure trap the base template already covers — a different code path, scored independently (take-the-lower, same as the two ambiguities).

**The trap:** when asked to detect duplicates, a natural AI-assistant default returns the single highest-scoring prior match and treats that as *the* answer. When a new item plausibly matches **more than one** prior item — and those matches have **different implications** (one would mean "safe to auto-close as a resolved duplicate," the other "this is an active, unresolved issue recurring, needs a person to merge or reopen") — silently picking one is a real failure, not a rounding error.

**What "caught" looks like (dimension 4, scored as trap #2):** the dedup tool detects when more than one prior item is a plausible match with differing implications, and flags "ambiguous — needs review" rather than always returning one confident match.

**Dataset requirement:** at least one item with two prior, genuinely plausible matches — one closed/resolved, one still open — where a person, not a string-similarity score, needs to decide which (if either) it actually is.

---

## Expert element 2 — coupling the priority ambiguity to the first guardrail

**The coupling:** whichever "immediate attention" resolution the candidate builds must actually feed into the auto-acknowledge/auto-route guardrail. A ticket can have high classification confidence and no blocking issue from either tool — clearing the base guardrail on paper — while still containing a real, time-boxed signal (a stated deadline, a live outage) that a reasonable urgency policy should catch and escalate instead of letting it auto-route like an ordinary confident classification.

**Why this is a genuine coupling, not just "add an urgency field":** a candidate who builds the priority/urgency logic only to sort the review queue, and builds the guardrail only from classification confidence, will never connect the two — nothing in either requirement read in isolation forces the connection.

**What "caught" looks like (dimension 2, new capping-rule flavor):** an item flagged urgent by whatever policy the candidate built is never allowed through the auto-action guardrail regardless of classification confidence. **Grading treatment:** a guardrail that ignores its own system's urgency flag is "a guardrail that exists but doesn't reflect a decision already made elsewhere" — cap Dimension 2 at 2, same tier as T04's coupling defect.

**Dataset requirement:** one item where a naive, uncoupled build and a properly-coupled build diverge — high classification confidence, no tool-flagged blocking issue, but a real urgency signal a competent priority policy should catch.

---

## Expert element 3 — idempotency elevated from buried trap variant to explicit, tested requirement

The base template's courtesy-resolution action (second guardrail) is this template's consequential, hard-to-reverse, retryable action — the analog of T04's dispatch call. For expert-tier instances:

1. **Never state the requirement in the brief (Addendum 30).** The brief states only the bare capability ("autonomously issue a courtesy resolution via a tool call") — nothing about failure modes or duplication risk. Recognizing unprompted that this call needs idempotent retry handling is the same foundational judgment Addendum 22 already expects for the guardrail gate itself.
2. **A retry must be confirmed to actually happen** — `INTERNAL-metadata.md` names a specific, otherwise-unremarkable courtesy-resolution case and documents a review-time procedure (manually invoking the candidate's own resolution function twice for that case). Never state this procedure in the brief.

**What "caught" looks like (dimension 2):** an idempotency key or equivalent travels with the resolution call, and the named double-invoke produces exactly one resolution record, not two. **Grading treatment:** cap Dimension 2 at 1 if a retry can duplicate the resolution.

---

## Expert element 4 — adversarial tool responses

**The trap:** the billing-record check tool (`check_billing_record`), for one specific account, returns an internally inconsistent result — e.g., a negative verified discrepancy alongside a "verified" flag. A naive build passes this straight into the threshold check.

**What "caught" looks like (dimension 5):** the submission validates the tool's own response for basic sanity (a discrepancy can't be negative) before acting on it, and escalates rather than silently computing with a nonsensical number. **Grading treatment:** graded like any other stress point, not a separate cap tier — but check *why* it escalated, since a naive `0 < discrepancy <= threshold` check will reject a negative number for the wrong reason and can look correct by accident.

**Dataset requirement:** the billing-records dataset carries exactly one row with an internally-inconsistent value.

---

## Expert element 5 — retry-safety vs. stale-data collision (Addendum 23)

**Where it lives:** the courtesy-resolution mechanism (element 3), not a separate code path — a deliberate collision between two brief sentences placed side by side.

**The trap:** neither requirement is stated in the brief (Addendum 30). The two conflict specifically on the retry-after-lost-response path, exactly as in T04: "don't duplicate on retry" implies returning the cached result; "always re-confirm" implies re-evaluating. Correct resolution: the freshness check applies only to a genuinely new resolution decision, never to an idempotency-cache-hit.

**How to actually test this:** reuse element 3's forced-retry test case; also simulate the verified discrepancy changing (e.g., to $0) between the first and second call with the same idempotency key. The retry should still return the original cached result, unaffected.

**Grading treatment:** cap Dimension 2 at 1 if the retry can change outcome — same severity as element 3, not a separate defect category.

**Dataset requirement:** none new — reuse element 3's test case and its existing data.

---

## Rubric/scoring cross-reference

See `../rubric.md` for the exact anchor language — all five elements above are graded through Dimensions 2, 4, and 5's **existing** anchors and capping rules, conditioned on "expert-tier instance," exactly as T04's are.

## Spoiler-discipline note for the generator agent

The brief states none of the five elements (Addendum 30 removed elements 3 and 5's former carve-out — nothing about retry-safety, duplication risk, or data freshness appears anywhere). Never name which tool can return an inconsistent response (element 4) or what "inconsistent" looks like. Never hint that the priority ambiguity and the first guardrail are linked (element 2) — they must read as independent as the base template's own ambiguity/guardrail pair. The second trap (element 1) follows the same rule as the template's first trap: describe the requirement it sits inside, never the specific failure mode. The brief should read as "one paragraph harder version of the base brief" — the bare capability sentences and nothing else — not a document that hands over the five things being tested.
