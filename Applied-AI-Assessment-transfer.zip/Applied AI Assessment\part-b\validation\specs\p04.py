"""P04 — Unassigned documents. Medium · SQL-located · `= NULL` never matches."""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "equality comparison against NULL"}

SCHEMA = """
CREATE TABLE documents (
    id       INTEGER PRIMARY KEY,
    title    TEXT NOT NULL,
    owner_id INTEGER,          -- nullable: unassigned documents have no owner
    status   TEXT NOT NULL
);
"""

_BROKEN_SQL = """
    SELECT title
    FROM documents
    WHERE owner_id = NULL
      AND status = 'active'
    ORDER BY title
"""

_FIXED_SQL = _BROKEN_SQL.replace("owner_id = NULL", "owner_id IS NULL")


def broken(conn):
    return [r[0] for r in conn.execute(_BROKEN_SQL).fetchall()]


def fixed(conn):
    return [r[0] for r in conn.execute(_FIXED_SQL).fetchall()]


WRONG_FIXES = {
    "dropped the status filter": lambda conn: [
        r[0]
        for r in conn.execute(
            _FIXED_SQL.replace("AND status = 'active'", "")
        ).fetchall()
    ],
}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, owner_id, status) VALUES
                (1,'Orphan A', NULL, 'active'),
                (2,'Orphan B', NULL, 'active'),
                (3,'Owned',       7, 'active');
        """,
        "expected": ["Orphan A", "Orphan B"],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, owner_id, status) VALUES
                (1,'Alpha', 1, 'active'),
                (2,'Beta',  2, 'active');
        """,
        "expected": [],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, owner_id, status) VALUES
                (1,'Solo Orphan', NULL, 'active');
        """,
        "expected": ["Solo Orphan"],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, owner_id, status) VALUES
                (1,'Archived Orphan', NULL, 'archived');
        """,
        "expected": [],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
