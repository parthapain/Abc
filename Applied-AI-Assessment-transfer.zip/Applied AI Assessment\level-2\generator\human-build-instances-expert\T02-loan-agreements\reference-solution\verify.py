import db_models
import extraction_tools
import orchestrator

checks_passed = 0
checks_failed = 0


def check(label, condition):
    global checks_passed, checks_failed
    if condition:
        checks_passed += 1
        print(f"[PASS] {label}")
    else:
        checks_failed += 1
        print(f"[FAIL] {label}")


db_models.reset_db()
docs = orchestrator.load_primary_documents()

check("all 11 primary loan agreements discovered (2 from the concatenated file)", len(docs) == 11)

results = {loan_number: orchestrator.process_document(loan_number, raw_text) for loan_number, raw_text in docs.items()}

# --- Ambiguity 1 / party normalization (Addendum 24) ---
check("LN-7003 borrower_name resolves to the recitals spelling, not the signature-block spelling",
      results["LN-7003"]["borrower_name"] == "Halloway Marine Holdings, Inc.")
check("LN-7003 still commits despite the name divergence (divergence is documented, not blocking)",
      results["LN-7003"]["final_status"] == "COMMITTED")

# --- Ambiguity 2 / relative-date resolution divergence pair (Addendum 24) ---
check("LN-7001 maturity resolves locally (60 months after its own stated Closing Date)",
      results["LN-7001"]["maturity_date"] == "2031-01-15" and results["LN-7001"]["maturity_status"] == "RESOLVED_LOCAL")
check("LN-7002 maturity resolves via external lookup (Promissory Note), not left unresolved",
      results["LN-7002"]["maturity_date"] == "2030-06-30" and results["LN-7002"]["maturity_status"] == "RESOLVED_LOOKUP")
check("LN-7001 and LN-7002 both commit -- a single fixed rule (always/never look up) would get one of these wrong",
      results["LN-7001"]["final_status"] == "COMMITTED" and results["LN-7002"]["final_status"] == "COMMITTED")

# --- Expert element 1: ambiguous cross-document reference ---
check("LN-7004 flags its Promissory Note reference as ambiguous (two notes on file), not silently picking one",
      results["LN-7004"]["maturity_status"] == "AMBIGUOUS" and results["LN-7004"]["maturity_date"] is None)

# --- Expert element 2: coupling -- ambiguous field must not reach auto-commit ---
check("LN-7004 does NOT commit despite otherwise-clean principal/interest fields (coupling holds)",
      results["LN-7004"]["final_status"] == "ESCALATED_REVIEW")

# --- Base template trap: hallucination-on-absence ---
check("LN-7005 interest_rate is reported absent (None), not invented",
      results["LN-7005"]["interest_rate"] is None)
check("LN-7005 does not commit (missing field blocks auto-commit)",
      results["LN-7005"]["final_status"] == "ESCALATED_REVIEW")

# --- Base template stress point: concatenated multi-document file ---
check("LN-7006 (first doc in the concatenated file) extracted and committed correctly",
      results["LN-7006"]["principal_amount"] == 700000.0 and results["LN-7006"]["final_status"] == "COMMITTED")
check("LN-7007 (second doc in the concatenated file) extracted and committed correctly, not merged with LN-7006",
      results["LN-7007"]["principal_amount"] == 1050000.0 and results["LN-7007"]["final_status"] == "COMMITTED")

# --- Expert element 4: adversarial tool response ---
check("LN-7010's interest_rate is NOT trusted despite verify_against_source claiming grounded=True (no matched_text)",
      results["LN-7010"]["final_status"] == "ESCALATED_REVIEW")

# --- Plain control records ---
check("LN-7008 (plain control, used for the retry test below) commits normally",
      results["LN-7008"]["final_status"] == "COMMITTED")
check("LN-7011 (plain control) commits normally",
      results["LN-7011"]["final_status"] == "COMMITTED")
check("LN-7009 (plain control, missing status row) commits normally",
      results["LN-7009"]["final_status"] == "COMMITTED")

# --- Second guardrail: status-gated follow-up, tested in 3 directions ---
status1, logs1 = orchestrator.process_followup("LN-7001")
check("LN-7001 (verified active) generates a follow-up", status1 == "FOLLOWUP_GENERATED")

status2, logs2 = orchestrator.process_followup("LN-7002")
check("LN-7002 (verified refinanced) does NOT generate a follow-up, even though its own document alone looks eligible",
      status2 == "SKIPPED_NOT_ACTIVE")

status3, logs3 = orchestrator.process_followup("LN-7003")
check("LN-7003 (verified paid_off) does NOT generate a follow-up", status3 == "SKIPPED_NOT_ACTIVE")

status9, logs9 = orchestrator.process_followup("LN-7009")
check("LN-7009 (no verified status on file) does NOT generate a follow-up -- not assumed active", status9 == "SKIPPED_NO_STATUS")

# --- Addendum 31: the two guardrails are independent (LN-7005) -----------
status5, logs5 = orchestrator.process_followup("LN-7005")
check("LN-7005 (failed the commit guardrail on a missing interest_rate) still gets its maturity follow-up evaluated independently, and generated",
      status5 == "FOLLOWUP_GENERATED")

# --- Expert elements 3 & 5: retry-safety and the stale-status collision ---
loan_number = "LN-7008"
key = orchestrator.make_idempotency_key(loan_number)

try:
    extraction_tools.generate_followup(loan_number, key, force_lost_response=True)
    raised_on_first_call = False
except extraction_tools.TransientFollowupError:
    raised_on_first_call = True
check("First follow-up attempt for LN-7008 raises a transient error (simulating a lost response)", raised_on_first_call)

first_retry = extraction_tools.generate_followup(loan_number, key)
check("Retry after the lost response still resolves to SUCCESS via the idempotency cache",
      first_retry["status"] == "SUCCESS")

is_new_1 = db_models.record_followup(loan_number, key, first_retry["followup_id"])
check("Exactly one follow-up record created after the forced lost-response retry", is_new_1 is True)

second_retry = extraction_tools.generate_followup(loan_number, key)
is_new_2 = db_models.record_followup(loan_number, key, second_retry["followup_id"])
check("A second manual retry with the same idempotency key returns the identical cached result, not a new one",
      second_retry["followup_id"] == first_retry["followup_id"] and is_new_2 is False)

extraction_tools.set_live_status(loan_number, "refinanced")
third_retry = extraction_tools.generate_followup(loan_number, key)
check("Idempotency-cache-hit retry ignores the now-changed status and returns the original cached result, untouched",
      third_retry["followup_id"] == first_retry["followup_id"])

print(f"\n{checks_passed}/{checks_passed + checks_failed} checks passed")
