# Build Brief — IT Helpdesk Triage & Resolution

Your organization receives a continuous stream of IT helpdesk requests. Build an application that:

1. Ingests helpdesk requests (seed datasets are provided — `helpdesk_tickets.csv` and `license_billing_records.csv`)
2. Uses the in-house LLM to classify each one into the categories: Hardware, Software Access, Network/VPN, Licensing & Reimbursement, Security Incident
3. Works as an agent, not a single call: after classifying, check for duplicate or related history on the item via a tool, and pull additional context via a second tool if the classification is uncertain — then decide how to proceed
4. **Flag requests that need immediate human attention.**
5. **Route requests to the right team.**
6. Autonomously acknowledge, auto-close (if a genuine duplicate), or auto-route the item via a tool call.
7. **Separately, for requests classified as Licensing & Reimbursement where the requester describes a specific, checkable discrepancy: check the real billing record via a tool, and if it confirms the discrepancy below a small threshold, autonomously issue a courtesy resolution via a tool call.**
8. Provides a UI where a human can review classifications, any automatic actions taken (routing/acknowledgment *and* any courtesy resolutions), see the LLM's reasoning, and override them
9. Persists requests, their classifications, actions taken (including any courtesy resolutions), and any human overrides to a database

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24 hours.
