# P15 — Documents awaiting embedding

| Field | Value |
|---|---|
| **ID** | P15 |
| **Difficulty** | High |
| **Bug pattern** | `NOT IN` over a nullable column |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Paper** | 6 (with P09) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A backfill job asks which documents still have no embedding, then queues them for processing.

The job has quietly stopped queueing anything. It reports zero documents awaiting embedding, while the backlog is visibly growing. It worked correctly until recently.

### Required behaviour

Return the `title` of every document that has **no** row in `embeddings` referencing it, ordered by `title` ascending.

### Schema

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE embeddings (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER REFERENCES documents(id),   -- nullable
    vector_ref  TEXT NOT NULL
);
```

Note that `embeddings.document_id` is nullable. A failed or orphaned embedding job can leave a row whose `document_id` is `NULL`.

---

## Fixture — `P15.sql`

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE embeddings (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER REFERENCES documents(id),
    vector_ref  TEXT NOT NULL
);

INSERT INTO documents (id, title) VALUES
    (1,'Embedded Doc'),
    (2,'Pending Doc'),
    (3,'Another Pending');

INSERT INTO embeddings (id, document_id, vector_ref) VALUES
    (1, 1,    'vec-1'),
    (2, NULL, 'vec-orphan');   -- orphaned row: this is what breaks the report
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def awaiting_embedding(db_path: str) -> List[str]:
    """
    Return the title of every document with no row in embeddings
    referencing it, ordered by title ascending.
    """
    query = """
        SELECT d.title
        FROM documents d
        WHERE d.id NOT IN (SELECT document_id FROM embeddings)
        ORDER BY d.title
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class BackfillQueue {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return the title of every document with no row in embeddings
     * referencing it, ordered by title ascending.
     */
    public static List<String> awaitingEmbedding(String dbPath) throws SQLException {
        String query =
            "SELECT d.title " +
            "FROM documents d " +
            "WHERE d.id NOT IN (SELECT document_id FROM embeddings) " +
            "ORDER BY d.title";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(rs.getString("title"));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class BackfillQueue
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return the title of every document with no row in embeddings
    /// referencing it, ordered by title ascending.
    /// </summary>
    public static List<string> AwaitingEmbedding(string dbPath)
    {
        const string query = @"
            SELECT d.title
            FROM documents d
            WHERE d.id NOT IN (SELECT document_id FROM embeddings)
            ORDER BY d.title";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 3 docs; doc 1 embedded; one orphaned `NULL` row | `["Another Pending", "Pending Doc"]` | **Discriminator** — broken returns `[]` |
| T2 | 2 docs; doc 1 embedded; **no** `NULL` rows | `["Pending Doc"]` | Guard — without a `NULL` present, `NOT IN` behaves correctly |
| T3 | 2 docs; embeddings contains only an orphaned `NULL` row | `["Alpha", "Beta"]` | **Discriminator** — broken returns `[]` |
| T4 | 2 docs, both embedded, no `NULL`s | `[]` | Guard |
| T5 | 1 doc, embeddings table empty | `["Solo"]` | Guard — `NOT IN` over an empty set is true for every row |

### Fixtures

```sql
-- T2
INSERT INTO documents  (id, title) VALUES (1,'Embedded Doc'),(2,'Pending Doc');
INSERT INTO embeddings (id, document_id, vector_ref) VALUES (1, 1, 'vec-1');

-- T3
INSERT INTO documents  (id, title) VALUES (1,'Alpha'),(2,'Beta');
INSERT INTO embeddings (id, document_id, vector_ref) VALUES (1, NULL, 'vec-orphan');

-- T4
INSERT INTO documents  (id, title) VALUES (1,'Alpha'),(2,'Beta');
INSERT INTO embeddings (id, document_id, vector_ref) VALUES (1, 1, 'vec-1'), (2, 2, 'vec-2');

-- T5
INSERT INTO documents (id, title) VALUES (1,'Solo');
```

---

## Reference solution

Replace `NOT IN` with `NOT EXISTS`.

```diff
  SELECT d.title
  FROM documents d
- WHERE d.id NOT IN (SELECT document_id FROM embeddings)
+ WHERE NOT EXISTS (
+     SELECT 1 FROM embeddings e WHERE e.document_id = d.id
+ )
  ORDER BY d.title
```

Adding `WHERE document_id IS NOT NULL` to the subquery also works and should be accepted. An anti-join (`LEFT JOIN ... WHERE e.id IS NULL`) is likewise correct.

### Why

`x NOT IN (a, b, NULL)` expands to `x <> a AND x <> b AND x <> NULL`. The final comparison is `UNKNOWN` rather than false — SQL cannot assert that a value differs from something unknown. `AND` with `UNKNOWN` can never yield true, so the whole predicate is at best `UNKNOWN` for **every** row, and `WHERE` keeps only rows that are definitively true.

The result: a single `NULL` anywhere in the subquery silently empties the entire result set. Not one row, not the orphaned document — all of them.

`NOT EXISTS` is immune because it tests whether a matching row was *found*, which is always a definite true or false, never unknown.

This is also why the report "worked until recently": the query was correct for as long as no `NULL` ever appeared. The first orphaned embedding row broke every document at once, with no error and no partial result to hint at the cause.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `LEFT JOIN embeddings` with no `IS NULL` check on the join result | T2, T4 — returns every document, including embedded ones |
| `NOT IN (SELECT COALESCE(document_id, -1) ...)` | Works here, but is fragile if a real id is ever negative — flag in review |
| Filtering `NULL` rows out in host code after the query returns | T1, T3 — the query already returned nothing to filter |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is an empty result set, not a SQL error — the silence is the point
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] `embeddings.document_id` is genuinely nullable in the fixture schema — with a `NOT NULL` constraint this problem does not exist
- [ ] Both `NOT EXISTS` and `IS NOT NULL` fixes are accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
