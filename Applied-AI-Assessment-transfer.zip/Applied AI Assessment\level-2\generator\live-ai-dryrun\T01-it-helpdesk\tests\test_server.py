from app import database as db
from app import server


def make_client():
    app = server.create_app()
    app.config["TESTING"] = True
    return app.test_client()


def test_list_and_get_ticket(temp_db):
    db.upsert_ticket("HD-1", "Someone", "Standard", "new", "2026-09-14T09:00:00Z", "My laptop won't turn on.")
    db.add_classification("HD-1", "Hardware", 0.9, "matched laptop", uncertain=False)

    client = make_client()
    resp = client.get("/api/tickets")
    assert resp.status_code == 200
    data = resp.get_json()
    assert len(data) == 1
    assert data[0]["ticket"]["ticket_id"] == "HD-1"

    resp2 = client.get("/api/tickets/HD-1")
    assert resp2.status_code == 200
    assert resp2.get_json()["classification"]["category"] == "Hardware"

    resp3 = client.get("/api/tickets/NOPE")
    assert resp3.status_code == 404


def test_category_override_persists_and_logs(temp_db):
    db.upsert_ticket("HD-1", "Someone", "Standard", "new", "2026-09-14T09:00:00Z", "Vague issue.")
    db.add_classification("HD-1", "Hardware", 0.4, "weak signal", uncertain=True)

    client = make_client()
    resp = client.post("/api/tickets/HD-1/override", json={
        "field": "category", "new_value": "Software Access", "note": "Actually a permissions issue.",
    })
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["classification"]["category"] == "Software Access"
    assert len(body["overrides"]) == 1
    assert body["overrides"][0]["old_value"] == "Hardware"
    assert any(a["actor"] == "human" for a in body["actions"])


def test_override_rejects_invalid_category(temp_db):
    db.upsert_ticket("HD-1", "Someone", "Standard", "new", "2026-09-14T09:00:00Z", "Issue.")
    client = make_client()
    resp = client.post("/api/tickets/HD-1/override", json={
        "field": "category", "new_value": "Not A Real Category",
    })
    assert resp.status_code == 400


def test_status_override_reopens_ticket(temp_db):
    db.upsert_ticket("HD-1", "Someone", "Standard", "closed", "2026-09-14T09:00:00Z", "Issue.")
    client = make_client()
    resp = client.post("/api/tickets/HD-1/override", json={
        "field": "status", "new_value": "new", "note": "Reopening.",
    })
    assert resp.status_code == 200
    assert db.get_ticket("HD-1")["status"] == "new"
