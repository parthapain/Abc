"""
Integration tests for the agent loop, tools, and persistence, run against a
throwaway SQLite DB (redirects db.DB_PATH before importing agent/tools so
nothing here touches rental_fulfillment.db).
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import db

# Redirect to a temp DB file before any other module opens a connection.
_tmpdir = tempfile.TemporaryDirectory()
db.DB_PATH = Path(_tmpdir.name) / "test.db"

import agent  # noqa: E402
import tools  # noqa: E402
import init_data  # noqa: E402

BASE = Path(__file__).parent.parent


def setup_module(_module):
    db.init_db(reset=True)
    catalog_rows = init_data.read_csv("equipment_catalog.csv")
    alt_rows = init_data.read_csv("alt_yard_inventory.csv")
    db.load_catalog_rows(catalog_rows)
    db.load_alt_yard_rows(alt_rows)


def make_order(order_id, client_name, client_type, desc):
    db.upsert_order(order_id, client_name, client_type, "2026-09-14T08:00:00Z", desc)


def test_fully_stocked_order_auto_dispatches():
    make_order("T-1", "Test Corp", "recurring corporate account", "1x PA System - Basic")
    result = agent.process_order("T-1")
    assert result["auto_dispatch_eligible"] is True
    assert result["risk_level"] == "low"
    order = db.get_order("T-1")
    assert order["status"] == "processed_auto_dispatched"
    actions = db.get_dispatch_actions("T-1")
    assert any(a["action_type"] == "dispatch" for a in actions)


def test_out_of_stock_item_with_alt_yard_coverage_reroutes_and_dispatches():
    # EQ-102 (Concrete Mixer - 6cu ft) has 0 primary stock but 6 at alt yard.
    make_order("T-2", "Test Corp", "recurring corporate account", "2x Concrete Mixer - 6cu ft")
    result = agent.process_order("T-2")
    actions = db.get_dispatch_actions("T-2")
    reroutes = [a for a in actions if a["action_type"] == "reroute"]
    assert len(reroutes) == 1
    assert reroutes[0]["sku"] == "EQ-102"
    assert reroutes[0]["qty"] == 2
    # Fully covered via reroute -> should still be low risk / auto-dispatched
    assert result["auto_dispatch_eligible"] is True
    dispatches = [a for a in actions if a["action_type"] == "dispatch"]
    assert len(dispatches) == 1  # outbound dispatch leg logged for the alt-yard-sourced quantity
    assert dispatches[0]["source_yard"] == "alt"


def test_item_out_of_stock_everywhere_is_backordered_and_needs_review():
    # EQ-108 (Pressure Washer - Commercial) is 0 at primary and not in alt yard file at all... wait it IS in alt file with 0.
    make_order("T-3", "Test Corp", "recurring corporate account", "1x Pressure Washer - Commercial")
    result = agent.process_order("T-3")
    assert result["auto_dispatch_eligible"] is False
    assert "backordered" in " ".join(result["risk_reasons"]).lower() or any(
        "backorder" in r.lower() for r in result["risk_reasons"]
    )
    order = db.get_order("T-3")
    assert order["status"] == "processed_needs_review"


def test_ambiguous_item_flagged_for_review_not_auto_dispatched():
    make_order("T-4", "Test Corp", "recurring corporate account", "3x Concrete Mixer")
    result = agent.process_order("T-4")
    line_items = db.get_line_items("T-4")
    assert any(li["ambiguous"] for li in line_items)
    assert result["auto_dispatch_eligible"] is False


def test_high_value_one_off_order_flagged_despite_full_stock():
    # 10x PA System Basic @ $175/day = $1750/day, one-off event, over the $1500 threshold.
    make_order("T-5", "Some Wedding", "one-off event", "10x PA System - Basic")
    result = agent.process_order("T-5")
    assert result["auto_dispatch_eligible"] is False
    assert any("one-off" in r.lower() for r in result["risk_reasons"])


def test_negative_alt_stock_is_clamped_not_negative_reroute():
    call = tools.check_alt_yard("EQ-110", 5)  # EQ-110 has alt_stock -2 in seed data
    assert call.output["alt_available"] == 0
    assert call.output["alt_available"] >= 0


def test_human_override_updates_line_item_and_is_logged():
    make_order("T-6", "Test Corp", "recurring corporate account", "3x Concrete Mixer")
    agent.process_order("T-6")
    li = db.get_line_items("T-6")[0]
    db.log_override("T-6", "reconciliation", li["resolved_sku"], "EQ-101",
                     note="test override", line_item_id=li["id"])
    db.set_line_item_override_sku(li["id"], "EQ-101", "Concrete Mixer - 3.5cu ft", 85)
    updated = db.get_line_item(li["id"])
    assert updated["resolved_sku"] == "EQ-101"
    assert updated["ambiguous"] == 0
    overrides = db.get_overrides("T-6")
    assert len(overrides) == 1


def test_full_seed_orders_process_without_errors():
    db.init_db(reset=True)
    init_data.main(reset=False)
    results = agent.process_all_pending()
    assert len(results) == 11  # 11 seed orders
    for r in results:
        order = db.get_order(r["order_id"])
        assert order["status"] in (
            "processed_auto_dispatched", "processed_needs_review",
        )
