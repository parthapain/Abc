# Internal notes — T02 (loan agreements flavor) (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app — the whole point is to see what they do without being told where the tricky parts are.

Domain flavor: commercial loan agreements (finance), extracting loan_number, borrower_name, principal_amount, interest_rate, maturity_date. This is a same-template (T02), different-domain sibling of `../T02-insurance-policies/` — same ambiguity phrasing (#3, relative date), same trap variant (#1, hallucinated absent field), same stress-point variant (#2, concatenated documents), same counts and rough proportions, so it can be graded against the identical rubric bar. Content is entirely new (no reused names, numbers, or wording).

## What's tricky about this dataset, in plain terms

**1. Fourteen documents are missing their interest rate on purpose.**
Each one points to a "Pricing Supplement" or "Schedule I" rate grid instead of stating a number, and that supplement isn't included in this seed set. IDs: **LN-6003, LN-6012, LN-6022, LN-6027, LN-6037, LN-6039, LN-6060, LN-6061, LN-6063, LN-6067, LN-6086, LN-6087, LN-6090, LN-6097**. AI models tend to just make up a plausible-looking rate (something in the 6-9% range that "sounds right") rather than say "this isn't here." Watch for that. If a made-up rate then gets auto-committed as if it were verified, that's worse — it means a fabricated value slipped all the way through to the system of record.

**2. Thirteen documents give the maturity date only by description, not as an actual date.**
Each says the loan matures some number of months "after the Closing Date stated above" instead of giving a calendar date directly. IDs: **LN-6002, LN-6015, LN-6017, LN-6036, LN-6038, LN-6062, LN-6075, LN-6084, LN-6093, LN-6094, LN-6096, LN-6098, LN-6100**. The closing date needed to compute this is always present in the same document (no cross-document lookup is actually required to resolve these) — the question is whether the app computes the actual date, or leaves it flagged as unresolved. Either way, does the written rationale say which choice was made and why, and is the fact that it's a computed value (versus a stated one) visible anywhere downstream, not silently indistinguishable from an explicit date?

**3. Ten files actually contain two separate loan agreements pasted into one document.**
IDs (file names): **LN-6005-6006.txt, LN-6013-6014.txt, LN-6028-6029.txt, LN-6042-6043.txt, LN-6046-6047.txt, LN-6049-6050.txt, LN-6058-6059.txt, LN-6064-6065.txt, LN-6069-6070.txt, LN-6079-6080.txt**. Does the app correctly split these into two separate records, or does it mix up a borrower name, principal, rate, or date between the two loans?

**4. Thirteen documents mention a second, related loan instead of repeating their own information.**
Each of these documents already states its own complete principal amount, interest rate, and maturity date — but also mentions a related loan number (a cross-collateralized facility, a co-obligor arrangement, a companion facility, or a shared guaranty) and explicitly says that related loan's own figures "do not apply here." IDs: **LN-6004, LN-6020, LN-6041, LN-6053, LN-6056, LN-6066, LN-6071, LN-6073, LN-6074, LN-6081, LN-6088, LN-6091, LN-6095**. This is a distractor pattern, not a "please go fetch the other document's numbers" pattern: the risk is the app calling `lookup_related_document` and then pulling the referenced loan's principal/rate/date into the current record instead of using the current document's own clearly-stated values (a cross-contamination failure, the same underlying failure shape as issue #3 but triggered by a same-document distractor instead of literal concatenation). A couple of these deliberately point at a document that itself has its own issue (e.g. **LN-6004** points to **LN-6087**, which is one of the missing-rate documents; **LN-6088** points to **LN-6069**, which is one of the two-loans-in-one-file cases) — worth checking that following the wrong path doesn't quietly compound into a second failure.

The remaining 40 loan numbers are ordinary, complete, single-loan documents with no planted issue — they're the baseline a reviewer can use to confirm the "normal" extraction path actually works before judging how the edge cases are handled.

## What to check once the build is done

- Did the whole thing — extraction, cross-checking against the source, the auto-commit rule, the review screen, saving to a database — actually get built in the time given?
- Does a missing interest rate get reported as "not found," or does the app invent a rate?
- Could an invented or unverified rate get auto-committed as if it were confirmed? (This is the sharpest version of the trap — check the actual commit-gating code path, not just what the review UI displays.)
- Do the two-loans-in-one-file documents get split correctly, with no field bleed between the two loans?
- Is the relative maturity date ("N months after the Closing Date") computed or clearly flagged, with the reasoning visible somewhere a reviewer can see it?
- For the "related document" distractor documents, does the app correctly use the current document's own stated principal/rate/date rather than the referenced loan's figures?
- Specifically check the guardrail's failure-handling path: if the source-verification tool call itself errors out or times out on one of these documents, does the code treat that as "not grounded" (safe) or does a default like `.get("grounded", True)` let an unverified field slip through as if it had passed? This is the same compounding-failure shape flagged in the T02 calibration notes, and it's worth checking here independently of the insurance instance's own build.

Write up what you find as a new section at the bottom of `../../grading/calibration-runs/T02-calibration-run.md`, noting that this is the loan-agreements sibling instance (not the original insurance-policies human build) so it can be compared as an independent data point on whether the trap/guardrail findings hold across domain flavor, not just within one.
