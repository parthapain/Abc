"""
Simulated fulfillment-dispatch service.

Real infrastructure characteristics on purpose:
- can fail transiently (timeout) or permanently (genuinely unavailable item)
- occasionally reports a failure for a call that actually succeeded server-side
  (the idempotency trap this instance requires handling correctly)
"""
import random
import time
import pandas as pd

class TransientDispatchError(Exception):
    """Worth retrying — a timeout or temporary hiccup."""

class PermanentDispatchError(Exception):
    """Not worth retrying — the item is genuinely unavailable."""

# server-side truth: idempotency_key -> dispatch record, independent of
# whether the CALLER ever heard back about it. This is what makes a
# "lost response" scenario distinguishable from "never actually happened".
_server_side_dispatches = {}

# Live primary-yard stock, separate from the static catalog CSV, so a test
# can simulate stock changing *after* an order was reconciled but before (or
# between) dispatch attempts -- this is what the brief's "always re-confirm
# current stock before dispatching" sentence refers to.
_live_primary_stock = pd.read_csv("equipment_catalog.csv").set_index("sku")["in_stock"].to_dict()

def set_live_primary_stock(sku, qty):
    """Test-only hook: simulate primary-yard stock changing between calls."""
    _live_primary_stock[sku] = qty

# SKUs that are permanently unavailable everywhere (used by the reconciled
# reference solution to simulate a genuine PermanentDispatchError case;
# nothing in this seed dataset actually reaches this branch since every
# permanently-out-of-stock item in this instance is caught upstream by the
# guardrails before a dispatch call would ever be attempted for it).
_PERMANENTLY_UNAVAILABLE_SKUS = set()

def dispatch_fulfillment(order_id, items, idempotency_key, force_lost_response=False):
    """
    idempotency_key must be the SAME value for logically-the-same dispatch
    attempt across retries, so a retried call can recognize prior success.

    force_lost_response: test-only hook. When True, simulates the server
    having already completed the dispatch on a PRIOR call, but the response
    to THAT call never reached the caller — so this call should tell the
    truth (already done) rather than re-executing.
    """
    if idempotency_key in _server_side_dispatches:
        # Already actually happened server-side. Whether this is a genuine
        # retry-after-lost-response or a second legitimate call, the answer
        # is the same: don't do it again, just return what already happened.
        #
        # Deliberately checked BEFORE the live-stock re-confirmation below.
        # The brief also says to "always re-confirm current stock before
        # dispatching" -- but that applies to a genuinely NEW dispatch
        # decision, not to a cache hit. A cache hit isn't a new decision at
        # all; it's reporting what already happened. Re-checking stock here
        # would let stock that changed *after* the original dispatch already
        # succeeded silently overturn an action that's already done --
        # exactly the retry-safety guarantee this instance tests for.
        return _server_side_dispatches[idempotency_key]

    # Fresh dispatch attempt only (never reached on a cache hit above): this
    # is where "always re-confirm current stock" actually applies.
    for item in items:
        sku = item.get("sku")
        needed = item.get("qty", 0)
        if sku and _live_primary_stock.get(sku, 0) < needed:
            raise PermanentDispatchError(
                f"SKU {sku}: primary stock changed before dispatch could complete "
                f"(now {_live_primary_stock.get(sku, 0)}, needed {needed})."
            )

    for item in items:
        if item.get("sku") in _PERMANENTLY_UNAVAILABLE_SKUS:
            raise PermanentDispatchError(f"SKU {item['sku']} is permanently unavailable.")

    if force_lost_response:
        # The action succeeds server-side, but we simulate the response
        # never reaching the caller (as if this were a real timeout) --
        # the NEXT call with the same idempotency_key is the one that
        # will actually observe success, from the cache above.
        result = {"status": "success", "dispatch_id": f"DSP-{order_id}-{int(time.time())}"}
        _server_side_dispatches[idempotency_key] = result
        raise TransientDispatchError("Connection timed out to yard dispatch API (response lost).")

    if random.random() < 0.1:
        raise TransientDispatchError("Connection timed out to yard dispatch API.")

    result = {"status": "success", "dispatch_id": f"DSP-{order_id}-{int(time.time())}"}
    _server_side_dispatches[idempotency_key] = result
    return result
