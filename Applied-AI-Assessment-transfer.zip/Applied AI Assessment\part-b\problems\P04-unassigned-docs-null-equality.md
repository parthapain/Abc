# P04 — Unassigned documents

| Field | Value |
|---|---|
| **ID** | P04 |
| **Difficulty** | Medium |
| **Bug pattern** | Equality comparison against `NULL` |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 9–12 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

An admin screen lists active documents that have no owner assigned, so they can be routed to someone.

The list is always empty, even though unassigned documents demonstrably exist in the table.

### Required behaviour

Return the `title` of every document where `owner_id` is unset **and** `status` is `'active'`, ordered by `title` ascending.

### Schema

```sql
CREATE TABLE documents (
    id       INTEGER PRIMARY KEY,
    title    TEXT NOT NULL,
    owner_id INTEGER,           -- nullable: unassigned documents have no owner
    status   TEXT NOT NULL
);
```

---

## Fixture — `P04.sql`

```sql
CREATE TABLE documents (
    id       INTEGER PRIMARY KEY,
    title    TEXT NOT NULL,
    owner_id INTEGER,
    status   TEXT NOT NULL
);

INSERT INTO documents (id, title, owner_id, status) VALUES
    (1,'Orphan A', NULL, 'active'),
    (2,'Orphan B', NULL, 'active'),
    (3,'Owned',       7, 'active');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def unassigned_documents(db_path: str) -> List[str]:
    """
    Return the title of every active document with no owner assigned,
    ordered by title ascending.
    """
    query = """
        SELECT title
        FROM documents
        WHERE owner_id = NULL
          AND status = 'active'
        ORDER BY title
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class OwnerAudit {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return the title of every active document with no owner assigned,
     * ordered by title ascending.
     */
    public static List<String> unassignedDocuments(String dbPath) throws SQLException {
        String query =
            "SELECT title " +
            "FROM documents " +
            "WHERE owner_id = NULL " +
            "  AND status = 'active' " +
            "ORDER BY title";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(rs.getString("title"));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class OwnerAudit
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return the title of every active document with no owner assigned,
    /// ordered by title ascending.
    /// </summary>
    public static List<string> UnassignedDocuments(string dbPath)
    {
        const string query = @"
            SELECT title
            FROM documents
            WHERE owner_id = NULL
              AND status = 'active'
            ORDER BY title";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 2 unassigned active docs, 1 owned | `["Orphan A", "Orphan B"]` | **Discriminator** — broken returns `[]` |
| T2 | Every document has an owner | `[]` | Guard — empty is genuinely correct here |
| T3 | One unassigned active doc | `["Solo Orphan"]` | **Discriminator** — broken returns `[]` |
| T4 | One unassigned doc, but `archived` | `[]` | Guard — catches removal of the status filter |
| T5 | Empty table | `[]` | Guard |

> Three of the five cases legitimately expect `[]`. That is deliberate: the broken query returns `[]` for every input, so the suite must prove that an empty result is sometimes *right*, reached by the right path. T1 and T3 then prove it is sometimes wrong.

### Fixtures

```sql
-- T2
INSERT INTO documents (id, title, owner_id, status) VALUES (1,'Alpha',1,'active'),(2,'Beta',2,'active');
-- T3
INSERT INTO documents (id, title, owner_id, status) VALUES (1,'Solo Orphan',NULL,'active');
-- T4
INSERT INTO documents (id, title, owner_id, status) VALUES (1,'Archived Orphan',NULL,'archived');
```

---

## Reference solution

```diff
  FROM documents
- WHERE owner_id = NULL
+ WHERE owner_id IS NULL
    AND status = 'active'
```

### Why

`NULL` is not a value — it is the absence of one. `owner_id = NULL` therefore asks "is this unknown quantity equal to another unknown quantity?", which SQL answers `UNKNOWN` rather than true or false. `WHERE` keeps only rows that evaluate to definitively true, so no row ever qualifies.

Crucially this is **not a syntax error**. The query is valid, runs without complaint, and returns an empty set — which reads as "there is nothing to assign" rather than "this filter can never match." That is why the screen looks merely empty rather than broken.

`IS NULL` is the dedicated test for absence and is the only correct way to express this.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `WHERE owner_id != NULL` or `<> NULL` | T1, T3 — same `UNKNOWN` problem, still empty |
| Dropping the status filter while fixing the null test | T4 — the archived document appears |
| `WHERE COALESCE(owner_id, -1) = -1` | Works, but breaks if `-1` is ever a real id — flag in review |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is an empty result, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Confirm no engine setting (e.g. ANSI null handling) makes `= NULL` behave like `IS NULL` in the sandbox
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
