# P10 — Average relevance score

| Field | Value |
|---|---|
| **ID** | P10 |
| **Difficulty** | Medium |
| **Bug pattern** | Missing value treated as zero |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A retrieval-quality dashboard reports the average relevance score across evaluated queries. Some queries have not been scored yet and carry a null score.

The reported average is far lower than the scores anyone can see in the table, and it drops further every time a new unscored query is added.

### Required behaviour

Return the mean `score` across evaluations, rounded to 2 decimal places.

- Rows whose score is not yet set are **excluded from the calculation entirely** — they are not zeros.
- If no row has a score, return `None` / `null`.

### Schema

```sql
CREATE TABLE evaluations (
    id    INTEGER PRIMARY KEY,
    query TEXT NOT NULL,
    score INTEGER            -- nullable: NULL means "not yet scored"
);
```

---

## Fixture — `P10.sql`

```sql
CREATE TABLE evaluations (
    id    INTEGER PRIMARY KEY,
    query TEXT NOT NULL,
    score INTEGER
);

INSERT INTO evaluations (id, query, score) VALUES
    (1,'a',80),
    (2,'b',90),
    (3,'c',NULL);   -- unscored: must not count as 0
```

---

## Broken code

### Python

```python
import sqlite3
from typing import Optional

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def average_score(db_path: str) -> Optional[float]:
    """
    Mean score across evaluations, rounded to 2 dp.
    Unscored rows are excluded. Returns None if nothing is scored.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute("SELECT score FROM evaluations ORDER BY id").fetchall()
    finally:
        conn.close()

    scores = [row[0] if row[0] is not None else 0 for row in rows]
    if not scores:
        return None
    return round(sum(scores) / len(scores), 2)
```

### Java

```java
import java.sql.*;
import java.util.*;

public class QualityReport {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Mean score across evaluations, rounded to 2 dp.
     * Unscored rows are excluded. Returns null if nothing is scored.
     */
    public static Double averageScore(String dbPath) throws SQLException {
        List<Integer> scores = new ArrayList<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT score FROM evaluations ORDER BY id")) {
            while (rs.next()) {
                int value = rs.getInt("score");
                scores.add(rs.wasNull() ? 0 : value);
            }
        }

        if (scores.isEmpty()) {
            return null;
        }
        double sum = scores.stream().mapToInt(Integer::intValue).sum();
        return Math.round(sum / scores.size() * 100.0) / 100.0;
    }
}
```

### C#

```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class QualityReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Mean score across evaluations, rounded to 2 dp.
    /// Unscored rows are excluded. Returns null if nothing is scored.
    /// </summary>
    public static double? AverageScore(string dbPath)
    {
        using var conn = Connect(dbPath);
        var raw = conn.Query<int?>("SELECT score FROM evaluations ORDER BY id").ToList();

        var scores = raw.Select(s => s ?? 0).ToList();
        if (scores.Count == 0)
        {
            return null;
        }
        return Math.Round(scores.Sum() / (double)scores.Count, 2);
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 80, 90, `NULL` | `85.0` | **Discriminator** — broken returns `56.67` |
| T2 | 80, 90 | `85.0` | Guard — no nulls, nothing to mishandle |
| T3 | 100, `NULL`, `NULL` | `100.0` | **Discriminator** — broken returns `33.33` |
| T4 | Single row, 42 | `42.0` | Guard |
| T5 | Empty table | `None` / `null` | Guard |
| T6 | Two rows, both `NULL` | `None` / `null` | **Discriminator** — broken returns `0.0` |

### Fixtures

```sql
-- T2
INSERT INTO evaluations (id, query, score) VALUES (1,'a',80),(2,'b',90);
-- T3
INSERT INTO evaluations (id, query, score) VALUES (1,'a',100),(2,'b',NULL),(3,'c',NULL);
-- T4
INSERT INTO evaluations (id, query, score) VALUES (1,'solo',42);
-- T6
INSERT INTO evaluations (id, query, score) VALUES (1,'a',NULL),(2,'b',NULL);
```

---

## Reference solution

Filter the unscored rows out instead of substituting zero.

**Python:**

```diff
- scores = [row[0] if row[0] is not None else 0 for row in rows]
+ scores = [row[0] for row in rows if row[0] is not None]
```

**Java:**

```diff
  int value = rs.getInt("score");
- scores.add(rs.wasNull() ? 0 : value);
+ if (!rs.wasNull()) {
+     scores.add(value);
+ }
```

**C#:**

```diff
- var scores = raw.Select(s => s ?? 0).ToList();
+ var scores = raw.Where(s => s.HasValue).Select(s => s.Value).ToList();
```

### Why

Substituting `0` for "unknown" changes both the numerator and the denominator: the sum does not grow, but the count does. Every unscored row therefore pulls the mean toward zero in proportion to how many there are — which is exactly the reported behaviour of the average falling as more unscored queries arrive.

The distinction matters conceptually, not just arithmetically. A score of zero asserts that a result was evaluated and found irrelevant. A null asserts that no one has looked yet. Collapsing the second into the first invents data.

T6 is the case people miss: when *nothing* is scored, the correct answer is "no average exists", not "the average is zero". Returning `0.0` there reports a confidently wrong quality figure.

Note the Java variant relies on `rs.wasNull()` — `getInt` returns `0` for SQL `NULL`, so the null check cannot be skipped.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Filtering nulls but returning `0.0` when nothing is scored | T6 — expected `null` |
| Dividing the filtered sum by the *unfiltered* row count | T1, T3 |
| Java: dropping `wasNull()` and testing `value != 0` | Treats a genuine score of 0 as missing — flag in review |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T6
- [ ] Broken version **fails T1, T3 and T6**, and **passes T2, T4, T5**
- [ ] Failure is a depressed average, not a crash or divide-by-zero
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] **Java: confirm `rs.wasNull()` is used** — `getInt` silently returns 0 for NULL, which would hide the bug's origin
- [ ] Confirm a genuine score of `0` is still counted after the fix
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
