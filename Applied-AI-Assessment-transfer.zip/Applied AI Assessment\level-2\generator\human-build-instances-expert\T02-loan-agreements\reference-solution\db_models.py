import sqlite3

DB_PATH = "loan_extraction.db"


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS loan_records (
            loan_number TEXT PRIMARY KEY,
            borrower_name TEXT,
            principal_amount REAL,
            interest_rate TEXT,
            maturity_date TEXT,
            status TEXT,
            log TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS followup_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            loan_number TEXT,
            idempotency_key TEXT UNIQUE,
            followup_id TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def init_db():
    conn = get_conn()
    conn.close()


def save_loan_record(loan_number, borrower_name, principal_amount, interest_rate, maturity_date, status, logs):
    conn = get_conn()
    conn.execute(
        """INSERT INTO loan_records (loan_number, borrower_name, principal_amount, interest_rate, maturity_date, status, log)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(loan_number) DO UPDATE SET
             borrower_name=excluded.borrower_name, principal_amount=excluded.principal_amount,
             interest_rate=excluded.interest_rate, maturity_date=excluded.maturity_date,
             status=excluded.status, log=excluded.log""",
        (loan_number, borrower_name, principal_amount, interest_rate, maturity_date, status, "\n".join(logs)),
    )
    conn.commit()
    conn.close()


def record_followup(loan_number, idempotency_key, followup_id):
    """Returns True if this was a new followup record, False if one already existed
    for this idempotency key (a retry correctly did not duplicate)."""
    conn = get_conn()
    cur = conn.execute("SELECT followup_id FROM followup_records WHERE idempotency_key = ?", (idempotency_key,))
    existing = cur.fetchone()
    if existing:
        conn.close()
        return False
    conn.execute(
        "INSERT INTO followup_records (loan_number, idempotency_key, followup_id) VALUES (?, ?, ?)",
        (loan_number, idempotency_key, followup_id),
    )
    conn.commit()
    conn.close()
    return True


def count_followups_for_loan(loan_number):
    conn = get_conn()
    cur = conn.execute("SELECT COUNT(*) FROM followup_records WHERE loan_number = ?", (loan_number,))
    n = cur.fetchone()[0]
    conn.close()
    return n


def reset_db():
    import os
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
