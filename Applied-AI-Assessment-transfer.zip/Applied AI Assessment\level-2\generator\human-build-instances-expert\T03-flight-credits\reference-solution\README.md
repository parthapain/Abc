# Reference solution — T03 expert-tier, Airline Flight-Credit & Rebooking Requests

Run `python verify.py` from this directory. All 20 checks pass.

## What verify.py confirms

- The two base-template ambiguities (value threshold, "clearly supported by the record") both resolve, and their "no safe default" divergence rows (FR-8004/FR-8005 tier pair; FR-8002/FR-8003 lenient-vs-strict pair) both come out correct.
- Expert element 1: a booking-ownership redirect (FR-8006, a booking legitimately owned by someone other than the requester) is caught, not silently trusted.
- Expert element 2: that same ownership mismatch correctly blocks the auto-resolve guardrail — the coupling actually holds, not just a cosmetic flag.
- The base-template trap (FR-8007, an amount sourced from untrusted customer text) never drives the executed action.
- Expert element 4: an adversarial record (BK-8008's `credit_eligible: true` paired with a negative `credit_value`) is not trusted at face value.
- The second guardrail (history-gated replacement scheduling) is tested in all required directions: under the cap, over the cap, and no history on file at all.
- Expert elements 3 & 5: the replacement-scheduling call is retry-safe (a forced lost-response retry produces exactly one record), and the idempotency-cache-hit path ignores a history change that happens between the original call and the retry.
- Addendum 31, guardrail independence: FR-8013 (a $1500 booking that would fail the refund guardrail's value threshold) still routes to and clears the replacement guardrail, since a replacement isn't gated by the refund guardrail's dollar ceiling.

## Key decisions

- **Value threshold (`USE_CUSTOMER_TIER_IN_THRESHOLD = False`, `orchestrator.py`):** a request's customer-service tier (Standard/Elite) is noted and logged but deliberately excluded from the auto-resolve value threshold — risk is judged on the request's verified dollar value alone. Either reading is defensible; what matters is that it's a named, isolated, one-line decision, applied the same way to every request, not an accident of which mention the code happened to weight.
- **"Clearly supported" (`process_request`'s eligibility check):** the customer's own wording is inferred into a rough category (`_infer_customer_described_category`) purely for the audit log — it never gates the decision. The gate is always the tool-verified `credit_eligible` field from `get_booking_details`. This resolves both directions of the ambiguity at once: a plausible-sounding but factually wrong customer claim (FR-8002) can't talk its way past a record that says otherwise, and a genuinely eligible request worded differently from the record's own label (FR-8003) isn't penalized for not using the "right" words.
- **Ownership check (elements 1 & 2):** `process_request` compares the booking record's own `customer_name` against the request's stated requester before anything else runs — a mismatch is a hard, unconditional escalation, checked before the eligibility/value logic even executes, so there's no path where a legitimately-eligible-looking record can slip past it.
- **Adversarial tool response (element 4):** implemented directly in `booking_records.csv` (BK-8008's own row) rather than a mocked tool quirk, since the inconsistency is between two fields of the same record (`credit_eligible` and `credit_value`), which a candidate would see directly in the seed data.
- **Idempotency + stale-history collision (elements 3 & 5):** `schedule_replacement()`'s idempotency cache check happens before anything else in the function — a cache hit returns immediately, without ever consulting the live history count. The orchestrator's `process_replacement()` checks history exactly once, before entering the retry loop, and never re-checks it on a retry — the retry loop only re-invokes the (already idempotency-protected) client call.
