# P01 — Document chunk counts

| Field | Value |
|---|---|
| **ID** | P01 |
| **Difficulty** | Medium |
| **Bug pattern** | #5 — `INNER JOIN` silently drops rows that need `LEFT JOIN` |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Status** | Draft — not yet peer reviewed |

---

## Candidate-facing brief

### Scenario

A document-ingestion pipeline splits uploaded documents into chunks for embedding. An internal dashboard reports how many chunks each document produced, so the team can spot documents that failed to chunk.

The report is returning wrong results: **documents that produced no chunks are missing from the output entirely**, when they should appear with a count of `0`. Those are exactly the documents the team needs to see.

### Required behaviour

Return one row per document whose `status` is `'processed'`, as `(title, chunk_count)`, ordered by `title` ascending.

A document with no chunks must appear with `chunk_count = 0`. Documents whose status is not `'processed'` must not appear at all.

### Schema

```sql
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    title   TEXT NOT NULL,
    status  TEXT NOT NULL          -- 'processed' | 'archived' | 'pending'
);

CREATE TABLE chunks (
    id           INTEGER PRIMARY KEY,
    document_id  INTEGER NOT NULL REFERENCES documents(id),
    chunk_index  INTEGER NOT NULL,
    token_count  INTEGER NOT NULL
);
```

---

## Fixture — `P01.sql`

```sql
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    title   TEXT NOT NULL,
    status  TEXT NOT NULL
);

CREATE TABLE chunks (
    id           INTEGER PRIMARY KEY,
    document_id  INTEGER NOT NULL REFERENCES documents(id),
    chunk_index  INTEGER NOT NULL,
    token_count  INTEGER NOT NULL
);

INSERT INTO documents (id, title, status) VALUES
    (1, 'Annual Report 2024', 'processed'),
    (2, 'Q3 Earnings Call',   'processed'),
    (3, 'Draft Memo',         'processed'),   -- no chunks: the discriminating row
    (4, 'Archived Notes',     'archived');    -- has chunks but must be excluded

INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
    (1, 1, 0, 512),
    (2, 1, 1, 480),
    (3, 2, 0, 300),
    (4, 4, 0, 200);
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def chunk_counts(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (title, chunk_count) for every document with status 'processed',
    ordered by title ascending.

    A document that has not been chunked must appear with a count of 0.
    """
    query = """
        SELECT d.title, COUNT(c.id) AS chunk_count
        FROM documents d
        JOIN chunks c ON c.document_id = d.id
        WHERE d.status = 'processed'
        GROUP BY d.id, d.title
        ORDER BY d.title
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute(query).fetchall()
        return [(title, count) for title, count in rows]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class ChunkReport {

    // --- boilerplate: do not modify ---
    public static class DocumentCount {
        public final String title;
        public final int chunkCount;

        public DocumentCount(String title, int chunkCount) {
            this.title = title;
            this.chunkCount = chunkCount;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (title, chunkCount) for every document with status 'processed',
     * ordered by title ascending.
     *
     * A document that has not been chunked must appear with a count of 0.
     */
    public static List<DocumentCount> chunkCounts(String dbPath) throws SQLException {
        String query =
            "SELECT d.title, COUNT(c.id) AS chunk_count " +
            "FROM documents d " +
            "JOIN chunks c ON c.document_id = d.id " +
            "WHERE d.status = 'processed' " +
            "GROUP BY d.id, d.title " +
            "ORDER BY d.title";

        List<DocumentCount> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new DocumentCount(
                    rs.getString("title"),
                    rs.getInt("chunk_count")
                ));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record DocumentCount(string Title, int ChunkCount);

public static class ChunkReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Title, ChunkCount) for every document with status 'processed',
    /// ordered by title ascending.
    ///
    /// A document that has not been chunked must appear with a count of 0.
    /// </summary>
    public static List<DocumentCount> ChunkCounts(string dbPath)
    {
        const string query = @"
            SELECT d.title AS Title, COUNT(c.id) AS ChunkCount
            FROM documents d
            JOIN chunks c ON c.document_id = d.id
            WHERE d.status = 'processed'
            GROUP BY d.id, d.title
            ORDER BY d.title";

        using var conn = Connect(dbPath);
        return conn.Query<DocumentCount>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Fixture | Expected output | Role |
|---|---|---|---|
| T1 | `P01.sql` (as above) | `[("Annual Report 2024", 2), ("Draft Memo", 0), ("Q3 Earnings Call", 1)]` | **Discriminator** — broken version omits `Draft Memo` |
| T2 | Only documents that have chunks | `[("Alpha", 1), ("Beta", 3)]` | Guard — passes in both versions; prevents over-fitting to the bug |
| T3 | Three `processed` documents, no chunks at all | `[("Alpha", 0), ("Beta", 0), ("Gamma", 0)]` | **Discriminator** — broken version returns `[]` |
| T4 | One `processed` doc (2 chunks), one `archived` doc (5 chunks) | `[("Live Doc", 2)]` | Guard — catches a candidate who "fixes" it by deleting the `WHERE` clause |
| T5 | Empty `documents` table | `[]` | Guard — no crash on empty input |

**T2, T4 and T5 pass in the broken version by design.** They exist so that a candidate cannot satisfy the suite by removing the status filter or otherwise loosening the query, and so the harness proves the failure is specific rather than incidental.

### Fixture for T2

```sql
INSERT INTO documents (id, title, status) VALUES
    (1, 'Alpha', 'processed'),
    (2, 'Beta',  'processed');
INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
    (1, 1, 0, 100),
    (2, 2, 0, 100), (3, 2, 1, 100), (4, 2, 2, 100);
```

### Fixture for T3

```sql
INSERT INTO documents (id, title, status) VALUES
    (1, 'Alpha', 'processed'),
    (2, 'Beta',  'processed'),
    (3, 'Gamma', 'processed');
-- chunks table intentionally empty
```

### Fixture for T4

```sql
INSERT INTO documents (id, title, status) VALUES
    (1, 'Live Doc',     'processed'),
    (2, 'Archived Doc', 'archived');
INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
    (1, 1, 0, 100), (2, 1, 1, 100),
    (3, 2, 0, 100), (4, 2, 1, 100), (5, 2, 2, 100),
    (6, 2, 3, 100), (7, 2, 4, 100);
```

---

## Reference solution

**One change, identical in all three languages:** `JOIN` → `LEFT JOIN`.

```diff
  FROM documents d
- JOIN chunks c ON c.document_id = d.id
+ LEFT JOIN chunks c ON c.document_id = d.id
  WHERE d.status = 'processed'
```

### Why this is the only change needed

`INNER JOIN` requires a matching row in `chunks`, so a document with no chunks produces no row at all and disappears from the result set. `LEFT JOIN` retains every qualifying document and supplies `NULL`s for the missing chunk columns.

The aggregate is already written as `COUNT(c.id)` rather than `COUNT(*)`. This matters: `COUNT(*)` counts the result row itself and would return `1` for an unchunked document under a `LEFT JOIN`, whereas `COUNT(c.id)` ignores `NULL` and correctly returns `0`. **This was deliberate when authoring** — writing `COUNT(*)` in the broken version would have created a second required change and made the problem ambiguous about what the intended fix was.

The `WHERE d.status = 'processed'` clause filters the left-hand table only, so it does not interact with the join change and does not need to move to the `ON` clause.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `LEFT JOIN` but changing the aggregate to `COUNT(*)` | T1, T3 — returns `1` instead of `0` |
| Removing the `WHERE` clause to "get more rows back" | T4 — archived document appears |
| `RIGHT JOIN` / swapping table order without adjusting the count | T1, T3 |
| Post-filtering in host code instead of fixing the query | T3 — nothing to filter; still returns `[]` |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is on the intended assertion (missing rows), not a crash or type error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot, 2–3 engineers per language)

**Reviewers:** _______________  **Date:** _______________
