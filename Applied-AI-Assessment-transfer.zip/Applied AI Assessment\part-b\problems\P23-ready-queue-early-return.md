# P23 — Ready-document collector

| Field | Value |
|---|---|
| **ID** | P23 |
| **Difficulty** | High |
| **Bug pattern** | Loop returns early instead of continuing |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 12–16 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A worker walks the processing queue and collects the names of every entry that is ready, skipping entries still blocked on an upstream dependency.

Throughput is far lower than expected. Items sit in the queue for hours even when they are ready — and the pattern is that everything after the first blocked entry is ignored.

### Required behaviour

Return the `name` of every queue entry whose `status` is `'ready'`, in `id` order.

Blocked entries are **skipped**; they do not stop the scan.

### Schema

```sql
CREATE TABLE queue (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    status TEXT NOT NULL   -- 'ready' | 'blocked'
);
```

---

## Fixture — `P23.sql`

```sql
CREATE TABLE queue (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    status TEXT NOT NULL
);

INSERT INTO queue (id, name, status) VALUES
    (1,'a','ready'),
    (2,'b','blocked'),   -- must be skipped, not treated as the end of the queue
    (3,'c','ready');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def collect_ready(db_path: str) -> List[str]:
    """
    Return the name of every queue entry with status 'ready', in id order.
    Blocked entries are skipped, not treated as the end of the queue.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute("SELECT name, status FROM queue ORDER BY id").fetchall()
    finally:
        conn.close()

    collected: List[str] = []
    for name, status in rows:
        if status != "ready":
            return collected
        collected.append(name)
    return collected
```

### Java

```java
import java.sql.*;
import java.util.*;

public class QueueWorker {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return the name of every queue entry with status 'ready', in id order.
     * Blocked entries are skipped, not treated as the end of the queue.
     */
    public static List<String> collectReady(String dbPath) throws SQLException {
        List<String> collected = new ArrayList<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name, status FROM queue ORDER BY id")) {
            while (rs.next()) {
                String name = rs.getString("name");
                String status = rs.getString("status");

                if (!"ready".equals(status)) {
                    return collected;
                }
                collected.add(name);
            }
        }
        return collected;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class QueueWorker
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return the name of every queue entry with status 'ready', in id order.
    /// Blocked entries are skipped, not treated as the end of the queue.
    /// </summary>
    public static List<string> CollectReady(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<(string Name, string Status)>(
            "SELECT name, status FROM queue ORDER BY id").ToList();

        var collected = new List<string>();
        foreach (var (name, status) in rows)
        {
            if (status != "ready")
            {
                return collected;
            }
            collected.Add(name);
        }
        return collected;
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `ready`, `blocked`, `ready` | `["a", "c"]` | **Discriminator** — broken returns `["a"]` |
| T2 | Three `ready` entries | `["a","b","c"]` | Guard — nothing blocks, so the early return never fires |
| T3 | `blocked` first, then `ready` | `["y"]` | **Discriminator** — broken returns `[]` |
| T4 | `ready`, `ready`, `blocked` — blocked entry **last** | `["a","b"]` | Guard — returning at the final element produces the same answer |
| T5 | Empty table | `[]` | Guard |

> T4 is the guard that makes this problem realistic. When blocked entries happen to sit at the end of the queue, bailing out and skipping are indistinguishable. A fixture ordered that way — which is what a queue drained in order tends to look like — will pass the buggy code.

### Fixtures

```sql
-- T2
INSERT INTO queue (id, name, status) VALUES (1,'a','ready'),(2,'b','ready'),(3,'c','ready');
-- T3
INSERT INTO queue (id, name, status) VALUES (1,'x','blocked'),(2,'y','ready');
-- T4
INSERT INTO queue (id, name, status) VALUES (1,'a','ready'),(2,'b','ready'),(3,'c','blocked');
```

---

## Reference solution

Skip the entry instead of abandoning the loop.

**Python:**

```diff
  if status != "ready":
-     return collected
+     continue
  collected.append(name)
```

**Java:**

```diff
  if (!"ready".equals(status)) {
-     return collected;
+     continue;
  }
  collected.add(name);
```

**C#:**

```diff
  if (status != "ready")
  {
-     return collected;
+     continue;
  }
  collected.Add(name);
```

### Why

`return` and `continue` both move control past the rest of the loop body, which is why the substitution is easy to make and easy to miss on review. They differ in what happens next: `continue` advances to the next item, `return` abandons the remaining items entirely.

The result is a queue scan that stops at the first blocked entry and silently reports partial success. Nothing errors, and the returned list is genuinely correct as far as it goes — it is just truncated. Throughput degrades in proportion to how early the first blocked entry sits, which produces the erratic, load-dependent behaviour described.

This class of bug is why a `return` inside a loop deserves a second look during review: it is correct when you have found what you were looking for, and wrong when you were filtering.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Changing `return` to `break` | T1, T3 — still abandons the remaining entries |
| Removing the status check entirely | T1, T3 — blocked entries are collected |
| Inverting the condition to `if status == "ready": continue` | T1, T2 — collects exactly the wrong set |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is a truncated list, not a crash
- [ ] **T4 genuinely passes in the broken version** — if it fails, the fixture ordering is wrong and the problem loses its subtlety
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Confirm the surrounding function is long enough that the early `return` is not obvious on a skim — if it reads as a one-liner, this is Medium rather than High
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
