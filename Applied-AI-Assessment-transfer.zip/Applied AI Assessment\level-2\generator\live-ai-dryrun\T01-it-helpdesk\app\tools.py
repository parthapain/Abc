"""
Tool definitions the agent can call.

Each tool is a plain Python function with a narrow, explicit contract -- this keeps
the agent's decisions auditable (every tool call is logged to `actions`) and makes
each tool independently testable. Read-only "check" tools (search_related_history,
get_additional_context, check_billing_record) don't change state; action tools
(acknowledge_ticket, auto_close_ticket, route_ticket, issue_courtesy_resolution)
mutate ticket state and are what the brief calls "autonomously acknowledge,
auto-close, or auto-route via a tool call."

`get_additional_context` is a simulated lookup against a system we don't have seed
data for (e.g. an account-security/audit log) -- see docstring below and RATIONALE.md.
"""
import difflib
import re
from typing import Optional

from app import database as db

TEAM_ROUTING = {
    "Hardware": "Hardware Support",
    "Software Access": "IT Service Desk",
    "Network/VPN": "Network & Infrastructure",
    "Licensing & Reimbursement": "Billing & Licensing",
    "Security Incident": "Security Operations (SOC)",
}

DUPLICATE_SIMILARITY_THRESHOLD = 0.6
COURTESY_RESOLUTION_THRESHOLD = 50.00  # "small threshold" from the brief
BILLING_MATCH_TOLERANCE = 0.01


# --------------------------------------------------------------- read tools -

_WORD_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text):
    return set(_WORD_RE.findall((text or "").lower()))


def _similarity(a: str, b: str) -> float:
    """Blend of full-text sequence similarity and token containment.

    Plain SequenceMatcher ratio alone under-scores a terse restatement of a long
    ticket (e.g. "Laptop won't turn on." vs a detailed follow-up that includes the
    same core complaint plus troubleshooting narrative) because most of the longer
    text isn't shared. Containment (what fraction of the *shorter* ticket's words
    appear in the other) catches that case; blending the two avoids over-triggering
    on containment alone for short, generic tickets that happen to share a few words.
    """
    seq_ratio = difflib.SequenceMatcher(None, (a or "").lower(), (b or "").lower()).ratio()
    tok_a, tok_b = _tokenize(a), _tokenize(b)
    if not tok_a or not tok_b:
        containment = 0.0
    else:
        shorter, longer = (tok_a, tok_b) if len(tok_a) <= len(tok_b) else (tok_b, tok_a)
        containment = len(shorter & longer) / len(shorter)
    return round(0.5 * seq_ratio + 0.5 * containment, 3)


def search_related_history(ticket_id: str, requester_name: str, body_text: str) -> dict:
    """Look for duplicate or related prior tickets from the same requester.

    This is a stand-in for a real "find related tickets" search (e.g. embeddings +
    vector search); the contract (ticket_id/requester/body -> ranked candidates) is
    what would carry over to a real implementation. A ticket only counts as a
    "genuine duplicate" (see brief) if the best-matching *open* prior ticket from the
    same requester clears the similarity threshold -- an old *closed* ticket about
    the same symptom is useful history, not grounds to auto-close a new report.
    """
    candidates = [t for t in db.list_tickets(exclude_ticket_id=ticket_id)
                  if t["requester_name"] == requester_name]

    scored = []
    for c in candidates:
        scored.append({
            "ticket_id": c["ticket_id"],
            "status": c["status"],
            "submitted_at": c["submitted_at"],
            "body_text": c["body_text"],
            "similarity": _similarity(body_text, c["body_text"]),
        })
    scored.sort(key=lambda x: x["similarity"], reverse=True)

    best_overall = scored[0] if scored else None
    open_candidates = [c for c in scored if c["status"] in ("new", "open")]
    best_open = open_candidates[0] if open_candidates else None
    is_genuine_duplicate = bool(best_open and best_open["similarity"] >= DUPLICATE_SIMILARITY_THRESHOLD)

    result = {
        "candidates": scored,
        "best_match": best_overall,
        "best_open_match": best_open,
        "is_genuine_duplicate": is_genuine_duplicate,
    }
    db.add_action(ticket_id, action_type="duplicate_check", tool_name="search_related_history",
                  tool_params={"requester_name": requester_name}, tool_result=result)
    return result


def get_additional_context(ticket_id: str, body_text: str) -> dict:
    """Pull additional context when the first-pass classification is uncertain.

    SIMULATED TOOL: the brief's seed data doesn't include an account-security /
    audit-log system, so there is nothing real to query here. This function stands
    in for "check the identity/security system for recent lockout or access-attempt
    signals" using the same keyword-triggered approach as the classifier stub, so
    the agent's second pass has *something* concrete to react to. In a real system
    this would be a call to an actual audit-log or IAM API; the contract
    (ticket_id/body -> free-text context) is what a real integration would keep.
    """
    lowered = (body_text or "").lower()
    if "failed login" in lowered or "locked" in lowered:
        if "someone else" in lowered or "wasn't me" in lowered or "not me" in lowered:
            context = (
                "Account-security audit log: 5 failed login attempts in the last 15 minutes "
                "from an unrecognized device/location, followed by an automatic lockout. "
                "Pattern is consistent with a credential-stuffing / unauthorized-access attempt, "
                "not routine VPN flakiness."
            )
        else:
            context = (
                "Account-security audit log: failed login attempts and lockout match the "
                "requester's usual device and location. No signs of unauthorized access; "
                "consistent with a routine credential/VPN client issue."
            )
    else:
        context = (
            "Account-security audit log: no failed-login or lockout events found for this "
            "requester in the last 24 hours."
        )
    result = {"context": context}
    db.add_action(ticket_id, action_type="context_lookup", tool_name="get_additional_context",
                  tool_params={"body_text": body_text}, tool_result=result)
    return result


_AMOUNT_RE = re.compile(r"\$\s?(\d+(?:\.\d{1,2})?)")


def extract_claimed_amount(body_text: str) -> Optional[float]:
    """Pull a specific dollar figure out of the ticket text, if the requester gave one.

    This is what the brief means by 'a specific, checkable discrepancy': a claim we
    can actually compare against a real record, as opposed to a vague complaint like
    'I think there was a billing error' with no number attached.
    """
    match = _AMOUNT_RE.search(body_text or "")
    return float(match.group(1)) if match else None


def check_billing_record(ticket_id: str, requester_name: str, claimed_amount: float) -> dict:
    """Check the requester's claimed discrepancy against the real billing system."""
    record = db.get_billing_record(requester_name)
    if record is None:
        result = {"found": False, "confirmed": False, "verified_discrepancy": None}
    else:
        verified = record["verified_discrepancy"]
        confirmed = abs(verified - claimed_amount) <= BILLING_MATCH_TOLERANCE and verified > 0
        result = {"found": True, "confirmed": confirmed, "verified_discrepancy": verified,
                   "claimed_amount": claimed_amount}
    db.add_action(ticket_id, action_type="billing_check", tool_name="check_billing_record",
                  tool_params={"requester_name": requester_name, "claimed_amount": claimed_amount},
                  tool_result=result)
    return result


# ------------------------------------------------------------- action tools -

def acknowledge_ticket(ticket_id: str, category: str) -> dict:
    result = {"message": f"Acknowledged and classified as '{category}'."}
    db.add_action(ticket_id, action_type="acknowledged", tool_name="acknowledge_ticket",
                  tool_params={"category": category}, tool_result=result)
    return result


def auto_close_ticket(ticket_id: str, duplicate_of: str, similarity: float) -> dict:
    db.update_ticket_status(ticket_id, "closed")
    result = {"message": f"Auto-closed as a duplicate of {duplicate_of}.",
               "duplicate_of": duplicate_of, "similarity": similarity}
    db.add_action(ticket_id, action_type="auto_closed_duplicate", tool_name="auto_close_ticket",
                  tool_params={"duplicate_of": duplicate_of, "similarity": similarity},
                  tool_result=result)
    return result


def route_ticket(ticket_id: str, category: str) -> dict:
    team = TEAM_ROUTING.get(category, "General IT Support")
    db.update_ticket_status(ticket_id, "routed")
    result = {"message": f"Routed to {team}.", "team": team}
    db.add_action(ticket_id, action_type="routed", tool_name="route_ticket",
                  tool_params={"category": category}, tool_result=result)
    return result


def issue_courtesy_resolution(ticket_id: str, amount: float) -> dict:
    db.update_ticket_status(ticket_id, "resolved")
    result = {"message": f"Courtesy resolution issued: ${amount:.2f} credited to requester.",
               "amount": amount}
    db.add_action(ticket_id, action_type="courtesy_resolution", tool_name="issue_courtesy_resolution",
                  tool_params={"amount": amount}, tool_result=result)
    return result
