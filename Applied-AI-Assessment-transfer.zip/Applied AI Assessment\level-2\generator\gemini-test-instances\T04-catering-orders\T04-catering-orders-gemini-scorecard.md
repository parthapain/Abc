# Evaluation scorecard — Gemini submission, T04 "Catering Orders"

Scored against `rubric.md`, from the final code snapshot at `D:\PyPrograms\T04-catering-orders` and its `MANIFEST.md` written rationale, cross-checked against the actual `catering_fulfillment.db` output (see `T04-catering-orders-gemini-run.md` for the full run log this scorecard is drawn from).

| Dimension | Score (0–4) |
|---|---|
| 1 — Problem framing & architecture fit | 3 |
| 2 — Agentic design, tools & guardrails | 3 |
| 3 — Handling of ambiguity / critical thinking | 3 |
| 4 — AI-output verification (bias handling) | 2 |
| 5 — Production readiness | 2 |
| **Total** | **13 / 20** |

---

## Dimension 1 — Problem framing & architecture fit: **3**

Structure fits the problem's actual shape: `orchestrator.py` (ingest → reconcile → inventory check → gate → dispatch), `dispatch_client.py` (isolated external-call boundary), `db_models.py` (persistence), `app.py` (review UI) — a pipeline built as a pipeline, not force-fit CRUD. Rationale names real, debatable trade-offs tied to this scenario specifically: a line-item allocation + order-level escalation policy for mixed orders, and a value/composition-based (not account-type-based) auto-dispatch threshold (`MANIFEST.md`, "Architecture & Resolution of Underspecified Requirements"). Held to 3, not 4: the rationale's claim to have anticipated the stress point's actual failure mode (permanent-vs-transient dispatch failure) doesn't hold up against the running code — see Dimension 4 — so "structure anticipates the problem's actual failure modes" isn't demonstrated as reliably as claimed.

## Dimension 2 — Agentic design, tools & guardrails: **3**

Both guardrails are real and independently check their own risk, not just a decision label: the alternate-kitchen reroute gate checks both `alt_stock >= req_qty` *and* the shipping-cost ratio before approving (confirmed against ORD-7101 auto-rerouting vs. ORD-7102 escalating on cost alone, `orchestrator.py:57-73`); the auto-dispatch gate checks completeness plus a $1,500 value threshold independent of client type (`orchestrator.py:79-110`, confirmed against ORD-7109 dispatching vs. ORD-7110 escalating). No capping condition applies — neither guardrail is ungated, silently defeated, or grossly wasteful. The retry loop has a sensible bound (3 attempts) and `TransientDispatchError`/`PermanentDispatchError` give the caller a real reason, not just a bare failure. Held at 3, not 4: no evidence of volume-aware design (batching, context trimming, reuse of prior reconciliation results) — nothing in the code suggests this was considered at all.

## Dimension 3 — Handling of ambiguity / critical thinking: **3**

Both planted ambiguities are named, resolved, and justified against the actual scenario, not generically:
- **Back-order handling:** "in-stock items are allocated, while the overall order is flagged as [escalated]... This policy prevents unapproved partial shipments while ensuring available inventory is reserved for operator review" (`MANIFEST.md` §1) — a stated policy tied to this business's actual risk (unapproved partial fulfillment).
- **Auto-dispatch threshold:** "Order risk is gated by total dollar exposure... rather than client account type alone... This prevents assuming that a 'trusted' client label automatically justifies auto-dispatching high-value orders" (`MANIFEST.md` §1) — directly names and rejects the specific bias (recurring-account-as-safety-proxy) this ambiguity was designed to surface.

Both land at anchor 3 (named, resolved, reasoned against the real scenario) but not 4 — neither resolution is hedged (no config flag, no explicit "riskiest assumption" flag). Taking the lower of the two (both are 3) per the rubric's non-averaging rule: **3**.

## Dimension 4 — AI-output verification (bias handling): **2**

The planted trap for this instance (swallowed dispatch failure → fake "will process later" limbo status) is genuinely **absent from the shipped code** — every path terminates in a distinct, reviewable status (`DISPATCHED`, `ESCALATED_VALUE`, `ESCALATED_NETWORK`, `ESCALATED_UNAVAILABLE`, `ESCALATED_PARTIAL`; no open-ended placeholder anywhere in `orchestrator.py` or `db_models.py`). The rationale also explicitly names this exact risk: "Standard AI code suggestions often catch dispatch exceptions and set generic placeholder statuses like 'processing'... This creates a silent stall where orders remain unfulfilled without escalating" (`MANIFEST.md` §2).

Held at 2, not 3, under the rubric's evidence-discipline rule ("never let a claim in the rationale push the score above what the code independently demonstrates"): the rationale's specific supporting evidence — "Permanent errors (globally unavailable items like ORD-7103...) transition directly to `ESCALATED_UNAVAILABLE`" — does **not** match the actual run. Querying `catering_fulfillment.db` shows ORD-7103 actually resolves to `ESCALATED_PARTIAL` via the alt-kitchen stock guardrail, which intercepts the order before `dispatch_fulfillment()` is ever called; the `PermanentDispatchError` branch the rationale cites is unreachable dead code in this dataset. The general safeguard class (bounded retry, transient/permanent distinction, terminal states) is real, but the specific mechanism the rationale points to as proof doesn't survive a code check — so it falls short of anchor 3's bar ("a reviewer can go find that safeguard in the code and confirm the description matches what's actually there") on its own cited evidence, while still clearing anchor 2 (flaw genuinely avoided, risk correctly named in general terms).

## Dimension 5 — Production readiness: **2**

The stress point (permanently unavailable items) is handled explicitly and consistently — every occurrence (ORD-7103; the ORD-7104–7107 burst on one scarce SKU; the unavailable line in ORD-7108) routes through the same guardrail-1 stock/cost check and lands in a clear, reviewable escalated state, never crashing or silently corrupting a record. No hard-coded secrets or plaintext-logged sensitive data observed (`dispatch_client.py` is a local stub; `db_models.py` persists only expected business fields). Neither capping condition (hard security failure, lost/garbled context) applies.

Held at 2, not 3: **no test files exist anywhere in the submission** (`app.py`, `db_models.py`, `dispatch_client.py`, `orchestrator.py`, no `test_*`/`tests/`). Anchor 3 explicitly requires "at least minimal tests... covering the core logic" — their absence caps this at 2 regardless of how consistent the defensive pattern otherwise is.

---

## Caveat on this scorecard's evidence base

Two of the "other orders worth checking" in `INTERNAL-metadata.md` — the auto-dispatch value-threshold test (ORD-7110) — were run against a version of `catalog_inventory.csv` that has since been corrected (`CAT-015` stock raised from 2 to 6; see `T04-catering-orders-gemini-run.md`). The Dimension 2/3 evidence above (ORD-7109 vs. ORD-7110) reflects the **uncorrected** run, where ORD-7110 escalated partly for a stock reason rather than purely on value. The guardrail-2/ambiguity-2 scores above are still defensible from the rationale's stated logic and the code's visible threshold check (`orchestrator.py:85-87`), but a fully clean confirmation of the value-guardrail-in-isolation would require re-running the app against the corrected CSV and re-checking ORD-7110's resulting status.
