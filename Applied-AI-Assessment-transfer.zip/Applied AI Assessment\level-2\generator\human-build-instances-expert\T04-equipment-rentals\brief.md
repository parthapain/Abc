# Build Brief — Equipment Rental Fulfillment & Reliability

Your organization processes a continuous stream of equipment-rental requests — short-term equipment rentals placed by construction companies and event organizers, fulfilled from a central equipment yard and dispatched via a hauling/delivery partner. Build an application that:

1. Ingests equipment-rental requests (seed datasets are provided — `equipment_catalog.csv`, `rental_orders.csv`, and `alt_yard_inventory.csv`)
2. Uses the in-house LLM to interpret each one — including reconciling line items that don't map cleanly onto the catalog
3. Works as an agent, not a single call: check inventory availability via a tool, reconcile ambiguous items against the catalog via a tool, and only then decide how to proceed
4. **Handle back-ordered items sensibly.**
5. **Only auto-dispatch low-risk orders.**
6. Autonomously dispatch fulfillment via a tool call.
7. **Separately, autonomously reroute a line item to the alternate yard via a tool call when the primary yard is out of stock on that item.**
8. Provides a UI showing the agent's reasoning, any autonomous action taken (dispatches *and* any alternate-yard reroutes), and lets a human review and override
9. Persists orders, reconciliation decisions, dispatch actions (including any reroutes), and any overrides to a database

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24 hours.
