"""
Tool definitions available to the fulfillment agent (agent.py).

Each tool is a plain Python function with a docstring describing its contract,
plus a `TOOLS` registry (name -> callable) so agent.py can log "tool calls" the
way a real LLM tool-calling loop would, without actually needing a model to emit
JSON tool-call payloads. This keeps the agent's control flow inspectable and
testable while still following the "check inventory via a tool, reconcile via a
tool, dispatch via a tool, reroute via a tool" shape the brief asks for.
"""
from __future__ import annotations

from dataclasses import dataclass

import db
from llm_interpreter import ReconciliationResult, interpret_line_item


@dataclass
class ToolCall:
    tool: str
    input: dict
    output: dict
    note: str = ""


# ---------------------------------------------------------------------------
# Tool 1: reconcile_line_item  (wraps the "in-house LLM" interpreter)
# ---------------------------------------------------------------------------

def reconcile_line_item(raw_text: str) -> ToolCall:
    """Reconcile a free-text line item description against the equipment catalog."""
    catalog = [dict(row) for row in db.get_catalog()]
    result: ReconciliationResult = interpret_line_item(raw_text, catalog)
    return ToolCall(
        tool="reconcile_line_item",
        input={"raw_text": raw_text},
        output={
            "resolved_sku": result.resolved_sku,
            "resolved_name": result.resolved_name,
            "confidence": round(result.confidence, 3),
            "ambiguous": result.ambiguous,
            "candidates": [
                {"sku": c.sku, "name": c.name, "score": round(c.score, 3)}
                for c in result.candidates
            ],
        },
        note=result.reasoning,
    )


# ---------------------------------------------------------------------------
# Tool 2: check_inventory  (primary yard)
# ---------------------------------------------------------------------------

def check_inventory(sku: str, requested_qty: int) -> ToolCall:
    """Check primary-yard stock for a SKU against the requested quantity."""
    row = db.get_catalog_sku(sku)
    if row is None:
        return ToolCall(
            tool="check_inventory",
            input={"sku": sku, "requested_qty": requested_qty},
            output={"available": 0, "shortfall": requested_qty, "found": False},
            note=f"SKU {sku} not found in primary catalog.",
        )
    available = min(row["in_stock"], requested_qty)
    shortfall = max(requested_qty - row["in_stock"], 0)
    return ToolCall(
        tool="check_inventory",
        input={"sku": sku, "requested_qty": requested_qty},
        output={
            "available": available,
            "in_stock": row["in_stock"],
            "shortfall": shortfall,
            "found": True,
        },
        note=(
            f"Primary yard has {row['in_stock']} of {sku} in stock; "
            f"{available} of the requested {requested_qty} can be filled from primary "
            f"({shortfall} short)." if shortfall else
            f"Primary yard has enough stock of {sku} ({row['in_stock']} in stock) to "
            f"fully cover the requested {requested_qty}."
        ),
    )


# ---------------------------------------------------------------------------
# Tool 3: check_alt_yard
# ---------------------------------------------------------------------------

def check_alt_yard(sku: str, shortfall_qty: int) -> ToolCall:
    """Check the alternate yard's stock for a SKU that is short at the primary yard."""
    row = db.get_alt_yard_sku(sku)
    if row is None:
        return ToolCall(
            tool="check_alt_yard",
            input={"sku": sku, "shortfall_qty": shortfall_qty},
            output={"alt_available": 0, "found": False},
            note=f"SKU {sku} is not tracked at the alternate yard.",
        )
    # Data quality guard: the seed alt-yard file has a negative stock value for
    # EQ-110 (-2), which is not physically meaningful. Treat any negative value
    # as zero available rather than letting it silently produce a negative
    # reroute quantity.
    raw_stock = row["alt_stock"]
    clamped_stock = max(raw_stock, 0)
    alt_available = min(clamped_stock, shortfall_qty)
    note = (
        f"Alternate yard has {clamped_stock} of {sku} available "
        f"(covers {alt_available} of the {shortfall_qty} short)."
    )
    if raw_stock < 0:
        note += f" NOTE: source data reported a negative stock value ({raw_stock}); clamped to 0."
    return ToolCall(
        tool="check_alt_yard",
        input={"sku": sku, "shortfall_qty": shortfall_qty},
        output={
            "alt_available": alt_available,
            "alt_stock_raw": raw_stock,
            "ship_cost": row["ship_cost"],
            "found": True,
        },
        note=note,
    )


# ---------------------------------------------------------------------------
# Tool 4: reroute_to_alt_yard  (autonomous action)
# ---------------------------------------------------------------------------

def reroute_to_alt_yard(order_id: str, sku: str, qty: int, ship_cost: float, reasoning: str) -> ToolCall:
    """
    Autonomously reroute `qty` units of `sku` to be fulfilled from the alternate
    yard instead of the primary yard, because the primary yard is out of stock.
    This is a *separate* autonomous action from dispatch (per the brief) and is
    logged to dispatch_actions with action_type='reroute'.
    """
    db.decrement_alt_stock(sku, qty)
    db.log_dispatch_action(
        order_id=order_id,
        action_type="reroute",
        sku=sku,
        qty=qty,
        source_yard="alt",
        ship_cost=ship_cost,
        reasoning=reasoning,
        autonomous=True,
    )
    return ToolCall(
        tool="reroute_to_alt_yard",
        input={"order_id": order_id, "sku": sku, "qty": qty},
        output={"rerouted_qty": qty, "source_yard": "alt", "ship_cost": ship_cost},
        note=f"Autonomously rerouted {qty}x {sku} to the alternate yard (ship cost ${ship_cost:.2f}).",
    )


# ---------------------------------------------------------------------------
# Tool 5: dispatch_order  (autonomous action)
# ---------------------------------------------------------------------------

def dispatch_order(order_id: str, line_items: list[dict], reasoning: str) -> ToolCall:
    """
    Autonomously dispatch fulfillment for an order. Decrements primary-yard
    stock for whatever portion of each line item is being filled from primary,
    and logs one dispatch_actions row per SKU.
    """
    dispatched = []
    for li in line_items:
        primary_qty = li["fulfill_primary_qty"]
        if primary_qty > 0:
            db.decrement_primary_stock(li["resolved_sku"], primary_qty)
            db.log_dispatch_action(
                order_id=order_id,
                action_type="dispatch",
                sku=li["resolved_sku"],
                qty=primary_qty,
                source_yard="primary",
                ship_cost=0.0,
                reasoning=reasoning,
                autonomous=True,
            )
            dispatched.append({"sku": li["resolved_sku"], "qty": primary_qty, "source": "primary"})
        alt_qty = li.get("fulfill_alt_qty", 0)
        if alt_qty > 0:
            # The reroute decision itself (moving the shortfall to the alt
            # yard) was already logged by reroute_to_alt_yard(); this records
            # the corresponding outbound dispatch leg to the customer so the
            # order's dispatch history is complete even when 100% of a line
            # item ends up sourced from the alternate yard.
            db.log_dispatch_action(
                order_id=order_id,
                action_type="dispatch",
                sku=li["resolved_sku"],
                qty=alt_qty,
                source_yard="alt",
                ship_cost=0.0,
                reasoning=reasoning,
                autonomous=True,
            )
            dispatched.append({"sku": li["resolved_sku"], "qty": alt_qty, "source": "alt"})
    db.set_order_status(order_id, "processed_auto_dispatched")
    return ToolCall(
        tool="dispatch_order",
        input={"order_id": order_id},
        output={"dispatched": dispatched},
        note=f"Autonomously dispatched order {order_id} ({len(dispatched)} line item(s) from primary yard).",
    )
