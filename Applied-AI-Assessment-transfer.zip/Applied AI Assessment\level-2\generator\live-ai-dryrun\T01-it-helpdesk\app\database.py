"""
SQLite persistence layer.

This is the single place that knows about table schemas and raw SQL. Everything
else (agent, tools, server) goes through the functions here so persistence stays
swappable (e.g. to Postgres) without touching business logic.
"""
import sqlite3
import json
import os
import threading
from contextlib import contextmanager
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "helpdesk.db")

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS tickets (
    ticket_id TEXT PRIMARY KEY,
    requester_name TEXT NOT NULL,
    requester_tier TEXT NOT NULL,
    status TEXT NOT NULL,
    submitted_at TEXT NOT NULL,
    body_text TEXT NOT NULL,
    ingested_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS billing_records (
    requester_name TEXT PRIMARY KEY,
    verified_discrepancy REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS classifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    category TEXT,
    confidence REAL,
    reasoning TEXT,
    uncertain INTEGER NOT NULL DEFAULT 0,
    context_pulled TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    action_type TEXT NOT NULL,
    tool_name TEXT,
    tool_params TEXT,
    tool_result TEXT,
    actor TEXT NOT NULL DEFAULT 'agent',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS flags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    flag_type TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS overrides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    field TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    human_note TEXT,
    created_at TEXT NOT NULL
);
"""


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def get_conn():
    """Thread-local connection so the Flask dev server (threaded) is safe."""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        _local.conn = conn
    return conn


@contextmanager
def cursor():
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    with cursor() as cur:
        cur.executescript(SCHEMA)


# ---------------------------------------------------------------- tickets ---

def upsert_ticket(ticket_id, requester_name, requester_tier, status, submitted_at, body_text):
    with cursor() as cur:
        cur.execute(
            """INSERT INTO tickets (ticket_id, requester_name, requester_tier, status,
                                     submitted_at, body_text, ingested_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(ticket_id) DO UPDATE SET
                 requester_name=excluded.requester_name,
                 requester_tier=excluded.requester_tier,
                 status=excluded.status,
                 submitted_at=excluded.submitted_at,
                 body_text=excluded.body_text""",
            (ticket_id, requester_name, requester_tier, status, submitted_at, body_text, now_iso()),
        )


def get_ticket(ticket_id):
    with cursor() as cur:
        cur.execute("SELECT * FROM tickets WHERE ticket_id = ?", (ticket_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def list_tickets(exclude_ticket_id=None):
    with cursor() as cur:
        if exclude_ticket_id:
            cur.execute("SELECT * FROM tickets WHERE ticket_id != ? ORDER BY submitted_at",
                        (exclude_ticket_id,))
        else:
            cur.execute("SELECT * FROM tickets ORDER BY submitted_at")
        return [dict(r) for r in cur.fetchall()]


def update_ticket_status(ticket_id, status):
    with cursor() as cur:
        cur.execute("UPDATE tickets SET status = ? WHERE ticket_id = ?", (status, ticket_id))


# --------------------------------------------------------- billing records --

def load_billing_record(requester_name, verified_discrepancy):
    with cursor() as cur:
        cur.execute(
            """INSERT INTO billing_records (requester_name, verified_discrepancy)
               VALUES (?, ?)
               ON CONFLICT(requester_name) DO UPDATE SET verified_discrepancy=excluded.verified_discrepancy""",
            (requester_name, verified_discrepancy),
        )


def get_billing_record(requester_name):
    with cursor() as cur:
        cur.execute("SELECT * FROM billing_records WHERE requester_name = ?", (requester_name,))
        row = cur.fetchone()
        return dict(row) if row else None


# ------------------------------------------------------------ classification-

def add_classification(ticket_id, category, confidence, reasoning, uncertain, context_pulled=None):
    with cursor() as cur:
        cur.execute(
            """INSERT INTO classifications (ticket_id, category, confidence, reasoning,
                                             uncertain, context_pulled, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (ticket_id, category, confidence, reasoning, int(uncertain), context_pulled, now_iso()),
        )
        return cur.lastrowid


def latest_classification(ticket_id):
    with cursor() as cur:
        cur.execute(
            "SELECT * FROM classifications WHERE ticket_id = ? ORDER BY id DESC LIMIT 1",
            (ticket_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None


# ------------------------------------------------------------------ actions -

def add_action(ticket_id, action_type, tool_name=None, tool_params=None, tool_result=None, actor="agent"):
    with cursor() as cur:
        cur.execute(
            """INSERT INTO actions (ticket_id, action_type, tool_name, tool_params, tool_result,
                                     actor, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                ticket_id,
                action_type,
                tool_name,
                json.dumps(tool_params) if tool_params is not None else None,
                json.dumps(tool_result) if tool_result is not None else None,
                actor,
                now_iso(),
            ),
        )
        return cur.lastrowid


def list_actions(ticket_id):
    with cursor() as cur:
        cur.execute("SELECT * FROM actions WHERE ticket_id = ? ORDER BY id", (ticket_id,))
        return [dict(r) for r in cur.fetchall()]


# -------------------------------------------------------------------- flags -

def add_flag(ticket_id, flag_type, reason):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO flags (ticket_id, flag_type, reason, created_at) VALUES (?, ?, ?, ?)",
            (ticket_id, flag_type, reason, now_iso()),
        )


def list_flags(ticket_id):
    with cursor() as cur:
        cur.execute("SELECT * FROM flags WHERE ticket_id = ? ORDER BY id", (ticket_id,))
        return [dict(r) for r in cur.fetchall()]


# --------------------------------------------------------------- overrides --

def add_override(ticket_id, field, old_value, new_value, human_note=None):
    with cursor() as cur:
        cur.execute(
            """INSERT INTO overrides (ticket_id, field, old_value, new_value, human_note, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (ticket_id, field, old_value, new_value, human_note, now_iso()),
        )
        return cur.lastrowid


def list_overrides(ticket_id):
    with cursor() as cur:
        cur.execute("SELECT * FROM overrides WHERE ticket_id = ? ORDER BY id", (ticket_id,))
        return [dict(r) for r in cur.fetchall()]


# ----------------------------------------------------------------- summary --

def ticket_full_view(ticket_id):
    """Everything the UI needs for one ticket, assembled in one place."""
    ticket = get_ticket(ticket_id)
    if not ticket:
        return None
    return {
        "ticket": ticket,
        "classification": latest_classification(ticket_id),
        "actions": list_actions(ticket_id),
        "flags": list_flags(ticket_id),
        "overrides": list_overrides(ticket_id),
    }


def all_tickets_full_view():
    return [ticket_full_view(t["ticket_id"]) for t in list_tickets()]
