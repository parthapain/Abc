import hashlib
import pandas as pd
from resolution_client import issue_resolution, TransientResolutionError, PermanentResolutionError
import db_models

tickets_df = pd.read_csv("helpdesk_tickets.csv").fillna("")
billing_df = pd.read_csv("license_billing_records.csv").set_index("requester_name")

RESOLUTION_THRESHOLD = 50.00

# Ambiguity #1 ("flag items that need immediate attention") -- deliberate
# resolution, isolated behind a single flag so it's a one-line change if this
# assumption is wrong. `requester_tier` (VIP vs. Standard) is present in the
# data, but a VIP label doesn't change how operationally severe an issue
# actually is -- it's a status signal, not a risk signal. Urgency here is
# judged on objective severity language in the request body, not on who's
# asking. See README.md "Key decisions".
USE_REQUESTER_TIER_IN_URGENCY = False

_URGENCY_SIGNALS = ["asap", "urgent", "production", "blocked", "minutes", "locked out", "entire remote team"]

_SECURITY_SIGNALS = ["someone else", "unauthorized", "locked after repeated failed login", "worried"]
_NETWORK_SIGNALS = ["vpn", "can't log in", "can't connect"]
_HARDWARE_SIGNALS = ["turn on", "won't power on", "screen flicker", "monitor"]
_SOFTWARE_SIGNALS = ["wallpaper", "desktop", "software", "install"]
_BILLING_SIGNALS = ["charged", "refund", "overcharged", "billing error", "reimburse", "subscription", "license renewal"]


def classify_ticket(body_text):
    """
    Returns {"status": "OK", "category": ..., "confidence": ...}
    or {"status": "OK", "category": "AMBIGUOUS_ROUTING", "candidates": [...]}
    or {"status": "CLASSIFICATION_FAILED"} -- distinct from a real low-confidence
    result, so a failed classification can never be mistaken for a genuine one.
    """
    text = body_text.strip().lower()
    if not text:
        return {"status": "CLASSIFICATION_FAILED"}

    hits_security = any(s in text for s in _SECURITY_SIGNALS)
    hits_network = any(s in text for s in _NETWORK_SIGNALS)

    if hits_security and hits_network:
        return {
            "status": "OK", "category": "AMBIGUOUS_ROUTING",
            "candidates": ["Network/VPN", "Security Incident"], "confidence": 0.9,
        }
    if hits_network:
        return {"status": "OK", "category": "Network/VPN", "confidence": 0.9}
    if any(s in text for s in _BILLING_SIGNALS):
        return {"status": "OK", "category": "Licensing & Reimbursement", "confidence": 0.9}
    if any(s in text for s in _HARDWARE_SIGNALS):
        return {"status": "OK", "category": "Hardware", "confidence": 0.85}
    if any(s in text for s in _SOFTWARE_SIGNALS):
        return {"status": "OK", "category": "Software Access", "confidence": 0.85}
    return {"status": "OK", "category": "Software Access", "confidence": 0.4}


def search_similar_items(requester_name, body_text, exclude_ticket_id):
    """
    Returns {"status": "NONE"} / {"status": "RESOLVED", "match": ticket_id, "match_status": ...}
    / {"status": "AMBIGUOUS", "candidates": [...]}
    Never silently picks one of several plausible prior matches.
    """
    text = set(body_text.lower().split())
    history = tickets_df[
        (tickets_df["requester_name"] == requester_name)
        & (tickets_df["ticket_id"] != exclude_ticket_id)
        & (tickets_df["status"].isin(["open", "closed"]))
    ]
    candidates = []
    for _, row in history.iterrows():
        overlap = len(text & set(row["body_text"].lower().split()))
        if overlap >= 3:  # crude but deliberate: "plausible enough to matter" threshold
            candidates.append((row["ticket_id"], row["status"]))

    if len(candidates) == 0:
        return {"status": "NONE"}
    if len(candidates) == 1:
        return {"status": "RESOLVED", "match": candidates[0][0], "match_status": candidates[0][1]}
    return {"status": "AMBIGUOUS", "candidates": [c[0] for c in candidates]}


def check_billing_record(requester_name):
    """Returns (discrepancy, valid) -- 'valid' False when the tool's own
    response doesn't make sense (a negative discrepancy)."""
    if requester_name not in billing_df.index:
        return None, True
    discrepancy = float(billing_df.loc[requester_name, "verified_discrepancy"])
    if discrepancy < 0:
        return discrepancy, False
    return discrepancy, True


def is_urgent(body_text, requester_tier):
    text = body_text.lower()
    urgent_by_severity = any(s in text for s in _URGENCY_SIGNALS)
    if USE_REQUESTER_TIER_IN_URGENCY:
        return urgent_by_severity or requester_tier == "VIP"
    return urgent_by_severity


def process_ticket(ticket_row, force_lost_response_for_ticket=None):
    ticket_id = ticket_row["ticket_id"]
    requester_name = ticket_row["requester_name"]
    requester_tier = ticket_row["requester_tier"]
    body_text = ticket_row["body_text"]
    logs = [f"Started processing {ticket_id} (requester_tier='{requester_tier}')"]

    if not USE_REQUESTER_TIER_IN_URGENCY:
        logs.append(
            "requester_tier noted but deliberately excluded from the urgency decision -- "
            "a VIP label is a status signal, not an operational-severity signal. Urgency is "
            "judged on the request's own content."
        )

    classification = classify_ticket(body_text)

    if classification["status"] == "CLASSIFICATION_FAILED":
        logs.append("Classification failed (empty/unusable body) -- flagged distinctly, escalating for review.")
        db_models.save_ticket(ticket_id, requester_name, requester_tier, "UNCLASSIFIED", "ESCALATED_CLASSIFICATION_FAILED", "N/A", logs)
        return "ESCALATED_CLASSIFICATION_FAILED", "UNCLASSIFIED", logs

    if classification["category"] == "AMBIGUOUS_ROUTING":
        logs.append(
            f"AMBIGUOUS: request plausibly belongs to more than one team "
            f"({', '.join(classification['candidates'])}) -- escalating for a person to triage, not guessing."
        )
        db_models.save_ticket(ticket_id, requester_name, requester_tier, "AMBIGUOUS_ROUTING", "ESCALATED_AMBIGUOUS_ROUTING", "N/A", logs)
        return "ESCALATED_AMBIGUOUS_ROUTING", "AMBIGUOUS_ROUTING", logs

    category = classification["category"]
    confidence = classification["confidence"]
    logs.append(f"Classified as '{category}' (confidence={confidence}).")

    dedup = search_similar_items(requester_name, body_text, ticket_id)
    if dedup["status"] == "AMBIGUOUS":
        logs.append(
            f"AMBIGUOUS duplicate match: more than one plausible prior ticket "
            f"({', '.join(dedup['candidates'])}) with different implications -- escalating for a person to decide, not auto-closing."
        )
        db_models.save_ticket(ticket_id, requester_name, requester_tier, category, "ESCALATED_AMBIGUOUS_DUPLICATE", "N/A", logs)
        return "ESCALATED_AMBIGUOUS_DUPLICATE", category, logs
    if dedup["status"] == "RESOLVED" and dedup["match_status"] == "closed":
        logs.append(f"Matches prior resolved ticket {dedup['match']} -- safe to auto-close as duplicate.")

    urgent = is_urgent(body_text, requester_tier)
    priority_flag = "URGENT" if urgent else "NORMAL"
    if urgent:
        logs.append("Flagged URGENT by content-based policy -- this must escalate regardless of classification confidence.")

    # First guardrail: auto-act only on high confidence, no blocking dedup
    # issue, and NOT flagged urgent (element 2 coupling).
    if category == "Licensing & Reimbursement":
        final_status, logs = _process_reimbursement(ticket_row, category, confidence, urgent, logs, force_lost_response_for_ticket)
        db_models.save_ticket(ticket_id, requester_name, requester_tier, category, final_status, priority_flag, logs)
        return final_status, category, logs

    if urgent:
        final_status = "ESCALATED_URGENT"
    elif confidence >= 0.8 and dedup["status"] != "AMBIGUOUS":
        final_status = "AUTO_ROUTED"
        logs.append(f"High confidence, no blocking issue, not urgent -- auto-routing to {category} team.")
    else:
        final_status = "ESCALATED_LOW_CONFIDENCE"

    db_models.save_ticket(ticket_id, requester_name, requester_tier, category, final_status, priority_flag, logs)
    return final_status, category, logs


def _process_reimbursement(ticket_row, category, confidence, urgent, logs, force_lost_response_for_ticket):
    ticket_id = ticket_row["ticket_id"]
    requester_name = ticket_row["requester_name"]

    discrepancy, valid = check_billing_record(requester_name)

    if discrepancy is None:
        logs.append("No billing record on file to corroborate this claim -- escalating.")
        return "ESCALATED_UNCORROBORATED", logs

    if not valid:
        logs.append(
            f"Billing record is invalid (verified_discrepancy={discrepancy}) -- not trusting this data, escalating."
        )
        return "ESCALATED_INVALID_BILLING_DATA", logs

    if discrepancy == 0:
        logs.append("Verified discrepancy is $0 -- claim not corroborated, escalating.")
        return "ESCALATED_UNCORROBORATED", logs

    if discrepancy > RESOLUTION_THRESHOLD:
        logs.append(f"Verified discrepancy (${discrepancy}) exceeds the ${RESOLUTION_THRESHOLD} threshold -- escalating.")
        return "ESCALATED_VALUE", logs

    logs.append(f"Verified discrepancy (${discrepancy}) is within threshold -- attempting courtesy resolution.")

    idempotency_key = hashlib.sha256(f"{ticket_id}|resolution|{requester_name}|{discrepancy}".encode()).hexdigest()
    force_lost_response = (ticket_id == force_lost_response_for_ticket)

    for attempt in range(3):
        try:
            result = issue_resolution(
                ticket_id, requester_name, discrepancy, idempotency_key,
                force_lost_response=(force_lost_response and attempt == 0),
            )
            is_new = db_models.record_resolution(ticket_id, idempotency_key, result["resolution_id"])
            logs.append(
                f"Resolution call succeeded (resolution_id={result['resolution_id']}); "
                f"{'new resolution record created' if is_new else 'already recorded -- retry correctly did not duplicate'}."
            )
            return ("PARTIALLY_RESOLVED" if urgent else "RESOLVED"), logs
        except TransientResolutionError as e:
            logs.append(f"Transient failure on attempt {attempt + 1}: {e}")
        except PermanentResolutionError as e:
            logs.append(f"Permanent failure: {e}")
            return "ESCALATED_UNAVAILABLE", logs

    logs.append("Max retries reached without success -- escalating to a human.")
    return "ESCALATED_NETWORK", logs
