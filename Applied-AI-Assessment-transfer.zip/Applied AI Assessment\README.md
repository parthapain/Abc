# Applied AI Developer Assessment

Content and specifications for a two-level hiring assessment. **Level 1 is complete** (1,000+ participants, 300 cleared). **Level 2 is in active design** for those 300 — rebuilt from scratch after Level 1's real numbers came in.

## Start here

| If you are… | Read |
|---|---|
| Picking this up cold, or on another machine | [`HANDOFF.md`](HANDOFF.md) — **start here** |
| Wondering why something was decided this way | [`design-rationale.md`](design-rationale.md) — covers both levels |
| Coordinating with HirePro (Level 1) | [`hirepro-dependencies.md`](hirepro-dependencies.md) |
| Working on Level 2 | [`level-2/`](level-2/) — see its own status below |
| Understanding why Dimension 4 works the way it does | [`level-2/dependencies/llm-gateway-logging.md`](level-2/dependencies/llm-gateway-logging.md) — **resolved: no server-side log; read this for why grading changed** |

## Layout

```
├── HANDOFF.md                     Context for resuming cold; decisions already settled
├── design-rationale.md            Approved design for both levels, incl. industry benchmarking
├── hirepro-dependencies.md        Level 1: ten questions for HirePro; six block authoring
├── part-a/
│   └── part-a-complexity-mix.md   Level 1: 21-question topic × complexity spec
├── part-b/
│   ├── part-b-paper-mapping.md    Level 1: 24-problem bank → 6 launch papers, with balance checks
│   ├── problems/                  Level 1: candidate-facing problems + solutions + reviewer checklists
│   └── validation/
│       ├── harness.py             Level 1: the validation gate
│       └── specs/                 Level 1: executable definition of each problem
└── level-2/
    ├── level-2-design-principles.md   Superseded — redirects to the files below
    ├── testing-principles.md          Vendor-neutral skill categories every template's slots must draw from
    ├── rubric.md                      5-dimension scoring rubric, 0–20 (AI grader + 3 human reviewers)
    ├── rubric.html                    Plain-language HTML version of rubric.md, for non-technical readers
    ├── presentation.html              Manager-facing slide deck: how Level 2 is built, tested, and scored (~2 min read)
    ├── generator/
    │   ├── architecture.md            Template + parameter design for 300+ comparable instances
    │   ├── generate_instances.py      The generator tool
    │   └── template_definitions.py    T01/T02 template content (pre-calibration)
    ├── templates/                     T01 (triage/classification), T02 (structured extraction), T03 (refund/request handling), T04 (order fulfillment/reliability) — none calibrated
    ├── grading/
    │   ├── grading-prompt.md          AI-grader instructions, operationalizing rubric.md
    │   ├── calibration-process.md     Mandatory validation before grading real candidates
    │   └── cutoff-and-aggregation.md  Absolute-bar cutoff, reconciled against 3-reviewer bandwidth
    ├── dependencies/
    │   └── llm-gateway-logging.md     Resolved: no server-side log — records why Dimension 4 was redesigned
    └── logistics.md                   Provisioning, disclosure, submission mechanics
```

## Running the Level 1 validation gate

```bash
python "part-b/validation/harness.py"
```

For a single problem: `python "part-b/validation/harness.py" p14`

Asserts four things per problem: the reference solution passes every case; the broken version fails every *discriminator* case; the broken version **passes** every *guard* case (proving breakage is specific, not incidental); every documented wrong-fix is caught by at least one case. It caught three real defects during authoring — see the closing section of `part-b/part-b-paper-mapping.md`.

## Running the Level 2 generator (preview mode only — see status below)

```bash
python "level-2/generator/generate_instances.py" --count 20 --out /some/preview/dir --allow-uncalibrated --seed 7
```

`--allow-uncalibrated` is required because **no template has passed calibration yet** — the flag exists specifically so this can't be pointed at real candidates by accident. Without it, the tool refuses to run.

## Status

### Level 1 — complete, live

| Deliverable | State |
|---|---|
| HirePro dependency checklist | ✅ Sent / resolved |
| Part A complexity spec | ✅ Complete |
| Part B — 24-problem bank | ✅ 24/24 passing validation |
| Part B — paper mapping | ✅ Complete |
| **Result** | **1,000+ participants, 300 cleared** |

Known limitations carried forward from Level 1 (Java/C# variants not machine-verified, difficulty labels are authorial judgement) are documented in `HANDOFF.md`.

### Level 2 — in design, rebuilt from scratch post-Level-1

| Deliverable | State |
|---|---|
| Testing principles (vendor-neutral skill categories) | ✅ Drafted |
| Rubric (5 dimensions, 0–20, behavioral anchors) | ✅ Drafted — Dimension 1 (architecture) split from the new Dimension 2 (agentic design/tools/guardrails) |
| LLM-gateway logging dependency doc | ✅ Resolved — no server-side log; rubric/grading/templates updated |
| Generator architecture + tool | ✅ Built and verified (see Known limitations) |
| Templates | **Mandatory shape strengthened again (Addendum 20): every template must now plant two ambiguities and two independently-guardrailed actions, not one.** Everything below this line describes the *old* 1-ambiguity/1-guardrail shape and is now superseded, kept as an accurate historical record: all 4 fully authored, all 4 locked to the mandatory agentic/tool/guardrail shape, all 4 with a completed dry-run calibration — re-validated (Run #2 in each) against the 5-dimension/0–20 rubric split. T01/T02 rework complete; T03 (category 4 trap), T04 (category 5 trap) built to the shape from the start. T01, T02, and T04 confirmed a compounding guardrail bug (a general form now added to the AI grader's guidance); T03's result was mixed, reported honestly. The re-validation pass also resolved a new grading-consistency question the split exposed — "gated decision, ungated parameter" (T03) caps Dimension 2 at **2**, and "two cap-triggering findings in one dimension" (T04) caps at the worse of the two — now general rules in the rubric and grading prompt. See `level-2/grading/calibration-runs/` and `level-2/design-rationale.md` Addenda 17–18. **None of this carries over to the new 2/2 shape** — the second ambiguity/guardrail is now authored into all 4 templates **and dry-run calibrated** (Calibration Run #3: T02/T03 confirmed as hypothesized, T01/T04 refined to a different/sharper real mechanism after testing), but all 4 remain not-yet-officially-calibrated until each second guardrail's compounding-failure risk is verified against an actual live AI assistant, plus the still-pending timed human build. See Addendum 20. |
| AI-grading prompt | ✅ Drafted |
| Calibration process | ✅ Drafted, not yet run |
| Cutoff/aggregation mechanism | ✅ Drafted |
| Logistics | ✅ Drafted |
| 300+ instance generation | ⏳ Blocked on template calibration |

**Nothing in Level 2 is launch-ready yet.** The generator works (verified below) but every template needs its trap tested against a live AI assistant before real instances are generated — see `level-2/generator/architecture.md`.

## Known limitations (Level 2)

- **The mandatory shape changed again (Addendum 20) and none of the 4 templates has been officially recalibrated at it yet.** Every template must now plant two ambiguities and two independently-guardrailed actions, not one — triggered by a quick internal test build (Gemini Pro, ~15 min) still scoring 9/20 on the old 1/1 shape. All 4 templates now have a Calibration Run #3 dry-run for the second guardrail (T02/T03 confirmed as hypothesized, T01/T04 refined after testing revealed a different/sharper real mechanism), but none of it has been verified against an actual live AI assistant yet — nothing below reflects the currently required shape until that happens, plus the still-pending timed human build.
- **All 4 templates have a completed dry-run calibration at the old, superseded 1-ambiguity/1-guardrail shape; none is officially calibrated at any shape.** T01, T02, and T04 all confirmed a version of the same compounding guardrail bug — a default-value gap that lets a failed or unverified result slip through as "safe to auto-act on" (now generalized into `level-2/grading/grading-prompt.md`'s Dimension 2 guidance as something to check on any submission). T03's dry-run honestly reports that this specific bug did *not* reproduce there, while a different, T03-specific gap (unverified action parameters) did — and that its trap's exact manifestation depends on implementation style. See `level-2/grading/calibration-runs/`. The remaining step — an actual timed human build (T01 first, then T02/T03/T04 in order) — gates official calibration for all four. Do not generate real candidate instances until it's done.
- **The AI-grading rubric is unvalidated.** `level-2/grading/calibration-process.md` must run against a real calibration set (with human-agreed baseline scores) before the grader can be trusted on real submissions — this is the single highest-risk element of the whole Level 2 design, since the AI grader is the only gate to human review.
- **No server-side AI-interaction log exists, and no commit history either — confirmed.** Submissions arrive as a single final code snapshot. Rubric Dimension 4 (AI-output verification) was redesigned around the final code and rationale only — see `level-2/dependencies/llm-gateway-logging.md`. This makes Dimension 4 a weaker signal than the original design (it can no longer reliably tell "never checked" from "checked reactively," and there's no timing evidence at all), an accepted trade-off documented in the rubric itself.
- **All 4 needed templates are now fully authored and locked to the mandatory shape — T01 and T02's rework is complete.** All 4 meet the mandatory agentic/tool/context/guardrail requirement (`level-2/testing-principles.md` categories 8, 9, 10, 12). See `level-2/generator/architecture.md` for what each rework added and the calibration sequencing.
- **Security/sensitive-data handling and cost/efficiency awareness (`level-2/testing-principles.md` categories 11, 13) are new rubric expectations not yet exercised against any real or sample submission.** They don't require template changes (every dataset already carries sensitive-looking fields; every architecture has an efficiency profile) but haven't been validated in practice yet.
- **Dimensions 2 and 5's capping rules, and the Dimension-2-vs-Dimension-4 guardrail-ownership split, are unvalidated on paper.** An independent peer review found both dimensions bundled multiple sub-criteria into one 0–4 score with no combination rule, and that a naive agentic guardrail's own default behavior had no assigned owner between them. Both are now fixed (`level-2/rubric.md`, `level-2/grading/grading-prompt.md`, `level-2/testing-principles.md` category 12), with calibration case #7 (`level-2/grading/calibration-process.md`) added specifically to check the AI grader applies the caps instead of averaging a hard failure away — but that calibration hasn't run yet.
- **Dimension 1 was split into two dimensions (rubric now 0–20, not 0–16).** Base architecture fit (now Dimension 1) was separated from agentic design/tools/guardrails/cost-efficiency (new Dimension 2), since the latter had grown to cover most of `../testing-principles.md`'s mandatory categories (8, 9, 12, 13) on its own. All downstream docs, all 4 templates, and the calibration-run write-ups have been renumbered to match — see `level-2/design-rationale.md` Addendum 16.
- **All 4 templates' dry-run calibrations have been re-run against the new split (Addenda 17–18) — findings hold, but the split exposed one real grading-consistency gap, now closed.** A guardrail that gates the *decision* correctly but leaves the executed *parameter* unverified (confirmed in T03, and as one of two co-occurring defects in T04) had no explicit cap level in either the pre- or post-split rubric. First resolved as Dimension 2 cap-1, then corrected to **cap-2** ("guardrail exists in name only") after human review — the decision-level check is real and works, so it isn't "no gate at all"; cap-1 is reserved for a guardrail that's actually defeated or absent. Written into `level-2/rubric.md` §2, `level-2/grading/grading-prompt.md`, and a new calibration-set case #8 in `level-2/grading/calibration-process.md`. Still not validated against a real calibration set, since that hasn't run yet regardless — this re-validation was a dry-run consistency check, not a live grading test.
- **T01's rework must be timeboxed against the new mandatory scope before any template is calibrated.** The 24–48hr estimate predates the agentic/tool/context/guardrail requirement and hasn't been re-validated against it — this gates calibration order, not authoring (all 4 templates are already authored) — see the sequencing note in `level-2/generator/architecture.md`.
- **Grading is static-only for all 300+ initial submissions — no execution environment is provisioned at that scale.** Persistence/DB behavior and everything else is assessed from the submitted code (schema, migrations, query logic), never by running it (`level-2/rubric.md` §4, `level-2/grading/grading-prompt.md`). The only execution check in the whole design is a short live demonstration requested from candidates who clear the cutoff, before human review (`level-2/grading/cutoff-and-aggregation.md`) — this hasn't been exercised against a real candidate yet, and the scheduling logistics for it aren't built (`level-2/logistics.md`).
- **Submission is a single zip upload (10MB max, dependency directories/build output excluded), not a hosted repo.** Replaces the earlier per-candidate Bitbucket provisioning plan — see `level-2/logistics.md` and both templates' submission lines. The upload portal itself (size-cap enforcement, malware scanning, per-candidate deadline enforcement) is not yet built.
