from app.tools import cross_check_field, load_all_agreements, lookup_loan_status, lookup_related_document


def test_load_all_agreements_splits_multi_loan_file():
    agreements = load_all_agreements()
    loan_numbers = {a["loan_number"] for a in agreements}
    # LN-7006-7007.txt must be split into two separate agreements
    assert "LN-7006" in loan_numbers
    assert "LN-7007" in loan_numbers
    assert len(agreements) == 11  # one per loan, note files excluded


def test_load_all_agreements_excludes_note_files():
    agreements = load_all_agreements()
    for a in agreements:
        assert "-note" not in a["source_file"]


def test_cross_check_field_true_and_false():
    text = "The borrower is Acme Inc. and the amount is $100."
    assert cross_check_field(text, "Acme Inc.") is True
    assert cross_check_field(text, "Globex Corp.") is False
    assert cross_check_field(text, None) is False


def test_lookup_related_document_finds_multiple_notes_for_LN7004():
    docs = lookup_related_document("LN-7004")
    filenames = {d["filename"] for d in docs}
    assert filenames == {"LN-7004-note-original.txt", "LN-7004-note-amended.txt"}


def test_lookup_related_document_single_note_for_LN7002():
    docs = lookup_related_document("LN-7002")
    assert len(docs) == 1
    assert docs[0]["filename"] == "LN-7002-note.txt"


def test_lookup_loan_status_known_and_unknown():
    assert lookup_loan_status("LN-7001") == "active"
    assert lookup_loan_status("LN-7003") == "paid_off"
    assert lookup_loan_status("LN-7009") is None  # not in registry
