# LLM Gateway Logging — Resolved: No

**Status: closed.** The answer confirmed is **no** — there is no server-side per-candidate interaction log available, and none is planned. **Separately confirmed: there is also no commit history** — submissions arrive as a single final code snapshot, not an incremental history. This document originally asked whether a log could be provisioned in time; that question no longer needs asking, and it turned out to not matter which way it went, since the fallback evidence source (commit history) turned out to be unavailable too. It's kept here (rather than deleted) as a record of what was asked, what was decided, and what changed as a result — see `../design-rationale.md` for the full account.

---

## What this doc originally asked (for context)

Level 2's rubric was designed to score whether a candidate verified or blindly accepted AI-generated code, by comparing what the AI proposed against what shipped — which only works with a reliable, per-candidate, server-captured record of AI interactions (not a candidate-exported one, which is trivially curated). This doc asked whether the in-house LLM/MCP gateway could provide that. It can't, and no equivalent capability exists.

## What changed as a result

This was the single biggest dependency risk called out in the original Level 2 design, and it resolved in the direction this doc's own "if the answer is no" section anticipated:

- **Rubric Dimension 4 (AI-output verification)** was rewritten around what's actually available: the final shipped code (a single snapshot, no history) and the written rationale. See `../rubric.md` Dimension 4 for the reworked anchors, and its grading note on never letting a rationale's claims outrun what the code demonstrates — that note is the direct replacement for what log evidence used to provide. There is now no timing signal of any kind — not "before/reactive-after/never," not even a rough "early commit vs. late commit" proxy.
- **The candidate-facing disclosure line** ("your AI interactions are logged...") has been removed from both templates (`../templates/T01-*.md`, `../templates/T02-*.md`), since it would now be false. Candidates are instead asked to submit their final repository (commit history is not collected) and to describe, in their rationale, anything they questioned or corrected in AI-generated output.
- **The AI-grading prompt** (`../grading/grading-prompt.md`) and **calibration process** (`../grading/calibration-process.md`) were both updated to drop every reference to interaction-log evidence and to add an explicit calibration case for the new central risk this creates: a rationale *claiming* verification happened with no corresponding code to back it up.
- **Logistics** (`../logistics.md`) no longer requires logging-capable credential provisioning — candidate LLM/MCP access is ordinary tool access, and the "submission closed" bundle the grader needs is just the submitted zip plus rationale, not a three-artifact bundle.

## The honest cost of this, carried forward

Dimension 4 is now a strictly weaker signal than originally designed: it can no longer reliably distinguish "never considered the risk," "considered it and got lucky," and "caught it reactively after a visible failure" — those distinctions required watching a conversation unfold turn by turn, and that evidence doesn't exist. What it *can* still do: confirm whether the flaw is present or absent in the final code, and — when a candidate's rationale specifically names the risk and points to a checkable mechanism in the code — credit deliberate verification over a submission that shows no awareness of the risk at all. Every other testing principle (`../testing-principles.md`) survives this change unchanged; this dependency only ever touched Dimension 4 directly, with light touches to Dimensions 3 and 5's grading notes for consistency.
