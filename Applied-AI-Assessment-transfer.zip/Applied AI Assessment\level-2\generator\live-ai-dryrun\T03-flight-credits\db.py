"""
Persistence layer (SQLite).

Schema:
  bookings          - snapshot of booking_records.csv, the system of record for verification
  rebooking_history - snapshot of rebooking_history.csv (customer -> rebookings in last 30 days)
  requests          - one row per inbound flight_requests.csv row, with current status
  reasoning_log     - append-only trace of every agent step taken while processing a request
                       (this is what the UI renders as "agent reasoning")
  actions           - executed actions (refund or rebooking), by agent or human
  overrides         - human review decisions that changed (or confirmed) an agent outcome

All writes go through this module so app.py / agent.py / tools.py never touch SQL directly
except here, which keeps the persistence story in one place per the brief's requirement #9.
"""
import sqlite3
import json
import os
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flight_credits.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS bookings (
    booking_ref TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    flight_route TEXT NOT NULL,
    verified_category TEXT NOT NULL,
    ticket_value REAL NOT NULL,
    credit_eligible INTEGER NOT NULL,
    credit_value REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS rebooking_history (
    customer_name TEXT PRIMARY KEY,
    rebookings_last_30_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS requests (
    request_id TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    customer_tier TEXT,
    booking_ref TEXT NOT NULL,
    submitted_at TEXT,
    request_text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    final_action_type TEXT,
    final_amount REAL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reasoning_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    step_order INTEGER NOT NULL,
    step_name TEXT NOT NULL,
    detail TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (request_id) REFERENCES requests(request_id)
);

CREATE TABLE IF NOT EXISTS actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    action_type TEXT NOT NULL,       -- 'refund' | 'rebooking'
    amount REAL,                     -- refund amount, null for rebooking
    details TEXT,                    -- JSON blob (e.g. new flight info)
    source TEXT NOT NULL,            -- 'agent' | 'human'
    status TEXT NOT NULL DEFAULT 'executed',  -- 'executed' | 'reversed'
    created_at TEXT NOT NULL,
    FOREIGN KEY (request_id) REFERENCES requests(request_id)
);

CREATE TABLE IF NOT EXISTS overrides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    reviewer_name TEXT,
    previous_status TEXT,
    new_status TEXT,
    note TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (request_id) REFERENCES requests(request_id)
);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(reset: bool = False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ---------- bookings / rebooking_history (reference data) ----------

def upsert_booking(b: dict):
    conn = get_conn()
    conn.execute(
        """INSERT INTO bookings (booking_ref, customer_name, flight_route, verified_category,
                                  ticket_value, credit_eligible, credit_value)
           VALUES (:booking_ref, :customer_name, :flight_route, :verified_category,
                   :ticket_value, :credit_eligible, :credit_value)
           ON CONFLICT(booking_ref) DO UPDATE SET
             customer_name=excluded.customer_name,
             flight_route=excluded.flight_route,
             verified_category=excluded.verified_category,
             ticket_value=excluded.ticket_value,
             credit_eligible=excluded.credit_eligible,
             credit_value=excluded.credit_value""",
        b,
    )
    conn.commit()
    conn.close()


def get_booking(booking_ref: str):
    conn = get_conn()
    row = conn.execute("SELECT * FROM bookings WHERE booking_ref = ?", (booking_ref,)).fetchone()
    conn.close()
    return dict(row) if row else None


def upsert_rebooking_history(customer_name: str, count: int):
    conn = get_conn()
    conn.execute(
        """INSERT INTO rebooking_history (customer_name, rebookings_last_30_days)
           VALUES (?, ?)
           ON CONFLICT(customer_name) DO UPDATE SET rebookings_last_30_days=excluded.rebookings_last_30_days""",
        (customer_name, count),
    )
    conn.commit()
    conn.close()


def get_rebooking_count(customer_name: str) -> int:
    conn = get_conn()
    row = conn.execute(
        "SELECT rebookings_last_30_days FROM rebooking_history WHERE customer_name = ?",
        (customer_name,),
    ).fetchone()
    conn.close()
    return row["rebookings_last_30_days"] if row else 0


# ---------- requests ----------

def insert_request(r: dict):
    conn = get_conn()
    ts = now()
    conn.execute(
        """INSERT OR IGNORE INTO requests
           (request_id, customer_name, customer_tier, booking_ref, submitted_at, request_text,
            status, created_at, updated_at)
           VALUES (:request_id, :customer_name, :customer_tier, :booking_ref, :submitted_at,
                   :request_text, 'pending', :created_at, :updated_at)""",
        {**r, "created_at": ts, "updated_at": ts},
    )
    conn.commit()
    conn.close()


def update_request_status(request_id: str, status: str, final_action_type=None, final_amount=None):
    conn = get_conn()
    conn.execute(
        """UPDATE requests SET status=?, final_action_type=COALESCE(?, final_action_type),
           final_amount=COALESCE(?, final_amount), updated_at=? WHERE request_id=?""",
        (status, final_action_type, final_amount, now(), request_id),
    )
    conn.commit()
    conn.close()


def get_request(request_id: str):
    conn = get_conn()
    row = conn.execute("SELECT * FROM requests WHERE request_id = ?", (request_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_requests():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM requests ORDER BY submitted_at ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------- reasoning log ----------

def log_step(request_id: str, step_name: str, detail):
    conn = get_conn()
    n = conn.execute(
        "SELECT COALESCE(MAX(step_order), 0) + 1 AS n FROM reasoning_log WHERE request_id=?",
        (request_id,),
    ).fetchone()["n"]
    detail_str = detail if isinstance(detail, str) else json.dumps(detail, default=str)
    conn.execute(
        "INSERT INTO reasoning_log (request_id, step_order, step_name, detail, created_at) VALUES (?,?,?,?,?)",
        (request_id, n, step_name, detail_str, now()),
    )
    conn.commit()
    conn.close()


def get_reasoning_log(request_id: str):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM reasoning_log WHERE request_id=? ORDER BY step_order ASC", (request_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------- actions ----------

def record_action(request_id: str, action_type: str, amount, details, source: str):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO actions (request_id, action_type, amount, details, source, status, created_at)
           VALUES (?,?,?,?,?, 'executed', ?)""",
        (request_id, action_type, amount, json.dumps(details, default=str), source, now()),
    )
    conn.commit()
    action_id = cur.lastrowid
    conn.close()
    return action_id


def get_actions(request_id: str):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM actions WHERE request_id=? ORDER BY created_at ASC", (request_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def reverse_actions(request_id: str):
    conn = get_conn()
    conn.execute(
        "UPDATE actions SET status='reversed' WHERE request_id=? AND status='executed'",
        (request_id,),
    )
    conn.commit()
    conn.close()


# ---------- overrides ----------

def record_override(request_id: str, reviewer_name: str, previous_status: str, new_status: str, note: str):
    conn = get_conn()
    conn.execute(
        """INSERT INTO overrides (request_id, reviewer_name, previous_status, new_status, note, created_at)
           VALUES (?,?,?,?,?,?)""",
        (request_id, reviewer_name, previous_status, new_status, note, now()),
    )
    conn.commit()
    conn.close()


def get_overrides(request_id: str):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM overrides WHERE request_id=? ORDER BY created_at ASC", (request_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
