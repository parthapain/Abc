# AI-Grader Calibration — Process

**This step is not optional.** The AI grader is the only gate between 300 submissions and 3 human reviewers — nothing reaches a human unless the AI grader passes it. An unvalidated grading prompt doesn't fail gracefully; it silently discards good candidates without anyone noticing until it's too late to recover them. This process is the only check against that before the grader runs unsupervised on real candidates.

## What "calibration" means here

Build a small set of submissions with **known, agreed-upon scores** (decided by a human first), run them through the AI grader, and check whether its scores match. Disagreement tells you whether the problem is the rubric anchors, the grading prompt, or the AI grader's judgment — and which to fix before trusting it on 300 real people.

## Building the calibration set (5–7 submissions)

Aim for spread, not just volume:

1. **One clearly strong submission** — resolves the ambiguity deliberately, catches the AI trap, handles the stress point well. Should score high on every dimension. If your own team can build this in the same 24–48hr window as part of the dry run (see architecture doc), use that; it doubles as validation that a strong solution is achievable in the time given.
2. **One clearly weak submission** — a rushed or naive attempt: ambiguity resolved arbitrarily with no reasoning shown, the AI trap shipped unmodified, stress point crashes. Should score low across the board.
3. **One "confidently wrong" submission** — polished code and a well-written rationale, but the AI trap is present and unverified, or the ambiguity is resolved without real justification. This is the one that tests whether the grader is scoring substance or scoring polish — the specific failure mode named in the grading prompt's "don't let confidence substitute for correctness" instruction.
4. **One "correct by luck" submission** — the right outcome (ambiguity resolved sensibly, trap avoided) but with no visible reasoning anywhere — no rationale mention of either. Should score no higher than a 1 on dimension 3 and a 1 on dimension 4 per the anchors, even though the outcome looks fine.
5. **One "unsupported claim" submission** — the trap is present unmodified in the shipped code, but the rationale *claims* the candidate verified and corrected it. This is the specific failure mode the no-log, no-history constraint creates: confirm the grader caps this at a 1 on dimension 4 (per the anchors) because the code contradicts the claim, rather than trusting the prose.
6. *(Optional)* One borderline case genuinely disputed among the team — useful for stress-testing agreement on judgment calls, not just clear-cut cases.
7. **One "strong architecture, capped by a hard failure" submission** — clean, well-organized code and a genuine agentic/tool design, but with either an ungated consequential action (should cap Dimension 2 at 1 per `../rubric.md` §2's capping rule) or a hard security failure such as a logged plaintext secret (should cap Dimension 5 at 1 per §5's capping rule). This is the specific case that tests whether the grader applies the caps or averages the failure away against the otherwise-strong architecture — the exact risk the capping rules were added to close.
8. **One "gated decision, ungated parameter" submission** — the guardrail's yes/no check is implemented correctly and genuinely gates *whether* to act, but the value actually passed into the consequential action (an amount, an item, a destination) is never verified against real data. Confirmed as T03 and T04's naive-code shape during calibration re-validation (`../grading/calibration-runs/T03-calibration-run.md`, `.../T04-calibration-run.md`, Run #2 in each). Should cap Dimension 2 at **2**, not 1 — the decision-level check is real and works, so this isn't "no gate at all"; it's a guardrail that exists but doesn't cover the actual risk. This is the case that tests whether the grader can tell "the decision is gated" apart from "the thing that actually happens is gated," rather than crediting a correct-looking eligibility check as full coverage, while also not over-penalizing it as if no check existed.

*(There is no "missing/incomplete AI-interaction log" or "missing commit history" archetype — no submission ever has either, since neither exists for anyone. Don't build a calibration case around this; it isn't a variable that differs between submissions.)*

## Running calibration

1. Have 2 people on the team independently score each calibration submission against `../rubric.md`, before looking at what the AI grader says. Reconcile disagreements — this fixes the human baseline first.
2. Run each submission through the AI grader using `grading-prompt.md`.
3. Compare. For each submission, note:
   - Did the total score land in the same range as the human baseline (within ~2 points on the 0–20 scale)?
   - Did the grader cite real, correct evidence, or vague/hallucinated evidence?
   - Did submission #3 (confidently wrong) get caught, or did the grader get swayed by polish?
   - Did submission #4 (correct by luck) get appropriately capped, or did the grader over-credit a good outcome with no reasoning behind it?
   - Did submission #5 (unsupported claim) get capped by the code contradicting the rationale, or did the grader take the claim at face value?
   - Did submission #7 (strong architecture, capped by a hard failure) actually get capped at 1 on the relevant dimension, or did the grader average the failure away against the otherwise-strong architecture?
   - Did submission #8 (gated decision, ungated parameter) get capped at 2 on Dimension 2 — not left uncapped by crediting the correct-looking decision-level gate, and not over-capped at 1 as if no check existed at all?

## If calibration fails

- **Systematic over-scoring:** tighten the anchors — likely the 2/3/4 boundaries are described too generously, or the grading prompt's "don't grade generously" instruction needs to be more concrete/example-driven rather than a general admonition.
- **Missing evidence citations accepted:** strengthen the output-format requirement in `grading-prompt.md` — consider a second pass that specifically audits whether cited evidence is real (quote-checks the code) before the score is finalized.
- **Unsupported claims accepted at face value (dimension 4):** this is the highest-priority failure mode to catch, since it's the one the missing-log/missing-history constraint created — if the grader lets a well-written rationale claim substitute for a checkable code mechanism, add an explicit worked example of this exact failure to the grading prompt (few-shot), not just the general instruction already there.
- **Confidently-wrong submissions score too high:** the grader is pattern-matching on writing quality. Add an explicit calibration example of this exact failure mode into the grading prompt itself (few-shot), not just a description of the failure mode.
- **Correct-by-luck submissions score too high on dimension 3/4:** reinforce in the prompt that outcome without evidence caps the score — this is already stated, but if it's not landing, an explicit worked example in the prompt (show a "1" case, not just describe one) will do more than another sentence of instruction.
- **Capping rule not applied (dimension 2 or 5) — a hard failure gets averaged against strong surrounding architecture instead of capping the score:** this is the failure mode submission #7 exists to catch. Add an explicit worked example to `grading-prompt.md`'s relevant dimension section showing the check-in-order procedure applied to a real case, not just the abstract rule — the grader needs to see the cap actually override a tempting high base score, the same way it needs a worked example for the unsupported-claim failure on dimension 4.
- **Gated-decision-vs-gated-parameter confusion (dimension 2) — the grader credits a correct eligibility/decision check without noticing the executed parameter itself is unverified:** this is the failure mode submission #8 exists to catch, and it's an easy one to miss because the decision-level code genuinely looks right. Add a worked example to `grading-prompt.md`'s Dimension 2 section showing this exact shape (a passing eligibility check, an untrusted amount/item flowing into the action anyway) scored as a cap-2, not left uncapped at a 3 and not over-capped at 1.

**Do not proceed to grading real submissions until calibration agreement is acceptable to the team.** Re-run calibration after any change to the rubric or grading prompt — a fix for one failure mode can introduce another.

## What calibration does not cover

Calibration validates the grader against submissions the team already understands. It does not validate that the **templates' traps and ambiguities actually work as intended in the wild** — that's the separate template-calibration step in `../generator/architecture.md` and each `../templates/*.md` file, and needs to happen first, since a grader calibrated against a broken trap is calibrated against the wrong thing.
