# Manifest

## Where the important logic lives

- **Agent / orchestration logic:** `app/agent.py` — `process_ticket()` is the full
  pipeline: classify, check duplicate/related history, pull extra context if uncertain,
  decide, act (all via tools), persist flags.
- **Tool definitions:** `app/tools.py` — `search_related_history`, `get_additional_context`,
  `check_billing_record` (read/check tools) and `acknowledge_ticket`, `auto_close_ticket`,
  `route_ticket`, `issue_courtesy_resolution` (action tools that mutate state and are
  called autonomously by the agent).
- **LLM stand-in:** `app/llm_stub.py` — deterministic classifier behind the contract a
  real model call would use (`classify(body_text, *, requester_tier, extra_context) ->
  ClassificationResult`).
- **Persistence:** `app/database.py` — SQLite schema (`tickets`, `billing_records`,
  `classifications`, `actions`, `flags`, `overrides`) and all read/write functions.
  Every tool call and every human override is logged to `actions`/`overrides`.
- **Ingestion:** `app/ingest.py` — loads both seed CSVs, runs the agent over every
  `new` ticket (idempotent: safe to re-run).

## Full file list

| Path | What it does |
|---|---|
| `brief.md` | The original assignment (unmodified). |
| `helpdesk_tickets.csv`, `license_billing_records.csv` | Seed data (unmodified). |
| `app/__init__.py` | Marks `app` as a package. |
| `app/database.py` | SQLite schema + all persistence functions. |
| `app/llm_stub.py` | Deterministic classifier stand-in for the in-house LLM. |
| `app/tools.py` | All agent tool definitions (read/check + action tools). |
| `app/agent.py` | Agent orchestration: `process_ticket()`. |
| `app/ingest.py` | CSV ingestion + runs the agent over new tickets. |
| `app/server.py` | Flask app: JSON API + serves the UI. |
| `static/index.html` | Review UI shell. |
| `static/style.css` | Review UI styling. |
| `static/app.js` | Review UI logic: fetches tickets, renders detail panel, submits overrides. |
| `tests/conftest.py` | Pytest fixture giving every test an isolated temp SQLite DB. |
| `tests/test_llm_stub.py` | Unit tests for the classifier stand-in. |
| `tests/test_tools.py` | Unit tests for each tool (duplicate search, billing check, actions). |
| `tests/test_agent.py` | Integration tests for the full agent decision pipeline. |
| `tests/test_server.py` | API tests (listing, detail, overrides). |
| `tests/test_ingest.py` | End-to-end smoke test against the real seed CSVs. |
| `requirements.txt` | `flask`, `pytest`. |
| `RATIONALE.md` | Design decisions, underspecified-brief resolutions, limitations. |
| `MANIFEST.md` | This file. |

## How to run

```
pip install -r requirements.txt
python -m pytest tests/ -v          # 29 tests, all passing
python -m app.server                # ingests seed data on first run, starts on :5050
```

Then open `http://127.0.0.1:5050/`. To re-ingest from scratch: `POST /api/ingest`
with `{"reset": true}`, or delete `helpdesk.db` and restart the server.
