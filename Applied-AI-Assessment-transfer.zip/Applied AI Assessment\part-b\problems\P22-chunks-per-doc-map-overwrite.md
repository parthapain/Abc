# P22 — Chunks per document

| Field | Value |
|---|---|
| **ID** | P22 |
| **Difficulty** | High |
| **Bug pattern** | Map insert replaces instead of accumulating |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 13–17 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

An indexing report groups chunk records by document and reports how many chunks each document produced.

Every document reports exactly **1** chunk, regardless of how many it actually has. The document ids are all correct; only the counts are wrong, and they are always 1.

### Required behaviour

Return `(document_id, chunk_count)` for every document that has at least one chunk, ordered by `document_id` ascending.

Chunks with identical names still count separately — the count is of chunk *rows*, not distinct names.

### Schema

```sql
CREATE TABLE chunks (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    chunk_name  TEXT NOT NULL
);
```

---

## Fixture — `P22.sql`

```sql
CREATE TABLE chunks (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    chunk_name  TEXT NOT NULL
);

INSERT INTO chunks (id, document_id, chunk_name) VALUES
    (1,1,'c0'),(2,1,'c1'),(3,1,'c2');   -- one document, three chunks
```

---

## Broken code

### Python

```python
import sqlite3
from typing import Dict, List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def chunks_per_document(db_path: str) -> List[Tuple[int, int]]:
    """
    Return (document_id, chunk_count) ordered by document_id ascending.
    Chunks with identical names still count separately.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute(
            "SELECT document_id, chunk_name FROM chunks ORDER BY id"
        ).fetchall()
    finally:
        conn.close()

    by_doc: Dict[int, List[str]] = {}
    for doc_id, chunk_name in rows:
        by_doc[doc_id] = [chunk_name]

    return [(doc_id, len(names)) for doc_id, names in sorted(by_doc.items())]
```

### Java

```java
import java.sql.*;
import java.util.*;

public class ChunkReport {

    // --- boilerplate: do not modify ---
    public static class DocCount {
        public final int documentId;
        public final int chunkCount;

        public DocCount(int documentId, int chunkCount) {
            this.documentId = documentId;
            this.chunkCount = chunkCount;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (documentId, chunkCount) ordered by documentId ascending.
     * Chunks with identical names still count separately.
     */
    public static List<DocCount> chunksPerDocument(String dbPath) throws SQLException {
        Map<Integer, List<String>> byDoc = new HashMap<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT document_id, chunk_name FROM chunks ORDER BY id")) {
            while (rs.next()) {
                int docId = rs.getInt("document_id");
                String chunkName = rs.getString("chunk_name");
                byDoc.put(docId, new ArrayList<>(List.of(chunkName)));
            }
        }

        List<DocCount> out = new ArrayList<>();
        byDoc.keySet().stream().sorted()
             .forEach(k -> out.add(new DocCount(k, byDoc.get(k).size())));
        return out;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record DocCount(int DocumentId, int ChunkCount);

public static class ChunkReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (DocumentId, ChunkCount) ordered by DocumentId ascending.
    /// Chunks with identical names still count separately.
    /// </summary>
    public static List<DocCount> ChunksPerDocument(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<(int DocumentId, string ChunkName)>(
            "SELECT document_id, chunk_name FROM chunks ORDER BY id").ToList();

        var byDoc = new Dictionary<int, List<string>>();
        foreach (var (docId, chunkName) in rows)
        {
            byDoc[docId] = new List<string> { chunkName };
        }

        return byDoc.OrderBy(kv => kv.Key)
                    .Select(kv => new DocCount(kv.Key, kv.Value.Count))
                    .ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | One document, 3 chunks | `[(1,3)]` | **Discriminator** — broken reports `(1,1)` |
| T2 | Three documents, 1 chunk each (all named `c0`) | `[(1,1),(2,1),(3,1)]` | Guard — one chunk per key, nothing to overwrite |
| T3 | Doc 1 with 2 chunks, doc 2 with 3 | `[(1,2),(2,3)]` | **Discriminator** — broken reports `(1,1),(2,1)` |
| T4 | Single chunk | `[(9,1)]` | Guard |
| T5 | Empty table | `[]` | Guard |
| T6 | One document, 2 chunks **sharing a name** | `[(1,2)]` | **Discriminator** — also the only case that catches a set-based rewrite |

### Fixtures

```sql
-- T2
INSERT INTO chunks (id, document_id, chunk_name) VALUES (1,1,'c0'),(2,2,'c0'),(3,3,'c0');
-- T3
INSERT INTO chunks (id, document_id, chunk_name) VALUES
    (1,1,'a'),(2,1,'b'),(3,2,'x'),(4,2,'y'),(5,2,'z');
-- T4
INSERT INTO chunks (id, document_id, chunk_name) VALUES (1,9,'solo');
-- T6
INSERT INTO chunks (id, document_id, chunk_name) VALUES (1,1,'dup'),(2,1,'dup');
```

---

## Reference solution

Append to the existing entry instead of replacing it.

**Python:**

```diff
  for doc_id, chunk_name in rows:
-     by_doc[doc_id] = [chunk_name]
+     by_doc.setdefault(doc_id, []).append(chunk_name)
```

**Java:**

```diff
- byDoc.put(docId, new ArrayList<>(List.of(chunkName)));
+ byDoc.computeIfAbsent(docId, k -> new ArrayList<>()).add(chunkName);
```

**C#:**

```diff
- byDoc[docId] = new List<string> { chunkName };
+ if (!byDoc.TryGetValue(docId, out var names))
+ {
+     names = new List<string>();
+     byDoc[docId] = names;
+ }
+ names.Add(chunkName);
```

### Why

Assigning to a map key **replaces** whatever was there. Each row therefore discards everything accumulated for that document and starts a fresh single-element list, so the final state holds only the last chunk seen per document — hence a count of exactly 1, always.

The constant `1` is the diagnostic signature. A count that is merely *wrong* suggests an arithmetic error; a count that is invariably 1 says the container is being reset rather than extended.

All three languages express the correct pattern idiomatically — `setdefault`, `computeIfAbsent`, `TryGetValue` — because "get the existing collection or create an empty one, then add" is common enough to warrant dedicated support.

**Why a set is not the fix.** Rebuilding `by_doc` as a map of sets removes the overwrite and passes most cases, but sets deduplicate by value, so two chunks legitimately sharing a name collapse into one. T6 exists to catch that.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Using a set instead of a list | T6 — reports 1 instead of 2 |
| Keeping an integer counter but still assigning `= 1` | T1, T3 |
| Rewriting as `SELECT document_id, COUNT(*) ... GROUP BY document_id` | Correct — accept it; the host-side map is not required |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T6
- [ ] Broken version **fails T1, T3 and T6**, and **passes T2, T4, T5**
- [ ] Failure is a constant count of 1, not a crash
- [ ] **T6 is present and uses two identically-named chunks** — without it a set-based rewrite passes and the problem is unsound
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] A correct SQL `GROUP BY` rewrite is accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
