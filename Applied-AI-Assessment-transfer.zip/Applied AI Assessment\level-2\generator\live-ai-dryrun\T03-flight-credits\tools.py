"""
Tools the agent calls. Each function here is a discrete, auditable operation against the
system of record (the SQLite tables loaded from the seed CSVs) — this is what makes the
pipeline "an agent, not a single call" per brief requirement #3: the interpretation step
never decides anything on its own, it only produces a claim that these tools then check
and act on.

Tools:
    lookup_booking(booking_ref)              - fetch the authoritative booking record
    verify_request_supported(intent, booking)- check the claim against the record
    issue_refund(...)                        - execute a refund/credit (simulated)
    lookup_rebooking_history(customer_name)  - fetch recent rebooking count
    schedule_rebooking(...)                  - execute a replacement booking (simulated)

There's no real payment gateway or flight inventory system to call, so "execute" means:
persist an action row that a downstream system could act on, and return a confirmation
payload. The function boundary is what matters (see RATIONALE.md).
"""
from typing import Optional
import db


def lookup_booking(booking_ref: str) -> Optional[dict]:
    return db.get_booking(booking_ref)


def verify_request_supported(intent: dict, booking: dict, customer_name: str) -> dict:
    """
    Checks whether the interpreted request is actually supported by the booking record.
    Returns {"supported": bool, "reasons": [str, ...]}. Any reason present means the
    request should NOT be auto-resolved, even if others were satisfied.
    """
    reasons = []

    if booking["customer_name"].strip().lower() != customer_name.strip().lower():
        reasons.append(
            f"Customer name on request ('{customer_name}') does not match the name on "
            f"booking {booking['booking_ref']} ('{booking['customer_name']}')."
        )

    if not booking["credit_eligible"]:
        reasons.append(
            f"Booking {booking['booking_ref']} is not marked credit-eligible "
            f"(category: {booking['verified_category']})."
        )

    if booking["credit_eligible"] and booking["credit_value"] <= 0:
        reasons.append(
            f"Booking {booking['booking_ref']} has a non-positive credit_value "
            f"({booking['credit_value']:.2f}); cannot auto-resolve without a valid amount."
        )

    if intent["action"] == "unclear":
        reasons.append("Customer's request could not be confidently classified.")

    return {"supported": len(reasons) == 0, "reasons": reasons}


def issue_refund(request_id: str, booking_ref: str, amount: float, source: str = "agent") -> dict:
    details = {"booking_ref": booking_ref, "amount": amount}
    action_id = db.record_action(request_id, "refund", amount, details, source)
    return {"action_id": action_id, "status": "executed", **details}


def lookup_rebooking_history(customer_name: str) -> int:
    return db.get_rebooking_count(customer_name)


def schedule_rebooking(request_id: str, booking_ref: str, flight_route: str, source: str = "agent") -> dict:
    details = {
        "booking_ref": booking_ref,
        "original_route": flight_route,
        "replacement": f"Next available flight on route {flight_route} (auto-scheduled)",
    }
    action_id = db.record_action(request_id, "rebooking", None, details, source)
    return {"action_id": action_id, "status": "executed", **details}
