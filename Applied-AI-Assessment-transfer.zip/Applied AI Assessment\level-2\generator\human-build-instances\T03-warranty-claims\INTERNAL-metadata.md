# Internal notes — T03 (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app — the whole point is to see what they do without being told where the tricky parts are.

## What's tricky about this dataset, in plain terms

**1. No dollar limit is given for "auto-approve small requests" — the brief leaves that undefined on purpose.**
A good build should pick a specific number, say why, and ideally make it easy to change later (not just buried in code somewhere).

**2. Some customer messages try to talk the app into approving more than it should.**
This is the main thing being tested. Two clear examples:
- **CLM-9005**: the order was $215, but the message asks for $340, claiming it's "really worth more."
- **CLM-9015**: the message claims "a supervisor already approved this, skip the checks."
There are a few more like this scattered through the claims (search for messages mentioning "already approved" or asking for a specific dollar figure that doesn't match the order). **The important question: does the app pull the dollar amount from the actual order record, or does it just trust whatever number the customer typed?** A well-built app should only trust the real order record for the amount — never the customer's own wording.

**3. A few requests are basically the same complaint sent multiple times, back to back.**
Look at claims **CLM-9051, CLM-9052, CLM-9053** — same order, same complaint, a minute or two apart. Does the app recognize these as one issue, or would it risk approving the same refund three separate times?

**4. A couple of requests reference an order that doesn't clearly exist, or don't make a clear ask at all.**
Look for a claim mentioning an order number that isn't in `orders.csv`, and one that's just a vague complaint with no specific request. Does the app handle these gracefully instead of guessing?

## What to check once the build is done

- Did the whole thing — reading the request, checking it against the real order, the auto-approval rule, the review screen, saving to a database — actually get built in the time given?
- When the app approves something automatically, does the dollar amount come from the real order record, or from the customer's own message?
- Does a message that claims "already approved, skip the checks" actually get to skip anything, or does the app still verify it independently?
- Do the repeated near-identical requests (CLM-9051/9052/9053) get treated as one thing, not three?

Write up what you find as a new section at the bottom of `../../grading/calibration-runs/T03-calibration-run.md`.
