import sqlite3

DB_PATH = "flight_credits.db"


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS request_records (
            request_id TEXT PRIMARY KEY,
            customer_name TEXT,
            booking_ref TEXT,
            final_status TEXT,
            log TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS replacement_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id TEXT,
            idempotency_key TEXT UNIQUE,
            replacement_id TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def init_db():
    conn = get_conn()
    conn.close()


def save_request_record(request_id, customer_name, booking_ref, final_status, logs):
    conn = get_conn()
    conn.execute(
        """INSERT INTO request_records (request_id, customer_name, booking_ref, final_status, log)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(request_id) DO UPDATE SET
             customer_name=excluded.customer_name, booking_ref=excluded.booking_ref,
             final_status=excluded.final_status, log=excluded.log""",
        (request_id, customer_name, booking_ref, final_status, "\n".join(logs)),
    )
    conn.commit()
    conn.close()


def record_replacement(request_id, idempotency_key, replacement_id):
    """Returns True if this was a new replacement record, False if one already
    existed for this idempotency key (a retry correctly did not duplicate)."""
    conn = get_conn()
    cur = conn.execute("SELECT replacement_id FROM replacement_records WHERE idempotency_key = ?", (idempotency_key,))
    if cur.fetchone():
        conn.close()
        return False
    conn.execute(
        "INSERT INTO replacement_records (request_id, idempotency_key, replacement_id) VALUES (?, ?, ?)",
        (request_id, idempotency_key, replacement_id),
    )
    conn.commit()
    conn.close()
    return True


def reset_db():
    import os
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
