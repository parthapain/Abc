import random

import pandas as pd

booking_df = pd.read_csv("booking_records.csv").set_index("booking_ref")
history_df = pd.read_csv("rebooking_history.csv").set_index("customer_name")

_server_side_replacements = {}  # idempotency_key -> replacement_id, simulating a real backend
_live_history = None  # test hook: override the "live" recent-history count mid-run


class TransientReplacementError(Exception):
    pass


class PermanentReplacementError(Exception):
    pass


def set_live_history(customer_name, new_count):
    """Test hook: simulate the customer's recent-rebooking count changing after it was first read."""
    global _live_history
    if _live_history is None:
        _live_history = history_df["rebookings_last_30_days"].to_dict()
    _live_history[customer_name] = new_count


def get_booking_details(booking_ref):
    """Returns the booking record dict, or {"status": "NOT_FOUND"} -- never
    invents a record for a reference that isn't actually in the dataset."""
    if booking_ref not in booking_df.index:
        return {"status": "NOT_FOUND"}
    row = booking_df.loc[booking_ref]
    return {
        "status": "FOUND",
        "customer_name": row["customer_name"],
        "verified_category": row["verified_category"],
        "credit_eligible": bool(row["credit_eligible"]),
        "credit_value": float(row["credit_value"]),
    }


def check_recent_request_history(customer_name):
    """Returns (count, valid) -- valid False when the registry's own response
    doesn't make sense; None count when there's no row at all (not found)."""
    global _live_history
    source = _live_history if _live_history is not None else history_df["rebookings_last_30_days"].to_dict()
    if customer_name not in source:
        return None, True
    count = source[customer_name]
    if count < 0:
        return count, False
    return count, True


def schedule_replacement(request_id, idempotency_key, force_lost_response=False):
    """Idempotent, retryable action -- same shape as T04's dispatch_fulfillment,
    T01's issue_resolution, T02's generate_followup. A cache hit on
    idempotency_key must return the original result untouched, regardless of
    force_lost_response or what the live history now says."""
    if idempotency_key in _server_side_replacements:
        return {"replacement_id": _server_side_replacements[idempotency_key], "status": "SUCCESS"}

    if force_lost_response:
        replacement_id = f"RP-{request_id}-{random.randint(1000,9999)}"
        _server_side_replacements[idempotency_key] = replacement_id
        raise TransientReplacementError("Response lost in transit (server-side action actually succeeded).")

    replacement_id = f"RP-{request_id}-{random.randint(1000,9999)}"
    _server_side_replacements[idempotency_key] = replacement_id
    return {"replacement_id": replacement_id, "status": "SUCCESS"}
