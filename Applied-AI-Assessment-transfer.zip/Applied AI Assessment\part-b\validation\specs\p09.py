"""P09 — Pipeline success rates. Medium · host-located · integer division truncates."""

META = {"difficulty": "Medium", "location": "host", "pattern": "integer division truncates percentage"}

SCHEMA = """
CREATE TABLE pipeline_runs (
    id        INTEGER PRIMARY KEY,
    stage     TEXT NOT NULL,
    succeeded INTEGER NOT NULL   -- 1 or 0
);
"""

_QUERY = """
    SELECT stage,
           COUNT(*)          AS total,
           SUM(succeeded)    AS ok
    FROM pipeline_runs
    GROUP BY stage
    ORDER BY stage
"""


def broken(conn):
    rows = conn.execute(_QUERY).fetchall()
    # BUG: integer division truncates toward zero instead of rounding to 1 dp
    return [(stage, (ok * 100) // total) for stage, total, ok in rows]


def fixed(conn):
    rows = conn.execute(_QUERY).fetchall()
    return [(stage, round(ok * 100 / total, 1)) for stage, total, ok in rows]


def _rounds_to_integer(conn):
    rows = conn.execute(_QUERY).fetchall()
    return [(stage, round(ok * 100 / total)) for stage, total, ok in rows]


WRONG_FIXES = {"rounds to whole number instead of 1 dp": _rounds_to_integer}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO pipeline_runs (id, stage, succeeded) VALUES
                (1,'chunking',1),(2,'chunking',0),(3,'chunking',0);
        """,
        "expected": [("chunking", 33.3)],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO pipeline_runs (id, stage, succeeded) VALUES
                (1,'embedding',1),(2,'embedding',0);
        """,
        "expected": [("embedding", 50.0)],
    },
    "T3": {
        "role": "guard",
        "seed": """
            INSERT INTO pipeline_runs (id, stage, succeeded) VALUES
                (1,'indexing',1),(2,'indexing',1);
        """,
        "expected": [("indexing", 100.0)],
    },
    "T4": {
        "role": "discriminator",
        "seed": """
            INSERT INTO pipeline_runs (id, stage, succeeded) VALUES
                (1,'parsing',1),(2,'parsing',1),(3,'parsing',0);
        """,
        "expected": [("parsing", 66.7)],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
