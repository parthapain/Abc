# P09 — Pipeline success rates

| Field | Value |
|---|---|
| **ID** | P09 |
| **Difficulty** | Medium |
| **Bug pattern** | Integer division truncates a percentage |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 8–11 min |
| **Paper** | 6 (with P15) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A monitoring dashboard shows the success rate of each pipeline stage as a percentage, reported to one decimal place.

The figures are consistently a little low. A stage that genuinely succeeds two runs in three is displayed as `66`, not `66.7`, and the error is always downward — never up.

### Required behaviour

Return `(stage, success_percentage)` for each stage, ordered by `stage` ascending. The percentage is successful runs as a proportion of total runs, **rounded to one decimal place**.

### Schema

```sql
CREATE TABLE pipeline_runs (
    id        INTEGER PRIMARY KEY,
    stage     TEXT NOT NULL,
    succeeded INTEGER NOT NULL   -- 1 or 0
);
```

---

## Fixture — `P09.sql`

```sql
CREATE TABLE pipeline_runs (
    id        INTEGER PRIMARY KEY,
    stage     TEXT NOT NULL,
    succeeded INTEGER NOT NULL
);

INSERT INTO pipeline_runs (id, stage, succeeded) VALUES
    (1,'chunking',1),(2,'chunking',0),(3,'chunking',0);   -- 1 of 3 = 33.3%
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)

_QUERY = """
    SELECT stage,
           COUNT(*)       AS total,
           SUM(succeeded) AS ok
    FROM pipeline_runs
    GROUP BY stage
    ORDER BY stage
"""
# --- end boilerplate ---


def success_rates(db_path: str) -> List[Tuple[str, float]]:
    """
    Return (stage, success_percentage) ordered by stage,
    with the percentage rounded to one decimal place.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute(_QUERY).fetchall()
    finally:
        conn.close()

    return [(stage, (ok * 100) // total) for stage, total, ok in rows]
```

### Java

```java
import java.sql.*;
import java.util.*;

public class SuccessRates {

    // --- boilerplate: do not modify ---
    public static class StageRate {
        public final String stage;
        public final double percentage;

        public StageRate(String stage, double percentage) {
            this.stage = stage;
            this.percentage = percentage;
        }
    }

    private static final String QUERY =
        "SELECT stage, COUNT(*) AS total, SUM(succeeded) AS ok " +
        "FROM pipeline_runs GROUP BY stage ORDER BY stage";

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (stage, percentage) ordered by stage,
     * with the percentage rounded to one decimal place.
     */
    public static List<StageRate> successRates(String dbPath) throws SQLException {
        List<StageRate> rates = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(QUERY)) {
            while (rs.next()) {
                String stage = rs.getString("stage");
                int total = rs.getInt("total");
                int ok = rs.getInt("ok");

                double percentage = (ok * 100) / total;
                rates.add(new StageRate(stage, percentage));
            }
        }
        return rates;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record StageRate(string Stage, double Percentage);

public static class SuccessRates
{
    // --- boilerplate: do not modify ---
    private const string Query = @"
        SELECT stage, COUNT(*) AS total, SUM(succeeded) AS ok
        FROM pipeline_runs
        GROUP BY stage
        ORDER BY stage";

    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Stage, Percentage) ordered by stage,
    /// with the percentage rounded to one decimal place.
    /// </summary>
    public static List<StageRate> Compute(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<(string Stage, int Total, int Ok)>(Query).ToList();

        return rows
            .Select(r => new StageRate(r.Stage, (r.Ok * 100) / r.Total))
            .ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `chunking`: 1 of 3 succeed | `[("chunking", 33.3)]` | **Discriminator** — broken returns `33` |
| T2 | `embedding`: 1 of 2 succeed | `[("embedding", 50.0)]` | Guard — result is exact, so truncation changes nothing |
| T3 | `indexing`: 2 of 2 succeed | `[("indexing", 100.0)]` | Guard — exact |
| T4 | `parsing`: 2 of 3 succeed | `[("parsing", 66.7)]` | **Discriminator** — broken returns `66` |
| T5 | Empty table | `[]` | Guard |

> **Comparison note for the harness:** compare numerically, not as strings. `50` and `50.0` are equal and T2 must pass in both versions; `33` and `33.3` are not, and T1 must fail in the broken version.

### Fixtures

```sql
-- T2
INSERT INTO pipeline_runs (id, stage, succeeded) VALUES (1,'embedding',1),(2,'embedding',0);
-- T3
INSERT INTO pipeline_runs (id, stage, succeeded) VALUES (1,'indexing',1),(2,'indexing',1);
-- T4
INSERT INTO pipeline_runs (id, stage, succeeded) VALUES (1,'parsing',1),(2,'parsing',1),(3,'parsing',0);
```

---

## Reference solution

Perform the division in floating point, then round to one decimal place.

**Python:**

```diff
- return [(stage, (ok * 100) // total) for stage, total, ok in rows]
+ return [(stage, round(ok * 100 / total, 1)) for stage, total, ok in rows]
```

**Java:**

```diff
- double percentage = (ok * 100) / total;
+ double percentage = Math.round(ok * 100.0 / total * 10.0) / 10.0;
```

**C#:**

```diff
- .Select(r => new StageRate(r.Stage, (r.Ok * 100) / r.Total))
+ .Select(r => new StageRate(r.Stage, Math.Round(r.Ok * 100.0 / r.Total, 1)))
```

### Why

Both operands are integers, so the division is integer division and the fractional part is discarded before the result is ever stored. In Java and C# the widening to `double` happens *after* the damage — assigning to a `double` cannot recover precision that was already thrown away. In Python the `//` operator does the same thing explicitly.

Truncation always rounds toward zero, which is why the dashboard is biased low and never high. That one-directional error is the diagnostic clue: a genuine rounding choice would scatter in both directions.

Note that the fix must both widen *and* round. Widening alone gives `33.333333…`, which is not the required one decimal place.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Casting the result to `double` without changing the division | T1, T4 — `(double)((ok*100)/total)` still truncates first |
| Rounding to a whole number instead of one decimal | T1 — gives `33`; T4 — gives `67` |
| Widening but not rounding | T1 — gives `33.33333…` rather than `33.3` |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T4**, and **passes T2, T3, T5**
- [ ] Test harness compares numerically — confirm `50 == 50.0` does not fail T2 spuriously
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Java/C#: confirm the broken version genuinely truncates and does not warn at compile time in a way that gives the bug away
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
