**`RATIONALE.md`** explains the decision logic behind handling ambiguities and risk[cite: 4]:

```markdown
# Key Decisions & Design Rationale

### Key Decisions & Ambiguity Resolution
1. **Coupled Risk Gating vs. Face Value (ORD-8103):**
   - In orders like `ORD-8103`, the face total of requested items is $1,161. However, since the primary item (Skid Steer) is out of stock, only the folding tables ($36) are fulfillable. Our agent evaluates risk based on the **coupled dispatchable value** ($36), allowing low-risk auto-dispatch of the available items while placing out-of-stock items on back-order.

2. **Adversarial / Invalid Tool Data Handling (ORD-8102):**
   - In `ORD-8102`, alternate yard stock for `EQ-011` is returned as `-2`. The agent detects invalid/corrupted data, treats it as a critical guardrail trigger, and escalates the order for human review.

3. **Reconciliation Ambiguity Protection (ORD-8101):**
   - Vague requests like "3x Concrete Mixer" match multiple catalog SKUs (`EQ-005` 3.5cu ft vs `EQ-006` 6cu ft). The agent flags an `AMBIGUOUS_RECONCILIATION` escalation rather than arbitrarily choosing a SKU.

4. **Idempotency Under Forced Retries (ORD-8006):**
   - To guard against transient network failures where a dispatch succeeds on the server but drops the response, network dispatches pass a unique `idempotency_key`. Retried calls return the existing dispatch record without duplicating fulfillment.

5. **Cost-Aware Alternate Yard Rerouting (ORD-8104 vs ORD-8105):**
   - Alternate yard rerouting evaluates freight cost relative to item value. In `ORD-8104`, shipping is $18 for a $240 item (7.5%), so auto-reroute executes. In `ORD-8105`, shipping is $140 for a $260 item (53.8%), so the agent escalates to human review.

### What We'd Do With More Time
- Integrate dynamic freight calculation APIs.
- Implement real-time WebSocket streaming of agent reasoning steps to the frontend dashboard.