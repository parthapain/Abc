# Template T02 — Structured Extraction from Unstructured Text

| Field | Value |
|---|---|
| **ID** | T02 |
| **Scenario shape** | Free-text documents arrive continuously; the app must extract structured fields via the in-house LLM, then work as an agent — cross-checking extracted values against the source and looking up related documents when needed — before deciding to auto-commit high-confidence, fully-grounded extractions to the system of record or flagging for human review, gated by a guardrail |
| **Target build time** | 24–48 hrs |
| **Status** | **Shape strengthened (Addendum 20) — two ambiguities and two independently-guardrailed actions now required.** Run #1/#2 (old 1/1 shape) and **Run #3 (new second guardrail, dry-run confirmed exactly as hypothesized — `../grading/calibration-runs/T02-calibration-run.md`)** are both done. **Still not verified against a live AI assistant, and T02's own timed build is still pending** — both required before this template counts as officially calibrated. |
| **Trap category** | Category 3 (unchanged from the pre-rework version) — hallucination-on-absence and related extraction failure modes. |

---

## Candidate-facing brief (template)

> Your organization needs to extract structured information from {{document_noun}} — {{document_description}}. Build an application that:
>
> 1. Ingests {{document_noun}} (seed datasets are provided — `{{dataset_file}}` and `{{second_dataset_file}}`)
> 2. Uses the in-house LLM to extract these fields into a structured record: {{field_list}}
> 3. Works as an agent, not a single call: cross-check extracted values against the source document via a tool, and look up a related document via a second tool when a field's value references another document — then decide how to proceed
> 4. **{{ambiguity_requirement_1}}**
> 5. **{{ambiguity_requirement_2}}**
> 6. For extractions that are fully grounded and high-confidence, autonomously commit the record to the system of record — gated by an explicit completeness/confidence check; anything incomplete, contradictory, or below that threshold is flagged for human review instead
> 7. **Separately, for documents where {{second_guardrail_condition}}: look up the current real-world status via a tool, and if it confirms the action is still warranted, autonomously generate a follow-up record via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate. Anything the status check doesn't confirm is skipped, not flagged as if it were still warranted.
> 8. Provides a UI where a human can review extracted fields against the source document, correct them, and see any autonomous commits *and* any follow-up records already generated
> 9. Persists documents, extracted fields, commit/review status, any follow-up records generated, and any corrections to a database
>
> Some {{document_noun}} in the seed dataset {{stress_point_description}} — your solution should handle these sensibly rather than crashing or inventing information that isn't there.
>
> Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

---

## Fixed elements (do not vary per instance)

### Ambiguity slot

`{{ambiguity_requirement_1}}` / `{{ambiguity_requirement_2}}` — **every instance now plants two distinct phrasings from this pool, not one** (strengthened per `../design-rationale.md` Addendum 20). Pool of phrasings, all sharing the same underlying ambiguity: **what to do when a field concept could map to more than one place in the source text**:

1. *"Extract the {{key_clause_field}}."* — the document may contain multiple related clauses (e.g., several termination-related provisions); which one satisfies the field, and how are multiple candidates handled — first found, most specific, all of them?
2. *"Extract {{key_party_field}}."* — documents may name a party inconsistently (a full legal name in one place, a short form or role label elsewhere); is normalization expected, and to what canonical form?
3. *"Extract {{key_date_field}}."* — some documents state this both explicitly and by reference to another clause ("30 days after the {{other_event}}"); is a computed/relative date acceptable or does it need to resolve to an absolute one? **This phrasing now ties directly into the mandatory `lookup_related_document` tool below** — resolving it may require the agent to actually fetch the referenced document/clause rather than guess.

Pick any 2 of the 3 above per instance. **What "handled well" looks like (dimension 3):** the rationale names each reading chosen and why, tied to something actually present in the dataset, and — for the top score on either — the schema/code makes the ambiguity visible rather than silently picking one (e.g., a confidence field, a "multiple candidates found" flag) so a downstream reviewer isn't misled into thinking extraction was unambiguous when it wasn't. Scored at the lower of the two — see `../rubric.md` §3's non-averaging rule.

### AI-trap slot (category 3, unchanged)

**The trap:** the brief requires extracting a field that is **absent** from some documents in the seed set. When a coding assistant is asked to implement "extract {{field}} using the LLM," a very common default behavior — because it's how LLMs behave by default, not a coding mistake exactly — is that **the LLM confidently fills in a plausible value when the field isn't actually present in the source document**, rather than reporting it as missing. This applies just as much inside the agentic loop: a hallucinated value that isn't caught before the auto-commit decision doesn't just look wrong in a review UI — it can get **written to the system of record autonomously**, which is a materially worse outcome than the pre-rework version's "a human will eventually notice."

**What "caught" looks like (dimension 4):** the shipped solution can distinguish "field genuinely absent" from "field present and extracted," typically via an explicit prompt instruction to say so when absent, a confidence/grounding check, or — now — the `verify_against_source` tool call itself, which should fail or flag when there's nothing in the source to ground the extracted value against. Critically, **an ungrounded extraction must never reach the auto-commit guardrail as "verified."** There's no AI-interaction log and no commit history to check against — only the final code plus the rationale: a "3"/"4" submission's rationale names this exact risk and points to the specific mechanism in the code that catches it, checkably. A rationale that merely claims "I tested against missing-field documents" with no cited mechanism a reviewer can find in the code doesn't clear this bar — see `../rubric.md` Dimension 4's grading note.

**Trap variants** (pool):
1. LLM invents a plausible value for a genuinely absent field (as above)
2. LLM extracts a value from the wrong section of a multi-document bundle (mixing up fields across two contracts concatenated in one file) without flagging cross-contamination
3. LLM normalizes a partially-stated value (e.g., an amount without a stated currency) to a default (e.g., assumes USD) without surfacing that it guessed
4. LLM's extracted date/number passes a superficial format check but is semantically wrong (e.g., swapped day/month) with nothing in the pipeline that would catch it

### Stress-point slot

`{{stress_point_description}}` — pool of variants:
1. A document missing one or more of the required fields entirely
2. A document containing more than one instance of the same document type concatenated together
3. A scanned/OCR-style document with garbled or partial text in places
4. A document that directly contradicts itself (two different values stated for the same field in different places)

**What "handled well" looks like (dimension 4):** the planted variant surfaces as a reviewable, visible state (missing / ambiguous / low-confidence) rather than either crashing or producing a confident-looking but wrong record — and, now, rather than being autonomously committed as if it were fully grounded.

---

## Mandatory agentic/tool/guardrail shape

- **Agentic loop:** extract → call a source-verification tool against each extracted field → call a related-document lookup tool when a field's value depends on another document → decide to auto-commit or flag for review — a genuine multi-step loop with a sensible stopping condition (bounded by the fields to verify plus the decision, not open-ended).
- **Tools:** e.g., `verify_against_source(document_id, field, value)` — returns grounded / not grounded / ambiguous, structured enough to drive the guardrail; `lookup_related_document(reference)` — returns the referenced document/clause content so a relative reference (e.g., "30 days after X") can be resolved rather than guessed. Clearly scoped, structured failure reporting, not a single do-everything function.
- **Context management:** the agent carries forward each field's verification result (and any looked-up related-document content) into the commit decision, rather than deciding from the raw extraction alone once tools have been consulted.
- **Guardrail:** the autonomous commit fires only when every extracted field passes source verification **and** no related-document lookup is left unresolved **and** the extraction isn't a hallucinated/ungrounded default (see AI-trap slot above); anything else is flagged for human review. **Guardrail-trap candidate** (graded under rubric Dimension 2, not Dimension 4 — see `../testing-principles.md` category 12 and `../rubric.md` §2): a naive first draft is likely to gate auto-commit on the LLM's own self-reported extraction confidence, without actually requiring the `verify_against_source` tool result to back it up — this is an architecture defect, not a second instance of the category-3 trap above.
  - **Confirmed compounding failure (calibration run #1, `../grading/calibration-runs/T02-calibration-run.md`):** a naive `verify_against_source` implementation's own error handling (an exception from a malformed LLM response, a timeout) typically returns an empty dict rather than an explicit failure marker. A naive guardrail reading `v.get("grounded", True)` then treats an unverified field as **grounded by default** — a hallucinated value that happens to trigger a verification hiccup gets auto-committed precisely because verification failed to run, the opposite of what "verified" should mean. Same class of bug as T01's compounding failure, one layer deeper (in the tool's own failure path, not the extraction call's) — check for it explicitly, not just in principle.
- **Second guardrail (new, Addendum 20) — a follow-up record generated only when a real-world status check confirms it's still warranted, not just from the document's own stated facts:** for documents where {{second_guardrail_condition}} (e.g., an approaching date the document itself states), the agent must call a tool (e.g., `check_current_status(record_id)`) that returns the *actual*, tool-verified current status from a second reference dataset (`{{second_dataset_file}}`) — never inferred purely from what the source document itself says. If the status confirms the follow-up is still warranted, autonomously generate it; otherwise skip it. This is a separate gate from step 6's commit guardrail — a submission that infers the follow-up purely from the document's own stated date/facts, without the second tool call, fails this requirement.
  - **Compounding-failure risk — confirmed via dry-run (calibration run #3, `../grading/calibration-runs/T02-calibration-run.md`):** a natural implementation writes the "still warranted" check as a double-negative — `if status != "renewed" and status != "cancelled": generate_reminder(...)` — rather than a positive check against an expected value. When the status lookup returns `None` (the record isn't found — a data gap, a typo'd ID), **both comparisons evaluate `True`**, so a genuinely unresolved status is silently treated as "still active" and the follow-up fires anyway. **Still not tested against a live AI assistant** (dry-run only) — see Status above.
  - **Design the second dataset so this guardrail is testable in more than one direction:** at least one record where the status genuinely confirms the follow-up (should fire), one where a real status update means it no longer applies (should not fire, even though the source document alone looks identical to the first case), and ideally a third with a different disqualifying status.

---

## Per-instance parameters

| Parameter | Example pool |
|---|---|
| `document_noun` / `document_description` | contracts / meeting notes (→ action items) / expense reports / resumes / insurance policy documents / vendor invoices |
| `field_list`, `key_clause_field`, `key_party_field`, `key_date_field` | varies naturally with the domain flavor |
| `dataset_file` | a generated seed set per instance (10–30 documents, varying length), structurally comparable across instances but different content, including the planted stress-point document(s) |
| `second_dataset_file` | a second, independent reference dataset per instance (e.g. `renewal_status.csv`) mapping record IDs to a real, tool-checkable current status — testable in all 3 directions described in the second-guardrail note above |
| `second_guardrail_condition` | whichever field naturally implies a time-sensitive follow-up in the domain flavor chosen (e.g., an approaching expiration/renewal date) |
| Ambiguity phrasings | 2 distinct of 3 above (not 1) |
| Trap variant | 1 of 4 above |
| Stress-point variant | 1 of 4 above |

---

## Reference solution outline (author before generating any instance)

1. **Framing:** ingest → extract (LLM) → verify (tool) → related-document lookup (tool, where applicable) → decide (auto-commit / flag) → review UI → persist, with extraction and verification isolated enough to test against known-good and known-absent cases independently.
2. **Ambiguity:** state the chosen reading of each of the two active phrasings, why, and whether/how each ambiguity is surfaced rather than hidden — including, for phrasing 3, how the related-document lookup actually resolves a relative reference.
3. **Trap:** show what an unverified extraction produces on an absent-field document (a fabricated value) versus the corrected behavior (an explicit "not found," ideally with the reasoning/grounding visible) — and confirm the fabricated case is blocked from auto-commit specifically, not just flagged in the UI.
4. **First guardrail:** show the naive first-draft guardrail (self-reported confidence only) versus the corrected version (confidence + tool-verified grounding) — **and explicitly show the compounding failure found in calibration run #1** (an unverified field defaulting to "grounded" via `v.get("grounded", True)` when `verify_against_source` itself fails), since a candidate could plausibly build a correct-looking verification tool and still leave this gap in how its failure path is handled.
5. **Second guardrail:** show the naive first draft (a status check that silently defaults to "still warranted" on a failed/missing lookup) versus the corrected version, and confirm the second reference dataset actually exercises all 3 test directions.
6. **Stress point:** the specific document that exercises it, and the expected reviewable state it should produce.

## Calibration — reset by Addendum 20 (shape strengthened to 2 ambiguities / 2 guardrails)

Steps 1–3 below were confirmed against the **old, superseded 1-ambiguity/1-guardrail shape** — see `../grading/calibration-runs/T02-calibration-run.md` for that historical dry-run (including Run #2's post-rubric-split re-validation). None of it has been re-verified against the new second ambiguity or the new second guardrail's compounding-failure risk. Do not treat this template as calibrated at the new shape, and do not generate instances from it, until T01's reset clears first (see `../generator/architecture.md`'s sequencing note) and this template's own reset steps below are done.

1. ✅ *(old shape)* **Confirmed.** An absent-field document run through a naturally-written extraction prompt produces a fabricated value, not an absence marker — the hallucination-on-absence trap reproduces as described.
2. ✅ *(old shape)* **Confirmed.** The ambiguity is genuinely two-way for phrasing 3, tested against realistic sample text. **Not yet re-tested** with a second phrasing active alongside it.
3. ✅ *(old shape)* **Confirmed — and sharper than anticipated.** A naturally-built guardrail auto-commits based on `v.get("grounded", True)`, which silently treats a *failed* verification-tool call as grounded.
3b. ✅ **Dry-run confirmed (calibration run #3), exactly as hypothesized.** A double-negative status check treats a missing/unmatched lookup as "still active." **Not yet posed to a live AI assistant.**
4. ⏳ **Not attempted.** T02's own timed build (now against both guardrails, not one) is second in the queue, behind T01's reset — running it before T01's settles the scope question would tell us little.
