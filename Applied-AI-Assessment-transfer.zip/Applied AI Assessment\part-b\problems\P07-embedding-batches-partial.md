# P07 — Embedding batch builder

| Field | Value |
|---|---|
| **ID** | P07 |
| **Difficulty** | Medium |
| **Bug pattern** | Partial final batch discarded |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 9–12 min |
| **Paper** | 4 (with P13) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

Documents awaiting embedding are grouped into fixed-size batches before being sent to the embedding API, which accepts at most three documents per call.

A few documents never get embedded. They sit in `pending` forever, and the number left behind is always fewer than a full batch.

### Required behaviour

Fetch the `name` of every document whose `status` is `'pending'`, ordered by `id`, and split them into batches of at most **3**.

Every pending document must appear in exactly one batch. The final batch may be smaller than 3.

### Schema

```sql
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    status  TEXT NOT NULL     -- 'pending' | 'indexed'
);
```

---

## Fixture — `P07.sql`

```sql
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    status  TEXT NOT NULL
);

INSERT INTO documents (id, name, status) VALUES
    (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
    (4,'d','pending'),(5,'e','pending'),(6,'f','pending'),
    (7,'g','pending');    -- seventh document: leaves a partial batch
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

BATCH_SIZE = 3

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def build_batches(db_path: str) -> List[List[str]]:
    """
    Split all pending document names (ordered by id) into batches of at
    most BATCH_SIZE. Every pending document must appear in exactly one batch.
    """
    conn = _connect(db_path)
    try:
        names = [row[0] for row in conn.execute(
            "SELECT name FROM documents WHERE status = 'pending' ORDER BY id"
        ).fetchall()]
    finally:
        conn.close()

    batches: List[List[str]] = []
    for i in range(0, len(names), BATCH_SIZE):
        batch = names[i:i + BATCH_SIZE]
        if len(batch) == BATCH_SIZE:
            batches.append(batch)
    return batches
```

### Java

```java
import java.sql.*;
import java.util.*;

public class BatchBuilder {

    public static final int BATCH_SIZE = 3;

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Split all pending document names (ordered by id) into batches of at
     * most BATCH_SIZE. Every pending document must appear in exactly one batch.
     */
    public static List<List<String>> buildBatches(String dbPath) throws SQLException {
        List<String> names = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT name FROM documents WHERE status = 'pending' ORDER BY id")) {
            while (rs.next()) {
                names.add(rs.getString("name"));
            }
        }

        List<List<String>> batches = new ArrayList<>();
        for (int i = 0; i < names.size(); i += BATCH_SIZE) {
            List<String> batch = names.subList(i, Math.min(i + BATCH_SIZE, names.size()));
            if (batch.size() == BATCH_SIZE) {
                batches.add(new ArrayList<>(batch));
            }
        }
        return batches;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class BatchBuilder
{
    public const int BatchSize = 3;

    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Split all pending document names (ordered by id) into batches of at
    /// most BatchSize. Every pending document must appear in exactly one batch.
    /// </summary>
    public static List<List<string>> BuildBatches(string dbPath)
    {
        List<string> names;
        using (var conn = Connect(dbPath))
        {
            names = conn.Query<string>(
                "SELECT name FROM documents WHERE status = 'pending' ORDER BY id").ToList();
        }

        var batches = new List<List<string>>();
        for (int i = 0; i < names.Count; i += BatchSize)
        {
            var batch = names.Skip(i).Take(BatchSize).ToList();
            if (batch.Count == BatchSize)
            {
                batches.Add(batch);
            }
        }
        return batches;
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 7 pending documents `a`–`g` | `[[a,b,c], [d,e,f], [g]]` | **Discriminator** — broken returns 2 batches, losing `g` |
| T2 | 6 pending documents | `[[a,b,c], [d,e,f]]` | Guard — exact multiple, no partial batch exists |
| T3 | 2 pending documents | `[[a,b]]` | **Discriminator** — broken returns `[]`, losing both |
| T4 | 3 pending + 2 `indexed` | `[[a,b,c]]` | Guard — catches removal of the status filter |
| T5 | Empty table | `[]` | Guard |

### Fixture for T2

```sql
INSERT INTO documents (id, name, status) VALUES
    (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
    (4,'d','pending'),(5,'e','pending'),(6,'f','pending');
```

### Fixture for T3

```sql
INSERT INTO documents (id, name, status) VALUES
    (1,'a','pending'),(2,'b','pending');
```

### Fixture for T4

```sql
INSERT INTO documents (id, name, status) VALUES
    (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
    (4,'x','indexed'),(5,'y','indexed');
```

---

## Reference solution

Remove the full-batch condition so every batch is kept.

**Python:**

```diff
  for i in range(0, len(names), BATCH_SIZE):
      batch = names[i:i + BATCH_SIZE]
-     if len(batch) == BATCH_SIZE:
-         batches.append(batch)
+     batches.append(batch)
```

**Java:**

```diff
  List<String> batch = names.subList(i, Math.min(i + BATCH_SIZE, names.size()));
- if (batch.size() == BATCH_SIZE) {
-     batches.add(new ArrayList<>(batch));
- }
+ batches.add(new ArrayList<>(batch));
```

**C#:**

```diff
  var batch = names.Skip(i).Take(BatchSize).ToList();
- if (batch.Count == BatchSize)
- {
-     batches.Add(batch);
- }
+ batches.Add(batch);
```

### Why

The loop itself is correct — it walks the list in strides of `BATCH_SIZE` and slices safely at the end. The defect is the guard *inside* it. `if (batch.size() == BATCH_SIZE)` reads like a sanity check but is a silent filter: any batch that is not exactly full is dropped.

This is why the symptom is "a few documents, always fewer than a batch, never get embedded." When the pending count is an exact multiple of 3 the system looks healthy, which is what lets a bug like this survive in production.

The failure is worst at small inputs: with only two pending documents, *every* document is lost and the function returns an empty list.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Padding the final batch to size 3 with empty strings | T1 — expected `[g]`, not `[g,"",""]` |
| Changing the condition to `> 0` but leaving the slice bounds wrong | T1, T3 |
| Removing the `status = 'pending'` filter | T4 — indexed documents appear |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing batches, not an index-out-of-range error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Java `subList` view is copied before being stored — confirm the reference fix keeps `new ArrayList<>(batch)`
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
