# Build Brief — Commercial Loan Agreement Extraction

Your organization needs to extract structured information from commercial loan agreements — legal documents describing the terms of a business loan. Build an application that:

1. Ingests commercial loan agreements (seed datasets are provided — `loan_documents/` and `loan_status_registry.csv`)
2. Uses the in-house LLM to extract these fields into a structured record: **loan_number, borrower_name, principal_amount, interest_rate, maturity_date**
3. Works as an agent, not a single call: cross-check extracted values against the source document via a tool, and look up a related document via a second tool when a field's value references another document — then decide how to proceed
4. **Extract the borrower_name field.**
5. **Extract the maturity_date field.**
6. Autonomously commit the record to the system of record via a tool call.
7. **Separately, for loan agreements approaching maturity, look up the current loan status via a tool, and if it confirms the loan is still active, autonomously generate a maturity follow-up record via a tool call.**
8. Provides a UI where a human can review extracted fields against the source document, correct them, and see any autonomous commits *and* any follow-up records already generated
9. Persists documents, extracted fields, commit/review status, any follow-up records generated, and any corrections to a database

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24 hours.
