import uuid
import datetime
from app.db.database import get_connection

class FulfillmentDispatchClient:
    def dispatch_fulfillment(self, order_id: str, idempotency_key: str, action_type: str, sku: str, quantity: int, shipping_cost: float = 0.0) -> dict:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Check server-side idempotency record to avoid duplicate fulfillment
        cursor.execute("SELECT dispatch_id, status FROM dispatch_log WHERE idempotency_key = ?", (idempotency_key,))
        row = cursor.fetchone()
        if row:
            conn.close()
            return {
                "dispatch_id": row[0],
                "status": row[1],
                "idempotency_hit": True,
                "message": "Existing dispatch returned (idempotency preserved)."
            }
        
        # Simulate network dispatch call
        dispatch_id = f"DSP-{uuid.uuid4().hex[:8].upper()}"
        timestamp = datetime.datetime.utcnow().isoformat()
        
        cursor.execute(
            "INSERT INTO dispatch_log (dispatch_id, order_id, idempotency_key, action_type, sku, quantity, shipping_cost, status, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (dispatch_id, order_id, idempotency_key, action_type, sku, quantity, shipping_cost, "SUCCESS", timestamp)
        )
        conn.commit()
        conn.close()
        
        return {
            "dispatch_id": dispatch_id,
            "status": "SUCCESS",
            "idempotency_hit": False,
            "message": f"Successfully dispatched {quantity}x {sku} via {action_type}"
        }