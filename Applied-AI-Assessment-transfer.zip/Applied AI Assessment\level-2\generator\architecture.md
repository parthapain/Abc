# Use-Case Generator — Architecture

## The problem this solves

300+ candidates need genuinely distinct use cases — sharing solutions between candidates who might be in the same room, on the same Slack channel, or just googling the exact phrasing of their brief would undermine the whole exercise. But 300+ candidates also need to be **comparable** on the same rubric, which means every instance has to test the same underlying skills regardless of its surface content.

Hand-authoring 300+ well-formed, appropriately-hard briefs in a week isn't achievable. The generator resolves this by separating **what varies** (surface content) from **what stays fixed** (the actual skill being tested), so uniqueness and comparability aren't in tension.

## Two layers

### Layer 1 — Templates (4 of them, hand-authored, high effort each)

**Reduced from the original 6–8 target to 4** — a direct consequence of every template now requiring the full agentic/tool/guardrail treatment (see below), which made per-template calibration effort the real constraint on timeline, not authoring. Fewer templates means more parameter variation is needed per template to still clear 300+ unique instances — see the revised arithmetic below.

A template fixes the things that make the rubric applicable:

- **Business scenario shape** — the category of problem (e.g., triage/classification over incoming items, extraction from unstructured text into structured records, a monitoring dashboard over noisy/incomplete data)
- **Two ambiguity slots, not one** — strengthened per `../design-rationale.md` Addendum 20. Each a requirement left genuinely underspecified in the brief, with 2+ defensible resolutions, drawn from the template's own ambiguity pool, so rubric Dimension 3 has two genuine judgment calls to grade (scored at the lower of the two, not averaged — see `../rubric.md` §3).
- **One AI-trap slot** — a sub-problem where an AI coding assistant, given a natural prompt, is likely to produce a plausible-but-wrong-by-default implementation. This has to be *verified in practice*, not assumed — see the calibration step below. (Unchanged by Addendum 20 — this is Dimension 4's concern, distinct from the guardrail-compounding risk below, which is Dimension 2's.)
- **Two independently-guardrailed consequential actions, not one, each with its own verified compounding-failure risk** — also strengthened per Addendum 20. Each action needs its own gate, its own reference dataset, and its own plausible "missing/failed field defaults permissive" failure mode, verified against a live AI assistant independently — so rubric Dimension 2 has two genuine guardrails to grade, worse cap governing across both.
- **One stress-point slot** — an edge case or failure mode (malformed input, empty result set, a timeout, a boundary condition) that a rushed or shallow submission will mishandle, giving rubric Dimension 5 something concrete to check

These are what make a template a template. They don't change between instances of it.

**Calibration reset (Addendum 20):** doubling the ambiguity and guardrail count is a change to what every template demonstrates, not a cosmetic relabel. All 4 templates are **not yet calibrated at this shape** — their existing dry-run calibrations (see `../grading/calibration-runs/`) were run against the old 1-ambiguity/1-guardrail shape and don't automatically carry over, specifically for the second guardrail's compounding-failure risk, which has never been tested against a live assistant. Re-run the calibration procedure below against the new shape before trusting any template for scale generation.

**Where slot content comes from:** don't invent ambiguity/trap/stress-point content ad hoc per template — draw it from `../testing-principles.md`, which enumerates the vendor-neutral skill categories the whole assessment is meant to probe and includes a coverage check (don't let every template's AI-trap be the same failure shape). Read that document before authoring a new template.

### Layer 2 — Instance parameters (many per template, cheap to vary)

Each template exposes a small set of parameters a generator script fills in per candidate:

- **Domain flavor** — the surface framing of the scenario (e.g., the same "extraction from unstructured text" template might surface as contract-clause extraction, meeting-notes-to-action-items, or expense-report parsing)
- **Dataset seed** — the specific sample data provided, generated or drawn from a pool, structurally identical in shape but different in content
- **Trap variant** — which specific version of the planted AI-trap is used, drawn from a small pool per template (so even two candidates on the same template rarely see the identical trap)
- **Stress-point variant** — similarly, which specific edge case is used

**Arithmetic (revised for 4 templates):** 4 templates × ~9 domain flavors × ~4 trap variants × ~4 dataset seeds = 576, comfortably clearing 300 with margin — but each template's pools now need to be roughly 1.5× larger per axis than the original 8-template plan assumed, specifically the domain-flavor pool (~9 instead of ~6), to avoid the smaller template count making any one pool feel repetitive across candidates. Exact pool sizes are tuned during authoring — the goal is "no two candidates compare notes and recognize an identical brief," not a specific multiplication target, but with fewer templates there's less room for a thin pool to hide behind template variety alone.

## Why this keeps comparability intact

The rubric doesn't grade "did you build a good expense-report tool." It grades: did you handle the ambiguity deliberately, did you verify the AI's suggested approach at the trap point, does your submission survive the stress point, is your architecture fit for the problem's actual shape. Those four questions are answerable identically regardless of which template, domain flavor, or trap variant a candidate drew — which is the whole point of fixing them at the template layer rather than letting them vary per instance.

## Calibration requirement — non-negotiable before generating at scale

For each template, before generating any instances from it:

1. **Author one full reference solution.** This is the only way to confirm the ambiguity is genuinely ambiguous (not obviously one-way), the trap is genuinely a trap (an AI assistant asked to solve it naturally *does* produce the flawed version — verify this by actually asking one, don't assume it), and the stress point is genuinely hard to handle under time pressure.
2. **If the trap doesn't reproduce** — i.e., the AI assistant handles it correctly on the first try when you test it — the template is broken in the same way P06 was broken in Level 1's Part B bank: it looks right on paper but doesn't exercise what it claims to. Rework the trap or discard the template rather than shipping it.
3. Only after step 1 and 2 pass should the parameter pools be filled in and instances generated.

This mirrors the Level 1 Part B validation gate in spirit — verify the defect actually reproduces before trusting a document that claims it does — just applied to a much less mechanically-checkable kind of defect. There's no automated harness that can confirm "is this AI trap real" the way `harness.py` confirmed a SQL bug was real; the check here is manual: actually run the scenario through an AI coding assistant and see what comes out.

## What the generator script needs to produce, per instance

- A candidate-facing brief (business framing, requirements including the embedded ambiguity, the dataset)
- A unique instance ID (template + parameter combination, for tracking which candidate got what)
- Internal-only metadata (which trap variant, which stress-point variant, where the reference solution lives) — **never shown to the candidate**, used later by the AI grader and human reviewers to know what to look for without re-deriving it from scratch each time

## Open item

**All 4 templates are now authored, and all 4 meet the mandatory agentic/tool/guardrail shape.** T01 and T02 have been reworked (see below — this closes the item that used to sit here); T03 and T04 were authored directly to the shape from the start. **All 4 templates have now had a dry-run calibration pass** (see `../grading/calibration-runs/`):
- **T01 and T02** each confirmed a compounding-failure pattern: a naive guardrail's default-value handling (`.get(key, True/1.0)`-style) silently treats an unverified or failed result as safe, letting a trap-triggered failure slip through. T02's version lives one layer deeper (the verification tool's own error handling, not the extraction call's).
- **T03's dry-run came back mixed, and honestly reported as such** — the same compounding null-default bug was specifically checked for and did **not** reproduce (this template's naive eligibility check fails closed). What did reproduce is a related but distinct, T03-specific gap: a guardrail can gate the *decision* correctly while an unverified *action parameter* (the resolution amount) still leaks from untrusted text. This is a genuinely different failure shape, not a forced match to T01/T02's pattern — worth remembering that not every template will fail the same way.
- **T04's dry-run was the strongest of the four** — all three trap variants reproduced simultaneously from one natural prompt, and a fourth instance of the missing-data-defaults-permissive pattern turned up (`item.get("price", 0)` making incomplete pricing data look cheaper and thus more auto-dispatchable). **This pattern is now confirmed 3 of 4 times (T01, T02, T04) with one honest negative (T03)** — common enough to call out explicitly in the AI grader's Dimension 2 guidance, not just handle template-by-template.

**What remains for all four: an actual timed human build (step 4)** — the dry-runs explicitly don't substitute for this. T01 must run first; T02, T03, and T04 were not attempted since they'd tell us little before T01 settles the scope question.

## Mandatory scenario shape — agentic / tool design / context management / safety guardrails (revised: applies to every template)

**This reverses an earlier decision.** The requirement used to be "at least 2 of 6–8 templates must be agentic/tool-using"; T01 and T02 were deliberately kept single-shot and left out of that requirement. **That is no longer the design.** Every template — all 4 of them, with no exception — must now require:

- **Agentic architecture & orchestration** — a genuine multi-step plan → act → observe → decide loop, not a single call
- **Tool / function interface design** — the app exposing callable tools to the LLM, with clear scope and structured error reporting, not a single direct LLM call
- **Context management** — enough real context volume (which falls out naturally once a template requires a multi-step loop over multiple tool calls) that this is a live design decision
- **Safety guardrails on AI-initiated actions** — the AI must be able to trigger a real, consequential, hard-to-reverse action itself, gated by whatever check the candidate designs — not merely produce a suggestion a human confirms before anything happens

### T01 and T02 — reworked, no longer an open gap

Both were single-shot, single-call, human-confirms-everything scenarios: one LLM call per item, no looping, no tool-calling, no consequential AI-triggered action. **Both have now been reworked** to the mandatory shape — see `../templates/T01-triage-classification.md` and `../templates/T02-structured-extraction.md` directly for the authored content. Summary of what each added:

- **T01 (triage/classification):** instead of one classification call, the agent works a multi-step case: classify → call a `search_similar_items` tool to check for duplicates/related history → call a `get_context` tool for more detail if the classification is uncertain → decide to auto-route, auto-acknowledge, or escalate → for low-risk/high-confidence cases, autonomously trigger a real action (e.g., send an acknowledgment, auto-close a duplicate) gated by an explicit confidence/policy threshold; anything above the threshold still goes to a human. T01's existing ambiguity slot (what determines priority) and AI-trap slot (silent failure masking, etc.) were preserved as-is — they still apply, now inside the larger loop, with the added requirement that a failure-masked classification must never reach the guardrail as "safe to auto-act on." The guardrail's own naive-default trap-worthiness (e.g., "auto-send if classification confidence > threshold" with no check on the ACTION's own risk) is graded under Dimension 2's capping rule, not as a second Dimension 4 trap.
- **T02 (structured extraction):** instead of one extraction call, the agent works a multi-step case: extract → call a `verify_against_source` tool to cross-check extracted values → call a `lookup_related_document` tool when a value references another document (the existing ambiguity slot already included this: "30 days after the {{other_event}}") → decide to auto-commit the extraction to the system of record or flag for human review → for high-confidence, fully-grounded extractions, autonomously commit the record, gated by a confidence/completeness check. T02's existing ambiguity and AI-trap slots (hallucinated absent fields, cross-contamination) were preserved and now sit inside the larger loop, with the added requirement that an ungrounded/hallucinated extraction must never reach the auto-commit guardrail as "verified."

Both templates' Status lines now read **"Reworked"** — the rework itself is complete. What remains for all 4 templates equally is calibration (see below), not authoring.

### Impact of this decision, and the resulting scope call

- **Authoring itself is not the constraint.** Writing a template's brief, tool definitions, and reference solution is drafted by an AI (same model used for Level 1's 24 problems) and human-reviewed before trust — this is fast regardless of template count, and was never really the bottleneck.
- **Calibration is the real, irreducible constraint, and it scales per template.** For every template someone has to actually run the scenario past a live AI assistant and observe real behavior: does the assistant produce the planted flaw, does a naive agentic build really skip or under-gate the consequential action, does the loop terminate sensibly, does the tool interface avoid getting misused. This can't be shortcut by faster drafting — it's empirical testing against live AI behavior, and if a trap doesn't reproduce, the template needs rework and re-testing (the same lesson as Level 1's P06: a plausible-sounding trap that didn't actually reproduce once tested for real).
- **Decision: reduce the template count from 6–8 to 4, rather than extend the timeline or accept the risk.** This directly trades template-count/variety for calibration throughput within the original 1-week build window — 4 templates means 4 calibration cycles instead of 6–8, at the cost of fewer distinct business scenarios in the pool (see the revised arithmetic above, which increases per-template parameter-pool size to compensate).
- **All 4 templates are now fully authored to the mandatory shape** — T01 and T02's rework is done, T03/T04 were built to it from the start. Each template's Calibration section has been updated to also cover the agentic loop, tool interface, and guardrail-trap layer, not just the original classification/extraction trap. What remains is calibrating all four, T01 first.
- **Grading is unaffected in mechanism, only in universality.** The rubric's Dimension 2 (`../rubric.md`) already covers agentic/tool/guardrail quality — it no longer carries a "some templates are exempt" carve-out, since none are exempt anymore.
- **Sequencing implication (corrected): calibrate T01 first, in full — including its internal timeboxed build-time check — before calibrating T02 or the 2 new templates.** This is a calibration-order constraint, not an authoring-order one — authoring is cheap and doesn't consume the scarce resource (per the point directly above), so T03 and T04 have in fact been authored in parallel with T01/T02's rework rather than waiting on it. What must wait is *trusting* any template: don't calibrate T02/T03/T04, and don't generate real instances from any of them, until T01's timeboxed build confirms the mandatory scope (agentic loop + tool interface + context management + gated action, on top of ambiguity/trap/stress-point slots) actually fits the 24–48hr window. If it doesn't, that's a scope problem affecting all four templates equally, and it's far cheaper to discover it once, against T01, than after investing calibration effort in all four.

### Guardrail-default flaws are a Dimension 2 concern, not a second Dimension 4 trap

Every template's guardrail-trap candidate (an agentic build's naive first-draft guardrail — e.g., "auto-fire once confidence clears a threshold," with no check on the *action's* own risk) is graded under rubric Dimension 2's capping rule (architecture/guardrail-design defect — categories 8, 9, 12), not as a second trap subject to Dimension 4's evidence-discipline rules (code as ground truth, rationale must cite a checkable mechanism). All 4 templates now state this explicitly in their own guardrail sections, so every template's guardrail-quality signal is scored the same way — see `../rubric.md` §2 and `../testing-principles.md` category 12.

**Note (this revision):** Dimension 1 in the rubric used to be a single "Problem framing & approach" dimension carrying both base architecture fit and agentic/tool/guardrail quality via a capping rule. It has since been split: Dimension 1 is now base architecture fit only, and the new Dimension 2 carries the agentic/tool/guardrail/cost-efficiency content and its capping rule. Every reference above to "Dimension 2" (guardrail ownership, the cross-template compounding-default pattern) reflects this split — see `../rubric.md`'s revision note and `../design-rationale.md` Addendum 16.

### Addendum 20 — ambiguity and guardrail count doubled (1 → 2 each), decided after a real test build exposed how quickly a naive build could pass at the old bar

**Trigger:** a quick internal test build (Gemini Pro, ~15 minutes, not a real 24–48hr candidate effort — see `design-rationale.md` Addendum 20 for the full record) still scored 9/20 on the old 1-ambiguity/1-guardrail shape, but the build was thin enough (a broken tool, no real LLM call, a decorative second tool call) that the user wanted the bar raised before trusting the shape at 300+ scale.

**What changed:** every template now requires **two** ambiguity slots (not one) and **two independently-guardrailed consequential actions** (not one), each with its own verified compounding-failure risk — this used to be an opt-in "harder" variant (see `../generator/human-build-instances-harder/`), now folded in as the standing default. Full mechanics are in `.claude/agents/level2-use-case-generator.md` and `.claude/agents/level2-use-case-evaluator.md`, and in `../rubric.md` §2/§3 and `../testing-principles.md` categories 2/12.

**What this section's history above does *not* reflect yet:** the T01/T02 rework narrative above (one guardrail each: auto-route/auto-close for T01, auto-commit for T02) and all four templates' calibration-run write-ups describe the **old, single-guardrail shape** — an accurate record of what was true at the time, left unedited per this doc's convention of not rewriting past decisions (see the Dimension-1-split note above, and `design-rationale.md`'s own convention). **All 4 templates need a second ambiguity and a second independently-guardrailed action authored into their briefs before they meet the new shape**, and all 4 reset to "not yet calibrated" until that authoring is done and re-verified against a live AI assistant — see the calibration-reset note in the Layer 1 section above.

**Status:** shape change decided, specified, **authored into all 4 templates, and now dry-run calibrated (Calibration Run #3, all 4 templates)** — each second guardrail's compounding-failure risk was simulated the same way this project's original guardrails were: one hypothesis (T01) didn't reproduce as originally guessed and was replaced with the mechanism that actually did (an omitted lower-bound check, confirmed against real data); one (T04) reproduced in a sharper, more specific form than guessed (a cost-only check confirmed against a real zero-stock row); two (T02, T03) confirmed exactly as hypothesized. **What remains for all 4: verification against an actual live AI assistant** (this run, like the project's original dry-runs, was hand-simulated reasoning, not a blind third-party trial) **and the timed human build (step 4), still pending for all 4.** A subsequent peer review of the authoring pass found and fixed real drift — a T03 dataset-schema mismatch, a T03/T04 dimension-mislabeling bug, and spoiler-style drift in the T02 harder instance's brief — see `../design-rationale.md` Addendum 20.

### Category 4/5 coverage — resolved

`../testing-principles.md`'s coverage check required at least one template's AI-trap to come from category 4 (untrusted/adversarial input) or category 5 (reliability engineering), so the trap pool isn't monotonously category-3-shaped. **Both new templates cover this, one each:** T03 (`../templates/T03-refund-request-handling.md`) draws its trap from category 4 — untrusted request text must not be able to dictate an autonomous action. T04 (`../templates/T04-order-fulfillment-reliability.md`) draws its trap from category 5 — transient-vs-permanent failure handling and retry/idempotency around a fulfillment-dispatch call. T01 and T02 remain category 3. The trap-shape coverage across the 4-template set is now: 3, 3, 4, 5 — varied, per the coverage check.
