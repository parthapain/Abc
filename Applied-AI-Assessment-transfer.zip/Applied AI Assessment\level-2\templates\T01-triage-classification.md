# Template T01 — Triage & Classification

| Field | Value |
|---|---|
| **ID** | T01 |
| **Scenario shape** | Incoming items arrive continuously; the app must classify each via the in-house LLM, then work as an agent — checking for duplicates/related history and pulling more context when uncertain — before deciding to auto-acknowledge/auto-route low-risk items or escalate to a human, with the AI-triggered action gated by a guardrail |
| **Target build time** | 24–48 hrs |
| **Status** | **Shape strengthened (Addendum 20) — two ambiguities and two independently-guardrailed actions now required.** Run #1/#2 (old 1/1 shape) and **Run #3 (new second guardrail, dry-run confirmed — `../grading/calibration-runs/T01-calibration-run.md`)** are both done. The second guardrail's compounding-failure risk (an omitted lower-bound check on the credit threshold) reproduced in dry-run, refined from the original hypothesis after testing. **Still not verified against a live AI assistant, and the timed build (step 4) is still pending** — both required before this template counts as officially calibrated. |
| **Trap category** | Category 3 (unchanged from the pre-rework version) — silent failure masking on the underlying LLM call. |

---

## Candidate-facing brief (template — `{{...}}` filled per instance)

> Your organization receives a continuous stream of {{item_noun}} — {{item_description}}. Build an application that:
>
> 1. Ingests {{item_noun}} (seed datasets are provided — `{{dataset_file}}` and `{{second_dataset_file}}`)
> 2. Uses the in-house LLM to classify each one into the categories: {{category_list}}
> 3. Works as an agent, not a single call: after classifying, check for duplicate or related history on the item via a tool, and pull additional context via a second tool if the classification is uncertain — then decide how to proceed
> 4. **{{ambiguity_requirement_1}}**
> 5. **{{ambiguity_requirement_2}}**
> 6. For items that are low-risk and high-confidence, autonomously acknowledge, auto-close (if a genuine duplicate), or auto-route the item — gated by an explicit confidence/policy threshold; anything above that threshold, or anything the tools couldn't resolve, is escalated to a human
> 7. **Separately, for items classified as {{second_guardrail_trigger_category}} where the requester describes a specific, checkable discrepancy: check the real account/system record via a tool, and if it confirms the discrepancy below a small threshold, autonomously issue a courtesy resolution via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate. Anything the record doesn't confirm, or that exceeds the threshold, is escalated to a human instead of being resolved automatically.
> 8. Provides a UI where a human can review classifications, any automatic actions taken (routing/acknowledgment *and* any courtesy resolutions), see the LLM's reasoning, and override them
> 9. Persists {{item_noun}}, their classifications, actions taken (including any courtesy resolutions), and any human overrides to a database
>
> The dataset includes some {{item_noun}} that are {{stress_point_description}} — your solution should handle these sensibly rather than crashing or producing silently wrong output.
>
> Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

---

## Fixed elements (do not vary per instance)

### Ambiguity slot

`{{ambiguity_requirement_1}}` / `{{ambiguity_requirement_2}}` — **every instance now plants two distinct phrasings from this pool, not one** (strengthened per `../design-rationale.md` Addendum 20). Pool of phrasings, all sharing the same underlying ambiguity: **what determines priority, and by what**:

1. *"Prioritize {{item_noun}} appropriately so urgent ones surface first."* — "urgent" and "appropriately" are undefined: by customer tier? language urgency signals? a deadline field? some combination?
2. *"Flag {{item_noun}} that need immediate human attention."* — the threshold for "immediate" is undefined.
3. *"Route {{item_noun}} to the right team."* — the team taxonomy and whether routing depends on category alone or also on severity/customer attributes is undefined.

Pick any 2 of the 3 above per instance (3 possible pairs across instances gives parameter variety on its own). **What "handled well" looks like (dimension 3):** the rationale names each ambiguity explicitly, states the assumption made, ties it to something real in the dataset or scenario (not a generic statement), and — for the top score on either — reduces the cost of being wrong (e.g., the priority/routing logic is isolated behind one clearly-named function/config rather than scattered inline). Scored at the lower of the two — see `../rubric.md` §3's non-averaging rule.

### AI-trap slot (category 3, unchanged)

**The trap:** the brief requires the system to call the LLM per item for classification. When a coding assistant is asked to "add error handling around the LLM call" or "make sure this doesn't crash if the API fails" — a completely natural, expected request in this build — a very common default is to **catch the failure and silently return a default classification** (e.g., `"category": "general", "priority": "low"`), indistinguishable in the data from a genuine LLM classification. This applies just as much inside the agentic loop as it did in the single-shot version: a failed classification feeding into the agent's downstream decision (auto-act vs. escalate) is just as dangerous, since a silently-defaulted "low priority" item could now get auto-acknowledged and closed instead of merely mis-filed.

This is realistic, not contrived: defensive fallback-on-exception is a standard pattern an assistant will produce unprompted, and it is *locally* reasonable (the app doesn't crash) while being *globally* wrong (a failed classification is now silently misrepresented as a real one, with no way for a reviewer to tell the difference later).

**What "caught" looks like (dimension 4):** the shipped code distinguishes a failed classification from a genuine low-priority/general one — a distinct status field, a flag surfaced in the review UI, a retry with visible failure state, anything that preserves the distinction — **and this distinction must reach the guardrail**: a failed classification should never be treated as "high-confidence, low-risk" for the purposes of the auto-action gate. There's no AI-interaction log and no commit history to check against — only the final code plus the rationale: a "3"/"4" submission's rationale names this exact risk and points to the specific mechanism in the code that preserves the distinction, checkably. A rationale that merely claims "I made sure failures are handled" with no cited mechanism a reviewer can find in the code doesn't clear this bar — see `../rubric.md` Dimension 4's grading note.

**Trap variants** (pool — vary which specific failure-masking pattern shows up):
1. Silent fallback classification on exception (as above)
2. Fallback returns HTTP 200 / "success" to the caller even though classification internally failed
3. Unbounded retry on failure with no backoff and no visible state, risking duplicate processing being mistaken for distinct items
4. Classification results cached by item ID with no invalidation, so an edited/resubmitted item silently keeps a stale result

### Stress-point slot

`{{stress_point_description}}` — pool of variants:
1. Blank/empty body text
2. Text far exceeding the LLM's context window
3. Text in a language other than the classifier's expected language
4. A burst arrival of several hundred items at once (load behavior, not data malformation)

**What "handled well" looks like (dimension 4):** the planted variant doesn't crash the app or silently corrupt output; ideally the same defensive pattern generalizes to similar cases, not just the one variant present in the seed dataset.

---

## Mandatory agentic/tool/guardrail shape

- **Agentic loop:** classify → call a duplicate/related-history lookup tool → call a context-lookup tool if the classification is uncertain → decide to auto-act or escalate — a genuine multi-step loop with a sensible stopping condition (bounded by the two tool calls plus the decision, not open-ended).
- **Tools:** e.g., `search_similar_items(item_content)` — returns related/duplicate items with enough detail to judge genuine duplication; `get_context(item_id)` — returns fuller detail (requester history, prior interactions) when classification confidence is low. Clearly scoped, structured failure reporting (not found / no matches / error), not a single do-everything function.
- **Context management:** the agent carries forward what the tools returned (duplicate status, additional context) into the decision step, rather than deciding on the classification alone once tools have been consulted.
- **Guardrail:** the autonomous action (acknowledge / auto-close / auto-route) fires only when classification confidence is high **and** the tools found no blocking issue (no genuine duplicate misidentified as new, no missing context flagged) **and** the classification wasn't a failure-masked default (see AI-trap slot above); anything else escalates. **Guardrail-trap candidate** (graded under rubric Dimension 2, not Dimension 4 — see `../testing-principles.md` category 12 and `../rubric.md` §2): a naive first draft is likely to gate the auto-action purely on classification confidence, with no check on the *action's own* risk (e.g., auto-closing a ticket the duplicate-lookup tool flagged as only a *possible*, not confirmed, duplicate) — this is an architecture defect, not a second instance of the category-3 trap above.
  - **Confirmed compounding failure (calibration run #1, `../grading/calibration-runs/T01-calibration-run.md`):** a naive implementation's failure-masked fallback dict (from the AI-trap slot) typically carries no `confidence` key. A naive guardrail reading `result.get("confidence", 1.0)` then treats a *failed* classification as **maximum confidence**, sailing it straight through the guardrail into auto-acknowledge. A candidate who fixes only the trap (adds a status flag) without auditing what the guardrail actually reads still fails here — this is a stronger, more specific version of "a trap-triggered failure must never reach the guardrail as safe to auto-act on," worth checking for explicitly rather than just in principle.
- **Second guardrail (new, Addendum 20) — a courtesy resolution gated on the real account/billing record, not the requester's own claimed number:** for {{second_guardrail_trigger_category}} items where the requester describes a specific, checkable discrepancy (e.g., "I was charged $X, should have been $Y"), the agent must call a tool (e.g., `check_billing_record(account_id)`) that returns the *actual*, tool-verified discrepancy from a second reference dataset (`{{second_dataset_file}}`) — never the number parsed from the requester's own text. If the verified discrepancy is non-zero and below a small threshold, autonomously issue the resolution; if it's zero, or exceeds the threshold, escalate instead. This is a separate gate from step 6's routing guardrail — a submission that reuses the same confidence check for both, or lets one action's approval also trigger the other, fails this requirement.
  - **Compounding-failure risk — confirmed via dry-run (calibration run #3, `../grading/calibration-runs/T01-calibration-run.md`), refined from the original hypothesis:** the originally-guessed failure mode (a lookup falling back to the requester's claimed number) did **not** reproduce — a natural `record.get("discrepancy", 0)` fails toward $0 on a missing lookup, not toward the customer's figure. What actually reproduces: a naive threshold check written as `if discrepancy <= 50` **omits the lower bound**, so a genuinely zero (or negative) discrepancy also passes and triggers an auto-credit of $0 — confirmed directly against T-2005 in the harder-instance dataset (real discrepancy exactly $0), which a naive build would incorrectly auto-"resolve" instead of escalating. **Still not tested against a live AI assistant** (dry-run only) — see Status above.
  - **Design the second dataset so this guardrail is testable in more than one direction:** at least one row where the verified discrepancy is real and within threshold (should auto-resolve), one where the requester's claim isn't corroborated by the real record at all (should refuse and escalate), and ideally a third where the real discrepancy is confirmed but exceeds the threshold (should escalate, not auto-resolve).

---

## Per-instance parameters

| Parameter | Example pool |
|---|---|
| `item_noun` / `item_description` | support tickets / insurance claims / IT helpdesk requests / sales leads / HR complaints / content-moderation reports |
| `category_list` | varies naturally with the domain flavor chosen above |
| `dataset_file` | a generated seed set per instance, structurally identical (id, submitted-at, free-text body, customer/requester metadata) but different content, sized ~50–200 rows including the planted stress-point row(s) |
| `second_dataset_file` | a second, independent reference dataset per instance (e.g. `billing_accounts.csv`) mapping requester/account IDs to a verified, tool-checkable figure — testable in all 3 directions described in the second-guardrail note above |
| `second_guardrail_trigger_category` | whichever category in `category_list` naturally carries a "requester claims a specific number" scenario (e.g., Billing) |
| Ambiguity phrasings | 2 distinct of 3 above (not 1) |
| Trap variant | 1 of 4 above |
| Stress-point variant | 1 of 4 above |

6 domain flavors × 3 ambiguity-phrasing pairs × 4 trap variants × 4 stress variants comfortably exceeds what's needed from this template alone; actual generation should undersample this space (see architecture doc) rather than exhaust every combination, to avoid the pools themselves becoming a fingerprint.

---

## Reference solution outline (author before generating any instance)

Not full code — a written answer key a grader (human or AI) checks a submission against:

1. **Framing:** a pipeline shape (ingest → classify → tool-check → decide → review/override → persist) with the classification and tool-check steps isolated enough to test/mock independently. Note which architecture choice you'd flag as debatable and why.
2. **Ambiguity:** state which two of the three phrasing variants you're calibrating against, your chosen resolution for each, and why.
3. **Trap:** show the naive version (what an assistant produces on first ask) and the corrected version side by side, including how the distinction survives into the guardrail decision.
4. **First guardrail:** show the naive first-draft guardrail (confidence-only gating) versus the corrected version (confidence + tool result + non-failure check) — **and explicitly show the compounding failure found in calibration run #1** (a failure-masked fallback with no `confidence` key reading as maximum confidence via `.get("confidence", 1.0)`), since a candidate could plausibly fix the trap and the guardrail each in isolation and still miss this.
5. **Second guardrail:** show the naive first draft (a billing-record check that silently falls back to the requester's own claimed number on lookup failure) versus the corrected version, and confirm the second reference dataset actually exercises all 3 test directions.
6. **Stress point:** show the specific input that exercises it and the expected behavior.

## Calibration — required before generating instances, run first

**Reset by Addendum 20 (shape strengthened to 2 ambiguities / 2 guardrails).** Steps 1–3 below were confirmed against the **old, superseded 1-ambiguity/1-guardrail shape** — see `../grading/calibration-runs/T01-calibration-run.md` for that historical run (including Run #2's post-rubric-split re-validation). None of it has been re-verified against the new second ambiguity or, more importantly, the new second guardrail's compounding-failure risk. T01 still calibrates first, ahead of T02/T03/T04, once this reset is cleared.

1. ✅ *(old shape)* **Confirmed.** A naturally-prompted coding assistant produces the flawed classification-trap pattern, and it reaches the guardrail decision via a shared default-value gap.
2. ✅ *(old shape)* **Confirmed.** The ambiguity is genuinely two-way in practice for phrasing #1, tested against realistic sample tickets. **Not yet re-tested** with a second phrasing active alongside it.
3. ✅ *(old shape)* **Confirmed — and sharper than anticipated.** A naturally-built guardrail gates on classification confidence alone, inheriting maximum confidence from a failed classification's fallback dict.
3b. ✅ **Dry-run confirmed (calibration run #3).** The originally-guessed mechanism (fallback to the requester's claimed number) did not reproduce; an omitted lower-bound check on the credit threshold did, confirmed against T-2005's real $0 discrepancy. **Not yet posed to a live AI assistant** — still needed before this counts as fully verified.
4. ⏳ **Not done.** Time-box a build of one full instance internally (brief + agentic loop + tools + **both** guardrails, not just the classification step) with an actual person and a real clock — the complexity estimate in the calibration run is not a substitute for this, and the estimate itself predates the second guardrail so should be treated as stale. This result gates calibrating T02, T03, and T04 — see `../generator/architecture.md`.
