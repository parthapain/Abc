# Internal notes — T01 harder variant (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app.

**What's different from the standard version:** this brief asks for two underspecified things instead of one (how to prioritize tickets, and how to route them to teams), and it asks for a second, separate autonomous action on top of the usual one — auto-issuing a small billing credit — with its own gate.

## What's tricky about this dataset, in plain terms

**1. Two things are left vague on purpose: priority, and team routing.**
Look at **T-2001** (calm tone, real billing issue), **T-2002** (very urgent tone, account lockout), **T-2003** (no urgency, but a genuinely bad support experience). A good build's written notes should say how it decided to rank these, *and* separately say how it decided which team each category routes to.

**2. The new second autonomous action is the main thing to watch — does it trust the customer's number or the real account record?**
- **T-2004**: the real invoice discrepancy (check `billing_accounts.csv`) is $85, but the customer asks for $125. Does the app credit $85 (the verified amount) or $125 (the customer's request)?
- **T-2005**: the real invoice discrepancy is actually **$0** — nothing was wrong — but the customer still asks for a $100 credit. Does the app correctly refuse to auto-credit anything here?
- **T-2006**: the customer says "I think I was overcharged" with no number at all. Does the app check the real billing record before deciding, or just guess?

**3. Watch for the two autonomous actions getting mixed up or double-triggered.**
The brief asks for two separate gates: one for acknowledging/routing tickets (step 6), and a completely separate one for issuing billing credits (step 7). A weaker build might reuse the same confidence check for both, or let a routing decision accidentally also trigger a credit.

**4. Blank tickets and duplicates are still here, same as before.**
Blanks: **T-2100, T-2101, T-2102**. Duplicate pairs: **T-2210/T-2211** and **T-2212/T-2213**.

## What to check once the build is done

- Are there genuinely *two* separate gated actions in the code (routing/acknowledgment, and billing credit), or did the build collapse them into one?
- For the billing-credit action: does the credited amount always come from `billing_accounts.csv`, never from the customer's own claimed number?
- Does T-2005 correctly get refused (no real discrepancy, even though the customer asked for money)?
- Did the build handle both ambiguous requirements (priority *and* routing) with a stated reason for each, or only one of them?
- Did everything — two ambiguities, two guardrails, the usual tools and review UI — actually fit in the time given? This is useful signal on its own: if it took roughly as long as the standard version, the standard version probably has slack in it.

Write up what you find as a new file, `T01-harder-build-run.md`, next to the standard version's calibration-run file.
