import sqlite3
import pandas as pd

DB_FILE = "rentals.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.executescript('''
    CREATE TABLE IF NOT EXISTS catalog (
        sku TEXT PRIMARY KEY,
        description TEXT NOT NULL,
        unit_price REAL NOT NULL,
        in_stock INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS alt_inventory (
        sku TEXT PRIMARY KEY,
        alt_stock INTEGER NOT NULL,
        ship_cost_from_alt REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
        order_id TEXT PRIMARY KEY,
        client_name TEXT NOT NULL,
        client_type TEXT NOT NULL,
        submitted_at TEXT NOT NULL,
        raw_line_items TEXT NOT NULL,
        status TEXT NOT NULL,
        total_face_value REAL NOT NULL,
        total_dispatchable_value REAL NOT NULL,
        reconciliation_notes TEXT,
        dispatch_notes TEXT,
        override_notes TEXT
    );

    CREATE TABLE IF NOT EXISTS order_line_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT NOT NULL,
        requested_desc TEXT NOT NULL,
        matched_sku TEXT,
        matched_desc TEXT,
        quantity INTEGER NOT NULL,
        unit_price REAL,
        reconciliation_status TEXT NOT NULL,
        primary_stock_available INTEGER,
        fulfillment_source TEXT NOT NULL,
        fulfilled_qty INTEGER NOT NULL DEFAULT 0,
        backordered_qty INTEGER NOT NULL DEFAULT 0,
        alt_ship_cost REAL DEFAULT 0.0,
        FOREIGN KEY(order_id) REFERENCES orders(order_id)
    );

    CREATE TABLE IF NOT EXISTS dispatch_log (
        dispatch_id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL,
        idempotency_key TEXT UNIQUE NOT NULL,
        action_type TEXT NOT NULL,
        sku TEXT,
        quantity INTEGER,
        shipping_cost REAL,
        status TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY(order_id) REFERENCES orders(order_id)
    );
    ''')
    
    # Seed tables from CSVs if available
    try:
        cat_df = pd.read_csv("equipment_catalog.csv")
        cat_df.to_sql("catalog", conn, if_exists="replace", index=False)
        
        alt_df = pd.read_csv("alt_yard_inventory.csv")
        alt_df.to_sql("alt_inventory", conn, if_exists="replace", index=False)
    except Exception as e:
        pass

    conn.commit()
    conn.close()

def get_connection():
    return sqlite3.connect(DB_FILE)