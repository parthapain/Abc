# Human-Build Instances — Harder Variant (Parallel Timing Set)

**⚠️ Superseded by Addendum 20 (`../../design-rationale.md`):** what this folder describes — 2 ambiguities, 2 independently-guardrailed actions per instance — is no longer a separate "harder" tier. It's now the standing default shape every template must meet (see the 4 template docs in `../../templates/`). This folder's content (the concrete second-ambiguity/second-guardrail mechanism per template, already designed and instance-tested at the folder level) is exactly what got formalized into each template's spec — it's kept here as an accurate historical record and a working concrete example, not because the "standard vs. harder" split still exists.

**This is a second, independent set of 4 instances — over and above `../human-build-instances/`, not a replacement for it.** *(This framing predates Addendum 20 — see the note above.)* Give the standard set to one group of humans and this harder set to a different group, timed in parallel, so a slow result on one set doesn't leave the whole calibration effort waiting on a single data point before the deadline.

## Why this set exists

If the standard build finishes comfortably inside 24–48 hours, that's not automatically a problem — the goal is finding real practitioners, not filling a fixed number of hours, and a fast finish can just mean a skilled builder. But if you *do* want to test whether the assessment has more room in it, this set adds real difficulty rather than busywork: bigger datasets don't test more skill, so this set instead stacks two things per template:

1. **A second instance of an existing slot** — every brief here asks the candidate to resolve *two* underspecified requirements instead of one (both drawn from that template's own existing ambiguity pool, not invented from scratch).
2. **A second, independently-guardrailed autonomous action** — every brief adds a second thing the AI can trigger on its own, separate from the original one, with its own gate and its own tool-verified check. This is the harder addition: it means the build now needs two genuinely different guardrails instead of one, each checked against a different piece of real data.

Every dataset also got a matching new reference table so the second guardrail has something real to check against (see per-instance notes below) — not just a second rule with nothing behind it.

## What's in each instance folder

Same shape as the standard set: `brief.md` (hand only this and the dataset files to whoever's building), one or more seed-dataset files, and `INTERNAL-metadata.md` (never share this — it names exactly where the tricky cases are and what to check afterward).

| Instance | Stacked ambiguity | Second guardrailed action | New reference data |
|---|---|---|---|
| T01 | Prioritize urgency **+** route to the right team | Auto-issue a small billing credit, gated on the *real* invoice record | `billing_accounts.csv` |
| T02 | Relative end-dates **+** inconsistent policyholder names | Auto-generate a renewal reminder, gated on real renewal/cancellation status | `renewal_status.csv` |
| T03 | Value threshold **+** repeat-customer caution | Auto-schedule a replacement shipment, gated on the customer's real recent-replacement count | `replacement_history.csv` |
| T04 | Catalog reconciliation **+** back-order handling | Auto-reroute a line item to an alternate warehouse, gated on real alt-stock and shipping cost | `alt_warehouse_inventory.csv` |

Each second guardrail is deliberately testable both ways in its dataset — e.g. T04's alt-warehouse data includes one item that should reroute, one that's available but too expensive to reroute, and one that's unavailable everywhere — so a build that only checks "does an alternate warehouse row exist" instead of actually reading the stock/cost numbers will get caught.

## Running the build

Same process as `../human-build-instances/README.md`: hand over only `brief.md` and the dataset files, start a real clock, ask for the same zip + `MANIFEST.md` + rationale submission shape, and don't hint at where the tricky parts are.

When it's done, record the result as `T0{n}-harder-build-run.md` next to that template's existing `../../grading/calibration-runs/T0{n}-calibration-run.md` — keep it as a separate file rather than folding it into the standard run's write-up, since this is a deliberately different (harder) brief, not another calibration pass of the same one. Worth comparing directly against the standard set's timing: if this set takes meaningfully longer, that's a real signal the standard brief has slack; if it takes about the same, the extra requirements may not have been the right lever and the standard set's time is closer to a true floor.

## A filename spoiler caught and fixed

`T02-insurance-policies/policy_documents/` originally used filenames like `POL-4021-AND-4022-CONCATENATED.txt` to mark the multi-document stress-point files — a spoiler visible in a plain folder listing, before the candidate opens anything. These have been renamed to a neutral ID-pair scheme (`POL-4021-4022.txt`); no metadata here cited the old names directly, so no other file needed updating. See `../human-build-instances/README.md`'s matching note — the same fix was applied to the standard set, and the underlying rule is now locked into `level2-use-case-generator.md`.

## A note on scope

This is still hand-built content, same as the standard set — not run through `generate_instances.py`/`template_definitions.py`, since a second guardrailed action and a second reference table per template is a one-off design addition, not part of the standard template shape those files already model. If a stacked-slot design like this is ever wanted at 300+-candidate scale, it would need its own template variant authored into `template_definitions.py` rather than assumed to fall out of the existing one.
