import glob
import os
import random
import re

import pandas as pd

LOAN_DOCS_DIR = "loan_documents"
status_df = pd.read_csv("loan_status_registry.csv").set_index("loan_number")

_server_side_followups = {}  # idempotency_key -> followup_id, simulating a real backend
_live_status = None  # test hook: override the "live" status lookup mid-run


class TransientFollowupError(Exception):
    pass


class PermanentFollowupError(Exception):
    pass


def set_live_status(loan_number, new_status):
    """Test hook: simulate the loan's status changing after it was first read."""
    global _live_status
    if _live_status is None:
        _live_status = status_df["verified_status"].to_dict()
    _live_status[loan_number] = new_status


def _all_note_files():
    """All promissory-note-style reference documents (not primary loan agreements)."""
    notes = {}
    for path in glob.glob(os.path.join(LOAN_DOCS_DIR, "*.txt")):
        text = open(path, encoding="utf-8").read()
        if "PROMISSORY NOTE" in text and "COMMERCIAL LOAN AGREEMENT" not in text:
            borrower_match = re.search(r"Borrower:\s*(.+)", text)
            date_match = re.search(r"Maturity Date:\s*(\d{4}-\d{2}-\d{2})", text)
            borrower = borrower_match.group(1).strip() if borrower_match else None
            maturity = date_match.group(1) if date_match else None
            notes.setdefault(borrower, []).append({
                "path": os.path.basename(path), "maturity_date": maturity, "text": text,
            })
    return notes


def lookup_related_document(borrower_name):
    """
    Returns one of:
      {"status": "RESOLVED", "maturity_date": ...}
      {"status": "AMBIGUOUS", "candidates": [path, ...]}
      {"status": "NONE"}
    Never silently picks one of several plausible referenced notes.
    """
    notes = _all_note_files()
    candidates = notes.get(borrower_name)
    if not candidates:
        return {"status": "NONE"}
    if len(candidates) == 1:
        return {"status": "RESOLVED", "maturity_date": candidates[0]["maturity_date"], "source": candidates[0]["path"]}
    return {"status": "AMBIGUOUS", "candidates": [c["path"] for c in candidates]}


def verify_against_source(doc_id, field, value, raw_text):
    """
    Returns {"grounded": bool, "confidence": float, "matched_text": str}.
    Adversarial case: LN-7010's interest_rate field always reports grounded=True
    with no actual matched text backing it up -- the tool's own response is
    internally inconsistent and must not be trusted at face value.
    """
    if doc_id == "LN-7010" and field == "interest_rate":
        return {"grounded": True, "confidence": 0.95, "matched_text": ""}

    if value is None:
        return {"grounded": False, "confidence": 0.0, "matched_text": ""}

    value_str = str(value)
    if value_str in raw_text:
        return {"grounded": True, "confidence": 0.95, "matched_text": value_str}
    return {"grounded": False, "confidence": 0.2, "matched_text": ""}


def check_current_status(loan_number):
    """Returns (status, valid) -- valid False when the registry's own response
    doesn't make sense; None status when there's no row at all (not found)."""
    global _live_status
    source = _live_status if _live_status is not None else status_df["verified_status"].to_dict()
    if loan_number not in source:
        return None, True
    status = source[loan_number]
    if status not in ("active", "refinanced", "paid_off"):
        return status, False
    return status, True


def generate_followup(loan_number, idempotency_key, force_lost_response=False):
    """Idempotent, retryable action -- same shape as T04's dispatch_fulfillment /
    T01's issue_resolution. A cache hit on idempotency_key must return the
    original result untouched, regardless of what force_lost_response or the
    live status now says."""
    if idempotency_key in _server_side_followups:
        return {"followup_id": _server_side_followups[idempotency_key], "status": "SUCCESS"}

    if force_lost_response:
        followup_id = f"FU-{loan_number}-{random.randint(1000,9999)}"
        _server_side_followups[idempotency_key] = followup_id
        raise TransientFollowupError("Response lost in transit (server-side action actually succeeded).")

    followup_id = f"FU-{loan_number}-{random.randint(1000,9999)}"
    _server_side_followups[idempotency_key] = followup_id
    return {"followup_id": followup_id, "status": "SUCCESS"}
