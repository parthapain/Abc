# Build Brief — Support Ticket Triage & Classification (Extended)

Your organization receives a continuous stream of support tickets — customer-submitted requests describing a problem or question. Build an application that:

1. Ingests support tickets (seed datasets are provided — `support_tickets_seed.csv` and `billing_accounts.csv`)
2. Uses the in-house LLM to classify each one into the categories: **Billing, Technical Issue, Account Access, Feature Request, Complaint**
3. Works as an agent, not a single call: after classifying, check for duplicate or related history on the ticket via a tool, and pull additional context via a second tool if the classification is uncertain — then decide how to proceed
4. **Prioritize support tickets appropriately so urgent ones surface first.**
5. **Route each support ticket to the right team.**
6. For tickets that are low-risk and high-confidence, autonomously acknowledge, auto-close (if a genuine duplicate), or auto-route the ticket — gated by an explicit confidence/policy threshold; anything above that threshold, or anything the tools couldn't resolve, is escalated to a human
7. **Separately, for tickets classified as Billing where the customer describes being overcharged: check the account's billing record via a tool, and if it confirms an overcharge below a small threshold, autonomously issue a courtesy credit via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate. Anything the billing record doesn't confirm, or that exceeds the threshold, is escalated to a human instead of being credited automatically.
8. Provides a UI where a human can review classifications, any automatic actions taken (routing/acknowledgment *and* any credits issued), see the LLM's reasoning, and override them
9. Persists tickets, their classifications, actions taken (including any credits issued), and any human overrides to a database

The dataset includes some tickets that are blank or empty in their body text — your solution should handle these sensibly rather than crashing or producing silently wrong output.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
