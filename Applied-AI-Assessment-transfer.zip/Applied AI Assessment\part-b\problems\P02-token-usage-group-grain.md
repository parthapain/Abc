# P02 — Token usage by model

| Field | Value |
|---|---|
| **ID** | P02 |
| **Difficulty** | Medium |
| **Bug pattern** | `GROUP BY` at the wrong grain |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Paper** | 2 (with P20) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A cost dashboard reports how many tokens each embedding model has consumed. Finance uses it to attribute spend per model.

The report is wrong: **some models appear more than once**, each row showing only part of their usage. Every model should appear exactly once with its full total.

### Required behaviour

Return `(model_name, total_tokens)` — one row per model — counting only requests whose `status` is `'success'`, ordered by `model_name` ascending.

### Schema

```sql
CREATE TABLE embedding_requests (
    id            INTEGER PRIMARY KEY,
    model_name    TEXT NOT NULL,
    request_date  TEXT NOT NULL,   -- 'YYYY-MM-DD'
    token_count   INTEGER NOT NULL,
    status        TEXT NOT NULL    -- 'success' | 'failed'
);
```

---

## Fixture — `P02.sql`

```sql
CREATE TABLE embedding_requests (
    id            INTEGER PRIMARY KEY,
    model_name    TEXT NOT NULL,
    request_date  TEXT NOT NULL,
    token_count   INTEGER NOT NULL,
    status        TEXT NOT NULL
);

INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
    (1, 'ada-002',      '2024-01-01', 100, 'success'),
    (2, 'ada-002',      '2024-01-01', 200, 'success'),
    (3, 'ada-002',      '2024-01-02', 300, 'success'),   -- second date: splits the group
    (4, 'text-3-large', '2024-01-01', 500, 'success'),
    (5, 'ada-002',      '2024-01-02', 999, 'failed');    -- must be excluded
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def usage_by_model(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (model_name, total_tokens) for successful requests only,
    one row per model, ordered by model_name ascending.
    """
    query = """
        SELECT model_name, SUM(token_count) AS total_tokens
        FROM embedding_requests
        WHERE status = 'success'
        GROUP BY model_name, request_date
        ORDER BY model_name
    """
    conn = _connect(db_path)
    try:
        return [(name, total) for name, total in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class UsageReport {

    // --- boilerplate: do not modify ---
    public static class ModelUsage {
        public final String modelName;
        public final int totalTokens;

        public ModelUsage(String modelName, int totalTokens) {
            this.modelName = modelName;
            this.totalTokens = totalTokens;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (modelName, totalTokens) for successful requests only,
     * one row per model, ordered by modelName ascending.
     */
    public static List<ModelUsage> usageByModel(String dbPath) throws SQLException {
        String query =
            "SELECT model_name, SUM(token_count) AS total_tokens " +
            "FROM embedding_requests " +
            "WHERE status = 'success' " +
            "GROUP BY model_name, request_date " +
            "ORDER BY model_name";

        List<ModelUsage> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new ModelUsage(
                    rs.getString("model_name"),
                    rs.getInt("total_tokens")
                ));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record ModelUsage(string ModelName, int TotalTokens);

public static class UsageReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (ModelName, TotalTokens) for successful requests only,
    /// one row per model, ordered by ModelName ascending.
    /// </summary>
    public static List<ModelUsage> UsageByModel(string dbPath)
    {
        const string query = @"
            SELECT model_name AS ModelName, SUM(token_count) AS TotalTokens
            FROM embedding_requests
            WHERE status = 'success'
            GROUP BY model_name, request_date
            ORDER BY model_name";

        using var conn = Connect(dbPath);
        return conn.Query<ModelUsage>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `P02.sql` above | `[("ada-002", 600), ("text-3-large", 500)]` | **Discriminator** — broken returns 3 rows, splitting `ada-002` into two |
| T2 | Each model active on exactly one date | `[("ada-002", 300), ("text-3-large", 500)]` | Guard — no split possible, both versions agree |
| T3 | One model across three dates | `[("ada-002", 300)]` | **Discriminator** — broken returns 3 rows |
| T4 | One success (100) and one failure (900), same model and date | `[("ada-002", 100)]` | Guard — catches removal of the status filter |
| T5 | Empty table | `[]` | Guard — no crash on empty input |

### Fixture for T2

```sql
INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
    (1, 'ada-002',      '2024-01-01', 100, 'success'),
    (2, 'ada-002',      '2024-01-01', 200, 'success'),
    (3, 'text-3-large', '2024-01-01', 500, 'success');
```

### Fixture for T3

```sql
INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
    (1, 'ada-002', '2024-01-01', 100, 'success'),
    (2, 'ada-002', '2024-01-02', 100, 'success'),
    (3, 'ada-002', '2024-01-03', 100, 'success');
```

### Fixture for T4

```sql
INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
    (1, 'ada-002', '2024-01-01', 100, 'success'),
    (2, 'ada-002', '2024-01-01', 900, 'failed');
```

---

## Reference solution

**One change, identical in all three languages:** remove `request_date` from the `GROUP BY`.

```diff
  WHERE status = 'success'
- GROUP BY model_name, request_date
+ GROUP BY model_name
  ORDER BY model_name
```

### Why

`GROUP BY model_name, request_date` produces one row per *(model, date)* pair. A model used on three days yields three rows, each summing only that day's tokens. The requirement is one row per model, so `request_date` does not belong in the grouping at all.

The symptom is easy to misread as a duplicate-rows problem and "fixed" with `DISTINCT`, which removes nothing here — the rows differ in their totals — or by de-duplicating in host code, which discards real usage. The grain of the aggregate is the actual defect.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Adding `DISTINCT` to the select list | T1, T3 — rows are not identical, so nothing is removed |
| De-duplicating by model in host code, keeping the first row | T1 — reports 300 instead of 600 |
| Dropping the `WHERE status = 'success'` filter | T4 — reports 1000 instead of 100 |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is on the intended assertion (row count and totals), not a crash
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
