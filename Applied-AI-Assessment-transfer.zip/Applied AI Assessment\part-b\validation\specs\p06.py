"""P06 — Documents needing review. Medium · SQL-located · AND binds tighter than OR.

Authoring note: this slot originally held a "LIMIT applied before ORDER BY" bug
(a subquery with LIMIT wrapped by an outer ORDER BY). It was discarded because
SQLite's query flattener removes the subquery and pushes the ORDER BY down, so
the supposedly broken query returned the correct answer and the bug could not be
reproduced at all. Operator precedence is a semantic property, so no optimiser
can rescue it.
"""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "AND/OR precedence without parentheses"}

SCHEMA = """
CREATE TABLE documents (
    id     INTEGER PRIMARY KEY,
    title  TEXT NOT NULL,
    status TEXT NOT NULL,   -- 'draft' | 'review' | 'published' | 'archived'
    team   TEXT NOT NULL
);
"""

_BROKEN_SQL = """
    SELECT title
    FROM documents
    WHERE status = 'draft' OR status = 'review' AND team = 'platform'
    ORDER BY title
"""

_FIXED_SQL = """
    SELECT title
    FROM documents
    WHERE (status = 'draft' OR status = 'review') AND team = 'platform'
    ORDER BY title
"""


def broken(conn):
    return [r[0] for r in conn.execute(_BROKEN_SQL).fetchall()]


def fixed(conn):
    return [r[0] for r in conn.execute(_FIXED_SQL).fetchall()]


WRONG_FIXES = {
    # Parenthesises the wrong pair: reproduces the original precedence exactly.
    "brackets the AND instead of the OR": lambda conn: [
        r[0]
        for r in conn.execute(
            """
            SELECT title FROM documents
            WHERE status = 'draft' OR (status = 'review' AND team = 'platform')
            ORDER BY title
            """
        ).fetchall()
    ],
    "uses IN but drops the team filter": lambda conn: [
        r[0]
        for r in conn.execute(
            """
            SELECT title FROM documents
            WHERE status IN ('draft','review')
            ORDER BY title
            """
        ).fetchall()
    ],
}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, status, team) VALUES
                (1,'A','draft',   'platform'),
                (2,'B','review',  'platform'),
                (3,'C','draft',   'research');
        """,
        "expected": ["A", "B"],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, status, team) VALUES
                (1,'A','draft',    'platform'),
                (2,'B','review',   'platform'),
                (3,'C','archived', 'platform');
        """,
        "expected": ["A", "B"],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, status, team) VALUES
                (1,'X','draft','research');
        """,
        "expected": [],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, status, team) VALUES
                (1,'A','review','platform'),
                (2,'B','review','research');
        """,
        "expected": ["A"],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
