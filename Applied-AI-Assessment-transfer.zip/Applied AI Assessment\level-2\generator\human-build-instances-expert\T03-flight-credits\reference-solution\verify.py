import pandas as pd

import booking_tools
import db_models
import orchestrator

checks_passed = 0
checks_failed = 0


def check(label, condition):
    global checks_passed, checks_failed
    if condition:
        checks_passed += 1
        print(f"[PASS] {label}")
    else:
        checks_failed += 1
        print(f"[FAIL] {label}")


db_models.reset_db()
requests_df = pd.read_csv("flight_requests.csv")
results = {}
for _, row in requests_df.iterrows():
    status, logs = orchestrator.process_request(row)
    results[row["request_id"]] = {"status": status, "logs": logs}

# --- Plain control ---
check("FR-8001 (plain control) executes normally", results["FR-8001"]["status"] == "EXECUTED")

# --- Ambiguity 2 / "clearly supported" divergence pair (Addendum 24) ---
check("FR-8002 (plausible-sounding claim, record shows voluntary cancellation) escalates, not auto-resolved",
      results["FR-8002"]["status"] == "ESCALATED_NOT_ELIGIBLE")
check("FR-8003 (differently-worded but genuinely eligible) still executes -- not over-escalated on wording alone",
      results["FR-8003"]["status"] == "EXECUTED")

# --- Ambiguity 1 / value-threshold divergence pair (Addendum 24) ---
check("FR-8004 (Elite, $1200) escalates on value", results["FR-8004"]["status"] == "ESCALATED_VALUE")
check("FR-8005 (Standard, $1180) escalates on value -- same outcome class as FR-8004 regardless of tier",
      results["FR-8005"]["status"] == "ESCALATED_VALUE")

# --- Expert element 1 & 2: ownership redirect + coupling to the guardrail ---
check("FR-8006 (booking belongs to a different customer) escalates on ownership mismatch, not executed",
      results["FR-8006"]["status"] == "ESCALATED_OWNERSHIP_MISMATCH")

# --- Base template trap: untrusted amount in customer text ---
check("FR-8007 (customer claims $650, record supports $200) does not execute with either figure",
      results["FR-8007"]["status"] == "ESCALATED_AMOUNT_MISMATCH")

# --- Expert element 4: adversarial tool response ---
check("FR-8008 (credit_eligible=True paired with a negative credit_value) is not trusted at face value",
      results["FR-8008"]["status"] == "ESCALATED_INVALID_RECORD")

# --- Base template stress point: booking reference not found ---
check("FR-8009 (booking ref not in the dataset) escalates cleanly, does not crash or guess",
      results["FR-8009"]["status"] == "ESCALATED_NOT_FOUND")

# --- Replacement routing ---
check("FR-8010/8011/8012 all route to the replacement guardrail, not a refund",
      all(results[r]["status"] == "ROUTED_TO_REPLACEMENT" for r in ("FR-8010", "FR-8011", "FR-8012")))

# --- Addendum 31: the two guardrails are independent (FR-8013) -----------
check("FR-8013 ($1500, would fail the refund guardrail's value threshold) still routes to replacement -- not wrongly gated by the refund guardrail's value ceiling",
      results["FR-8013"]["status"] == "ROUTED_TO_REPLACEMENT")

# --- Expert elements 3 & 5: retry-safety and the stale-history collision ---
# Run this BEFORE the "3 directions" check below, since it manually exercises
# FR-8010's idempotency key directly -- doing it first keeps this test's
# forced-failure/cache-hit sequence uncontaminated by an earlier real call.
request_id = "FR-8010"
customer = "Miriam Osei"
key = orchestrator.make_idempotency_key(request_id)

try:
    booking_tools.schedule_replacement(request_id, key, force_lost_response=True)
    raised_on_first_call = False
except booking_tools.TransientReplacementError:
    raised_on_first_call = True
check("First replacement attempt for FR-8010 raises a transient error (simulating a lost response)", raised_on_first_call)

first_retry = booking_tools.schedule_replacement(request_id, key)
check("Retry after the lost response still resolves to SUCCESS via the idempotency cache", first_retry["status"] == "SUCCESS")

is_new_1 = db_models.record_replacement(request_id, key, first_retry["replacement_id"])
check("Exactly one replacement record created after the forced lost-response retry", is_new_1 is True)

second_retry = booking_tools.schedule_replacement(request_id, key)
is_new_2 = db_models.record_replacement(request_id, key, second_retry["replacement_id"])
check("A second manual retry with the same idempotency key returns the identical cached result, not a new one",
      second_retry["replacement_id"] == first_retry["replacement_id"] and is_new_2 is False)

booking_tools.set_live_history(customer, 5)
third_retry = booking_tools.schedule_replacement(request_id, key)
check("Idempotency-cache-hit retry ignores the now-changed (over-cap) history and returns the original cached result, untouched",
      third_retry["replacement_id"] == first_retry["replacement_id"])

# --- Second guardrail: history-gated replacement, tested in 3 directions ---
# Restore Miriam's history to its original seed value -- the collision test above
# deliberately mutated it to simulate a live change, and that mutation must not
# leak into this independent check.
booking_tools.set_live_history(customer, 1)
status10, _ = orchestrator.process_replacement("FR-8010", "Miriam Osei")
check("Miriam Osei (1 recent rebooking, under the cap) gets scheduled", status10 == "REPLACEMENT_SCHEDULED")

status11, _ = orchestrator.process_replacement("FR-8011", "Declan Farrow")
check("Declan Farrow (3 recent rebookings, over the cap) does NOT get scheduled, even though this request alone looks fine",
      status11 == "SKIPPED_OVER_CAP")

status12, _ = orchestrator.process_replacement("FR-8012", "Halden Voss")
check("Halden Voss (no history on file) does NOT get scheduled -- not assumed clear", status12 == "SKIPPED_NO_HISTORY")

status13, _ = orchestrator.process_replacement("FR-8013", "Priya Doshi")
check("Priya Doshi (0 recent rebookings, high-value booking that would've failed the refund guardrail) gets scheduled on her own merits",
      status13 == "REPLACEMENT_SCHEDULED")

print(f"\n{checks_passed}/{checks_passed + checks_failed} checks passed")
