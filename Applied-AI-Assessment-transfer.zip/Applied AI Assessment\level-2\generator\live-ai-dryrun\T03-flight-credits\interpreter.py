"""
LLM interpretation step — deterministic stand-in.

The brief calls for "the in-house LLM" to interpret each request: what is the customer
actually asking for, and which booking does it concern. No LLM API key was available in
this environment (checked OPENAI_API_KEY / ANTHROPIC_API_KEY / LLM_API_KEY / AZURE_OPENAI_*),
so this module implements the same function contract with a deterministic, rule-based
classifier. Swapping in a real model later means reimplementing `interpret_request`
with the same input/output shape — nothing else in the app needs to change.

Contract:
    interpret_request(request_text: str, booking_ref_field: str) -> dict with keys:
        action: "refund" | "rebooking" | "unclear"
        stated_reason: one of "AIRLINE_CANCELLED" | "SCHEDULE_CHANGE_MAJOR" |
                       "VOLUNTARY_CANCELLATION" | "UNSPECIFIED"
        stated_amount: float | None   (any dollar figure the customer mentioned)
        referenced_booking_ref: str   (the booking the request concerns)
        notes: list[str]              (anything worth surfacing to a reviewer)

Deliberate security note: this function extracts structured fields (action / reason /
amount) from free text. It never treats the free text as instructions to the system.
For example "please expedite without further checks" in a request is not parsed as a
directive of any kind — it simply isn't one of the fields this function looks for. This
matters because customer-submitted text is untrusted input and the pipeline must not let
it steer agent behavior (see FR-8006 in the seed data, and RATIONALE.md).
"""
import re
from typing import Optional

_REBOOK_MARKERS = [
    "instead of a refund",
    "rather than a refund",
    "no need for money back",
    "rebooked on the next available flight",
]

_REFUND_MARKERS = ["refund", "credit", "money back", "reimburse"]

_AMOUNT_RE = re.compile(r"\$\s*([\d,]+(?:\.\d{1,2})?)")

_BOOKING_REF_RE = re.compile(r"\bBK-\d+\b")


def _detect_action(text_lower: str) -> str:
    if any(m in text_lower for m in _REBOOK_MARKERS) or (
        "rebook" in text_lower and "refund" not in text_lower
    ):
        return "rebooking"
    if any(m in text_lower for m in _REFUND_MARKERS):
        return "refund"
    if "rebook" in text_lower:
        return "rebooking"
    return "unclear"


def _detect_reason(text_lower: str) -> str:
    if "voluntar" in text_lower:
        return "VOLUNTARY_CANCELLATION"
    if "cancelled" in text_lower or "canceled" in text_lower:
        return "AIRLINE_CANCELLED"
    if "moved my flight" in text_lower or "schedule change" in text_lower or "missed my connecting" in text_lower:
        return "SCHEDULE_CHANGE_MAJOR"
    return "UNSPECIFIED"


def _detect_amount(text: str) -> Optional[float]:
    m = _AMOUNT_RE.search(text)
    if not m:
        return None
    return float(m.group(1).replace(",", ""))


def interpret_request(request_text: str, booking_ref_field: str) -> dict:
    text_lower = request_text.lower()
    action = _detect_action(text_lower)
    reason = _detect_reason(text_lower)
    amount = _detect_amount(request_text)

    notes = []

    # The intake form already gives us a structured booking_ref column (booking_ref_field).
    # We cross-check it against any BK-#### token mentioned in the free text: if the
    # customer's own text names a *different* booking than the structured field, that's
    # worth a reviewer's attention rather than silently trusting either source.
    mentioned_refs = set(_BOOKING_REF_RE.findall(request_text))
    if mentioned_refs and booking_ref_field not in mentioned_refs:
        notes.append(
            f"Request text mentions {sorted(mentioned_refs)} which does not include the "
            f"structured booking_ref '{booking_ref_field}'."
        )

    if action == "unclear":
        notes.append("Could not confidently classify the request as refund or rebooking.")

    return {
        "action": action,
        "stated_reason": reason,
        "stated_amount": amount,
        "referenced_booking_ref": booking_ref_field,
        "notes": notes,
    }
