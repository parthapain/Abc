"""
Flask app: JSON API for the review UI, plus static file serving for the UI itself.

Routes:
  GET  /api/tickets              -> list every ticket with its classification/actions/flags/overrides
  GET  /api/tickets/<id>         -> single ticket, same shape
  POST /api/tickets/<id>/override -> human override (category or status), persisted + logged
  POST /api/ingest               -> (re)run ingestion from the seed CSVs
  GET  /                         -> the review UI (static/index.html)
"""
import os

from flask import Flask, jsonify, request, send_from_directory

from app import database as db
from app import ingest

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")

VALID_CATEGORIES = [
    "Hardware", "Software Access", "Network/VPN",
    "Licensing & Reimbursement", "Security Incident",
]


def create_app():
    app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")

    @app.route("/")
    def index():
        return send_from_directory(STATIC_DIR, "index.html")

    @app.route("/api/tickets", methods=["GET"])
    def list_tickets():
        return jsonify(db.all_tickets_full_view())

    @app.route("/api/tickets/<ticket_id>", methods=["GET"])
    def get_ticket(ticket_id):
        view = db.ticket_full_view(ticket_id)
        if view is None:
            return jsonify({"error": "not found"}), 404
        return jsonify(view)

    @app.route("/api/tickets/<ticket_id>/override", methods=["POST"])
    def override_ticket(ticket_id):
        ticket = db.get_ticket(ticket_id)
        if ticket is None:
            return jsonify({"error": "not found"}), 404

        payload = request.get_json(force=True, silent=True) or {}
        field = payload.get("field")
        new_value = payload.get("new_value")
        note = payload.get("note", "")

        if field not in ("category", "status"):
            return jsonify({"error": "field must be 'category' or 'status'"}), 400
        if not new_value:
            return jsonify({"error": "new_value is required"}), 400

        if field == "category":
            if new_value not in VALID_CATEGORIES:
                return jsonify({"error": f"new_value must be one of {VALID_CATEGORIES}"}), 400
            current = db.latest_classification(ticket_id)
            old_value = current["category"] if current else None
            db.add_override(ticket_id, "category", old_value, new_value, note)
            # Record the human correction as its own classification entry so the
            # "latest classification" reflects the human decision, with the override
            # trail (app/database.py: overrides table) preserving who changed what and why.
            db.add_classification(ticket_id, new_value, 1.0,
                                   f"Human override: {note}" if note else "Human override.",
                                   uncertain=False)
        else:  # status
            old_value = ticket["status"]
            db.update_ticket_status(ticket_id, new_value)
            db.add_override(ticket_id, "status", old_value, new_value, note)

        db.add_action(ticket_id, action_type="human_override", tool_name=None,
                       tool_params={"field": field, "new_value": new_value, "note": note},
                       tool_result=None, actor="human")

        return jsonify(db.ticket_full_view(ticket_id))

    @app.route("/api/ingest", methods=["POST"])
    def run_ingest():
        payload = request.get_json(force=True, silent=True) or {}
        reset = bool(payload.get("reset", False))
        results = ingest.run(reset=reset)
        return jsonify({"processed": results})

    return app


if __name__ == "__main__":
    if not os.path.exists(db.DB_PATH):
        db.init_db(reset=True)
        ingest.run(reset=False)
    application = create_app()
    application.run(host="127.0.0.1", port=5050, debug=True)
