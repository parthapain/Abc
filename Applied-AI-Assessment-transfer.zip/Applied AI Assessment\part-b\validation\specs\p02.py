"""P02 — Token usage by model. Medium · SQL-located · GROUP BY at the wrong grain."""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "GROUP BY at wrong grain"}

SCHEMA = """
CREATE TABLE embedding_requests (
    id            INTEGER PRIMARY KEY,
    model_name    TEXT NOT NULL,
    request_date  TEXT NOT NULL,
    token_count   INTEGER NOT NULL,
    status        TEXT NOT NULL
);
"""

_BROKEN_SQL = """
    SELECT model_name, SUM(token_count) AS total_tokens
    FROM embedding_requests
    WHERE status = 'success'
    GROUP BY model_name, request_date
    ORDER BY model_name
"""

_FIXED_SQL = _BROKEN_SQL.replace(
    "GROUP BY model_name, request_date", "GROUP BY model_name"
)


def broken(conn):
    return [tuple(r) for r in conn.execute(_BROKEN_SQL).fetchall()]


def fixed(conn):
    return [tuple(r) for r in conn.execute(_FIXED_SQL).fetchall()]


WRONG_FIXES = {
    "dropped the status filter": lambda conn: [
        tuple(r)
        for r in conn.execute(
            _FIXED_SQL.replace("WHERE status = 'success'", "")
        ).fetchall()
    ],
}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
                (1, 'ada-002',      '2024-01-01', 100, 'success'),
                (2, 'ada-002',      '2024-01-01', 200, 'success'),
                (3, 'ada-002',      '2024-01-02', 300, 'success'),
                (4, 'text-3-large', '2024-01-01', 500, 'success'),
                (5, 'ada-002',      '2024-01-02', 999, 'failed');
        """,
        "expected": [("ada-002", 600), ("text-3-large", 500)],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
                (1, 'ada-002',      '2024-01-01', 100, 'success'),
                (2, 'ada-002',      '2024-01-01', 200, 'success'),
                (3, 'text-3-large', '2024-01-01', 500, 'success');
        """,
        "expected": [("ada-002", 300), ("text-3-large", 500)],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
                (1, 'ada-002', '2024-01-01', 100, 'success'),
                (2, 'ada-002', '2024-01-02', 100, 'success'),
                (3, 'ada-002', '2024-01-03', 100, 'success');
        """,
        "expected": [("ada-002", 300)],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO embedding_requests (id, model_name, request_date, token_count, status) VALUES
                (1, 'ada-002', '2024-01-01', 100, 'success'),
                (2, 'ada-002', '2024-01-01', 900, 'failed');
        """,
        "expected": [("ada-002", 100)],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
