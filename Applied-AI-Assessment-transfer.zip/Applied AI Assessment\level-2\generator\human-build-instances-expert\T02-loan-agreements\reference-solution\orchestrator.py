import glob
import hashlib
import os
import re
from datetime import date

import db_models
from extraction_tools import (
    lookup_related_document, verify_against_source, check_current_status,
    generate_followup, TransientFollowupError, PermanentFollowupError,
)

LOAN_DOCS_DIR = "loan_documents"

# Ambiguity #1 ("extract the borrower_name field") -- deliberate resolution,
# isolated behind a single flag so it's a one-line change if this assumption
# is wrong. When the name stated in the agreement's opening recitals disagrees
# with the name in its own signature block, this solution trusts whichever
# name was stated FIRST (the agreement's own defining reference), not
# whichever was stated most recently. Either is defensible -- see README.md
# "Key decisions".
USE_FIRST_DEFINED_BORROWER_NAME = True


def make_idempotency_key(loan_number):
    return hashlib.sha256(f"{loan_number}|followup".encode()).hexdigest()


def _split_into_sub_documents(raw_text):
    """A seed file may contain more than one loan agreement concatenated
    together. Split on repeated 'COMMERCIAL LOAN AGREEMENT' headers rather
    than assuming one document per file."""
    parts = re.split(r"(?=COMMERCIAL LOAN AGREEMENT)", raw_text)
    return [p.strip() for p in parts if p.strip()]


def load_primary_documents():
    """Loads every primary loan agreement (not promissory-note reference
    documents, which are only ever reached via lookup_related_document)."""
    docs = {}
    for path in sorted(glob.glob(os.path.join(LOAN_DOCS_DIR, "*.txt"))):
        text = open(path, encoding="utf-8").read()
        if "COMMERCIAL LOAN AGREEMENT" not in text:
            continue  # a reference-only document (a promissory note), not a primary filing
        for sub_doc in _split_into_sub_documents(text):
            m = re.search(r"Loan Number:\s*(LN-\d+)", sub_doc)
            if m:
                docs[m.group(1)] = sub_doc
    return docs


def _extract_borrower(raw_text):
    recital_match = re.search(r"Borrower:\s*(.+)", raw_text)
    signed_match = re.search(r"Signed:\s*([^,]+),", raw_text)
    recital_name = recital_match.group(1).strip() if recital_match else None
    signed_name = signed_match.group(1).strip() if signed_match else None
    return recital_name, signed_name


def _extract_principal(raw_text):
    m = re.search(r"principal amount of this Loan is \$([\d,]+\.\d{2})", raw_text)
    return float(m.group(1).replace(",", "")) if m else None


def _extract_interest_rate(raw_text):
    m = re.search(r"fixed rate of ([\d.]+)% per annum", raw_text)
    return float(m.group(1)) if m else None


def _add_months(d, months):
    month = d.month - 1 + months
    year = d.year + month // 12
    month = month % 12 + 1
    return date(year, month, d.day)


def _resolve_maturity(loan_number, borrower_name, raw_text, logs):
    """Returns (maturity_date_str_or_None, status) where status is one of
    RESOLVED_LOCAL / RESOLVED_LOOKUP / AMBIGUOUS / UNRESOLVED."""
    local_match = re.search(
        r"Maturity Date of this Loan shall be the date [a-z\-]*\s*\((\d+)\)\s*months after the Closing Date",
        raw_text,
    )
    if local_match:
        closing_match = re.search(r"Closing Date of this Agreement is (\d{4}-\d{2}-\d{2})", raw_text)
        if closing_match:
            months = int(local_match.group(1))
            closing = date.fromisoformat(closing_match.group(1))
            maturity = _add_months(closing, months)
            logs.append(
                f"Maturity date resolves locally: {months} months after the Closing Date "
                f"({closing.isoformat()}) stated in this same document -- no external lookup needed."
            )
            return maturity.isoformat(), "RESOLVED_LOCAL"

    if "as set forth in the Promissory Note" in raw_text:
        logs.append("Maturity date references an external Promissory Note -- looking it up, not guessing.")
        result = lookup_related_document(borrower_name)
        if result["status"] == "RESOLVED":
            logs.append(f"Found exactly one Promissory Note on file for {borrower_name} ({result['source']}).")
            return result["maturity_date"], "RESOLVED_LOOKUP"
        if result["status"] == "AMBIGUOUS":
            logs.append(
                f"AMBIGUOUS: more than one Promissory Note on file for {borrower_name} "
                f"({', '.join(result['candidates'])}), and this agreement doesn't specify which -- "
                f"escalating for a person to determine which note governs, not guessing."
            )
            return None, "AMBIGUOUS"
        logs.append(f"No Promissory Note on file for {borrower_name} -- cannot resolve, escalating.")
        return None, "UNRESOLVED"

    return None, "UNRESOLVED"


def process_document(loan_number, raw_text):
    logs = [f"Started processing {loan_number}"]

    recital_name, signed_name = _extract_borrower(raw_text)
    borrower_name = recital_name
    if signed_name and recital_name and signed_name != recital_name:
        logs.append(
            f"Borrower name is stated inconsistently: '{recital_name}' in the recitals vs. "
            f"'{signed_name}' in the signature block. Policy: use the name as first defined "
            f"in the agreement's own recitals, not the most recently stated form."
        )
        if not USE_FIRST_DEFINED_BORROWER_NAME:
            borrower_name = signed_name

    principal = _extract_principal(raw_text)
    interest_rate = _extract_interest_rate(raw_text)
    if interest_rate is None:
        logs.append("interest_rate is not present in the source text -- reporting absent, not inventing a default value.")

    maturity_date, maturity_status = _resolve_maturity(loan_number, borrower_name, raw_text, logs)

    principal_str = f"{principal:,.2f}" if principal is not None else None
    principal_check = verify_against_source(loan_number, "principal_amount", principal_str, raw_text)
    rate_check = verify_against_source(loan_number, "interest_rate", interest_rate, raw_text)

    if rate_check["grounded"] and not rate_check["matched_text"]:
        logs.append(
            "verify_against_source reports interest_rate as grounded, but returned no actual matched "
            "text to back that up -- the tool's own response is internally inconsistent. Not trusting "
            "it at face value; treating this field as unverified."
        )
        rate_check = {"grounded": False, "confidence": 0.0, "matched_text": ""}

    all_grounded = (
        principal is not None and principal_check["grounded"]
        and interest_rate is not None and rate_check["grounded"]
        and maturity_status in ("RESOLVED_LOCAL", "RESOLVED_LOOKUP")
    )

    if all_grounded:
        final_status = "COMMITTED"
        logs.append("All fields grounded and unambiguous -- committing to the system of record.")
    else:
        final_status = "ESCALATED_REVIEW"
        reasons = []
        if principal is None or not principal_check["grounded"]:
            reasons.append("principal_amount not grounded")
        if interest_rate is None or not rate_check["grounded"]:
            reasons.append("interest_rate missing or not grounded")
        if maturity_status not in ("RESOLVED_LOCAL", "RESOLVED_LOOKUP"):
            reasons.append(f"maturity_date {maturity_status.lower()}")
        logs.append(f"Not committing -- flagged for human review ({'; '.join(reasons)}).")

    db_models.save_loan_record(loan_number, borrower_name, principal, interest_rate, maturity_date, final_status, logs)
    return {
        "loan_number": loan_number, "borrower_name": borrower_name, "principal_amount": principal,
        "interest_rate": interest_rate, "maturity_date": maturity_date, "maturity_status": maturity_status,
        "final_status": final_status, "logs": logs,
    }


def process_followup(loan_number, force_lost_response_for_loan=None):
    logs = [f"Evaluating follow-up for {loan_number}"]
    status, valid = check_current_status(loan_number)

    if status is None:
        logs.append(f"No verified status on file for {loan_number} -- not assuming active, skipping follow-up.")
        return "SKIPPED_NO_STATUS", logs
    if not valid:
        logs.append(f"Status registry response for {loan_number} is invalid (status={status}) -- not trusting it, skipping.")
        return "SKIPPED_INVALID_STATUS", logs
    if status != "active":
        logs.append(f"Verified status is '{status}' -- loan no longer warrants a follow-up, skipping.")
        return "SKIPPED_NOT_ACTIVE", logs

    logs.append("Verified status is 'active' -- attempting follow-up generation.")
    idempotency_key = make_idempotency_key(loan_number)
    force_lost_response = (loan_number == force_lost_response_for_loan)

    final_status = "PENDING"
    for attempt in range(3):
        try:
            result = generate_followup(loan_number, idempotency_key, force_lost_response=(force_lost_response and attempt == 0))
            is_new = db_models.record_followup(loan_number, idempotency_key, result["followup_id"])
            logs.append(
                f"Follow-up call succeeded (followup_id={result['followup_id']}); "
                f"{'new follow-up record created' if is_new else 'already recorded -- retry correctly did not duplicate'}."
            )
            final_status = "FOLLOWUP_GENERATED"
            break
        except TransientFollowupError as e:
            logs.append(f"Transient failure on attempt {attempt + 1}: {e}")
        except PermanentFollowupError as e:
            logs.append(f"Permanent failure: {e}")
            final_status = "SKIPPED_PERMANENT_FAILURE"
            break

    if final_status == "PENDING":
        logs.append("Max retries reached without success -- escalating to a human.")
        final_status = "ESCALATED_NETWORK"

    return final_status, logs
