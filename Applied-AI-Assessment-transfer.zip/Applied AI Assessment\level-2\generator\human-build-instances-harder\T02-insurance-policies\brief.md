# Build Brief — Insurance Policy Document Extraction (Extended)

Your organization needs to extract structured information from insurance policy documents — policy documents describing coverage terms. Build an application that:

1. Ingests insurance policy documents (seed datasets are provided — `policy_documents/` and `renewal_status.csv`)
2. Uses the in-house LLM to extract these fields into a structured record: **policy_number, policyholder_name, coverage_start_date, coverage_end_date, premium_amount**
3. Works as an agent, not a single call: cross-check extracted values against the source document via a tool, and look up a related document via a second tool when a field's value references another document — then decide how to proceed
4. **Extract the coverage_end_date field.**
5. **Extract the policyholder_name field.**
6. For extractions that are fully grounded and high-confidence, autonomously commit the record to the system of record — gated by an explicit completeness/confidence check; anything incomplete, contradictory, or below that threshold is flagged for human review instead
7. **Separately, for policies confirmed to be within 30 days of their coverage_end_date: look up the policy's current renewal/cancellation status via a tool, and if it's still active (not already renewed or cancelled), autonomously generate a renewal-reminder record via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate.
8. Provides a UI where a human can review extracted fields against the source document, correct them, and see any autonomous commits *and* any renewal reminders already generated
9. Persists documents, extracted fields, commit/review status, renewal-reminder actions, and any corrections to a database

Some documents in the seed dataset contain more than one policy document concatenated together in the same file — your solution should handle these sensibly rather than crashing or inventing information that isn't there.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
