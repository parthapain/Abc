# P18 — Active tag counts

| Field | Value |
|---|---|
| **ID** | P18 |
| **Difficulty** | High |
| **Bug pattern** | Outer join downgraded by a `WHERE` clause |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A tagging overview shows every document alongside how many **active** tags it carries. Documents with no active tags should show `0` — those are the ones the content team needs to find.

Instead, documents with no active tags are missing from the report entirely. Only documents that already have active tags appear, which makes the report useless for its actual purpose.

### Required behaviour

Return `(title, active_tags)` for **every** document, ordered by `title` ascending.

`active_tags` counts only tags whose `status` is `'active'`. A document with no tags, or with only retired tags, must still appear with a count of `0`.

### Schema

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE tags (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    label       TEXT NOT NULL,
    status      TEXT NOT NULL   -- 'active' | 'retired'
);
```

---

## Fixture — `P18.sql`

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE tags (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES documents(id),
    label       TEXT NOT NULL,
    status      TEXT NOT NULL
);

INSERT INTO documents (id, title) VALUES
    (1,'Has Active'),
    (2,'Retired Only'),
    (3,'No Tags');

INSERT INTO tags (id, document_id, label, status) VALUES
    (1,1,'a','active'),
    (2,1,'b','active'),
    (3,2,'c','retired');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def active_tag_counts(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (title, active_tags) for EVERY document, ordered by title ascending.
    Documents with no active tags must appear with a count of 0.
    """
    query = """
        SELECT d.title, COUNT(t.id) AS active_tags
        FROM documents d
        LEFT JOIN tags t ON t.document_id = d.id
        WHERE t.status = 'active'
        GROUP BY d.id, d.title
        ORDER BY d.title
    """
    conn = _connect(db_path)
    try:
        return [(title, count) for title, count in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class TagOverview {

    // --- boilerplate: do not modify ---
    public static class TagCount {
        public final String title;
        public final int activeTags;

        public TagCount(String title, int activeTags) {
            this.title = title;
            this.activeTags = activeTags;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (title, activeTags) for EVERY document, ordered by title ascending.
     * Documents with no active tags must appear with a count of 0.
     */
    public static List<TagCount> activeTagCounts(String dbPath) throws SQLException {
        String query =
            "SELECT d.title, COUNT(t.id) AS active_tags " +
            "FROM documents d " +
            "LEFT JOIN tags t ON t.document_id = d.id " +
            "WHERE t.status = 'active' " +
            "GROUP BY d.id, d.title " +
            "ORDER BY d.title";

        List<TagCount> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new TagCount(rs.getString("title"), rs.getInt("active_tags")));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record TagCount(string Title, int ActiveTags);

public static class TagOverview
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Title, ActiveTags) for EVERY document, ordered by title ascending.
    /// Documents with no active tags must appear with a count of 0.
    /// </summary>
    public static List<TagCount> ActiveTagCounts(string dbPath)
    {
        const string query = @"
            SELECT d.title AS Title, COUNT(t.id) AS ActiveTags
            FROM documents d
            LEFT JOIN tags t ON t.document_id = d.id
            WHERE t.status = 'active'
            GROUP BY d.id, d.title
            ORDER BY d.title";

        using var conn = Connect(dbPath);
        return conn.Query<TagCount>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | One doc with 2 active tags, one with only a retired tag, one with no tags | `[("Has Active",2), ("No Tags",0), ("Retired Only",0)]` | **Discriminator** — broken returns only `Has Active` |
| T2 | Two documents, each with one active tag | `[("Alpha",1), ("Beta",1)]` | Guard — every document survives the filter anyway |
| T3 | One document, no tags at all | `[("Untagged",0)]` | **Discriminator** — broken returns `[]` |
| T4 | One document with three active tags | `[("Busy",3)]` | Guard |
| T5 | Empty tables | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO documents (id, title) VALUES (1,'Alpha'),(2,'Beta');
INSERT INTO tags (id, document_id, label, status) VALUES (1,1,'a','active'),(2,2,'b','active');
-- T3
INSERT INTO documents (id, title) VALUES (1,'Untagged');
-- T4
INSERT INTO documents (id, title) VALUES (1,'Busy');
INSERT INTO tags (id, document_id, label, status) VALUES
    (1,1,'a','active'),(2,1,'b','active'),(3,1,'c','active');
```

---

## Reference solution

Move the status condition from `WHERE` into the join's `ON` clause.

```diff
  FROM documents d
- LEFT JOIN tags t ON t.document_id = d.id
- WHERE t.status = 'active'
+ LEFT JOIN tags t ON t.document_id = d.id AND t.status = 'active'
  GROUP BY d.id, d.title
```

### Why

`LEFT JOIN` supplies a row of `NULL`s for documents with no matching tag — that is how they survive into the result. The `WHERE` clause then runs **after** the join and evaluates `NULL = 'active'`, which is `UNKNOWN`, so those rows are discarded. The outer join is silently downgraded to an inner join.

The distinction is about *when* each condition applies:

- A condition in **`ON`** decides which rows of the right table are eligible to match. Non-matching documents still appear, with `NULL`s.
- A condition in **`WHERE`** filters the joined result. Any test against a right-table column eliminates the very rows the outer join was there to preserve.

`COUNT(t.id)` is already correct — it ignores `NULL`, so unmatched documents naturally count `0` once they are allowed through.

T2 shows why this survives review: when every document has at least one active tag, no row is ever `NULL` and both queries agree exactly.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `WHERE t.status = 'active' OR t.status IS NULL` | T1 — `Retired Only` reappears, but so does anything else the join produced |
| Changing `COUNT(t.id)` to `COUNT(*)` while leaving the `WHERE` | T1, T3 — documents are still missing, and `COUNT(*)` would report 1 instead of 0 |
| Removing the status condition entirely | T1 — `Retired Only` reports 1 instead of 0 |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing documents, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Confirm `COUNT(t.id)` is used rather than `COUNT(*)` — with `COUNT(*)` the fix would need two changes and the problem becomes ambiguous
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
