"""
Use-case instance generator.

Takes template definitions (fixed scenario shape + parameter pools) and produces
per-candidate instance briefs, spreading parameter combinations so no two
instances look identical and no single pool value is overrepresented.

IMPORTANT: a template must pass calibration (see templates/*.md — the
"Calibration" section) before instances generated from it are used with real
candidates. This script does not check that for you; it only generates content.
Nothing here should be treated as launch-ready until each template's
calibration step is confirmed done.

Usage:
    python generate_instances.py --count 300 --out instances/
    python generate_instances.py --count 10 --templates T01 --out /tmp/preview
"""

from __future__ import annotations

import argparse
import itertools
import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from string import Template as _StrTemplate


@dataclass
class UseCaseTemplate:
    template_id: str
    calibrated: bool  # must be True before this template is used for real generation
    brief_markdown: str  # candidate-facing brief with $placeholder tokens
    domain_flavors: list[dict]  # each dict supplies all domain-specific placeholders
    ambiguity_variants: list[str]
    trap_variants: list[str]
    stress_variants: list[str]
    dataset_seed_count: int = 3  # distinct dataset seeds to rotate through

    def all_combinations(self):
        """Every (flavor, ambiguity, trap, stress, seed) combination, for sizing."""
        return itertools.product(
            range(len(self.domain_flavors)),
            range(len(self.ambiguity_variants)),
            range(len(self.trap_variants)),
            range(len(self.stress_variants)),
            range(self.dataset_seed_count),
        )


@dataclass
class GeneratedInstance:
    instance_id: str
    template_id: str
    brief_text: str
    # internal-only — never shown to the candidate
    meta: dict = field(default_factory=dict)


def render_brief(tmpl: UseCaseTemplate, flavor: dict, ambiguity: str, trap_idx: int,
                  stress_idx: int, dataset_file: str) -> str:
    context = dict(flavor)
    # Variant strings (ambiguity/stress) may themselves contain $placeholders
    # referencing the domain flavor (e.g. "Prioritize $item_noun...") — render
    # them against the flavor context FIRST, then insert the resolved text into
    # the outer template. A single outer substitute() would leave those nested
    # placeholders as literal "$item_noun" in the final brief.
    context["ambiguity_requirement"] = _StrTemplate(ambiguity).safe_substitute(context)
    context["stress_point_description"] = _StrTemplate(
        _stress_point_text(tmpl, stress_idx)
    ).safe_substitute(context)
    context["dataset_file"] = dataset_file
    return _StrTemplate(tmpl.brief_markdown).safe_substitute(context)


def _stress_point_text(tmpl: UseCaseTemplate, idx: int) -> str:
    return tmpl.stress_variants[idx]


def generate(tmpl: UseCaseTemplate, n: int, rng: random.Random) -> list[GeneratedInstance]:
    if not tmpl.calibrated:
        raise ValueError(
            f"Template {tmpl.template_id} is not marked calibrated. "
            f"Do not generate real instances until calibration is confirmed "
            f"(see templates/{tmpl.template_id}-*.md)."
        )

    combos = list(tmpl.all_combinations())
    if n > len(combos):
        raise ValueError(
            f"Requested {n} instances from {tmpl.template_id}, but only "
            f"{len(combos)} distinct parameter combinations exist. "
            f"Widen a pool (more domain flavors, trap variants, etc.) before "
            f"asking for this many from one template."
        )

    rng.shuffle(combos)
    chosen = combos[:n]

    instances = []
    for i, (flavor_i, amb_i, trap_i, stress_i, seed_i) in enumerate(chosen):
        flavor = tmpl.domain_flavors[flavor_i]
        ambiguity = tmpl.ambiguity_variants[amb_i]
        dataset_file = f"{tmpl.template_id.lower()}_seed_{seed_i:02d}.csv"

        instance_id = f"{tmpl.template_id}-{i+1:04d}"
        brief = render_brief(tmpl, flavor, ambiguity, trap_i, stress_i, dataset_file)

        instances.append(GeneratedInstance(
            instance_id=instance_id,
            template_id=tmpl.template_id,
            brief_text=brief,
            meta={
                "domain_flavor": flavor,
                "ambiguity_variant_index": amb_i,
                "trap_variant_index": trap_i,
                "trap_variant_text": tmpl.trap_variants[trap_i],
                "stress_variant_index": stress_i,
                "stress_variant_text": tmpl.stress_variants[stress_i],
                "dataset_file": dataset_file,
            },
        ))
    return instances


def write_instances(instances: list[GeneratedInstance], out_dir: Path) -> None:
    briefs_dir = out_dir / "briefs"
    briefs_dir.mkdir(parents=True, exist_ok=True)

    manifest = []
    for inst in instances:
        brief_path = briefs_dir / f"{inst.instance_id}.md"
        brief_path.write_text(inst.brief_text, encoding="utf-8")
        manifest.append({
            "instance_id": inst.instance_id,
            "template_id": inst.template_id,
            "brief_file": str(brief_path.relative_to(out_dir)),
            **inst.meta,
        })

    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Wrote {len(instances)} briefs to {briefs_dir}")
    print(f"Wrote internal manifest to {manifest_path}  <-- NEVER share this with candidates")


def load_templates() -> dict[str, UseCaseTemplate]:
    """
    Template content lives here as data. All 4 templates (T01-T04) are defined
    in template_definitions.py, kept in one module since 4 is still small enough
    to browse easily — split into one file per template if the bank grows further.
    """
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from template_definitions import TEMPLATES  # noqa: E402
    return TEMPLATES


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, required=True,
                         help="Total instances to generate across selected templates")
    parser.add_argument("--templates", nargs="*", default=None,
                         help="Template IDs to use (default: all calibrated templates)")
    parser.add_argument("--out", type=Path, required=True, help="Output directory")
    parser.add_argument("--seed", type=int, default=None, help="RNG seed for reproducibility")
    parser.add_argument("--allow-uncalibrated", action="store_true",
                         help="DANGEROUS: generate preview content from templates "
                              "that haven't passed calibration. Never use this for "
                              "real candidates — preview/demo only.")
    args = parser.parse_args()

    all_templates = load_templates()
    selected_ids = args.templates or list(all_templates.keys())
    selected = [all_templates[t] for t in selected_ids]

    if args.allow_uncalibrated:
        for t in selected:
            t.calibrated = True  # override, preview mode only
        print("*** --allow-uncalibrated set: this run is PREVIEW ONLY, not for real candidates ***")

    rng = random.Random(args.seed)
    per_template = args.count // len(selected)
    remainder = args.count - per_template * len(selected)

    all_instances = []
    for i, tmpl in enumerate(selected):
        n = per_template + (1 if i < remainder else 0)
        all_instances.extend(generate(tmpl, n, rng))

    write_instances(all_instances, args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
