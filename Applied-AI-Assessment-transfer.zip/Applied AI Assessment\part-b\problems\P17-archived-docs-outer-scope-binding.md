# P17 — Archived documents

| Field | Value |
|---|---|
| **ID** | P17 |
| **Difficulty** | High |
| **Bug pattern** | Subquery column silently bound to the outer table |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 15–19 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A cleanup screen lists documents that have been archived, so they can be purged.

It lists **every** document in the system, archived or not. The one thing that does work: when nothing has been archived at all, the list is correctly empty.

### Required behaviour

Return the `title` of every document that has a corresponding row in `archived_docs`, ordered by `title` ascending.

### Schema

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE archived_docs (
    document_id INTEGER NOT NULL,
    archived_at TEXT NOT NULL
);
```

Note the column names carefully. `archived_docs` has **no column called `id`**.

---

## Fixture — `P17.sql`

```sql
CREATE TABLE documents (
    id    INTEGER PRIMARY KEY,
    title TEXT NOT NULL
);
CREATE TABLE archived_docs (
    document_id INTEGER NOT NULL,
    archived_at TEXT NOT NULL
);

INSERT INTO documents (id, title) VALUES (1,'Alpha'),(2,'Beta'),(3,'Gamma');
INSERT INTO archived_docs (document_id, archived_at) VALUES (2,'2024-01-01');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def archived_documents(db_path: str) -> List[str]:
    """
    Return the title of every document that has a row in archived_docs,
    ordered by title ascending.
    """
    query = """
        SELECT d.title
        FROM documents d
        WHERE d.id IN (SELECT id FROM archived_docs)
        ORDER BY d.title
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class ArchiveReport {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return the title of every document that has a row in archived_docs,
     * ordered by title ascending.
     */
    public static List<String> archivedDocuments(String dbPath) throws SQLException {
        String query =
            "SELECT d.title " +
            "FROM documents d " +
            "WHERE d.id IN (SELECT id FROM archived_docs) " +
            "ORDER BY d.title";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(rs.getString("title"));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class ArchiveReport
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return the title of every document that has a row in archived_docs,
    /// ordered by title ascending.
    /// </summary>
    public static List<string> ArchivedDocuments(string dbPath)
    {
        const string query = @"
            SELECT d.title
            FROM documents d
            WHERE d.id IN (SELECT id FROM archived_docs)
            ORDER BY d.title";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 3 documents, 1 archived | `["Beta"]` | **Discriminator** — broken returns all three |
| T2 | 2 documents, `archived_docs` empty | `[]` | Guard — an empty subquery makes `IN` false regardless |
| T3 | 3 documents, 2 archived | `["Alpha", "Gamma"]` | **Discriminator** — broken returns all three |
| T4 | 2 documents, **both** archived | `["Alpha", "Beta"]` | Guard — "all documents" happens to be the right answer |
| T5 | No documents; one orphaned archive row | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO documents (id, title) VALUES (1,'Alpha'),(2,'Beta');

-- T3
INSERT INTO documents (id, title) VALUES (1,'Alpha'),(2,'Beta'),(3,'Gamma');
INSERT INTO archived_docs (document_id, archived_at) VALUES (1,'2024-01-01'),(3,'2024-01-02');

-- T4
INSERT INTO documents (id, title) VALUES (1,'Alpha'),(2,'Beta');
INSERT INTO archived_docs (document_id, archived_at) VALUES (1,'2024-01-01'),(2,'2024-01-02');

-- T5
INSERT INTO archived_docs (document_id, archived_at) VALUES (99,'2024-01-01');
```

---

## Reference solution

```diff
  FROM documents d
- WHERE d.id IN (SELECT id FROM archived_docs)
+ WHERE d.id IN (SELECT document_id FROM archived_docs)
```

`WHERE EXISTS (SELECT 1 FROM archived_docs a WHERE a.document_id = d.id)` is equally correct.

### Why

`archived_docs` has no column named `id`. Rather than failing, SQL name resolution falls back to the **enclosing** query and binds `id` to `documents.id` — the subquery becomes a correlated reference to the outer row.

For each document, the subquery therefore evaluates to that document's own id, repeated once per row in `archived_docs`. The test becomes `d.id IN (d.id, d.id, …)`, which is true whenever `archived_docs` has any rows at all. Every document qualifies.

This is standard SQL scoping, not a SQLite quirk — PostgreSQL, MySQL and SQL Server all behave the same way. It is one of the few places where a *typo in a column name* produces a silently wrong answer instead of an error, which is what makes it worth testing.

The two guards explain the reported symptom precisely. When `archived_docs` is empty (T2) the `IN` list is empty and nothing matches, so the screen is correctly blank — the one case the user noticed working. When everything is archived (T4) "all documents" is the right answer by coincidence.

**Qualifying table aliases in subqueries prevents this class of bug entirely** — `SELECT a.id FROM archived_docs a` would have failed loudly at parse time.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Renaming the outer alias without fixing the column | T1, T3 — resolution still falls through to the outer scope |
| `JOIN archived_docs ON documents.id = archived_docs.document_id` without `DISTINCT` | Duplicates if a document is archived twice — verify against T3 |
| Filtering in host code after fetching all documents | T1, T3 — the query already returned everything |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is too many rows, not a "no such column" error
- [ ] **Confirm the sandbox engine resolves the unqualified column to the outer scope** rather than erroring — if it errors, the bug becomes a trivial syntax fix and the problem should be reworked
- [ ] `archived_docs` genuinely has no `id` column in the fixture schema
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Both the `document_id` and `EXISTS` fixes are accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
