from app import llm_stub


def test_classifies_hardware():
    result = llm_stub.classify("Laptop won't turn on.")
    assert result.category == "Hardware"
    assert result.confidence > 0


def test_classifies_licensing():
    result = llm_stub.classify("I was charged $15 for a Zoom Pro license renewal, requesting a refund.")
    assert result.category == "Licensing & Reimbursement"


def test_empty_body_is_unclassified_and_uncertain():
    result = llm_stub.classify("")
    assert result.category is None
    assert llm_stub.is_uncertain(result)


def test_no_keyword_match_is_unclassified():
    result = llm_stub.classify("zzz qqq flibbertigibbet")
    assert result.category is None


def test_extra_context_can_shift_classification():
    body = "Can't log into the VPN -- account locked after repeated failed logins, worried someone else tried."
    first = llm_stub.classify(body)
    context = ("Account-security audit log: 5 failed login attempts from an unrecognized "
               "device, consistent with a credential-stuffing attempt.")
    refined = llm_stub.classify(body, extra_context=context)
    # The security-flavored context should push (or keep) the classification toward
    # Security Incident rather than plain Network/VPN.
    assert refined.category == "Security Incident"
