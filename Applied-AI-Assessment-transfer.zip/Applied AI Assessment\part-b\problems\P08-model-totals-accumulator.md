# P08 — Per-model token totals

| Field | Value |
|---|---|
| **ID** | P08 |
| **Difficulty** | Medium |
| **Bug pattern** | Accumulator reset in the wrong scope |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Paper** | 5 (with P14) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A usage log is walked in a single pass to produce per-model token totals. The rows arrive already sorted by model, so the code accumulates until the model name changes, then emits a total and moves on.

The first model in the report is always correct. Every model after it is inflated — and the further down the report, the worse it gets.

### Required behaviour

Return `(model, total_tokens)` — one entry per distinct model, in the order the models appear in the sorted result set.

### Schema

```sql
CREATE TABLE usage_log (
    id      INTEGER PRIMARY KEY,
    model   TEXT NOT NULL,
    tokens  INTEGER NOT NULL
);
```

The query orders by `model, id`, so all rows for a model are contiguous.

---

## Fixture — `P08.sql`

```sql
CREATE TABLE usage_log (
    id      INTEGER PRIMARY KEY,
    model   TEXT NOT NULL,
    tokens  INTEGER NOT NULL
);

INSERT INTO usage_log (id, model, tokens) VALUES
    (1,'ada-002',100),
    (2,'ada-002',200),
    (3,'text-3-large',50);
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def totals_by_model(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (model, total_tokens), one entry per distinct model,
    in the order the models appear in the sorted result set.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute(
            "SELECT model, tokens FROM usage_log ORDER BY model, id"
        ).fetchall()
    finally:
        conn.close()

    totals: List[Tuple[str, int]] = []
    running = 0
    current = None

    for model, tokens in rows:
        if model != current:
            if current is not None:
                totals.append((current, running))
            current = model
        running += tokens

    if current is not None:
        totals.append((current, running))
    return totals
```

### Java

```java
import java.sql.*;
import java.util.*;

public class UsageTotals {

    // --- boilerplate: do not modify ---
    public static class ModelTotal {
        public final String model;
        public final int totalTokens;

        public ModelTotal(String model, int totalTokens) {
            this.model = model;
            this.totalTokens = totalTokens;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (model, totalTokens), one entry per distinct model,
     * in the order the models appear in the sorted result set.
     */
    public static List<ModelTotal> totalsByModel(String dbPath) throws SQLException {
        List<ModelTotal> totals = new ArrayList<>();
        int running = 0;
        String current = null;

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT model, tokens FROM usage_log ORDER BY model, id")) {
            while (rs.next()) {
                String model = rs.getString("model");
                int tokens = rs.getInt("tokens");

                if (!model.equals(current)) {
                    if (current != null) {
                        totals.add(new ModelTotal(current, running));
                    }
                    current = model;
                }
                running += tokens;
            }
        }

        if (current != null) {
            totals.add(new ModelTotal(current, running));
        }
        return totals;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record ModelTotal(string Model, int TotalTokens);

public static class UsageTotals
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Model, TotalTokens), one entry per distinct model,
    /// in the order the models appear in the sorted result set.
    /// </summary>
    public static List<ModelTotal> TotalsByModel(string dbPath)
    {
        List<(string Model, int Tokens)> rows;
        using (var conn = Connect(dbPath))
        {
            rows = conn.Query<(string Model, int Tokens)>(
                "SELECT model, tokens FROM usage_log ORDER BY model, id").ToList();
        }

        var totals = new List<ModelTotal>();
        int running = 0;
        string current = null;

        foreach (var (model, tokens) in rows)
        {
            if (model != current)
            {
                if (current != null)
                {
                    totals.Add(new ModelTotal(current, running));
                }
                current = model;
            }
            running += tokens;
        }

        if (current != null)
        {
            totals.Add(new ModelTotal(current, running));
        }
        return totals;
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `ada-002` 100+200, `text-3-large` 50 | `[("ada-002", 300), ("text-3-large", 50)]` | **Discriminator** — broken reports `text-3-large` as 350 |
| T2 | One model, three rows (100, 200, 300) | `[("ada-002", 600)]` | Guard — nothing to carry over with a single group |
| T3 | Three models, 10 / 20 / 30 | `[("alpha",10), ("beta",20), ("gamma",30)]` | **Discriminator** — broken reports 10 / 30 / 60 |
| T4 | Single row | `[("solo", 42)]` | Guard |
| T5 | Empty table | `[]` | Guard — final flush must not emit a phantom group |

### Fixture for T2

```sql
INSERT INTO usage_log (id, model, tokens) VALUES
    (1,'ada-002',100),(2,'ada-002',200),(3,'ada-002',300);
```

### Fixture for T3

```sql
INSERT INTO usage_log (id, model, tokens) VALUES
    (1,'alpha',10),(2,'beta',20),(3,'gamma',30);
```

### Fixture for T4

```sql
INSERT INTO usage_log (id, model, tokens) VALUES (1,'solo',42);
```

---

## Reference solution

Reset the accumulator when a new group starts.

**Python:**

```diff
  if model != current:
      if current is not None:
          totals.append((current, running))
      current = model
+     running = 0
  running += tokens
```

**Java:**

```diff
  if (!model.equals(current)) {
      if (current != null) {
          totals.add(new ModelTotal(current, running));
      }
      current = model;
+     running = 0;
  }
  running += tokens;
```

**C#:**

```diff
  if (model != current)
  {
      if (current != null)
      {
          totals.Add(new ModelTotal(current, running));
      }
      current = model;
+     running = 0;
  }
  running += tokens;
```

### Why

`running` is declared once, outside the loop, so it is shared across every group. Emitting the previous group's total does not clear it — the next group starts from wherever the last one finished, and each total is the running sum of all models seen so far rather than that model's own usage.

This is why the first model is always right and the error compounds down the report: the totals are effectively a cumulative series.

The boundary handling around it is correct and should be left alone — the `current is not None` check before the first emit, and the final flush after the loop, are both needed. A candidate who "fixes" the symptom by removing the final flush loses the last model entirely, which is a common wrong turn here.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Adding the reset but deleting the post-loop flush | T1, T2, T3, T4 — last model disappears |
| Resetting *after* `running += tokens` instead of before | T1 — every total becomes 0 |
| Moving `running = 0` outside the `if` block | T1 — every total equals only the last row |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is inflated totals, not a crash
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Java: `!model.equals(current)` is null-safe on the first iteration — confirm no NPE
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
