"""P01 — Document chunk counts. Medium · SQL-located · INNER vs LEFT JOIN."""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "INNER JOIN drops unmatched rows"}

SCHEMA = """
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    title   TEXT NOT NULL,
    status  TEXT NOT NULL
);
CREATE TABLE chunks (
    id           INTEGER PRIMARY KEY,
    document_id  INTEGER NOT NULL REFERENCES documents(id),
    chunk_index  INTEGER NOT NULL,
    token_count  INTEGER NOT NULL
);
"""

_BROKEN_SQL = """
    SELECT d.title, COUNT(c.id) AS chunk_count
    FROM documents d
    JOIN chunks c ON c.document_id = d.id
    WHERE d.status = 'processed'
    GROUP BY d.id, d.title
    ORDER BY d.title
"""

_FIXED_SQL = _BROKEN_SQL.replace("JOIN chunks", "LEFT JOIN chunks")


def broken(conn):
    return [tuple(r) for r in conn.execute(_BROKEN_SQL).fetchall()]


def fixed(conn):
    return [tuple(r) for r in conn.execute(_FIXED_SQL).fetchall()]


WRONG_FIXES = {
    "LEFT JOIN but COUNT(*)": lambda conn: [
        tuple(r) for r in conn.execute(_FIXED_SQL.replace("COUNT(c.id)", "COUNT(*)")).fetchall()
    ],
    "dropped the WHERE clause": lambda conn: [
        tuple(r)
        for r in conn.execute(
            _FIXED_SQL.replace("WHERE d.status = 'processed'", "")
        ).fetchall()
    ],
}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, status) VALUES
                (1, 'Annual Report 2024', 'processed'),
                (2, 'Q3 Earnings Call',   'processed'),
                (3, 'Draft Memo',         'processed'),
                (4, 'Archived Notes',     'archived');
            INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
                (1, 1, 0, 512), (2, 1, 1, 480), (3, 2, 0, 300), (4, 4, 0, 200);
        """,
        "expected": [("Annual Report 2024", 2), ("Draft Memo", 0), ("Q3 Earnings Call", 1)],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, status) VALUES
                (1, 'Alpha', 'processed'), (2, 'Beta', 'processed');
            INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
                (1, 1, 0, 100), (2, 2, 0, 100), (3, 2, 1, 100), (4, 2, 2, 100);
        """,
        "expected": [("Alpha", 1), ("Beta", 3)],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, title, status) VALUES
                (1, 'Alpha', 'processed'), (2, 'Beta', 'processed'), (3, 'Gamma', 'processed');
        """,
        "expected": [("Alpha", 0), ("Beta", 0), ("Gamma", 0)],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, title, status) VALUES
                (1, 'Live Doc', 'processed'), (2, 'Archived Doc', 'archived');
            INSERT INTO chunks (id, document_id, chunk_index, token_count) VALUES
                (1, 1, 0, 100), (2, 1, 1, 100),
                (3, 2, 0, 100), (4, 2, 1, 100), (5, 2, 2, 100), (6, 2, 3, 100), (7, 2, 4, 100);
        """,
        "expected": [("Live Doc", 2)],
    },
    "T5": {
        "role": "guard",
        "seed": "",
        "expected": [],
    },
}
