from app import agent, database as db


def _seed(ticket_id, requester, tier, status, submitted_at, body):
    db.upsert_ticket(ticket_id, requester, tier, status, submitted_at, body)
    return db.get_ticket(ticket_id)


def test_hardware_ticket_gets_acknowledged_and_routed(temp_db):
    t = _seed("HD-1", "Someone", "Standard", "new", "2026-09-14T09:00:00Z", "My laptop won't turn on.")
    summary = agent.process_ticket(t)
    assert summary["category"] == "Hardware"
    assert "acknowledged_and_routed" in summary["action_summary"]
    actions = {a["action_type"] for a in db.list_actions("HD-1")}
    assert "acknowledged" in actions
    assert "routed" in actions


def test_duplicate_is_auto_closed(temp_db):
    _seed("HD-1", "Marcus", "Standard", "open", "2026-09-01T00:00:00Z",
          "Laptop won't turn on, tried multiple outlets, still escalated to hardware team, unresolved.")
    t2 = _seed("HD-2", "Marcus", "Standard", "new", "2026-09-02T00:00:00Z", "Laptop won't turn on.")
    summary = agent.process_ticket(t2)
    assert summary["action_summary"].startswith("auto_closed_duplicate")
    assert db.get_ticket("HD-2")["status"] == "closed"


def test_confirmed_small_billing_discrepancy_gets_courtesy_resolution(temp_db):
    db.load_billing_record("Priya Anand", 15.00)
    t = _seed("HD-1", "Priya Anand", "Standard", "new", "2026-09-14T09:30:00Z",
              "I was charged $15 for a Zoom Pro license renewal that should have been covered -- requesting a refund.")
    summary = agent.process_ticket(t)
    assert summary["category"] == "Licensing & Reimbursement"
    assert summary["action_summary"] == "courtesy_resolution($15.00)"
    assert db.get_ticket("HD-1")["status"] == "resolved"


def test_billing_discrepancy_above_threshold_is_not_auto_resolved(temp_db):
    db.load_billing_record("Farah Siddiqui", 200.00)
    t = _seed("HD-1", "Farah Siddiqui", "Standard", "new", "2026-09-14T10:40:00Z",
              "I was charged $200 more than I should have been for my laptop insurance add-on.")
    summary = agent.process_ticket(t)
    assert summary["action_summary"] == "routed_for_billing_review"
    flags = {f["flag_type"] for f in db.list_flags("HD-1")}
    assert "billing_above_threshold" in flags
    assert db.get_ticket("HD-1")["status"] != "resolved"


def test_billing_mismatch_is_not_auto_resolved(temp_db):
    db.load_billing_record("Noah Kim", 0.00)
    t = _seed("HD-1", "Noah Kim", "Standard", "new", "2026-09-14T10:30:00Z",
              "I think I was overcharged $40 on my last subscription renewal, can I get that back?")
    summary = agent.process_ticket(t)
    assert summary["action_summary"] == "routed_for_billing_review"
    flags = {f["flag_type"] for f in db.list_flags("HD-1")}
    assert "billing_mismatch" in flags


def test_vague_billing_complaint_has_no_amount_to_check(temp_db):
    t = _seed("HD-1", "Ari Feldman", "Standard", "new", "2026-09-14T10:20:00Z",
              "Requesting reimbursement -- I believe there was a billing error on my last license renewal.")
    summary = agent.process_ticket(t)
    assert summary["category"] == "Licensing & Reimbursement"
    assert summary["action_summary"] == "routed_unspecified_billing_claim"
    # No billing_check tool call should have happened -- nothing specific to check.
    assert not any(a["action_type"] == "billing_check" for a in db.list_actions("HD-1"))


def test_urgent_language_is_flagged(temp_db):
    t = _seed("HD-1", "Sam Okafor", "Standard", "new", "2026-09-14T09:50:00Z",
              "Our entire remote team is locked out of the VPN and production deploys are blocked -- this is urgent.")
    agent.process_ticket(t)
    flags = {f["flag_type"] for f in db.list_flags("HD-1")}
    assert "urgent_language" in flags


def test_empty_body_needs_human_triage(temp_db):
    t = _seed("HD-1", "Jordan Blake", "Standard", "new", "2026-09-14T10:10:00Z", "")
    summary = agent.process_ticket(t)
    assert summary["category"] is None
    assert summary["action_summary"] == "needs_human_triage"
    flags = {f["flag_type"] for f in db.list_flags("HD-1")}
    assert "insufficient_info" in flags


def test_ambiguous_vpn_security_ticket_pulls_additional_context(temp_db):
    t = _seed("HD-1", "Lin Huang", "Standard", "new", "2026-09-14T10:00:00Z",
              "Can't log into the VPN -- my account got locked after repeated failed login attempts, "
              "and I'm worried someone else tried to access my account.")
    summary = agent.process_ticket(t)
    context_calls = [a for a in db.list_actions("HD-1") if a["action_type"] == "context_lookup"]
    assert len(context_calls) == 1
    assert summary["category"] == "Security Incident"
    flags = {f["flag_type"] for f in db.list_flags("HD-1")}
    assert "security_incident" in flags
