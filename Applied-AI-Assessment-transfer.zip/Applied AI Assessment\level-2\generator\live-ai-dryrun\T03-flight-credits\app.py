"""
Flask UI + review/override endpoints.

Routes:
    GET  /                          - list all requests with status/decision summary
    GET  /request/<request_id>      - detail view: full reasoning trace, actions, overrides
    POST /request/<request_id>/override - human approves, denies, or reverses a decision

Run:
    python ingest.py     # one-time (or --reset) load of CSVs + agent processing
    python app.py         # start the UI at http://127.0.0.1:5000
"""
import json
import os

from flask import Flask, render_template, request, redirect, url_for, flash

import db
import tools

app = Flask(__name__)
app.secret_key = "dev-only-secret-not-for-production"


def _pretty(detail_str):
    try:
        obj = json.loads(detail_str)
        return json.dumps(obj, indent=2, default=str)
    except (TypeError, ValueError):
        return detail_str


@app.route("/")
def index():
    if not os.path.exists(db.DB_PATH):
        flash("No database found yet — run `python ingest.py` first.")
        return render_template("index.html", requests=[])
    reqs = db.list_requests()
    return render_template("index.html", requests=reqs)


@app.route("/request/<request_id>")
def detail(request_id):
    req = db.get_request(request_id)
    if req is None:
        flash(f"Request {request_id} not found.")
        return redirect(url_for("index"))
    log = db.get_reasoning_log(request_id)
    for step in log:
        step["detail_pretty"] = _pretty(step["detail"])
    actions = db.get_actions(request_id)
    overrides = db.get_overrides(request_id)
    booking = db.get_booking(req["booking_ref"])
    return render_template(
        "detail.html", req=req, log=log, actions=actions, overrides=overrides, booking=booking
    )


@app.route("/request/<request_id>/override", methods=["POST"])
def override(request_id):
    req = db.get_request(request_id)
    if req is None:
        flash(f"Request {request_id} not found.")
        return redirect(url_for("index"))

    decision = request.form.get("decision")  # 'approve' | 'deny' | 'reverse'
    reviewer = request.form.get("reviewer_name", "").strip() or "reviewer"
    note = request.form.get("note", "").strip()
    previous_status = req["status"]

    if decision == "approve" and previous_status == "flagged_review":
        # Re-derive what the agent would have done, and execute it now under human sign-off.
        booking = db.get_booking(req["booking_ref"])
        log = db.get_reasoning_log(request_id)
        interpret_step = next((s for s in log if s["step_name"] == "interpret"), None)
        action = None
        if interpret_step:
            action = json.loads(interpret_step["detail"])["output"]["action"]

        if action == "refund" and booking:
            amount = booking["credit_value"]
            tools.issue_refund(request_id, booking["booking_ref"], amount, source="human")
            db.update_request_status(request_id, "approved_by_human", "refund", amount)
        elif action == "rebooking" and booking:
            tools.schedule_rebooking(request_id, booking["booking_ref"], booking["flight_route"], source="human")
            db.update_request_status(request_id, "approved_by_human", "rebooking", None)
        else:
            db.update_request_status(request_id, "approved_by_human")
        new_status = "approved_by_human"

    elif decision == "deny" and previous_status == "flagged_review":
        db.update_request_status(request_id, "denied_by_human")
        new_status = "denied_by_human"

    elif decision == "reverse" and previous_status in ("auto_resolved", "approved_by_human"):
        db.reverse_actions(request_id)
        db.update_request_status(request_id, "reversed_by_human")
        new_status = "reversed_by_human"

    else:
        flash(f"Override '{decision}' is not valid from status '{previous_status}'.")
        return redirect(url_for("detail", request_id=request_id))

    db.record_override(request_id, reviewer, previous_status, new_status, note)
    flash(f"Override recorded: {previous_status} -> {new_status}.")
    return redirect(url_for("detail", request_id=request_id))


if __name__ == "__main__":
    app.run(debug=True)
