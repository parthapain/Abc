# T04 Calibration Run #1

Per `../../templates/T04-order-fulfillment-reliability.md`'s Calibration section. **Dry-run only, same status as T02/T03** — T01's step 4 hasn't cleared, so nothing here is official. Purpose: confirm the trap/ambiguity/guardrail, and check for the recurring "missing data defaults to permissive" pattern found (in different forms) in all three prior runs.

**Instance used for this run:** domain flavor = spare-parts orders; ambiguity phrasing #2 ("handle back-ordered items sensibly"); trap variants #1, #2, and #3 all tested together, since — as it turned out — a single natural implementation reproduces all three at once; stress-point variant not exercised.

---

## Step 1 — does the AI-trap reproduce?

**Prompt given (simulating the candidate):** *"Write a function that reconciles an order's line items against our catalog and checks inventory, using tools `check_inventory(sku)` and `reconcile_catalog_item(description)`."*

**Naive output:**
```python
def process_order(order_id: str, line_items: list) -> dict:
    reconciled_items = []
    for item in line_items:
        catalog_match = reconcile_catalog_item(item["description"])
        availability = check_inventory(catalog_match["sku"])
        reconciled_items.append({
            "sku": catalog_match["sku"],
            "quantity": item["quantity"],
            "available": availability["in_stock"] >= item["quantity"],
        })
    return {"order_id": order_id, "items": reconciled_items}
```

**Follow-up prompt:** *"Now add the dispatch step: if all items are available, call `dispatch_fulfillment(order_id, items)` to actually ship the order. Add error handling and retry so a temporary failure doesn't lose the order."*

**Naive output:**
```python
def dispatch_with_retry(order_id: str, items: list, max_retries=3) -> dict:
    for attempt in range(max_retries):
        try:
            result = dispatch_fulfillment(order_id, items)
            return {"status": "dispatched", "result": result}
        except Exception as e:
            logger.error(f"Dispatch attempt {attempt + 1} failed: {e}")
            time.sleep(2 ** attempt)
    return {"status": "failed", "reason": "max retries exceeded"}
```

**Verdict: this is the cleanest, strongest reproduction of the four templates so far — three trap variants confirmed simultaneously from one natural response to a single prompt:**

1. **Variant #1 (blind retry, no idempotency key) — confirmed.** `dispatch_fulfillment` is called with no idempotency token anywhere. If attempt 1 actually succeeds server-side but the response is lost to a timeout, attempt 2 dispatches the same order again. Nothing in this code could tell the two situations apart.
2. **Variant #2 (permanent failures retried the same as transient) — confirmed.** The `except Exception` is undifferentiated — an "item genuinely out of stock" failure gets the identical retry-with-backoff treatment as a network timeout, wasting three attempts on something no amount of retrying will fix, before failing with a reason string that doesn't say which happened.
3. **Variant #3 (no distinction between "call failed to send" and "call succeeded, response lost") — confirmed**, and it's the actual mechanism behind variant #1: this code has no way to ask "did that already go through?" before retrying.

This is a stronger result than T01/T02/T03: those needed a specific follow-up scenario to expose the flaw. Here, the single most natural response to "add error handling and retry" produces all three variants at once — this is arguably the single most reliable trap in the template set, consistent with reliability/retry-without-idempotency being one of the most well-documented default failure modes for AI-assisted backend code.

## Step 2 — is the ambiguity genuinely two-way?

Phrasing #2: *"Handle back-ordered items sensibly."* Tested against a 3-item order where one item is out of stock. Two reasonable engineers plausibly differ: ship the 2 available items now and back-order the third separately, vs. hold the entire shipment together so the customer gets one delivery instead of two partial ones (with cost/complexity trade-offs on each side). **Confirmed genuinely two-way.**

## Step 3 — does the guardrail-default trap reproduce?

**Follow-up prompt:** *"Now decide whether to auto-dispatch: if all items are available and the order's total value is $500 or under, auto-dispatch via the function above; otherwise escalate to a human."*

**Naive output:**
```python
def handle_order(order_id: str, line_items: list) -> dict:
    reconciliation = process_order(order_id, line_items)
    all_available = all(item["available"] for item in reconciliation["items"])
    order_value = sum(item["quantity"] * item.get("price", 0) for item in line_items)

    if all_available and order_value <= 500:
        result = dispatch_with_retry(order_id, reconciliation["items"])
        return {"action": "auto_dispatched", "result": result}
    else:
        escalate_to_human(order_id, reconciliation)
        return {"action": "escalated", "reconciliation": reconciliation}
```

**Verdict: reproduces exactly as the template predicted, plus one bonus finding matching the recurring pattern from T01/T02.**

- **Confirmed as worded:** the guardrail gates auto-dispatch on availability and order value alone — it has zero awareness of whether the dispatch action it's about to call is itself safe to retry/duplicate-proof. A candidate could build a perfectly reasonable-looking value threshold and still auto-fire straight into the unsafe retry logic from step 1.
- **Bonus finding — the recurring "missing data defaults to permissive" pattern shows up here too, in a fourth distinct form:** `item.get("price", 0)` silently treats a line item with a missing/malformed price as **free**. That drags `order_value` down, meaning an order with incomplete pricing data is *more* likely to clear the "$500 or under" threshold and get auto-dispatched, not less. Same family of bug as T01's `confidence` default and T02's `grounded` default — a missing field defaulting to the value that makes the guardrail *more* permissive rather than less — this time on a numeric threshold instead of a boolean flag. This is now the **third confirmed instance** of this pattern (T01, T02, T04) and one honest miss (T03), suggesting it's a genuinely common default-coding habit worth checking for explicitly on every template's guardrail, not just assuming it and not just dropping it after T03's negative result.

## Step 4 — timeboxed build check

**Not attempted** — last in the queue, behind T01, T02, and T03.

---

## Overall verdict

| Step | Result |
|---|---|
| 1. Trap reproduces | ✅ Confirmed — strongly; three trap variants (1, 2, 3) reproduce simultaneously from one natural response |
| 2. Ambiguity genuinely two-way | ✅ Confirmed |
| 3. Guardrail-default trap reproduces | ✅ Confirmed as worded, **plus** a fourth instance of the recurring missing-data-defaults-permissive pattern (`item.get("price", 0)`) |
| 4. Timeboxed build | ⏳ Not attempted |

**T04 is not calibrated** — same dry-run status as T02/T03. This is the strongest, cleanest set of confirmations across all four templates: every hypothesis in the written design reproduced, plus a genuinely new instance of the cross-template default-value pattern.

## Follow-up actions this run identified

1. Fold the `item.get("price", 0)` finding into T04's reference solution and guardrail notes, same treatment as the other three templates.
2. **Cross-template pattern now confirmed 3 of 4 times (T01, T02, T04) with one honest miss (T03):** a missing/failed field defaulting to whatever value makes the guardrail *more* permissive. This is common enough now to call out explicitly in the AI-grader's Dimension 2 guidance (`../grading-prompt.md`) as a specific thing to check for across any template, not just something folded into each template's own notes piecemeal.
3. All four templates' dry-runs are now done. The one thing genuinely outstanding across the whole set is step 4 for all of them — an actual timed human build, T01 first.

---

## Calibration Run #2 — post-split re-validation (2026-09-12)

**Purpose:** confirm run #1's findings still hold after the rubric's Dimension 1 split, and resolve T04's cap level explicitly — T04 is the one template whose naive code carries **two independent Dimension 2 defects at once**, which the pre-split bundled dimension had no clean way to express (there was only one capping rule to apply, not a question of which of two findings governs). Same prompts and code as run #1; nothing about the split changes what the naive implementation looks like.

**Dimension mapping, resolved:**
- Step 1's trap finding (all three reliability-engineering variants — blind retry, permanent/transient conflation, no send/lost-response distinction) → **Dimension 4** (was Dimension 3). Unchanged, still the cleanest single-prompt reproduction across all four templates.
- Step 2's ambiguity finding (phrasing #2, back-order handling) → **Dimension 3** (was Dimension 2). Unchanged.
- Step 3's guardrail findings → **Dimension 2** (was folded into the old Dimension 1), and this is where the split required a real resolution rather than a renumbering:
  1. The guardrail checks availability + order value but has zero awareness of whether `dispatch_fulfillment` is itself safe to retry/duplicate-proof. In isolation, this is a **cap-2** finding ("guardrail exists, checks something real, just not the actual risk of the action it's gating").
  2. `item.get("price", 0)` treats missing/malformed price data as free, making an incomplete-data order *more* likely to auto-dispatch — the recurring cross-template pattern, a **cap-1** finding.
  - **Resolved: because both are present in the same naive code, the overall Dimension 2 score is capped at 1, not 2** — the worse finding governs, and a legitimate (if incomplete) availability/value check does not buy back the more severe permissive-default failure elsewhere in the same guardrail. This "worse cap governs, don't average across findings within one dimension" rule is now written into `../../rubric.md` §2, `grading-prompt.md`, and T04's own template file.

**Why this matters beyond T04:** before this run, the docs stated the capping rule per-finding but never explicitly addressed what happens when a single submission trips two different cap severities in the same dimension. That's now settled generally, not just for T04.

**Verdict: T04's calibration status is unchanged in substance (still the strongest, cleanest confirmation of the four templates), but its guardrail findings now resolve to an explicit combined cap (1) instead of two separately-implied ones.** Step 4 remains last in the queue, unaffected by the split.

---

## Calibration Run #3 — Addendum 20 second-guardrail dry-run (2026-09-13)

**Purpose:** T04's brief now requires a second, independent guardrailed action (auto-reroute to an alternate warehouse gated on `alt_warehouse_inventory.csv`, see `../../templates/T04-order-fulfillment-reliability.md`'s "Second guardrail" note). Dry-testing that specific addition against the real dataset, not just in the abstract.

**Prompt given (simulating the candidate):** *"For orders where the primary warehouse is out of stock on an item, check alternate-warehouse stock via `check_alt_warehouse(sku)`, and if it's available within a reasonable shipping-cost threshold, reroute via `reroute_to_alt_warehouse(order_id, sku)`."*

**Naive output (first, careful draft — checks both fields):**
```python
def check_alt_warehouse(sku: str) -> dict:
    row = alt_df[alt_df["sku"] == sku]
    if row.empty:
        return {}
    r = row.iloc[0]
    return {"alt_stock": r["alt_stock"], "ship_cost": r["ship_cost_from_alt"]}

def maybe_reroute(sku, order_id):
    alt = check_alt_warehouse(sku)
    if alt.get("alt_stock", 0) > 0 and alt.get("ship_cost", 0) <= 20:
        reroute_to_alt_warehouse(order_id, sku)
        return {"action": "rerouted"}
    escalate_to_human(order_id)
    return {"action": "escalated"}
```

This careful version actually fails closed on a missing row (both `.get()` defaults resolve to "escalate"). **But the template's original guess (a missing-field default making a reroute look free) doesn't need a missing row to reproduce — it can happen with a row that's present but that a less careful implementation only partly checks.** A more natural simplification, given the brief's own phrasing emphasizes the *cost* threshold ("within a reasonable shipping-cost threshold"):

```python
def maybe_reroute(sku, order_id):
    alt = check_alt_warehouse(sku)
    if not alt:
        escalate_to_human(order_id)
        return {"action": "escalated"}
    if alt["ship_cost"] <= 20:          # BUG: never checks alt_stock at all
        reroute_to_alt_warehouse(order_id, sku)
        return {"action": "rerouted"}
    escalate_to_human(order_id)
    return {"action": "escalated"}
```

**Verdict: reproduces, and confirmed directly against the real dataset — a sharper, more concrete finding than the template's original guess.** `alt_warehouse_inventory.csv` has a row for **SKU-9008** (ORD-9013's item): `alt_stock=0, ship_cost_from_alt=0.00` — the alternate warehouse has **zero** stock, but the row is present with a valid, low shipping-cost figure. A naive implementation that checks only `ship_cost <= 20` and never checks `alt_stock > 0` would **reroute ORD-9013 to a warehouse that has nothing to ship** — exactly the case the template's INTERNAL-metadata.md says must escalate instead. This is a real, checkable, dataset-grounded instance of "checks the cost threshold the brief emphasizes, silently skips the stock check the brief also requires" — the same broad family as the template's already-confirmed `item.get("price", 0)` finding (a naive implementation satisfying part of a compound check while silently skipping the other part), but a distinct specific mechanism. **Action taken: updated `T04-order-fulfillment-reliability.md`'s second-guardrail compounding-risk note to describe this confirmed, dataset-grounded mechanism.**

**Ambiguity check (brief):** the second phrasing paired with this guardrail ("handle back-ordered items sensibly," pool item #2, already confirmed two-way in run #1) is unchanged by this addition — no new ambiguity test needed since this instance reuses the same pool item already calibrated.

**T04's second guardrail is dry-run confirmed, not yet independently verified against a live AI assistant.**
