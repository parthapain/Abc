"""P07 — Embedding batch builder. Medium · host-located · partial final batch dropped."""

META = {"difficulty": "Medium", "location": "host", "pattern": "partial final batch discarded"}

SCHEMA = """
CREATE TABLE documents (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    status  TEXT NOT NULL
);
"""

_QUERY = "SELECT name FROM documents WHERE status = 'pending' ORDER BY id"
BATCH_SIZE = 3


def _pending(conn):
    return [r[0] for r in conn.execute(_QUERY).fetchall()]


def broken(conn):
    names = _pending(conn)
    batches = []
    for i in range(0, len(names), BATCH_SIZE):
        batch = names[i : i + BATCH_SIZE]
        if len(batch) == BATCH_SIZE:  # BUG: silently discards the final partial batch
            batches.append(batch)
    return batches


def fixed(conn):
    names = _pending(conn)
    return [names[i : i + BATCH_SIZE] for i in range(0, len(names), BATCH_SIZE)]


def _no_status_filter(conn):
    names = [r[0] for r in conn.execute("SELECT name FROM documents ORDER BY id").fetchall()]
    return [names[i : i + BATCH_SIZE] for i in range(0, len(names), BATCH_SIZE)]


WRONG_FIXES = {"dropped the status filter": _no_status_filter}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, name, status) VALUES
                (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
                (4,'d','pending'),(5,'e','pending'),(6,'f','pending'),
                (7,'g','pending');
        """,
        "expected": [["a", "b", "c"], ["d", "e", "f"], ["g"]],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, name, status) VALUES
                (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
                (4,'d','pending'),(5,'e','pending'),(6,'f','pending');
        """,
        "expected": [["a", "b", "c"], ["d", "e", "f"]],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO documents (id, name, status) VALUES
                (1,'a','pending'),(2,'b','pending');
        """,
        "expected": [["a", "b"]],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO documents (id, name, status) VALUES
                (1,'a','pending'),(2,'b','pending'),(3,'c','pending'),
                (4,'x','indexed'),(5,'y','indexed');
        """,
        "expected": [["a", "b", "c"]],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
