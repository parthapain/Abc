# P21 — Retrieval ranking

| Field | Value |
|---|---|
| **ID** | P21 |
| **Difficulty** | High |
| **Bug pattern** | Sort lacks a deterministic tiebreak |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 13–17 min |
| **Paper** | 3 (with P03) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

Search results are ranked by relevance score, highest first. Where two results score equally, they must be ordered by name so the ranking is reproducible across runs.

The ordering is *mostly* right — highest scores do come first — but equally-scored results come back in an order that does not match the specification, and that changes if the underlying rows are inserted differently.

### Required behaviour

Return `(name, score)` for all results, sorted by:

1. `score` **descending**, then
2. `name` **ascending** as a tiebreak.

### Schema

```sql
CREATE TABLE results (
    id    INTEGER PRIMARY KEY,
    name  TEXT NOT NULL,
    score INTEGER NOT NULL
);
```

The query returns rows in `id` order; all ranking is done in host code.

---

## Fixture — `P21.sql`

```sql
CREATE TABLE results (
    id    INTEGER PRIMARY KEY,
    name  TEXT NOT NULL,
    score INTEGER NOT NULL
);

INSERT INTO results (id, name, score) VALUES
    (1,'zeta', 90),   -- tied on score, inserted before 'alpha'
    (2,'alpha',90),
    (3,'mid',  80);
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)

_QUERY = "SELECT name, score FROM results ORDER BY id"
# --- end boilerplate ---


def ranked_results(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (name, score) sorted by score descending,
    then by name ascending as a tiebreak.
    """
    conn = _connect(db_path)
    try:
        rows = [(name, score) for name, score in conn.execute(_QUERY).fetchall()]
    finally:
        conn.close()

    rows.sort(key=lambda r: -r[1])
    return rows
```

### Java

```java
import java.sql.*;
import java.util.*;

public class Ranker {

    // --- boilerplate: do not modify ---
    public static class Result {
        public final String name;
        public final int score;

        public Result(String name, int score) {
            this.name = name;
            this.score = score;
        }
    }

    private static final String QUERY = "SELECT name, score FROM results ORDER BY id";

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (name, score) sorted by score descending,
     * then by name ascending as a tiebreak.
     */
    public static List<Result> rankedResults(String dbPath) throws SQLException {
        List<Result> rows = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(QUERY)) {
            while (rs.next()) {
                rows.add(new Result(rs.getString("name"), rs.getInt("score")));
            }
        }

        rows.sort(Comparator.comparingInt((Result r) -> r.score).reversed());
        return rows;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record Result(string Name, int Score);

public static class Ranker
{
    // --- boilerplate: do not modify ---
    private const string Query = "SELECT name, score FROM results ORDER BY id";

    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Name, Score) sorted by Score descending,
    /// then by Name ascending as a tiebreak.
    /// </summary>
    public static List<Result> RankedResults(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<Result>(Query).ToList();

        return rows.OrderByDescending(r => r.Score).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `zeta` 90, `alpha` 90, `mid` 80 — tie inserted in reverse-alphabetical order | `[("alpha",90), ("zeta",90), ("mid",80)]` | **Discriminator** — broken returns `zeta` before `alpha` |
| T2 | `charlie` 90, `bravo` 80, `alpha` 70 — no ties | `[("charlie",90), ("bravo",80), ("alpha",70)]` | Guard — with no ties there is nothing to break |
| T3 | Two tie groups: `delta`/`bravo` at 50, `yankee`/`xray` at 70 | `[("xray",70), ("yankee",70), ("bravo",50), ("delta",50)]` | **Discriminator** — both groups come back in insertion order |
| T4 | `alpha` 90, `beta` 90, `gamma` 80 — tie **already** in alphabetical order | `[("alpha",90), ("beta",90), ("gamma",80)]` | Guard — the broken version is accidentally correct here |
| T5 | Empty table | `[]` | Guard |

> T4 is the important guard. It proves the broken version is not universally wrong — it produces the right answer whenever insertion order happens to coincide with name order. That coincidence is exactly what lets this defect pass a casual test and reach production.

### Fixtures

```sql
-- T2
INSERT INTO results (id, name, score) VALUES (1,'charlie',90),(2,'bravo',80),(3,'alpha',70);
-- T3
INSERT INTO results (id, name, score) VALUES (1,'delta',50),(2,'bravo',50),(3,'yankee',70),(4,'xray',70);
-- T4
INSERT INTO results (id, name, score) VALUES (1,'alpha',90),(2,'beta',90),(3,'gamma',80);
```

---

## Reference solution

Add the name as a secondary sort key.

**Python:**

```diff
- rows.sort(key=lambda r: -r[1])
+ rows.sort(key=lambda r: (-r[1], r[0]))
```

**Java:**

```diff
- rows.sort(Comparator.comparingInt((Result r) -> r.score).reversed());
+ rows.sort(Comparator.comparingInt((Result r) -> r.score).reversed()
+                     .thenComparing(r -> r.name));
```

**C#:**

```diff
- return rows.OrderByDescending(r => r.Score).ToList();
+ return rows.OrderByDescending(r => r.Score).ThenBy(r => r.Name).ToList();
```

### Why

The sort specifies only the primary key. All three languages use a **stable** sort, so records comparing equal retain their relative input order — here, the `id` order the query returned them in. The output therefore satisfies the score ordering but silently substitutes database insertion order for the required name tiebreak.

Nothing is obviously broken: the list is sorted, the highest scores are first, and no error occurs. The defect only surfaces when someone compares two runs over differently-ordered data, or when a re-index changes the order rows come back in and a ranking that "never changed before" suddenly does.

Note the Java fix must chain onto the **reversed** comparator, not reverse the whole chain. `comparingInt(...).thenComparing(...).reversed()` would reverse both keys and sort names descending — a common and easily-missed error.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Sorting by name first, then score | T1 — `alpha` 90, `mid` 80, `zeta` 90; the primary key is wrong |
| Java: `.thenComparing(name).reversed()` — reversing the whole chain | T1 — names sort descending, so `zeta` precedes `alpha` |
| Adding `ORDER BY score DESC, name` to the SQL and leaving the host sort in place | Acceptable if the host sort is also corrected or removed; verify against T1 and T3 |
| Relying on the database to order and removing the host sort entirely | Correct if the SQL specifies both keys — accept it |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is ordering within tie groups only — the score ordering itself must still be correct in the broken version
- [ ] **T4 genuinely passes in the broken version** — if it fails, the fixture insertion order is wrong and the problem loses its subtlety
- [ ] Exactly one intended change; no second defect introduced
- [ ] Java: confirm `.reversed()` placement in the reference fix sorts score descending and name **ascending**
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
