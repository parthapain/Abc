"""Agent orchestration.

This is the piece that makes the app "an agent, not a single call": for each
document it makes an extraction call, then uses tools to verify and enrich
that extraction, branches on what it finds, and only then commits — logging
every step to agent_log so a human reviewer can see the reasoning trail.

Two entry points:
  process_document(conn, agreement)   - extract + verify + commit one loan
  run_maturity_followups(conn, ...)   - separate pass: for loans approaching
                                         maturity, check status and maybe
                                         generate a follow-up record
"""
from __future__ import annotations

import json
import sqlite3
from datetime import date, timedelta
from typing import Optional

from . import db
from .extraction import (
    extract_fields_llm,
    extract_note_maturity,
    note_executed_date,
    note_supersedes_date,
)
from .tools import cross_check_field, lookup_related_document, lookup_loan_status

# How far ahead of "today" a loan counts as "approaching maturity" for the
# follow-up workflow (brief item 7). Not specified by the brief, so made
# configurable rather than hard-coded; 12 months is a reasonable
# relationship-management horizon for a commercial lender and is the value
# used by run_pipeline.py by default. See RATIONALE.md.
DEFAULT_APPROACHING_MONTHS = 12


def _choose_governing_note(notes: list[dict]) -> tuple[Optional[dict], list[str]]:
    """Given every promissory note on file for a loan, decide which one
    governs (an amended-and-restated note supersedes the original it names),
    and return (chosen_note_or_None, decision_notes)."""
    decision_notes: list[str] = []
    if not notes:
        return None, decision_notes
    if len(notes) == 1:
        return notes[0], decision_notes

    # If any note explicitly says it supersedes an earlier note dated X,
    # drop the note(s) dated X from consideration and prefer the superseding
    # one. Falls back to the most-recently-executed note otherwise.
    superseded_dates = set()
    for n in notes:
        sup = note_supersedes_date(n["text"])
        if sup:
            superseded_dates.add(sup)

    candidates = [n for n in notes if note_executed_date(n["text"]) not in superseded_dates]
    if len(candidates) < len(notes):
        dropped = [n["filename"] for n in notes if n not in candidates]
        decision_notes.append(
            f"Found {len(notes)} promissory notes on file; "
            f"{', '.join(dropped)} superseded per its amendment and was ignored."
        )
    if len(candidates) == 1:
        return candidates[0], decision_notes

    # Still ambiguous: prefer the most recently executed.
    def _key(n: dict) -> str:
        return note_executed_date(n["text"]) or ""

    candidates.sort(key=_key, reverse=True)
    decision_notes.append(
        f"Multiple current notes on file; chose the most recently executed "
        f"({candidates[0]['filename']})."
    )
    return candidates[0], decision_notes


def process_document(conn: sqlite3.Connection, agreement: dict) -> None:
    """Run the full extract -> verify -> (maybe fetch related doc) -> decide
    -> commit pipeline for one loan agreement."""
    loan_number = agreement["loan_number"]
    text = agreement["text"]
    source_file = agreement["source_file"]

    db.log(conn, loan_number, "extract_start", f"source={source_file}")
    result = extract_fields_llm(text)
    review_notes = list(result.notes)
    maturity_source = result.maturity_date_type

    # --- tool call: resolve a cross-document maturity-date reference -------
    if result.maturity_reference_needed:
        db.log(conn, loan_number, "tool:lookup_related_document", f"loan_number={loan_number}")
        notes = lookup_related_document(loan_number)
        chosen, decision_notes = _choose_governing_note(notes)
        review_notes.extend(decision_notes)
        for dn in decision_notes:
            db.log(conn, loan_number, "decision", dn)

        if chosen is None:
            maturity_source = "missing"
            review_notes.append(
                "Agreement defers maturity date to a Promissory Note, but no "
                "matching note document was found on file."
            )
            db.log(conn, loan_number, "decision", "No related note found; maturity_date left blank.")
        else:
            note_date = extract_note_maturity(chosen["text"])
            result.maturity_date = note_date
            maturity_source = f"reference:{chosen['filename']}"
            db.log(
                conn, loan_number, "tool_result:lookup_related_document",
                f"chosen={chosen['filename']} maturity_date={note_date}",
            )
            # cross-check the referenced value against ITS source (the note),
            # not the main agreement, since that's where it actually came from
            passed = cross_check_field(chosen["text"], note_date)
            db.log(conn, loan_number, "tool:cross_check_field", f"field=maturity_date (from note) passed={passed}")
            if not passed:
                review_notes.append("Maturity date could not be verified against the promissory note text.")

    # --- tool call: cross-check every directly-extracted field -------------
    fields_to_check = {
        "borrower_name": result.borrower_name,
        "principal_amount": result.principal_amount,
        "interest_rate": result.interest_rate,
    }
    if maturity_source == "explicit":
        fields_to_check["maturity_date"] = result.maturity_date

    all_passed = True
    for field_name, value in fields_to_check.items():
        passed = cross_check_field(text, value)
        db.log(conn, loan_number, "tool:cross_check_field", f"field={field_name} value={value!r} passed={passed}")
        if not passed:
            all_passed = False
            review_notes.append(f"Could not verify extracted {field_name} against the source document.")

    if maturity_source == "computed":
        # A computed date is derived, not quoted verbatim, so verify the two
        # inputs the computation used (Closing Date and the N-months term)
        # are both actually present in the source instead of substring-
        # matching the derived date itself.
        closing_ok = cross_check_field(text, result.maturity_computed_closing_date)
        months_ok = result.maturity_computed_months is not None and (
            f"({result.maturity_computed_months})" in text
        )
        passed = closing_ok and months_ok
        db.log(
            conn, loan_number, "tool:cross_check_field",
            f"field=maturity_date (computed inputs) closing_ok={closing_ok} months_ok={months_ok} passed={passed}",
        )
        if not passed:
            all_passed = False
            review_notes.append("Could not verify the inputs used to compute maturity_date against the source document.")

    if result.borrower_name_variant:
        all_passed = False  # not a hard failure, but surfaced to the reviewer

    if maturity_source == "missing" or not result.maturity_date:
        all_passed = False
        if "No maturity date clause recognized" not in " ".join(review_notes) and maturity_source == "missing":
            review_notes.append("Maturity date could not be determined.")

    if not result.interest_rate:
        all_passed = False

    needs_review = not all_passed

    db.upsert_loan(
        conn,
        {
            "loan_number": loan_number,
            "source_file": source_file,
            "raw_text": text,
            "borrower_name": result.borrower_name,
            "borrower_name_variant": result.borrower_name_variant,
            "principal_amount": result.principal_amount,
            "interest_rate": result.interest_rate,
            "maturity_date": result.maturity_date,
            "maturity_source": maturity_source,
            "cross_check_passed": int(all_passed),
            "needs_review": int(needs_review),
            "review_notes": json.dumps(review_notes),
        },
    )

    # --- tool call: autonomously commit the record to the system of record -
    # Per the brief this happens autonomously regardless of needs_review;
    # needs_review only controls what the human reviewer sees highlighted.
    db.mark_committed(conn, loan_number)
    db.log(conn, loan_number, "tool:commit_loan_record", f"needs_review={needs_review}")


def run_maturity_followups(
    conn: sqlite3.Connection,
    reference_date: Optional[date] = None,
    approaching_months: int = DEFAULT_APPROACHING_MONTHS,
) -> None:
    """Separate pass (brief item 7): for every committed loan whose maturity
    date falls within `approaching_months` of `reference_date`, look up its
    current status and, only if that confirms the loan is still active,
    autonomously generate a maturity follow-up record."""
    reference_date = reference_date or date.today()
    horizon = reference_date + timedelta(days=30 * approaching_months)

    for row in db.all_loans(conn):
        loan_number = row["loan_number"]
        maturity_str = row["maturity_date"]
        if not maturity_str:
            continue
        try:
            maturity = date.fromisoformat(maturity_str)
        except ValueError:
            continue

        if not (reference_date <= maturity <= horizon):
            continue

        db.log(conn, loan_number, "followup_check", f"maturity={maturity_str} within {approaching_months}mo horizon")
        db.log(conn, loan_number, "tool:lookup_loan_status", f"loan_number={loan_number}")
        status = lookup_loan_status(loan_number)

        if status is None:
            reason = "Loan not found in status registry; cannot confirm it is still active, so no follow-up was generated."
            db.log(conn, loan_number, "decision", reason)
            db.record_followup(conn, loan_number, maturity_str, "not_found", generated=False, reason=reason)
            continue

        if status != "active":
            reason = f"Registry status is '{status}' (not active); no follow-up generated."
            db.log(conn, loan_number, "decision", reason)
            db.record_followup(conn, loan_number, maturity_str, status, generated=False, reason=reason)
            continue

        reason = "Registry confirms loan is still active and approaching maturity; follow-up record generated."
        db.log(conn, loan_number, "decision", reason)
        db.record_followup(conn, loan_number, maturity_str, status, generated=True, reason=reason)
        db.log(conn, loan_number, "tool:generate_followup_record", reason)
