# P19 — Paged export

| Field | Value |
|---|---|
| **ID** | P19 |
| **Difficulty** | High |
| **Bug pattern** | Pagination loop discards the last page |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 13–17 min |
| **Paper** | 1 (with P01) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

An export job reads a table in pages of three rows and accumulates them into one list. It stops when it reaches a page that is not full, on the assumption that a short page means the end of the data.

Exports are short. Small tables sometimes export nothing at all, which is how the problem was noticed.

### Required behaviour

Read every row from `items` in pages of **3**, ordered by `id`, and return all of the `name` values in order.

Every row must appear exactly once.

### Schema

```sql
CREATE TABLE items (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
```

---

## Fixture — `P19.sql`

```sql
CREATE TABLE items (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);

INSERT INTO items (id, name) VALUES
    (1,'a'),(2,'b'),(3,'c'),(4,'d'),(5,'e'),(6,'f'),
    (7,'g');   -- seventh row lands alone on the final page
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

PAGE_SIZE = 3

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)

_PAGE_QUERY = "SELECT name FROM items ORDER BY id LIMIT ? OFFSET ?"
# --- end boilerplate ---


def export_all(db_path: str) -> List[str]:
    """
    Read every row in pages of PAGE_SIZE, ordered by id,
    and return all name values in order.
    """
    conn = _connect(db_path)
    offset = 0
    out: List[str] = []
    try:
        while True:
            page = conn.execute(_PAGE_QUERY, (PAGE_SIZE, offset)).fetchall()
            if len(page) < PAGE_SIZE:
                break
            out.extend(row[0] for row in page)
            offset += PAGE_SIZE
    finally:
        conn.close()
    return out
```

### Java

```java
import java.sql.*;
import java.util.*;

public class Exporter {

    public static final int PAGE_SIZE = 3;

    // --- boilerplate: do not modify ---
    private static final String PAGE_QUERY =
        "SELECT name FROM items ORDER BY id LIMIT ? OFFSET ?";

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Read every row in pages of PAGE_SIZE, ordered by id,
     * and return all name values in order.
     */
    public static List<String> exportAll(String dbPath) throws SQLException {
        List<String> out = new ArrayList<>();
        int offset = 0;

        try (Connection conn = connect(dbPath)) {
            while (true) {
                List<String> page = new ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement(PAGE_QUERY)) {
                    ps.setInt(1, PAGE_SIZE);
                    ps.setInt(2, offset);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            page.add(rs.getString("name"));
                        }
                    }
                }

                if (page.size() < PAGE_SIZE) {
                    break;
                }
                out.addAll(page);
                offset += PAGE_SIZE;
            }
        }
        return out;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class Exporter
{
    public const int PageSize = 3;

    // --- boilerplate: do not modify ---
    private const string PageQuery =
        "SELECT name FROM items ORDER BY id LIMIT @limit OFFSET @offset";

    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Read every row in pages of PageSize, ordered by id,
    /// and return all name values in order.
    /// </summary>
    public static List<string> ExportAll(string dbPath)
    {
        var output = new List<string>();
        int offset = 0;

        using var conn = Connect(dbPath);
        while (true)
        {
            var page = conn.Query<string>(
                PageQuery, new { limit = PageSize, offset }).ToList();

            if (page.Count < PageSize)
            {
                break;
            }
            output.AddRange(page);
            offset += PageSize;
        }
        return output;
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 7 rows `a`–`g` | `[a,b,c,d,e,f,g]` | **Discriminator** — broken returns 6, dropping `g` |
| T2 | 6 rows | `[a,b,c,d,e,f]` | Guard — exact multiple; the short page is genuinely empty |
| T3 | 2 rows | `[a,b]` | **Discriminator** — broken returns `[]` |
| T4 | 3 rows | `[a,b,c]` | Guard — one full page, then an empty one |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO items (id, name) VALUES (1,'a'),(2,'b'),(3,'c'),(4,'d'),(5,'e'),(6,'f');
-- T3
INSERT INTO items (id, name) VALUES (1,'a'),(2,'b');
-- T4
INSERT INTO items (id, name) VALUES (1,'a'),(2,'b'),(3,'c');
```

---

## Reference solution

Consume the page **before** testing whether it was the last one.

**Python:**

```diff
  page = conn.execute(_PAGE_QUERY, (PAGE_SIZE, offset)).fetchall()
+ out.extend(row[0] for row in page)
  if len(page) < PAGE_SIZE:
      break
- out.extend(row[0] for row in page)
  offset += PAGE_SIZE
```

**Java:**

```diff
+ out.addAll(page);
  if (page.size() < PAGE_SIZE) {
      break;
  }
- out.addAll(page);
  offset += PAGE_SIZE;
```

**C#:**

```diff
+ output.AddRange(page);
  if (page.Count < PageSize)
  {
      break;
  }
- output.AddRange(page);
  offset += PageSize;
```

### Why

"Fewer rows than requested" correctly identifies the final page — but a final page is still data. The loop treats the signal as a reason to discard the page rather than a reason to stop *after* consuming it.

The two conditions have been conflated: *is this the last page* and *is this page empty* are different questions, and only the second justifies throwing the page away.

Severity depends on the shape of the data, which is what makes it survive testing:

- Row count an exact multiple of the page size — no loss at all (T2, T4). The final fetch returns zero rows and nothing is discarded.
- Row count not a multiple — the remainder is lost (T1).
- Fewer rows than one page — **everything** is lost (T3). This is the case that exposed the bug in production.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Advancing the offset by `PAGE_SIZE - 1` | T1 — pages overlap and rows are duplicated |
| Testing `if len(page) == 0` but still breaking before the extend | T1, T3 — the short page is still discarded |
| Fetching everything without pagination | Passes the tests, but abandons the requirement — flag in review |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing rows, not an infinite loop — confirm the loop still terminates after the fix
- [ ] Exactly one intended change; no second defect introduced
- [ ] Bug is not visible on a skim, and does not require guessing
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Confirm T3 (fewer rows than one page) is present — it is the case that makes the severity obvious
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
