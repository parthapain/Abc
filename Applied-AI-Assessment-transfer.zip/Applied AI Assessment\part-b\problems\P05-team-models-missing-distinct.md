# P05 — Models used by a team

| Field | Value |
|---|---|
| **ID** | P05 |
| **Difficulty** | Medium |
| **Bug pattern** | Join emits duplicate rows |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 9–12 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A team page lists which models that team has used, as a set of chips. Each model should appear once.

Instead, heavily-used models appear many times over — `ada-002` shows up eleven times because the team made eleven calls to it.

### Required behaviour

Return the distinct `name` of every model used by the team called `'platform'`, ordered by model name ascending. Each model appears exactly once, however many requests were made.

### Schema

```sql
CREATE TABLE teams (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE models (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE requests (
    id       INTEGER PRIMARY KEY,
    team_id  INTEGER NOT NULL REFERENCES teams(id),
    model_id INTEGER NOT NULL REFERENCES models(id)
);
```

---

## Fixture — `P05.sql`

```sql
INSERT INTO teams  (id, name) VALUES (1,'platform'),(2,'research');
INSERT INTO models (id, name) VALUES (1,'ada-002'),(2,'text-3-large'),(3,'rerank-v1');

INSERT INTO requests (id, team_id, model_id) VALUES
    (1,1,1),(2,1,1),(3,1,1);   -- same model, three calls
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def models_used_by_platform(db_path: str) -> List[str]:
    """
    Return the distinct name of every model used by the 'platform' team,
    ordered by model name ascending.
    """
    query = """
        SELECT m.name
        FROM models m
        JOIN requests r ON r.model_id = m.id
        JOIN teams    t ON t.id = r.team_id
        WHERE t.name = 'platform'
        ORDER BY m.name
    """
    conn = _connect(db_path)
    try:
        return [row[0] for row in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class TeamModels {

    // --- boilerplate: do not modify ---
    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return the distinct name of every model used by the 'platform' team,
     * ordered by model name ascending.
     */
    public static List<String> modelsUsedByPlatform(String dbPath) throws SQLException {
        String query =
            "SELECT m.name " +
            "FROM models m " +
            "JOIN requests r ON r.model_id = m.id " +
            "JOIN teams    t ON t.id = r.team_id " +
            "WHERE t.name = 'platform' " +
            "ORDER BY m.name";

        List<String> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(rs.getString("name"));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public static class TeamModels
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return the distinct name of every model used by the 'platform' team,
    /// ordered by model name ascending.
    /// </summary>
    public static List<string> ModelsUsedByPlatform(string dbPath)
    {
        const string query = @"
            SELECT m.name
            FROM models m
            JOIN requests r ON r.model_id = m.id
            JOIN teams    t ON t.id = r.team_id
            WHERE t.name = 'platform'
            ORDER BY m.name";

        using var conn = Connect(dbPath);
        return conn.Query<string>(query).ToList();
    }
}
```

---

## Hidden test cases

All fixtures include the standard `teams` and `models` rows shown above.

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | Three requests, all to `ada-002` | `["ada-002"]` | **Discriminator** — broken returns it three times |
| T2 | One request each to two models | `["ada-002", "text-3-large"]` | Guard — no repetition to collapse |
| T3 | One request to `ada-002`, two to `text-3-large` | `["ada-002", "text-3-large"]` | **Discriminator** — broken repeats the second |
| T4 | `platform` uses `rerank-v1`; `research` uses two others | `["rerank-v1"]` | Guard — catches removal of the team filter |
| T5 | No requests at all | `[]` | Guard |

---

## Reference solution

```diff
- SELECT m.name
+ SELECT DISTINCT m.name
  FROM models m
  JOIN requests r ON r.model_id = m.id
```

`GROUP BY m.name` is equally correct and should be accepted.

### Why

The join is row-multiplying by design: one row comes back per *request*, not per model. The query answers "which model did each request use", while the requirement is "which models has this team used" — a set, not a log.

The defect hides whenever usage happens to be one request per model (T2), which is exactly what a small test fixture tends to look like.

Note that de-duplicating in host code also works and should be accepted if the ordering is preserved — but it moves data across the wire only to discard it, which is worth a comment in review rather than a mark against.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| `LIMIT 1` to stop the repeats | T2, T3 — drops genuine second models |
| Dropping the `teams` join to simplify | T4 — models from `research` appear |
| `GROUP BY m.id` without selecting distinct names | Equivalent here; accept |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is duplicated rows, not a SQL error
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Both `DISTINCT` and `GROUP BY` fixes are accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
