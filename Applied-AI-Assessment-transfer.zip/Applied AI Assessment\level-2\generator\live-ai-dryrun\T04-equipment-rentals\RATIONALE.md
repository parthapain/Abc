# Rationale

## Architecture

`agent.py::process_order()` runs a fixed but genuinely agentic control flow per
order: split the free text -> reconcile each fragment against the catalog ->
check primary inventory -> if short, check the alt yard and autonomously
reroute -> assess risk from what was actually learned -> dispatch only if
low-risk. Each step is a discrete function in `tools.py` with a typed
input/output contract, logged into a `reasoning_trace` the UI renders
verbatim. The "decide how to proceed only after gathering information" shape
the brief asks for comes from the fact that whether alt-yard checks or a
reroute happen at all *depends on* the primary-inventory tool's result, and
whether dispatch happens depends on the accumulated risk signal across all
line items — not from an LLM emitting tool-call JSON in a loop.

## In-house LLM stand-in

No API key was available in this environment, so `llm_interpreter.py` is a
clearly-marked deterministic stand-in (docstring says so up front): it splits
`line_items_description` on the `<qty>x <name>` pattern the seed data uses,
then scores each fragment against every catalog name (exact match / prefix
match / sequence similarity) to pick a SKU. It's built as one function with a
fixed contract (`text, catalog -> sku, confidence, candidates, reasoning`)
specifically so a real model call could replace it without touching
`tools.py` or `agent.py`.

## Reconciling ambiguous items ("doesn't map cleanly")

The seed data's clearest case is ORD-9001, `"3x Concrete Mixer"` — a real
product family name that matches two catalog SKUs (3.5cu ft and 6cu ft
variants) equally well. I treat near-tied top candidates as ambiguous rather
than silently picking one: the agent still proposes a best guess (tie-broken
toward whichever candidate has primary-yard stock, since defaulting to an
out-of-stock variant helps no one), but flags the line item and routes the
whole order to human review instead of acting on a guess. A reviewer can
correct it via the UI's override control, which persists to `overrides` and
updates the line item for the next agent run.

## "Low risk" definition (the underspecified judgment call)

I defined low-risk / auto-dispatch-eligible as: every line item reconciled
with high confidence, every line item fully fulfillable right now (primary
stock + autonomous alt-yard reroutes, no leftover backorder), and — my own
addition — not a high-value one-off (non-recurring) client order (I used
>$1500/day as the cutoff). The third condition isn't strictly forced by the
brief, but "only auto-dispatch low-risk orders" implies risk is more than
"can we currently source the equipment" — a first-time, no-history client
placing a large order carries more exposure than the same order from an
established recurring account, so it's a case worth a human glance even when
inventory lines up cleanly. This is documented in `agent.py`'s module
docstring and is the one place I'd most want to validate against a real
policy owner.

## Backorders and reroutes

Reroute-to-alt-yard is autonomous and per-line-item, independent of the
overall order's risk verdict — it happens whenever primary stock is short,
even on an order that ends up needing review for other reasons (matches the
brief's "separately... reroute" wording). Any shortfall left after checking
both yards is recorded as `backorder_qty` on the line item and, by itself,
is enough to keep the whole order out of auto-dispatch — partial fulfillment
(ship now vs. wait for the rest) is treated as a judgment call for a human,
not something to guess at.

## A correction I made to my own first pass

I initially only logged a `dispatch_actions` row when a line item's quantity
came from primary stock, on the assumption the alt-yard `reroute` row already
covered it. On review that under-represents the audit trail: an order that's
100% sourced from the alt yard (e.g. ORD-9005/9006 in the seed data) would
show a reroute but no dispatch, which reads as "never actually shipped."
Fixed `tools.dispatch_order()` to also log a `dispatch` row (source_yard=alt)
for any alt-fulfilled quantity, and updated the matching test.

## Data quality handling

`alt_yard_inventory.csv` has a negative stock value for EQ-110 (-2), which
isn't physically meaningful. `check_alt_yard()` clamps negative values to 0
and notes the anomaly in its reasoning rather than propagating a negative
reroute quantity.

## What I'd do with more time

- Wire in a real LLM call (with the same `interpret_line_item` contract) for
  genuinely free-text requests instead of the `<qty>x <name>` pattern the
  seed data happens to follow, and add a confidence-calibration eval set.
- Concurrency: the SQLite writes (stock decrements) aren't wrapped in
  transactions spanning the whole per-order decision, so two orders processed
  in parallel could race on the same SKU's stock count.
- A richer risk model (e.g. weighting by client order history, not just
  client_type) instead of a single dollar threshold.
- Order-level partial-dispatch support (ship the fulfillable lines now,
  backorder the rest as a tracked sub-order) rather than an all-or-nothing
  auto-dispatch gate.
