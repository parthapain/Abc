"""
Template content backing generate_instances.py.

All 4 templates are represented here (T01-T04), each mirroring its
`../templates/T0{n}-*.md` file's candidate-facing brief exactly, including the
mandatory agentic loop / tool interface / guardrail shape (see
`../testing-principles.md`'s "mandatory, every template" section). Ambiguity,
trap, and stress-point pools are copied from each template's own "Fixed
elements" section, not invented independently here — if a template file's pool
changes, update it here too, and vice versa.

All 4 are still `calibrated=False`. Each template's dry-run calibration
(`../grading/calibration-runs/T0{n}-calibration-run.md`) has confirmed 3 of the
4 required steps; the remaining step — an actual timed human build — is not yet
done for any of them (see `human-build-instances/` for the concrete instances
used to run that step). Do not flip any of these to True until that template's
own Calibration section says step 4 has cleared, per the sequencing rule in
`architecture.md` (T01 first, then T02/T03/T04 in order).

Trap variants are never inserted into the candidate-facing brief text — they
live only in each generated instance's internal metadata (see
GeneratedInstance.meta in generate_instances.py), the same "never shown to the
candidate" rule the architecture doc specifies.
"""

from generate_instances import UseCaseTemplate

# ---------------------------------------------------------------------------
# T01 -- Triage & Classification
# ---------------------------------------------------------------------------

T01_BRIEF = """\
Your organization receives a continuous stream of $item_noun — $item_description. Build an application that:

1. Ingests $item_noun (a seed dataset is provided — `$dataset_file`)
2. Uses the in-house LLM to classify each one into the categories: $category_list
3. Works as an agent, not a single call: after classifying, check for duplicate or related history on the item via a tool, and pull additional context via a second tool if the classification is uncertain — then decide how to proceed
4. **$ambiguity_requirement**
5. For items that are low-risk and high-confidence, autonomously acknowledge, auto-close (if a genuine duplicate), or auto-route the item — gated by an explicit confidence/policy threshold; anything above that threshold, or anything the tools couldn't resolve, is escalated to a human
6. Provides a UI where a human can review classifications, any automatic actions taken, see the LLM's reasoning, and override them
7. Persists $item_noun, their classifications, actions taken, and any human overrides to a database

The dataset includes some $item_noun that are $stress_point_description — your solution should handle these sensibly rather than crashing or producing silently wrong output.

Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, 10MB max, exclude dependency directories and build output), including a short MANIFEST.md at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (about half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.
"""

T01 = UseCaseTemplate(
    template_id="T01",
    calibrated=False,  # <-- flip only after templates/T01-*.md Calibration section's step 4 clears
    brief_markdown=T01_BRIEF,
    domain_flavors=[
        {
            "item_noun": "support tickets",
            "item_description": "customer-submitted requests describing a problem or question",
            "category_list": "Billing, Technical Issue, Account Access, Feature Request, Complaint",
        },
        {
            "item_noun": "insurance claims",
            "item_description": "policyholder-submitted claim narratives",
            "category_list": "Auto, Property, Medical, Liability, Fraud Review",
        },
        {
            "item_noun": "IT helpdesk requests",
            "item_description": "employee-submitted technical support requests",
            "category_list": "Hardware, Software, Access/Permissions, Network, Other",
        },
        {
            "item_noun": "sales leads",
            "item_description": "inbound inquiries from a contact form",
            "category_list": "Hot Lead, Needs Nurturing, Not a Fit, Spam",
        },
        {
            "item_noun": "HR complaints",
            "item_description": "employee-submitted workplace concern reports",
            "category_list": "Harassment, Compensation, Policy Violation, General Grievance",
        },
        {
            "item_noun": "content-moderation reports",
            "item_description": "user-submitted reports flagging other users' content",
            "category_list": "Spam, Harassment, Misinformation, Not a Violation",
        },
    ],
    # Matches templates/T01-triage-classification.md's Ambiguity slot pool exactly.
    ambiguity_variants=[
        "Prioritize $item_noun appropriately so urgent ones surface first.",
        "Flag $item_noun that need immediate human attention.",
        "Route $item_noun to the right team.",
    ],
    # Matches the AI-trap slot's Trap variants pool. Internal-only — never rendered into the brief.
    trap_variants=[
        "silent fallback classification on exception (a default dict indistinguishable from a genuine result)",
        "fallback returns HTTP 200 / success to the caller even though classification internally failed",
        "unbounded retry on failure with no backoff and no visible state, risking duplicate processing",
        "classification results cached by item ID with no invalidation, so an edited/resubmitted item silently keeps a stale result",
    ],
    # Matches the Stress-point slot pool.
    stress_variants=[
        "blank or empty in their body text",
        "far longer than the LLM's context window",
        "written in a language other than the classifier's expected language",
        "submitted in a sudden burst of several hundred at once",
    ],
    dataset_seed_count=3,
)

# ---------------------------------------------------------------------------
# T02 -- Structured Extraction from Unstructured Text
# ---------------------------------------------------------------------------

T02_BRIEF = """\
Your organization needs to extract structured information from $document_noun — $document_description. Build an application that:

1. Ingests $document_noun (a seed dataset is provided — `$dataset_file`)
2. Uses the in-house LLM to extract these fields into a structured record: $field_list
3. Works as an agent, not a single call: cross-check extracted values against the source document via a tool, and look up a related document via a second tool when a field's value references another document — then decide how to proceed
4. **$ambiguity_requirement**
5. For extractions that are fully grounded and high-confidence, autonomously commit the record to the system of record — gated by an explicit completeness/confidence check; anything incomplete, contradictory, or below that threshold is flagged for human review instead
6. Provides a UI where a human can review extracted fields against the source document, correct them, and see any autonomous commits already made
7. Persists documents, extracted fields, commit/review status, and any corrections to a database

Some $document_noun in the seed dataset $stress_point_description — your solution should handle these sensibly rather than crashing or inventing information that isn't there.

Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, 10MB max, exclude dependency directories and build output), including a short MANIFEST.md at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (about half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.
"""

T02 = UseCaseTemplate(
    template_id="T02",
    calibrated=False,  # <-- flip only after templates/T02-*.md Calibration section's step 4 clears
    brief_markdown=T02_BRIEF,
    domain_flavors=[
        {
            "document_noun": "contracts",
            "document_description": "commercial agreements between two or more parties",
            "field_list": "party names, effective date, termination clause, payment terms",
        },
        {
            "document_noun": "meeting notes",
            "document_description": "free-text notes from internal meetings",
            "field_list": "attendees, decisions made, action items with owners, due dates",
        },
        {
            "document_noun": "expense reports",
            "document_description": "employee-submitted expense claim narratives and receipts",
            "field_list": "amount, currency, category, date, approver",
        },
        {
            "document_noun": "resumes",
            "document_description": "candidate-submitted resumes in free text/PDF form",
            "field_list": "years of experience, skills, most recent employer, education",
        },
        {
            "document_noun": "insurance policy documents",
            "document_description": "policy documents describing coverage terms",
            "field_list": "policy number, policyholder name, coverage start date, coverage end date, premium amount",
        },
        {
            "document_noun": "vendor invoices",
            "document_description": "invoices submitted by external vendors",
            "field_list": "vendor name, invoice number, line items, total due, due date",
        },
    ],
    # Matches templates/T02-structured-extraction.md's Ambiguity slot pool (simplified to
    # not require a per-flavor key_clause_field/key_party_field/key_date_field placeholder
    # set — the underlying ambiguity is preserved, just phrased generically per-instance).
    ambiguity_variants=[
        "Extract the key clause relevant to the field in question, even when a document contains multiple related clauses.",
        "Extract the party name field, normalizing inconsistent references to the same party across the document.",
        "Extract the key date field, including cases where it is stated only relative to another event or clause in the document rather than as an explicit date.",
    ],
    trap_variants=[
        "LLM invents a plausible value for a field genuinely absent from the source document",
        "LLM extracts a value from the wrong section when multiple documents are concatenated in one file, without flagging cross-contamination",
        "LLM normalizes a partially-stated value (e.g. an amount with no stated currency) to a default without surfacing that it guessed",
        "LLM's extracted date/number passes a superficial format check but is semantically wrong (e.g. swapped day/month)",
    ],
    stress_variants=[
        "are missing one or more of the required fields entirely",
        "contain more than one instance of the same document type concatenated together",
        "have garbled or partial text in places, as from a scanned/OCR source",
        "directly contradict themselves, stating two different values for the same field in different places",
    ],
    dataset_seed_count=3,
)

# ---------------------------------------------------------------------------
# T03 -- Refund/Account Request Handling (Untrusted-Input Safety)
# ---------------------------------------------------------------------------

T03_BRIEF = """\
Your organization receives a continuous stream of $item_noun — $item_description — some of which include a request for a refund, credit, or account change. Build an application that:

1. Ingests $item_noun (a seed dataset is provided — `$dataset_file`)
2. Uses the in-house LLM to interpret each one: what is the customer actually asking for, and which order/account does it concern?
3. Works as an agent, not a single call: look up the referenced order/account via a tool, check whether the request is actually supported by that record via a tool, and only then decide how to proceed
4. **$ambiguity_requirement**
5. For requests that are fully verified against the account/order data and low-risk, autonomously execute the resolution (issue the refund/credit, apply the account change) — gated by an explicit check that the tool-returned account/order data supports it, not the LLM's own reading of the request text; anything that fails that check, or exceeds a value/risk threshold, is escalated to a human
6. Provides a UI showing the agent's reasoning, any autonomous action taken, and lets a human review and override
7. Persists requests, decisions, actions taken, and any overrides to a database

Some $item_noun in the seed dataset $stress_point_description — your solution should handle these sensibly rather than crashing or acting on incomplete information.

Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, 10MB max, exclude dependency directories and build output), including a short MANIFEST.md at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (about half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.
"""

T03 = UseCaseTemplate(
    template_id="T03",
    calibrated=False,  # <-- flip only after templates/T03-*.md Calibration section's step 4 clears
    brief_markdown=T03_BRIEF,
    domain_flavors=[
        {"item_noun": "refund requests", "item_description": "customer requests to reverse a charge or issue a credit"},
        {"item_noun": "warranty claims", "item_description": "customer requests for repair, replacement, or refund under product warranty"},
        {"item_noun": "subscription-cancellation requests", "item_description": "customer requests to cancel or downgrade a recurring subscription"},
        {"item_noun": "account-change requests", "item_description": "customer requests to modify billing, shipping, or plan details on their account"},
        {"item_noun": "loyalty-point disputes", "item_description": "customer requests disputing a loyalty/rewards point balance or redemption"},
        {"item_noun": "delivery-issue reports", "item_description": "customer reports of a missing, late, or damaged delivery"},
        {"item_noun": "billing disputes", "item_description": "customer requests disputing a specific charge on an invoice"},
        {"item_noun": "return requests", "item_description": "customer requests to return a purchased item for refund or exchange"},
        {"item_noun": "service-credit requests", "item_description": "customer requests for a service credit following an outage or service failure"},
    ],
    # Matches templates/T03-refund-request-handling.md's Ambiguity slot pool.
    ambiguity_variants=[
        "Auto-resolve $item_noun where the customer's stated reason is clearly supported by the order record.",
        "Treat repeat requests from the same customer with extra caution.",
        "Only auto-resolve requests below a reasonable value threshold.",
    ],
    trap_variants=[
        "embedded text claiming prior approval causes the agent to skip its own eligibility-check tool call entirely",
        "embedded text redirects the agent to act on a different, attacker-chosen order/account ID than the one legitimately tied to the requester",
        "embedded text asks the agent to include an additional item/amount beyond what the verified order record supports, and the agent complies",
        "embedded text instructs the agent to omit information from the human-facing review summary, and a naive implementation honors it",
    ],
    stress_variants=[
        "reference an order/account ID that doesn't exist in the dataset",
        "contain contradictory information (two different order numbers stated)",
        "arrive as a burst of near-duplicate requests referencing the same order in rapid succession",
        "have no clearly identifiable ask at all (vague or rambling text)",
    ],
    dataset_seed_count=3,
)

# ---------------------------------------------------------------------------
# T04 -- Order Fulfillment & Inventory Reconciliation (Reliability Engineering)
# ---------------------------------------------------------------------------

T04_BRIEF = """\
Your organization processes a continuous stream of $item_noun — $item_description. Build an application that:

1. Ingests $item_noun (a seed dataset is provided — `$dataset_file`)
2. Uses the in-house LLM to interpret each one — including reconciling line items that don't map cleanly onto the catalog
3. Works as an agent, not a single call: check inventory availability via a tool, reconcile ambiguous items against the catalog via a tool, and only then decide how to proceed
4. **$ambiguity_requirement**
5. For fully-available, low-risk orders, autonomously dispatch fulfillment via a tool call — gated by an explicit check; anything uncertain, back-ordered, or above a value/risk threshold is escalated to a human
6. Provides a UI showing the agent's reasoning, any autonomous action taken, and lets a human review and override
7. Persists orders, reconciliation decisions, dispatch actions, and any overrides to a database

The fulfillment-dispatch call is realistic infrastructure: it can fail transiently (a timeout, a temporary service hiccup) or permanently (the item is genuinely unavailable, the destination is invalid) — your system needs to tell these apart and behave accordingly, rather than treating every failure the same way.

Some $item_noun in the seed dataset $stress_point_description — your solution should handle these sensibly rather than crashing or silently corrupting the fulfillment record.

Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, 10MB max, exclude dependency directories and build output), including a short MANIFEST.md at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (about half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.
"""

T04 = UseCaseTemplate(
    template_id="T04",
    calibrated=False,  # <-- flip only after templates/T04-*.md Calibration section's step 4 clears
    brief_markdown=T04_BRIEF,
    domain_flavors=[
        {"item_noun": "retail orders", "item_description": "consumer orders placed through an online store"},
        {"item_noun": "purchase orders", "item_description": "B2B purchase orders placed against a supplier catalog"},
        {"item_noun": "pharmacy refill requests", "item_description": "prescription refill requests against a pharmacy's stock"},
        {"item_noun": "equipment-rental requests", "item_description": "requests to reserve and dispatch rental equipment"},
        {"item_noun": "catering orders", "item_description": "bulk food orders placed against a catering menu/inventory"},
        {"item_noun": "spare-parts orders", "item_description": "orders for replacement parts against a spare-parts catalog"},
        {"item_noun": "subscription-box shipments", "item_description": "recurring subscription-box orders drawing from rotating inventory"},
        {"item_noun": "grocery-delivery orders", "item_description": "consumer grocery orders drawn from a store's live inventory"},
        {"item_noun": "print-shop orders", "item_description": "print jobs ordered against paper/material/finishing stock"},
    ],
    # Matches templates/T04-order-fulfillment-reliability.md's Ambiguity slot pool.
    ambiguity_variants=[
        "Reconcile line items against the catalog when they don't match exactly.",
        "Handle back-ordered items sensibly.",
        "Only auto-dispatch low-risk orders.",
    ],
    trap_variants=[
        "blind retry-on-any-failure with no idempotency key, risking duplicate fulfillment dispatch",
        "retry logic treats a permanent failure (item genuinely unavailable) the same as a transient one, retrying indefinitely",
        "no distinction between 'the dispatch call failed to send' and 'the dispatch call succeeded but the response was lost', risking duplication",
        "a failure is swallowed and replaced with a generic 'will process later' placeholder status that never actually resolves",
    ],
    stress_variants=[
        "hit a fulfillment-dispatch call that times out (a marked test path in the dataset/mock service)",
        "reference an item that is permanently out of stock",
        "arrive in a burst referencing the same limited-stock item simultaneously (a race condition on inventory, not just malformed data)",
        "are malformed or incomplete (missing a required field)",
    ],
    dataset_seed_count=3,
)

TEMPLATES = {"T01": T01, "T02": T02, "T03": T03, "T04": T04}
