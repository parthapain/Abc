# Build Brief — Airline Flight-Credit & Rebooking Request Handling

Your organization receives a continuous stream of customer emails about disrupted flights — some of which include a request for a refund, credit, or rebooking. Build an application that:

1. Ingests flight-credit and rebooking requests (seed datasets are provided — `flight_requests.csv`, `booking_records.csv`, and `rebooking_history.csv`)
2. Uses the in-house LLM to interpret each one: what is the customer actually asking for, and which booking does it concern?
3. Works as an agent, not a single call: look up the referenced booking via a tool, check whether the request is actually supported by that record via a tool, and only then decide how to proceed
4. **Only auto-resolve requests below a reasonable value threshold.**
5. **Auto-resolve requests where the customer's stated reason is clearly supported by the booking record.**
6. Autonomously execute the resolution (issue the refund/credit) via a tool call.
7. **Separately, for requests where the customer wants a straightforward rebooking rather than a refund and the booking still qualifies: look up the customer's recent rebooking history via a tool, and if they're under a reasonable cap for the relevant window, autonomously schedule the replacement flight via a tool call.**
8. Provides a UI showing the agent's reasoning, any autonomous action taken (resolutions *and* any replacements scheduled), and lets a human review and override
9. Persists requests, decisions, actions taken (including any scheduled replacements), and any overrides to a database

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24 hours.
