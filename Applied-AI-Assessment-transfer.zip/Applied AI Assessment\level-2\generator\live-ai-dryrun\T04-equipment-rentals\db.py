"""
Persistence layer (SQLite).

Tables:
  orders                 - one row per rental order ingested
  line_items             - one row per parsed line item within an order
  reconciliation_decisions - the "in-house LLM" reconciliation call log (tool #1)
  dispatch_actions       - every autonomous dispatch / reroute tool call (tool #3 & #4)
  overrides              - every human override applied through the UI
  agent_runs             - full reasoning trace + risk verdict for one agent pass over an order

All code that touches the DB goes through this module so app.py / agent.py never
write raw SQL directly.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

DB_PATH = Path(__file__).parent / "rental_fulfillment.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    order_id            TEXT PRIMARY KEY,
    client_name         TEXT NOT NULL,
    client_type         TEXT NOT NULL,
    submitted_at        TEXT NOT NULL,
    raw_description      TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'ingested',
        -- ingested | processed_auto_dispatched | processed_needs_review |
        -- dispatched_by_human | held | rejected
    estimated_value     REAL,
    ingested_at         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS line_items (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id            TEXT NOT NULL REFERENCES orders(order_id),
    line_no             INTEGER NOT NULL,
    raw_text            TEXT NOT NULL,
    requested_qty       INTEGER NOT NULL,
    resolved_sku        TEXT,
    resolved_name       TEXT,
    unit_price          REAL,
    confidence          REAL,
    ambiguous           INTEGER NOT NULL DEFAULT 0,
    candidates_json      TEXT,
    fulfill_primary_qty  INTEGER NOT NULL DEFAULT 0,
    fulfill_alt_qty      INTEGER NOT NULL DEFAULT 0,
    backorder_qty        INTEGER NOT NULL DEFAULT 0,
    override_sku         TEXT,
    UNIQUE(order_id, line_no)
);

CREATE TABLE IF NOT EXISTS reconciliation_decisions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        TEXT NOT NULL REFERENCES orders(order_id),
    line_item_id    INTEGER NOT NULL REFERENCES line_items(id),
    method          TEXT NOT NULL,
    input_text      TEXT NOT NULL,
    resolved_sku    TEXT,
    confidence      REAL,
    candidates_json TEXT,
    reasoning       TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dispatch_actions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        TEXT NOT NULL REFERENCES orders(order_id),
    action_type     TEXT NOT NULL,  -- 'dispatch' | 'reroute'
    sku             TEXT,
    qty             INTEGER,
    source_yard     TEXT,           -- 'primary' | 'alt'
    ship_cost       REAL,
    reasoning       TEXT,
    autonomous      INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS overrides (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        TEXT NOT NULL REFERENCES orders(order_id),
    line_item_id    INTEGER,
    override_type   TEXT NOT NULL,  -- 'reconciliation' | 'dispatch' | 'hold' | 'reject' | 'reroute'
    old_value       TEXT,
    new_value       TEXT,
    actor           TEXT NOT NULL DEFAULT 'human_reviewer',
    note            TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_runs (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id                TEXT NOT NULL REFERENCES orders(order_id),
    reasoning_trace         TEXT NOT NULL,  -- JSON list of {step, tool, input, output, note}
    risk_level              TEXT NOT NULL,  -- 'low' | 'high'
    risk_reasons            TEXT,
    auto_dispatch_eligible  INTEGER NOT NULL,
    created_at              TEXT NOT NULL
);

-- reference tables mirroring the seed CSVs, so the app has its own durable copy
CREATE TABLE IF NOT EXISTS catalog (
    sku             TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    price_per_day   REAL NOT NULL,
    in_stock        INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS alt_yard_inventory (
    sku         TEXT PRIMARY KEY,
    alt_stock   INTEGER NOT NULL,
    ship_cost   REAL NOT NULL
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(reset: bool = False):
    if reset and DB_PATH.exists():
        DB_PATH.unlink()
    with get_conn() as conn:
        conn.executescript(SCHEMA)


# ---------------------------------------------------------------------------
# Catalog / alt-yard loading
# ---------------------------------------------------------------------------

def load_catalog_rows(rows: list[dict]):
    with get_conn() as conn:
        for r in rows:
            conn.execute(
                "INSERT OR REPLACE INTO catalog (sku, name, price_per_day, in_stock) "
                "VALUES (?, ?, ?, ?)",
                (r["sku"], r["name"], float(r["price_per_day"]), int(r["in_stock"])),
            )


def load_alt_yard_rows(rows: list[dict]):
    with get_conn() as conn:
        for r in rows:
            conn.execute(
                "INSERT OR REPLACE INTO alt_yard_inventory (sku, alt_stock, ship_cost) "
                "VALUES (?, ?, ?)",
                (r["sku"], int(r["alt_stock"]), float(r["ship_cost"])),
            )


def get_catalog() -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM catalog").fetchall()


def get_catalog_sku(sku: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM catalog WHERE sku = ?", (sku,)).fetchone()


def get_alt_yard_sku(sku: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM alt_yard_inventory WHERE sku = ?", (sku,)
        ).fetchone()


def decrement_primary_stock(sku: str, qty: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE catalog SET in_stock = MAX(in_stock - ?, 0) WHERE sku = ?",
            (qty, sku),
        )


def decrement_alt_stock(sku: str, qty: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE alt_yard_inventory SET alt_stock = MAX(alt_stock - ?, 0) WHERE sku = ?",
            (qty, sku),
        )


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

def upsert_order(order_id, client_name, client_type, submitted_at, raw_description,
                  status="ingested", estimated_value=None):
    with get_conn() as conn:
        exists = conn.execute(
            "SELECT 1 FROM orders WHERE order_id = ?", (order_id,)
        ).fetchone()
        if exists:
            conn.execute(
                "UPDATE orders SET status = ? WHERE order_id = ?", (status, order_id)
            )
        else:
            conn.execute(
                "INSERT INTO orders (order_id, client_name, client_type, submitted_at, "
                "raw_description, status, estimated_value, ingested_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (order_id, client_name, client_type, submitted_at, raw_description,
                 status, estimated_value, now_iso()),
            )


def set_order_status(order_id: str, status: str):
    with get_conn() as conn:
        conn.execute("UPDATE orders SET status = ? WHERE order_id = ?", (status, order_id))


def set_order_value(order_id: str, value: float):
    with get_conn() as conn:
        conn.execute(
            "UPDATE orders SET estimated_value = ? WHERE order_id = ?", (value, order_id)
        )


def get_order(order_id: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,)).fetchone()


def get_all_orders() -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM orders ORDER BY submitted_at").fetchall()


# ---------------------------------------------------------------------------
# Line items
# ---------------------------------------------------------------------------

def clear_line_items(order_id: str):
    with get_conn() as conn:
        conn.execute("DELETE FROM line_items WHERE order_id = ?", (order_id,))


def insert_line_item(order_id, line_no, raw_text, requested_qty, resolved_sku,
                      resolved_name, unit_price, confidence, ambiguous, candidates,
                      fulfill_primary_qty=0, fulfill_alt_qty=0, backorder_qty=0) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO line_items (order_id, line_no, raw_text, requested_qty, "
            "resolved_sku, resolved_name, unit_price, confidence, ambiguous, "
            "candidates_json, fulfill_primary_qty, fulfill_alt_qty, backorder_qty) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (order_id, line_no, raw_text, requested_qty, resolved_sku, resolved_name,
             unit_price, confidence, int(ambiguous), json.dumps(candidates),
             fulfill_primary_qty, fulfill_alt_qty, backorder_qty),
        )
        return cur.lastrowid


def update_line_item_fulfillment(line_item_id: int, fulfill_primary_qty: int,
                                  fulfill_alt_qty: int, backorder_qty: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE line_items SET fulfill_primary_qty = ?, fulfill_alt_qty = ?, "
            "backorder_qty = ? WHERE id = ?",
            (fulfill_primary_qty, fulfill_alt_qty, backorder_qty, line_item_id),
        )


def set_line_item_override_sku(line_item_id: int, sku: str, name: str, unit_price: float):
    with get_conn() as conn:
        conn.execute(
            "UPDATE line_items SET override_sku = ?, resolved_sku = ?, resolved_name = ?, "
            "unit_price = ?, confidence = 1.0, ambiguous = 0 WHERE id = ?",
            (sku, sku, name, unit_price, line_item_id),
        )


def get_line_items(order_id: str) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM line_items WHERE order_id = ? ORDER BY line_no", (order_id,)
        ).fetchall()


def get_line_item(line_item_id: int) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM line_items WHERE id = ?", (line_item_id,)
        ).fetchone()


# ---------------------------------------------------------------------------
# Reconciliation decisions
# ---------------------------------------------------------------------------

def log_reconciliation(order_id, line_item_id, method, input_text, resolved_sku,
                        confidence, candidates, reasoning):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO reconciliation_decisions (order_id, line_item_id, method, "
            "input_text, resolved_sku, confidence, candidates_json, reasoning, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (order_id, line_item_id, method, input_text, resolved_sku, confidence,
             json.dumps(candidates), reasoning, now_iso()),
        )


def get_reconciliations(order_id: str) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM reconciliation_decisions WHERE order_id = ? ORDER BY id",
            (order_id,),
        ).fetchall()


# ---------------------------------------------------------------------------
# Dispatch / reroute actions
# ---------------------------------------------------------------------------

def log_dispatch_action(order_id, action_type, sku, qty, source_yard, ship_cost,
                         reasoning, autonomous=True):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO dispatch_actions (order_id, action_type, sku, qty, source_yard, "
            "ship_cost, reasoning, autonomous, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (order_id, action_type, sku, qty, source_yard, ship_cost, reasoning,
             int(autonomous), now_iso()),
        )


def get_dispatch_actions(order_id: str) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM dispatch_actions WHERE order_id = ? ORDER BY id", (order_id,)
        ).fetchall()


def get_all_dispatch_actions() -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute("SELECT * FROM dispatch_actions ORDER BY id").fetchall()


# ---------------------------------------------------------------------------
# Overrides
# ---------------------------------------------------------------------------

def log_override(order_id, override_type, old_value, new_value, note, line_item_id=None,
                  actor="human_reviewer"):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO overrides (order_id, line_item_id, override_type, old_value, "
            "new_value, actor, note, created_at) VALUES (?,?,?,?,?,?,?,?)",
            (order_id, line_item_id, override_type, str(old_value), str(new_value),
             actor, note, now_iso()),
        )


def get_overrides(order_id: str) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM overrides WHERE order_id = ? ORDER BY id", (order_id,)
        ).fetchall()


# ---------------------------------------------------------------------------
# Agent runs (full reasoning trace)
# ---------------------------------------------------------------------------

def log_agent_run(order_id, reasoning_trace: list[dict], risk_level: str,
                   risk_reasons: list[str], auto_dispatch_eligible: bool):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO agent_runs (order_id, reasoning_trace, risk_level, risk_reasons, "
            "auto_dispatch_eligible, created_at) VALUES (?,?,?,?,?,?)",
            (order_id, json.dumps(reasoning_trace), risk_level,
             json.dumps(risk_reasons), int(auto_dispatch_eligible), now_iso()),
        )


def get_latest_agent_run(order_id: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM agent_runs WHERE order_id = ? ORDER BY id DESC LIMIT 1",
            (order_id,),
        ).fetchone()
