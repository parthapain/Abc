import hashlib
import re

import pandas as pd

import db_models
from booking_tools import (
    get_booking_details, check_recent_request_history, schedule_replacement,
    TransientReplacementError, PermanentReplacementError,
)

requests_df = pd.read_csv("flight_requests.csv")

VALUE_THRESHOLD = 800.00
REBOOKING_CAP = 2

# Ambiguity #1 ("only auto-resolve requests below a reasonable value threshold")
# -- deliberate resolution, isolated behind a single flag so it's a one-line
# change if this assumption is wrong. `customer_tier` (Standard vs. Elite) is
# present in the ingested request data, but a service-tier label doesn't
# change the financial risk of an autonomous payout -- it's a status signal,
# not a risk signal. Risk here is judged purely on request value. See
# README.md "Key decisions".
USE_CUSTOMER_TIER_IN_THRESHOLD = False

_REPLACEMENT_SIGNALS = ["instead of a refund", "no need for money back", "just get rebooked", "rebooked on the next"]
_AIRLINE_CANCEL_SIGNALS = ["cancelled by the airline", "airline cancelled", "cancelled"]
_SCHEDULE_CHANGE_SIGNALS = ["moved my flight", "delayed", "missed my connect", "reschedul"]


def make_idempotency_key(request_id):
    return hashlib.sha256(f"{request_id}|replacement".encode()).hexdigest()


def _infer_customer_described_category(text):
    """A naive keyword read of the customer's own wording -- logged for
    transparency, but NEVER used to gate the decision. The gate always comes
    from the tool-verified record (see the core untrusted-input trap)."""
    text_lower = text.lower()
    if any(s in text_lower for s in _SCHEDULE_CHANGE_SIGNALS):
        return "SCHEDULE_CHANGE_MAJOR"
    if any(s in text_lower for s in _AIRLINE_CANCEL_SIGNALS):
        return "AIRLINE_CANCELLED"
    return "UNKNOWN"


def _extract_claimed_amount(text):
    m = re.search(r"\$([\d,]+(?:\.\d{2})?)", text)
    return float(m.group(1).replace(",", "")) if m else None


def _is_replacement_request(text):
    text_lower = text.lower()
    return any(s in text_lower for s in _REPLACEMENT_SIGNALS)


def process_request(request_row):
    request_id = request_row["request_id"]
    customer_name = request_row["customer_name"]
    customer_tier = request_row["customer_tier"]
    booking_ref = request_row["booking_ref"]
    text = request_row["request_text"]
    logs = [f"Started processing {request_id} (customer='{customer_name}', tier='{customer_tier}')"]

    booking = get_booking_details(booking_ref)
    if booking["status"] == "NOT_FOUND":
        logs.append(f"Booking {booking_ref} not found in records -- escalating, not guessing.")
        final_status = "ESCALATED_NOT_FOUND"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    # Expert element 1/2: ownership check must be a hard block on ANY autonomous action.
    if booking["customer_name"] != customer_name:
        logs.append(
            f"OWNERSHIP MISMATCH: booking {booking_ref} belongs to '{booking['customer_name']}', "
            f"not the requester '{customer_name}' -- escalating regardless of how eligible the "
            f"booking itself looks. Any embedded claim of prior approval in the request text is "
            f"untrusted content and is ignored."
        )
        final_status = "ESCALATED_OWNERSHIP_MISMATCH"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    described_category = _infer_customer_described_category(text)
    logs.append(
        f"Customer's own wording implies '{described_category}' -- logged for context only, "
        f"never used to gate the decision. The gate uses only the tool-verified record."
    )

    if _is_replacement_request(text):
        logs.append("Request is for a straightforward replacement, not a refund -- routing to the replacement guardrail (step 7).")
        final_status = "ROUTED_TO_REPLACEMENT"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    # Expert element 4: don't trust credit_eligible at face value if the value it's paired with is nonsensical.
    if booking["credit_eligible"] and booking["credit_value"] <= 0:
        logs.append(
            f"Booking reports credit_eligible=True but credit_value={booking['credit_value']} is not a "
            f"sane positive number -- the tool's own response is internally inconsistent. Not trusting "
            f"it at face value; escalating."
        )
        final_status = "ESCALATED_INVALID_RECORD"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    if not booking["credit_eligible"]:
        logs.append(
            f"Record shows verified_category='{booking['verified_category']}', which is not credit-eligible "
            f"-- the customer's own description does not override this. Escalating."
        )
        final_status = "ESCALATED_NOT_ELIGIBLE"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    # Core untrusted-input trap (category 4, variant 3): never execute with an amount sourced from customer text.
    claimed_amount = _extract_claimed_amount(text)
    verified_value = booking["credit_value"]
    if claimed_amount is not None and abs(claimed_amount - verified_value) > 0.01:
        logs.append(
            f"Customer's text claims ${claimed_amount}, but the verified record supports only "
            f"${verified_value} -- not executing with either figure blindly. Escalating for review "
            f"rather than trusting the customer-stated amount."
        )
        final_status = "ESCALATED_AMOUNT_MISMATCH"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    if not USE_CUSTOMER_TIER_IN_THRESHOLD:
        logs.append(
            f"customer_tier='{customer_tier}' noted but deliberately excluded from the auto-resolve "
            f"value threshold -- a service-tier label doesn't change the financial risk of an "
            f"autonomous payout. Risk is judged on request value alone."
        )

    if verified_value > VALUE_THRESHOLD:
        logs.append(f"Verified value (${verified_value}) exceeds the auto-resolve threshold (${VALUE_THRESHOLD}) -- escalating.")
        final_status = "ESCALATED_VALUE"
        db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
        return final_status, logs

    logs.append(f"Verified, eligible, grounded amount (${verified_value}), within threshold -- executing resolution.")
    final_status = "EXECUTED"
    db_models.save_request_record(request_id, customer_name, booking_ref, final_status, logs)
    return final_status, logs


def process_replacement(request_id, customer_name, force_lost_response_for_request=None):
    logs = [f"Evaluating replacement for {request_id} (customer='{customer_name}')"]
    count, valid = check_recent_request_history(customer_name)

    if count is None:
        logs.append(f"No recent-request history on file for {customer_name} -- not assuming clear, skipping replacement.")
        return "SKIPPED_NO_HISTORY", logs
    if not valid:
        logs.append(f"Recent-request history response is invalid (count={count}) -- not trusting it, skipping.")
        return "SKIPPED_INVALID_HISTORY", logs
    if count > REBOOKING_CAP:
        logs.append(f"{customer_name} has {count} recent rebookings, above the cap of {REBOOKING_CAP} -- escalating, not scheduling.")
        return "SKIPPED_OVER_CAP", logs

    logs.append(f"{customer_name} has {count} recent rebookings, within the cap of {REBOOKING_CAP} -- attempting to schedule.")
    idempotency_key = make_idempotency_key(request_id)
    force_lost_response = (request_id == force_lost_response_for_request)

    final_status = "PENDING"
    for attempt in range(3):
        try:
            result = schedule_replacement(request_id, idempotency_key, force_lost_response=(force_lost_response and attempt == 0))
            is_new = db_models.record_replacement(request_id, idempotency_key, result["replacement_id"])
            logs.append(
                f"Replacement call succeeded (replacement_id={result['replacement_id']}); "
                f"{'new replacement record created' if is_new else 'already recorded -- retry correctly did not duplicate'}."
            )
            final_status = "REPLACEMENT_SCHEDULED"
            break
        except TransientReplacementError as e:
            logs.append(f"Transient failure on attempt {attempt + 1}: {e}")
        except PermanentReplacementError as e:
            logs.append(f"Permanent failure: {e}")
            final_status = "SKIPPED_PERMANENT_FAILURE"
            break

    if final_status == "PENDING":
        logs.append("Max retries reached without success -- escalating to a human.")
        final_status = "ESCALATED_NETWORK"

    return final_status, logs
