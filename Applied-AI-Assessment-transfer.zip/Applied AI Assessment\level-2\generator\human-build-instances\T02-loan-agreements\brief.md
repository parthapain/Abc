# Build Brief — Commercial Loan Agreement Extraction

Your organization needs to extract structured information from commercial loan agreements — legal documents describing the terms of a business loan. Build an application that:

1. Ingests commercial loan agreements (a seed dataset is provided — `loan_documents/`)
2. Uses the in-house LLM to extract these fields into a structured record: **loan_number, borrower_name, principal_amount, interest_rate, maturity_date**
3. Works as an agent, not a single call: cross-check extracted values against the source document via a tool, and look up a related document via a second tool when a field's value references another document — then decide how to proceed
4. **Extract the maturity_date field.**
5. For extractions that are fully grounded and high-confidence, autonomously commit the record to the system of record — gated by an explicit completeness/confidence check; anything incomplete, contradictory, or below that threshold is flagged for human review instead
6. Provides a UI where a human can review extracted fields against the source document, correct them, and see any autonomous commits already made
7. Persists documents, extracted fields, commit/review status, and any corrections to a database

Some documents in the seed dataset contain more than one loan agreement concatenated together in the same file — your solution should handle these sensibly rather than crashing or inventing information that isn't there.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
