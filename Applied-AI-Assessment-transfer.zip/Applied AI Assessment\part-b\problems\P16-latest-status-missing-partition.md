# P16 — Latest status per document

| Field | Value |
|---|---|
| **ID** | P16 |
| **Difficulty** | High |
| **Bug pattern** | Window function not partitioned |
| **Bug location** | SQL |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

Each document accumulates status events over time. A dashboard shows the current status of every document — that is, each document's most recent event.

The dashboard shows exactly **one** document, no matter how many exist. The one it shows is correct; the rest are simply absent.

### Required behaviour

Return `(document_id, status)` — the most recent event for **each** document — ordered by `document_id` ascending.

### Schema

```sql
CREATE TABLE status_events (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL   -- 'YYYY-MM-DD HH:MM:SS'
);
```

---

## Fixture — `P16.sql`

```sql
CREATE TABLE status_events (
    id          INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

INSERT INTO status_events (id, document_id, status, created_at) VALUES
    (1, 1, 'pending', '2024-01-01 10:00:00'),
    (2, 1, 'indexed', '2024-01-03 10:00:00'),
    (3, 2, 'pending', '2024-01-02 10:00:00'),
    (4, 2, 'failed',  '2024-01-04 10:00:00');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def latest_status(db_path: str) -> List[Tuple[int, str]]:
    """
    Return (document_id, status) for the most recent event of each document,
    ordered by document_id ascending.
    """
    query = """
        SELECT document_id, status
        FROM (
            SELECT document_id,
                   status,
                   ROW_NUMBER() OVER (ORDER BY created_at DESC) AS rn
            FROM status_events
        )
        WHERE rn = 1
        ORDER BY document_id
    """
    conn = _connect(db_path)
    try:
        return [(doc_id, status) for doc_id, status in conn.execute(query).fetchall()]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class StatusDashboard {

    // --- boilerplate: do not modify ---
    public static class DocStatus {
        public final int documentId;
        public final String status;

        public DocStatus(int documentId, String status) {
            this.documentId = documentId;
            this.status = status;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (documentId, status) for the most recent event of each document,
     * ordered by documentId ascending.
     */
    public static List<DocStatus> latestStatus(String dbPath) throws SQLException {
        String query =
            "SELECT document_id, status FROM ( " +
            "    SELECT document_id, status, " +
            "           ROW_NUMBER() OVER (ORDER BY created_at DESC) AS rn " +
            "    FROM status_events " +
            ") WHERE rn = 1 " +
            "ORDER BY document_id";

        List<DocStatus> results = new ArrayList<>();
        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new DocStatus(rs.getInt("document_id"), rs.getString("status")));
            }
        }
        return results;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record DocStatus(int DocumentId, string Status);

public static class StatusDashboard
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (DocumentId, Status) for the most recent event of each document,
    /// ordered by DocumentId ascending.
    /// </summary>
    public static List<DocStatus> LatestStatus(string dbPath)
    {
        const string query = @"
            SELECT document_id AS DocumentId, status AS Status
            FROM (
                SELECT document_id,
                       status,
                       ROW_NUMBER() OVER (ORDER BY created_at DESC) AS rn
                FROM status_events
            )
            WHERE rn = 1
            ORDER BY document_id";

        using var conn = Connect(dbPath);
        return conn.Query<DocStatus>(query).ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | 2 documents, 2 events each | `[(1,"indexed"), (2,"failed")]` | **Discriminator** — broken returns only the single globally-latest row |
| T2 | 1 document, 2 events | `[(1,"indexed")]` | Guard — with one document, global and per-document latest coincide |
| T3 | 3 documents, 1 event each | `[(1,"a"), (2,"b"), (3,"c")]` | **Discriminator** — broken returns 1 row |
| T4 | 1 document, 1 event | `[(7,"only")]` | Guard |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO status_events (id, document_id, status, created_at) VALUES
    (1,1,'pending','2024-01-01 10:00:00'),(2,1,'indexed','2024-01-03 10:00:00');
-- T3
INSERT INTO status_events (id, document_id, status, created_at) VALUES
    (1,1,'a','2024-01-01 10:00:00'),(2,2,'b','2024-01-02 10:00:00'),(3,3,'c','2024-01-03 10:00:00');
-- T4
INSERT INTO status_events (id, document_id, status, created_at) VALUES
    (1,7,'only','2024-01-01 10:00:00');
```

---

## Reference solution

```diff
  SELECT document_id,
         status,
-        ROW_NUMBER() OVER (ORDER BY created_at DESC) AS rn
+        ROW_NUMBER() OVER (PARTITION BY document_id ORDER BY created_at DESC) AS rn
  FROM status_events
```

### Why

Without `PARTITION BY`, the window is the **entire result set**. `ROW_NUMBER()` numbers every event in the table from 1 upward, so exactly one row anywhere receives `rn = 1` — the single most recent event across all documents. The outer `WHERE rn = 1` then keeps that one row.

`PARTITION BY document_id` restarts the numbering for each document, so each one gets its own `rn = 1`. The window frame is the whole point of the construct, and omitting the partition quietly reduces "latest per group" to "latest overall".

T2 is why this reaches production: with a single document in the fixture, the global maximum *is* the per-document maximum, and the query looks correct. It only fails once a second document exists.

Note that a candidate may instead rewrite this as a correlated subquery or a join against `MAX(created_at)` grouped by `document_id`. Both are correct and should be accepted — but watch for ties, which `ROW_NUMBER()` breaks arbitrarily while a `MAX`-join returns twice.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Partitioning correctly but ordering `created_at ASC` | T1 — returns the *oldest* status per document |
| `GROUP BY document_id` with a bare `status` in the select list | Non-deterministic status; verify against T1 |
| Removing the `WHERE rn = 1` filter | T1, T3 — every event returned |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is a single row returned, not a SQL error
- [ ] **Confirm the sandbox's SQLite is 3.25 or newer** — window functions are unavailable before that, which would turn this into a syntax error rather than a logic bug
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Correct `MAX`-join or correlated-subquery rewrites are accepted by the grader
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
