"""
Agent orchestration — this is the core of the brief.

process_request() drives one flight-credit/rebooking request through:
  1. interpret        (interpreter.interpret_request - "LLM" step)
  2. lookup_booking    (tool)
  3. verify_request_supported (tool)
  4. decide             - threshold / cap gates, applied in code, not by the interpreter
  5. act                 (issue_refund or schedule_rebooking tool, only if auto-resolved)

Every step is written to the reasoning_log table via db.log_step so the UI can show the
full trace, and every terminal outcome updates requests.status so the UI can list/filter.

Business gates (documented further in RATIONALE.md):
  REFUND_VALUE_THRESHOLD - refunds at or below this amount, for a request that is fully
                            supported by the booking record, are auto-resolved. Above it,
                            the request is always sent for human review even if supported,
                            per brief requirement #4.
  REBOOKING_CAP           - customers with fewer than this many rebookings in the last 30
                            days (per rebooking_history.csv) are auto-scheduled; at or
                            above the cap, a human reviews it, per brief requirement #7.

Refund amounts are always taken from the booking record's credit_value (the system of
record), never from a dollar figure the customer typed in free text — see RATIONALE.md
for why (FR-8007 in the seed data is the case that motivates this).
"""
import interpreter
import tools
import db

REFUND_VALUE_THRESHOLD = 500.00
REBOOKING_CAP = 2


def process_request(req: dict) -> dict:
    request_id = req["request_id"]
    customer_name = req["customer_name"]
    booking_ref_field = req["booking_ref"]
    text = req["request_text"]

    # Step 1: interpret
    intent = interpreter.interpret_request(text, booking_ref_field)
    db.log_step(request_id, "interpret", {
        "input": text,
        "output": intent,
        "description": "Deterministic stand-in for the in-house LLM classified the "
                        "customer's request text into a structured intent.",
    })

    # Step 2: lookup_booking (tool)
    booking = tools.lookup_booking(intent["referenced_booking_ref"])
    db.log_step(request_id, "lookup_booking", {
        "booking_ref": intent["referenced_booking_ref"],
        "found": booking is not None,
        "record": booking,
    })

    if booking is None:
        return _finalize(request_id, "flagged_review", [
            f"No booking record found for '{intent['referenced_booking_ref']}'."
        ])

    # Step 3: verify_request_supported (tool)
    verification = tools.verify_request_supported(intent, booking, customer_name)
    db.log_step(request_id, "verify_request_supported", verification)

    if not verification["supported"]:
        return _finalize(request_id, "flagged_review", verification["reasons"])

    # Step 4/5: decide + act, branching on interpreted action
    if intent["action"] == "refund":
        return _handle_refund(request_id, intent, booking)
    elif intent["action"] == "rebooking":
        return _handle_rebooking(request_id, intent, booking, customer_name)
    else:
        return _finalize(request_id, "flagged_review", ["Unrecognized request action."])


def _handle_refund(request_id: str, intent: dict, booking: dict) -> dict:
    amount = booking["credit_value"]
    notes = []
    if intent["stated_amount"] is not None and abs(intent["stated_amount"] - amount) > 0.01:
        notes.append(
            f"Customer's stated amount (${intent['stated_amount']:.2f}) differs from the "
            f"booking record's authorized credit_value (${amount:.2f}). The record is treated "
            f"as authoritative; resolving at ${amount:.2f}."
        )

    if amount > REFUND_VALUE_THRESHOLD:
        db.log_step(request_id, "decide", {
            "decision": "flagged_review",
            "reason": f"Refund amount ${amount:.2f} exceeds auto-resolve threshold "
                      f"${REFUND_VALUE_THRESHOLD:.2f}.",
            "notes": notes,
        })
        return _finalize(request_id, "flagged_review", [
            f"Refund amount ${amount:.2f} exceeds the ${REFUND_VALUE_THRESHOLD:.2f} "
            f"auto-resolve threshold; requires human review."
        ] + notes)

    db.log_step(request_id, "decide", {
        "decision": "auto_refund",
        "amount": amount,
        "notes": notes,
    })
    result = tools.issue_refund(request_id, booking["booking_ref"], amount, source="agent")
    db.log_step(request_id, "act", {"tool": "issue_refund", "result": result})
    return _finalize(request_id, "auto_resolved", notes, final_action_type="refund", final_amount=amount)


def _handle_rebooking(request_id: str, intent: dict, booking: dict, customer_name: str) -> dict:
    history_count = tools.lookup_rebooking_history(customer_name)
    db.log_step(request_id, "lookup_rebooking_history", {
        "customer_name": customer_name,
        "rebookings_last_30_days": history_count,
        "cap": REBOOKING_CAP,
    })

    if history_count >= REBOOKING_CAP:
        db.log_step(request_id, "decide", {
            "decision": "flagged_review",
            "reason": f"{history_count} rebookings in the last 30 days meets/exceeds cap "
                      f"of {REBOOKING_CAP}.",
        })
        return _finalize(request_id, "flagged_review", [
            f"Customer has {history_count} rebookings in the last 30 days, at/over the "
            f"cap of {REBOOKING_CAP}; requires human review."
        ])

    db.log_step(request_id, "decide", {"decision": "auto_rebooking", "history_count": history_count})
    result = tools.schedule_rebooking(request_id, booking["booking_ref"], booking["flight_route"], source="agent")
    db.log_step(request_id, "act", {"tool": "schedule_rebooking", "result": result})
    return _finalize(request_id, "auto_resolved", [], final_action_type="rebooking", final_amount=None)


def _finalize(request_id: str, status: str, reasons, final_action_type=None, final_amount=None) -> dict:
    if reasons:
        db.log_step(request_id, "summary", {"status": status, "reasons": reasons})
    db.update_request_status(request_id, status, final_action_type, final_amount)
    return {"request_id": request_id, "status": status, "reasons": reasons}
