from app.extraction import extract_fields_llm, extract_note_maturity, note_supersedes_date


def test_explicit_fields_extracted():
    text = (
        "COMMERCIAL LOAN AGREEMENT\n\nLoan Number: LN-9001\nBorrower: Test Co LLC\n\n"
        "This Agreement is entered into as of 2026-01-01 (the \"Closing Date\").\n"
        "Section 1 (Closing): The Closing Date of this Agreement is 2026-01-01.\n"
        "Section 3 (Term): The Maturity Date of this Loan shall be the date twelve (12) "
        "months after the Closing Date set forth in Section 1.\n"
        "Principal Amount: The original principal amount of this Loan is $100,000.00.\n"
        "Interest Rate: Interest accrues on the outstanding principal balance at a fixed "
        "rate of 5.00% per annum.\n"
        "Signed: Test Co LLC, by its authorized officer.\n"
    )
    r = extract_fields_llm(text)
    assert r.loan_number == "LN-9001"
    assert r.borrower_name == "Test Co LLC"
    assert r.principal_amount == "100,000.00"
    assert r.interest_rate == "5.00"
    assert r.maturity_date == "2027-01-01"
    assert r.maturity_date_type == "computed"


def test_hyphenated_month_word_parses():
    """Regression test: 'forty-eight (48) months' must parse (hyphenated word)."""
    text = (
        "Loan Number: LN-9002\nBorrower: X\n"
        "This Agreement is entered into as of 2026-03-01 (the \"Closing Date\").\n"
        "Section 1 (Closing): The Closing Date of this Agreement is 2026-03-01.\n"
        "Section 3 (Term): The Maturity Date of this Loan shall be the date forty-eight (48) "
        "months after the Closing Date set forth in Section 1.\n"
    )
    r = extract_fields_llm(text)
    assert r.maturity_date == "2030-03-01"


def test_reference_to_promissory_note_flagged():
    text = (
        "Loan Number: LN-9003\nBorrower: X\n"
        "Section 3 (Term): The Maturity Date of this Loan shall be as set forth in the "
        "Promissory Note executed concurrently herewith.\n"
    )
    r = extract_fields_llm(text)
    assert r.maturity_reference_needed is True
    assert r.maturity_date_type == "reference"
    assert r.maturity_date is None


def test_missing_interest_rate_flagged():
    text = (
        "Loan Number: LN-9004\nBorrower: X\n"
        "Interest Rate: To be determined pursuant to a forthcoming Rate Addendum, not yet "
        "executed as of the Closing Date.\n"
    )
    r = extract_fields_llm(text)
    assert r.interest_rate is None
    assert any("Rate Addendum" in n for n in r.notes)


def test_borrower_signature_mismatch_flagged():
    text = (
        "Loan Number: LN-9005\n"
        "This Agreement is entered into as of 2026-01-01 between the Lender and "
        "Acme Inc. (the \"Borrower\").\n"
        "Signed: Acme LLC, by its authorized officer.\n"
    )
    r = extract_fields_llm(text)
    assert r.borrower_name == "Acme Inc."
    assert r.borrower_name_variant == "Acme LLC"


def test_extract_note_maturity():
    note_text = "PROMISSORY NOTE\nMaturity Date: 2030-06-30\n"
    assert extract_note_maturity(note_text) == "2030-06-30"


def test_note_supersedes_date():
    note_text = (
        "AMENDED AND RESTATED PROMISSORY NOTE\n"
        "This Amended and Restated Promissory Note supersedes and replaces the original "
        "Promissory Note dated 2026-01-20 in its entirety.\n"
    )
    assert note_supersedes_date(note_text) == "2026-01-20"
