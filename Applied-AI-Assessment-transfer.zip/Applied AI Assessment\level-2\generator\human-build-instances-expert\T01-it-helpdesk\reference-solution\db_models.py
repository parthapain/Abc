import sqlite3
import json

DB_FILE = "helpdesk.db"


def get_connection():
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id TEXT PRIMARY KEY,
                requester_name TEXT,
                requester_tier TEXT,
                category TEXT,
                status TEXT,
                priority_flag TEXT,
                reasoning_log TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS resolution_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id TEXT,
                idempotency_key TEXT UNIQUE,
                resolution_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()


def save_ticket(ticket_id, requester_name, requester_tier, category, status, priority_flag, logs):
    with get_connection() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO tickets
                (ticket_id, requester_name, requester_tier, category, status, priority_flag, reasoning_log)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (ticket_id, requester_name, requester_tier, category, status, priority_flag, json.dumps(logs)))
        conn.commit()


def record_resolution(ticket_id, idempotency_key, resolution_id):
    """Returns True if this created a NEW row, False if one already existed
    for this idempotency_key (i.e. a retry correctly did not duplicate)."""
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT id FROM resolution_records WHERE idempotency_key = ?", (idempotency_key,)
        ).fetchone()
        if existing:
            return False
        conn.execute(
            "INSERT INTO resolution_records (ticket_id, idempotency_key, resolution_id) VALUES (?, ?, ?)",
            (ticket_id, idempotency_key, resolution_id),
        )
        conn.commit()
        return True


def count_resolution_records(ticket_id):
    with get_connection() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM resolution_records WHERE ticket_id = ?", (ticket_id,)
        ).fetchone()[0]
