# Build Brief — Warranty Claim Handling (Extended)

Your organization receives a continuous stream of warranty claims — customer requests for repair, replacement, or refund under product warranty, some of which include a request for a refund, credit, or account change. Build an application that:

1. Ingests warranty claims (seed datasets are provided — `orders.csv`, `claims.csv`, and `replacement_history.csv`)
2. Uses the in-house LLM to interpret each one: what is the customer actually asking for, and which order/account does it concern?
3. Works as an agent, not a single call: look up the referenced order/account via a tool, check whether the request is actually supported by that record via a tool, and only then decide how to proceed
4. **Only auto-resolve requests below a reasonable value threshold.**
5. **Treat repeat requests from the same customer with extra caution.**
6. For requests that are fully verified against the account/order data and low-risk, autonomously execute the resolution (issue the refund/credit, apply the account change) — gated by an explicit check that the *tool-returned* account/order data supports it, not the LLM's own reading of the request text; anything that fails that check, or exceeds a value/risk threshold, is escalated to a human
7. **Separately, for claims where the resolution is a straightforward replacement (not a refund) and the item is still within its warranty window: look up the customer's recent replacement history via a tool, and if they're under a reasonable replacement cap for the past 30 days, autonomously schedule a replacement shipment via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate.
8. Provides a UI showing the agent's reasoning, any autonomous action taken (resolutions *and* any replacement shipments scheduled), and lets a human review and override
9. Persists requests, decisions, actions taken (including any scheduled replacements), and any overrides to a database

Some claims in the seed dataset arrive as a burst of near-duplicate requests referencing the same order in rapid succession — your solution should handle these sensibly rather than crashing or acting on incomplete information.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
