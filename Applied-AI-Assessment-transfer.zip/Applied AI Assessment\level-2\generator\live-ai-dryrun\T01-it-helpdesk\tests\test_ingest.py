"""End-to-end smoke test: run the real seed CSVs through the full pipeline."""
from app import database as db
from app import ingest


def test_full_ingest_runs_and_produces_expected_outcomes(temp_db):
    results = ingest.run(reset=False)  # temp_db fixture already reset the DB
    by_id = {r["ticket_id"]: r for r in results}

    # Only 'new' tickets are actively triaged (see app/ingest.py docstring).
    assert "HD-3001" not in by_id  # historical, closed
    assert "HD-3007" not in by_id  # historical, open

    # HD-3010 duplicates the still-open HD-3007 from the same requester.
    assert db.get_ticket("HD-3010")["status"] == "closed"
    dup_actions = [a for a in db.list_actions("HD-3010") if a["action_type"] == "auto_closed_duplicate"]
    assert len(dup_actions) == 1

    # HD-3020: confirmed $15 discrepancy, below threshold -> courtesy resolution.
    assert db.get_ticket("HD-3020")["status"] == "resolved"

    # HD-3050: claimed $40 but billing shows $0 -> mismatch, no auto-resolution.
    assert db.get_ticket("HD-3050")["status"] != "resolved"
    assert any(f["flag_type"] == "billing_mismatch" for f in db.list_flags("HD-3050"))

    # HD-3055: confirmed $200 discrepancy, above threshold -> needs human approval.
    assert db.get_ticket("HD-3055")["status"] != "resolved"
    assert any(f["flag_type"] == "billing_above_threshold" for f in db.list_flags("HD-3055"))

    # HD-3060: confirmed $20 discrepancy, below threshold -> courtesy resolution.
    assert db.get_ticket("HD-3060")["status"] == "resolved"

    # HD-3030: urgent outage language -> flagged for human attention.
    assert any(f["flag_type"] == "urgent_language" for f in db.list_flags("HD-3030"))

    # HD-3040: empty body -> no category, needs human triage.
    cls = db.latest_classification("HD-3040")
    assert cls["category"] is None

    # Every 'new' ticket got a classification row.
    for ticket_id in by_id:
        assert db.latest_classification(ticket_id) is not None
