# Internal notes — T01 (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app — the whole point is to see what they do without being told where the tricky parts are.

## What's tricky about this dataset, in plain terms

**1. Two customers deserve urgent attention for different reasons, and the brief doesn't say which one wins.**
Look at ticket **T-1002** (calm tone, but a real billing mistake) vs. **T-1007** (very urgent tone, an account lockout) vs. **T-1010** (no urgency at all, but a genuinely bad support experience worth escalating). A good build should say, in its written notes, that it noticed this tension and picked a reasonable way to rank them — not just silently pick one.

**2. Some tickets are blank.**
Rows **T-1004, T-1014, T-1026, T-1054, T-1082** have no subject or body at all. Watch what the app does with these — does it crash, quietly file them as something wrong, or handle them sensibly?

**3. A few tickets are exact duplicates of each other.**
**T-1001 and T-1012** are word-for-word the same ticket from the same person. So are **T-1031/T-1032** and **T-1066/T-1067**. The brief asks the app to check for duplicates before acting — see if it actually catches these.

**4. The trickiest thing to check isn't in the data — it's in the code.**
The brief asks for "error handling if the AI call fails." A very common shortcut is to quietly return a fake "everything's fine, low priority" result when the AI call fails, instead of clearly marking it as failed. If that happens, and nothing stops it, a failed classification could get auto-approved as if it were a real, safe result. You can only see this by reading the code, not the data — check how the app handles an AI failure, and whether a failure could sneak through as "safe."

## What to check once the build is done

- Did the whole thing — the AI classification, the duplicate check, the auto-approval rule, the review screen, saving to a database — actually get built in the time given?
- Does a failed AI call get clearly marked as failed, or could it look like a normal, trustworthy result?
- Does the auto-approval step check more than just "the AI seems confident," or could a bad result sneak through?
- Do the blank tickets (T-1004, T-1014, T-1026, T-1054, T-1082) get handled without crashing?
- Do the duplicate tickets get recognized as duplicates?

Write up what you find as a new section at the bottom of `../../grading/calibration-runs/T01-calibration-run.md`.
