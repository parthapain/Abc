const state = { tickets: [], selectedId: null };

async function fetchTickets() {
  const res = await fetch("/api/tickets");
  state.tickets = await res.json();
  render();
}

function snippet(text, n = 90) {
  if (!text) return "(empty)";
  return text.length > n ? text.slice(0, n) + "…" : text;
}

function flagLabel(f) {
  return f.flag_type.replace(/_/g, " ");
}

function renderList() {
  const list = document.getElementById("ticket-list");
  list.innerHTML = "";
  const tpl = document.getElementById("ticket-row-template");

  for (const view of state.tickets) {
    const t = view.ticket;
    const cls = view.classification;
    const node = tpl.content.cloneNode(true);
    const row = node.querySelector(".ticket-row");
    row.dataset.id = t.ticket_id;
    if (t.ticket_id === state.selectedId) row.classList.add("active");
    if (view.flags.length > 0) row.classList.add("needs-attention");

    node.querySelector(".ticket-id").textContent = t.ticket_id;
    node.querySelector(".requester").textContent = `${t.requester_name} (${t.requester_tier})`;
    node.querySelector(".snippet").textContent = snippet(t.body_text);
    const badge = node.querySelector(".category-badge");
    badge.textContent = cls && cls.category ? cls.category : "Unclassified";

    const flagsEl = node.querySelector(".row-flags");
    for (const f of view.flags) {
      const chip = document.createElement("span");
      chip.className = "flag-chip" + (f.flag_type === "security_incident" ? " security" : "");
      chip.textContent = flagLabel(f);
      flagsEl.appendChild(chip);
    }

    row.addEventListener("click", () => {
      state.selectedId = t.ticket_id;
      render();
    });

    list.appendChild(node);
  }
}

function statusBadgeClass(status) {
  if (status === "resolved") return "status-resolved";
  if (status === "closed") return "status-closed";
  if (status === "routed") return "status-routed";
  return "status-new";
}

function timelineItem(kind, title, meta, extra) {
  const div = document.createElement("div");
  div.className = "timeline-item" + (kind === "human" ? " human" : "");
  const t = document.createElement("div");
  t.className = "ttype";
  t.textContent = title;
  div.appendChild(t);
  if (extra) {
    const e = document.createElement("div");
    e.textContent = extra;
    div.appendChild(e);
  }
  if (meta) {
    const m = document.createElement("div");
    m.className = "tmeta";
    m.textContent = meta;
    div.appendChild(m);
  }
  return div;
}

function renderDetail() {
  const panel = document.getElementById("detail-panel");
  const view = state.tickets.find(v => v.ticket.ticket_id === state.selectedId);
  if (!view) {
    panel.innerHTML = '<p class="empty-hint">Select a ticket to review the agent\'s classification, reasoning, and actions.</p>';
    return;
  }

  const { ticket, classification, actions, flags, overrides } = view;
  panel.innerHTML = "";

  const h2 = document.createElement("h2");
  h2.textContent = `${ticket.ticket_id} — ${ticket.requester_name}`;
  panel.appendChild(h2);

  const meta = document.createElement("div");
  meta.className = "detail-meta";
  const statusBadge = `<span class="badge ${statusBadgeClass(ticket.status)}">${ticket.status}</span>`;
  meta.innerHTML = `${ticket.requester_tier} requester &middot; submitted ${ticket.submitted_at} &middot; ${statusBadge}`;
  panel.appendChild(meta);

  const body = document.createElement("div");
  body.className = "body-text";
  body.textContent = ticket.body_text || "(empty ticket body)";
  panel.appendChild(body);

  const clsTitle = document.createElement("div");
  clsTitle.className = "section-title";
  clsTitle.textContent = "Classification";
  panel.appendChild(clsTitle);

  const clsBox = document.createElement("div");
  clsBox.className = "classification-box";
  if (classification) {
    clsBox.innerHTML = `
      <strong>${classification.category || "Unclassified"}</strong>
      <span class="confidence"> &middot; confidence ${classification.confidence ?? "n/a"}${classification.uncertain ? " (uncertain)" : ""}</span>
      <div class="reasoning">${classification.reasoning || ""}</div>
      ${classification.context_pulled ? `<div class="context-box">Additional context pulled: ${classification.context_pulled}</div>` : ""}
    `;
  } else {
    clsBox.textContent = "No classification recorded.";
  }
  panel.appendChild(clsBox);

  if (flags.length > 0) {
    const flagsTitle = document.createElement("div");
    flagsTitle.className = "section-title";
    flagsTitle.textContent = "Flags for human attention";
    panel.appendChild(flagsTitle);

    const flagsList = document.createElement("div");
    flagsList.className = "flags-list";
    for (const f of flags) {
      const div = document.createElement("div");
      div.className = "flag-item" + (f.flag_type === "security_incident" ? " security" : "");
      div.textContent = `${flagLabel(f)}: ${f.reason}`;
      flagsList.appendChild(div);
    }
    panel.appendChild(flagsList);
  }

  const actTitle = document.createElement("div");
  actTitle.className = "section-title";
  actTitle.textContent = "Agent tool calls & actions";
  panel.appendChild(actTitle);

  const timeline = document.createElement("div");
  timeline.className = "timeline";
  for (const a of actions) {
    const title = a.actor === "human" ? `Human override (${a.action_type})` : a.action_type.replace(/_/g, " ");
    let extra = "";
    try {
      const res = a.tool_result ? JSON.parse(a.tool_result) : null;
      if (res && res.message) extra = res.message;
    } catch (e) { /* ignore */ }
    if (!extra && a.tool_params) {
      try { extra = JSON.stringify(JSON.parse(a.tool_params)); } catch (e) { /* ignore */ }
    }
    timeline.appendChild(timelineItem(a.actor, title, `${a.tool_name || "human"} · ${a.created_at}`, extra));
  }
  panel.appendChild(timeline);

  if (overrides.length > 0) {
    const ovTitle = document.createElement("div");
    ovTitle.className = "section-title";
    ovTitle.textContent = "Override history";
    panel.appendChild(ovTitle);
    for (const o of overrides) {
      panel.appendChild(timelineItem("human", `${o.field}: ${o.old_value ?? "—"} → ${o.new_value}`, o.created_at, o.human_note || ""));
    }
  }

  // Override form
  const formTitle = document.createElement("div");
  formTitle.className = "section-title";
  formTitle.textContent = "Override";
  panel.appendChild(formTitle);

  const form = document.createElement("div");
  form.className = "override-form";

  const categories = ["Hardware", "Software Access", "Network/VPN", "Licensing & Reimbursement", "Security Incident"];
  const row1 = document.createElement("div");
  row1.className = "override-row";
  const select = document.createElement("select");
  for (const c of categories) {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    if (classification && classification.category === c) opt.selected = true;
    select.appendChild(opt);
  }
  row1.innerHTML = `<label>Correct category:</label>`;
  row1.appendChild(select);
  form.appendChild(row1);

  const noteBox = document.createElement("textarea");
  noteBox.placeholder = "Reason for override (optional, shown in the audit trail)";
  form.appendChild(noteBox);

  const actionsRow = document.createElement("div");
  actionsRow.className = "override-actions";

  const applyBtn = document.createElement("button");
  applyBtn.textContent = "Apply category override";
  applyBtn.addEventListener("click", async () => {
    await submitOverride(ticket.ticket_id, "category", select.value, noteBox.value);
  });
  actionsRow.appendChild(applyBtn);

  const reopenBtn = document.createElement("button");
  reopenBtn.className = "secondary";
  reopenBtn.textContent = "Reopen ticket";
  reopenBtn.addEventListener("click", async () => {
    await submitOverride(ticket.ticket_id, "status", "new", noteBox.value || "Reopened by human reviewer.");
  });
  actionsRow.appendChild(reopenBtn);

  form.appendChild(actionsRow);
  panel.appendChild(form);
}

async function submitOverride(ticketId, field, newValue, note) {
  await fetch(`/api/tickets/${ticketId}/override`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ field, new_value: newValue, note }),
  });
  await fetchTickets();
}

function renderSummary() {
  const el = document.getElementById("summary");
  const total = state.tickets.length;
  const needsAttention = state.tickets.filter(v => v.flags.length > 0).length;
  el.textContent = `${total} tickets · ${needsAttention} flagged for human attention`;
}

function render() {
  renderList();
  renderDetail();
  renderSummary();
}

document.getElementById("refresh-btn").addEventListener("click", fetchTickets);
fetchTickets();
