# Gemini build review — T04 "Catering Orders" instance

Submission reviewed at `D:\PyPrograms\T04-catering-orders` (`orchestrator.py`, `dispatch_client.py`, `db_models.py`, `app.py`, `MANIFEST.md`). Verified by reading the code and querying the actual `catering_fulfillment.db` the app produced — not just reading the rationale.

## What worked correctly

Checked against every scenario in `INTERNAL-metadata.md`, using the real DB rows:

- **ORD-7101** (reroute, cheap shipping): `REROUTED` / `ALT_KITCHEN`, order `DISPATCHED`. Correct.
- **ORD-7102** (reroute, shipping too costly): `ESCALATED_COST`, order `ESCALATED_PARTIAL`. Correct — didn't reroute just because a row existed in `alt_kitchen_inventory.csv`; it checked the cost.
- **ORD-7103** (unavailable everywhere): `ESCALATED_STOCK`, order escalated. Correctly did **not** reroute or auto-dispatch. (But see finding 1 below — the *label* and *mechanism* claimed for this in the rationale don't match what actually ran.)
- **ORD-7104–7107** (burst on one scarce SKU): all four tracked and escalated as four distinct orders, no collapsing/double-counting. Correct.
- **ORD-7108** (mixed available/unavailable): in-stock line item marked `AVAILABLE`, out-of-stock line item correctly routed through the reroute-cost check and escalated; order held for review rather than partially auto-shipped. A defensible, clearly-stated back-order policy. Correct in substance (see finding 1 for the label mismatch).
- **ORD-7109** (plain low-risk order): `DISPATCHED`. Correct.
- Two genuinely independent gates exist (`evaluate_alternate_reroute`-equivalent logic vs. the value/risk check) and don't collapse into one — matches the 2-guardrail shape.

## Findings

### 1. Written rationale doesn't match what the shipped code actually does (dimension 3 signal)

The `MANIFEST.md` rationale makes two specific factual claims about system behavior that are **false when you actually run the app and check the database**:

- Claims ORD-7103 "transition[s] directly to `ESCALATED_UNAVAILABLE`" via the `PermanentDispatchError` path in `dispatch_client.py`. **Actual DB status: `ESCALATED_PARTIAL`**, via `orchestrator.py`'s Guardrail 1 (alt-kitchen stock check), which fires and short-circuits the order *before* `dispatch_fulfillment()` is ever called. The `PermanentDispatchError` branch for `CAT-011` in `dispatch_client.py` is **dead code** — because Guardrail 1 always escalates any order containing an item with zero stock everywhere, `dispatch_fulfillment()` is never reached for that item, so the permanent-failure classification it's supposed to demonstrate never runs.
- Claims the mixed-order back-order policy produces a status called `ESCALATED_BACKORDER`. **Actual status: `ESCALATED_PARTIAL`** (the same generic escalation status used for every other guardrail-1 failure) — there's no `ESCALATED_BACKORDER` anywhere in the code.

This is exactly the kind of gap the AI-verification/bias-handling dimension is meant to catch: the rationale reads as a plausible, confident description of the system's behavior, but it wasn't checked against the actual running output. The specific mechanism the AI-trap in this instance targets — genuine transient-vs-permanent dispatch-failure handling — is real, correctly-structured code (bounded retry, distinct terminal states), but it's **never exercised by anything in this dataset** except by chance (the 10% random transient-failure roll), and the one deterministic "permanent failure" test case built into the code (`CAT-011`) can never fire given how Guardrail 1 is ordered. A candidate who ran their own app and read the resulting dashboard/DB before writing the rationale would have noticed the status name didn't match.

### 2. Minor: retry/permanent-failure path is effectively unverifiable from this dataset

Because the `CAT-011` permanent-failure branch is unreachable (see above) and the transient-failure branch is gated behind `random.random() < 0.1`, there's no deterministic order in this run that actually exercises `dispatch_fulfillment()`'s failure handling. The code (bounded 3-attempt retry, distinct `ESCALATED_NETWORK` vs `ESCALATED_UNAVAILABLE` states) looks correct on inspection, but "looks correct on inspection" is exactly what finding 1 shows isn't good enough on its own here.

## A confound in this test instance itself (fixed)

**ORD-7110** was designed to isolate the auto-dispatch value/risk guardrail in isolation (high-value order from a "trusted" recurring account, all items otherwise in stock). It didn't: `CAT-015` (Tent Canopy - 20x20) had `in_stock=2` in `catalog_inventory.csv` while ORD-7110 requests 3 (and ORD-7014 elsewhere in the dataset requests 1 more), and `CAT-015` isn't listed in `alt_kitchen_inventory.csv` at all — so **any** implementation, correct or not, escalated this order via the stock guardrail before the value guardrail was ever reached. Confirmed against the DB from this run: `CAT-015` on ORD-7110 showed `ESCALATED_STOCK`, not a value-based escalation.

**Fix applied:** `CAT-015`'s `in_stock` raised from 2 to 6 in `catalog_inventory.csv` — covers both ORD-7014 (1 unit) and ORD-7110 (3 units) with headroom, so ORD-7110 is now genuinely all-in-stock and the order's fate turns purely on the value/risk guardrail as intended. Note this invalidates the specific DB rows and status values discussed above for ORD-7110 in this writeup (captured before the fix) — a rerun against the corrected CSV is needed to re-verify the value-guardrail behavior specifically.

## Bottom line

Two of two guardrails structurally present and independently gated; ambiguity handling (back-order policy) reasoned about and stated, not defaulted silently; AI-trap (swallowed-failure) mitigation code is present and well-structured. But the rationale contains two factual claims about the system's own behavior that don't hold up against the actual database output — a real, concrete example of exactly the over-trust failure mode dimension 3 exists to catch, and worth treating as a meaningful mark-down there even though the underlying code architecture is otherwise solid.
