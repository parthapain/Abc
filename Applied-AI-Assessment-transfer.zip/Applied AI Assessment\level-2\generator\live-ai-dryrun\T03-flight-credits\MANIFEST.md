# Manifest

## How to run
```
python -m venv .venv
.venv\Scripts\activate          # (or . .venv/bin/activate on macOS/Linux)
pip install -r requirements.txt
python ingest.py --reset        # loads the 3 CSVs into flight_credits.db and runs the agent
python app.py                   # starts the UI at http://127.0.0.1:5000
```
Re-running `python ingest.py` without `--reset` is idempotent — it skips requests already
in the database rather than reprocessing them.

## Where things live

| Concern | File |
|---|---|
| Agent orchestration (the core logic: interpret -> lookup -> verify -> decide -> act) | `agent.py` |
| Tool definitions (lookup_booking, verify_request_supported, issue_refund, lookup_rebooking_history, schedule_rebooking) | `tools.py` |
| "LLM" interpretation step (deterministic stand-in, documented contract for a real model swap) | `interpreter.py` |
| Persistence (SQLite schema + all read/write functions; every other module goes through this) | `db.py` |
| CSV ingestion + batch processing entry point | `ingest.py` |
| Web UI + human review/override endpoints | `app.py` |
| UI templates | `templates/base.html`, `templates/index.html`, `templates/detail.html` |
| UI styling | `static/style.css` |
| Tests | `tests/test_interpreter.py`, `tests/test_tools.py`, `tests/test_agent.py`, `tests/conftest.py` |
| Design decisions / rationale | `RATIONALE.md` |
| Seed data (as provided) | `brief.md`, `flight_requests.csv`, `booking_records.csv`, `rebooking_history.csv` |
| Generated at runtime (not committed logic, just output) | `flight_credits.db` |

## Data flow
`ingest.py` reads the 3 CSVs, loads `booking_records.csv` and `rebooking_history.csv` into
their own reference tables, then for each row of `flight_requests.csv` calls
`agent.process_request()`, which:
1. calls `interpreter.interpret_request()` (the "LLM" step),
2. calls the `tools.lookup_booking` tool,
3. calls the `tools.verify_request_supported` tool,
4. applies the auto-resolve value threshold (refunds) or rebooking cap (rebookings) in
   `agent.py` itself,
5. if auto-resolving, calls `tools.issue_refund` or `tools.schedule_rebooking`.

Every step writes to `reasoning_log` via `db.log_step`; every executed action writes to
`actions` via `db.record_action`. The Flask UI (`app.py`) reads both tables to render the
per-request trace, and `POST /request/<id>/override` lets a human approve, deny, or
reverse a decision, recorded in the `overrides` table.

## Tests
24 tests, `python -m pytest tests/ -v` — all passing at time of submission. Covers the
interpreter's classification/extraction, each tool in isolation, and full agent runs over
every edge case represented in the seed data (ineligible booking, over-threshold refund,
customer-name mismatch + embedded injection attempt, missing booking, negative credit
value, stated-amount-vs-record-amount mismatch, rebooking under/at cap, and a customer
absent from the rebooking history file).
