# Superseded

This document has been replaced. The earlier Level 2 design (built before Level 1 results were known — 300 of 1,000+ candidates cleared) assumed a shared use case and a simpler scoring model. Once real numbers landed, the design was rebuilt from scratch against the actual constraints: 300+ distinct use cases, only 3 human reviewers, an AI-based first-pass rubric gate, and a high-difficulty bar.

**Current Level 2 design lives in:**

- [`rubric.md`](rubric.md) — the four scoring dimensions, used by both the AI grader and the human reviewers
- [`generator/architecture.md`](generator/architecture.md) — how 300+ comparable-but-unique use cases are produced from a small template set
- [`templates/`](templates/) — the templates themselves (2 fully worked, pre-calibration)
- [`grading/`](grading/) — the AI-grading prompt, calibration process, and human-review cutoff mechanism
- [`dependencies/llm-gateway-logging.md`](dependencies/llm-gateway-logging.md) — now a closed record: no server-side log exists, and rubric dimension 3 was redesigned around repo + rationale evidence as a result
- [`logistics.md`](logistics.md) — provisioning, communication, and submission mechanics

See `../design-rationale.md` for the full reasoning behind this rebuild, including why the previous principles document didn't fit the actual scale once Level 1 results were in.
