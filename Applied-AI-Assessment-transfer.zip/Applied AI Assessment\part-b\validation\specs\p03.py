"""P03 — Monthly ingestion report. Medium · SQL-located · date-boundary error."""

META = {"difficulty": "Medium", "location": "SQL", "pattern": "date boundary excludes final day"}

SCHEMA = """
CREATE TABLE ingestion_events (
    id             INTEGER PRIMARY KEY,
    document_name  TEXT NOT NULL,
    created_at     TEXT NOT NULL,   -- 'YYYY-MM-DD HH:MM:SS'
    event_type     TEXT NOT NULL
);
"""

_BROKEN_SQL = """
    SELECT document_name
    FROM ingestion_events
    WHERE event_type = 'ingested'
      AND created_at BETWEEN ? AND date(?, '+1 month', '-1 day')
    ORDER BY created_at
"""

_FIXED_SQL = """
    SELECT document_name
    FROM ingestion_events
    WHERE event_type = 'ingested'
      AND created_at >= ?
      AND created_at < date(?, '+1 month')
    ORDER BY created_at
"""

MONTH_START = "2024-03-01"


def broken(conn):
    return [r[0] for r in conn.execute(_BROKEN_SQL, (MONTH_START, MONTH_START)).fetchall()]


def fixed(conn):
    return [r[0] for r in conn.execute(_FIXED_SQL, (MONTH_START, MONTH_START)).fetchall()]


# Note for reviewers: `created_at <= date(?, '+1 month')` is NOT a distinct wrong
# fix here. Because created_at carries a time component, '2024-04-01 00:00:00'
# sorts after the bare string '2024-04-01', so `<=` and `<` are equivalent on any
# realistic row. Do not document it as a trap the suite catches — it isn't one.
WRONG_FIXES = {
    "dropped the event_type filter": lambda conn: [
        r[0]
        for r in conn.execute(
            _FIXED_SQL.replace("WHERE event_type = 'ingested'", "WHERE 1=1"),
            (MONTH_START, MONTH_START),
        ).fetchall()
    ],
}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
                (1, 'policy.pdf',   '2024-03-15 10:00:00', 'ingested'),
                (2, 'contract.pdf', '2024-03-31 14:22:00', 'ingested'),
                (3, 'february.pdf', '2024-02-28 09:00:00', 'ingested');
        """,
        "expected": ["policy.pdf", "contract.pdf"],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
                (1, 'alpha.pdf', '2024-03-05 08:00:00', 'ingested'),
                (2, 'beta.pdf',  '2024-03-18 16:30:00', 'ingested');
        """,
        "expected": ["alpha.pdf", "beta.pdf"],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
                (1, 'lastsecond.pdf', '2024-03-31 23:59:59', 'ingested');
        """,
        "expected": ["lastsecond.pdf"],
    },
    "T4": {
        "role": "guard",
        "seed": """
            INSERT INTO ingestion_events (id, document_name, created_at, event_type) VALUES
                (1, 'inmarch.pdf',  '2024-03-10 12:00:00', 'ingested'),
                (2, 'nextmonth.pdf','2024-04-01 00:00:00', 'ingested'),
                (3, 'removed.pdf',  '2024-03-11 12:00:00', 'deleted');
        """,
        "expected": ["inmarch.pdf"],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
