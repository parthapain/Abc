# HirePro — Critical Path Questions

**Send by:** Day 1 · **Written answers needed by:** Day 3
**Why the deadline:** answers 2 and 3 determine *what problems get authored*, not just how they are packaged. If either is unresolved by Day 3 we commit to the fallback design and proceed, accepting reduced scope.

**Context for HirePro:** ~1 hour proctored assessment, 200–500 candidates, 2 days × 3 slots = 6 unique papers. Part A = 21 MCQs from your bank. Part B = 2 custom debugging problems, candidate chooses Python / Java / C#.

---

## Blocking — answers change what we build

### 1. Can the coding sandbox seed a small database that submitted code queries?

Each Part B problem is a small data pipeline: run a SQL query, then process the results. For the SQL half to be gradable, the sandbox must provide a pre-seeded database (SQLite preferred — file-based, no server) that the candidate's submitted code can open and query at run time.

- Is this supported?
- Is it supported in **all three** of Python, Java, and C#?
- If not SQLite, what is available — an in-memory DB, a fixture file, a pre-provisioned Postgres instance?

> **If no:** we fall back to supplying query results as fixed in-memory data with the SQL shown as read-only context. **This removes every SQL-located bug from the assessment** — roughly half the planned problems — and Part B becomes host-language logic only.

### 2. Is C#/.NET a supported runtime for custom coding questions?

We are committing to three language options so candidates from Java, .NET, and database backgrounds compete on equal footing. Please confirm C#/.NET is available for custom (not just bank) questions, and specify the runtime version and which DB access libraries are present (we plan on **Dapper**; `System.Data.SQLite` or `Microsoft.Data.Sqlite` also needed for question 1 above).

Same confirmation needed for Java (JDBC + SQLite driver) and Python (`psycopg2` / `sqlite3`).

> **If C# is unavailable:** we drop to Python + Java and must inform .NET candidates before the test opens.

### 3. What is the import format for custom coding questions?

Please share the template/spec — CSV, JSON, or manual entry — covering:

- Problem statement field (does it accept Markdown? code blocks?)
- Starter/broken code per language
- Hidden test case schema (stdin/stdout pairs, unit-test harness, or function-signature based?)
- Any per-question resource files (needed for the DB fixture in question 1)
- Runtime/timeout configuration
- Bulk import limits — we have up to 24 problems × 3 language variants

---

## Blocking — answers change the scoring design

### 4. Will you share historical item difficulty data (p-values) for the bank questions?

We are setting an **absolute** pass mark on Part A that gates access to Part B in-session. To set it defensibly rather than by guesswork, we need the historical proportion-correct for the items drawn, or at minimum a per-complexity-band average (Low / Medium / High).

> **If unavailable:** we set a provisional cutoff from the dress rehearsal and accept a wider error margin on the first run.

### 5. Does the bank hold enough items per topic × complexity cell to build 6 low-overlap papers?

Requested Part A composition per paper (21 items):

| Topic | Low | Medium | High |
|---|---|---|---|
| Data Structures & Algorithms | 1 | 1 | 1 |
| Python | 1 | 3 | 1 |
| Gen AI / LLM concepts | 1 | 3 | 1 |
| ML & Statistics | 1 | 1 | 1 |
| PostgreSQL | 1 | 2 | — |
| API / Backend fundamentals | — | 1 | — |
| Data wrangling | — | 1 | — |

Across 6 papers with minimal repetition, the thinnest cells need roughly **18 distinct items** (e.g. Python-Medium, GenAI-Medium). Please confirm availability **per cell** — particularly for Gen AI / LLM concepts and Data wrangling, which are the newest topic areas and most likely to be thin.

> **If a cell is short:** tell us which, and we will redistribute counts to topics with depth rather than accept repeated items across slots.

---

## Non-blocking — affects rigor, not feasibility

### 6. Randomization granularity

Can questions be randomized **per candidate**, or only per paper/slot? Per-candidate is strongly preferred: with 6 slots on consecutive days, per-slot assignment staggers leakage rather than preventing it and systematically advantages Day 2 candidates. It also does nothing about collusion within a room.

### 7. Anchor items across papers

Can we force ~5 identical items to appear in **all 6** papers? This lets us statistically equate difficulty between slots after the fact, so scores from different papers are comparable. Optional but valuable.

### 8. Proctoring controls — please confirm what is enforced

Our stated policy is that Level 1 is **unassisted**. Please confirm which of these are active: screen lockdown, copy-paste block, camera monitoring, face detection, second-device detection. We will state the enforced set explicitly to candidates.

### 9. Section gating mechanics

Confirm Part B can be **conditionally unlocked** in-session based on the Part A score, and what the candidate sees if they do not clear the cutoff (test terminates / message shown / time returned).

### 10. Partial credit on coding questions

Can a Part B question award partial credit for passing a subset of hidden tests, or is it binary pass/fail per question? This affects how we weight a candidate who fixes one of the two bugs.

---

## Summary — what we need in writing by Day 3

| # | Question | Blocks |
|---|---|---|
| 1 | SQLite/DB seeding in sandbox, all 3 languages | Problem authoring |
| 2 | C#/.NET runtime + DB library availability | Language coverage |
| 3 | Custom question import format | Content packaging |
| 4 | Historical item p-values | Cutoff setting |
| 5 | Bank depth per topic × complexity cell | Part A composition |
| 6–10 | Randomization, anchors, proctoring, gating, partial credit | Rigor and scoring detail |
