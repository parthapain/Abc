# Level 2 Rubric

**Used by both the AI grader (first pass, gates access to human review) and the 3 human reviewers (final pass).** Same rubric, same anchors, so a human reviewing a shortlisted candidate is checking the AI's work against a shared standard, not applying a different one.

Five dimensions, each scored **0–4** against concrete behavioral anchors. No dimension is scored on vague adjectives ("good", "clean") — every level below describes something observable in the code or the written rationale.

**No server-side evidence is available for grading, and no commit history either.** There is no LLM-gateway interaction log, and none is planned. The repository arrives as a single final snapshot, not an incremental commit history — so there is no "when did this change" signal at all, from any source. Grading works from exactly two things: **the final code as submitted, and the written rationale.** This is a real constraint on Dimension 4 (AI-output verification) specifically — see that dimension's notes below for how its anchors were reworked around it, and `../design-rationale.md` for the full reasoning behind the change.

**Total: 0–20, weighted.** Each dimension is still scored **0–4 against its own anchors below — nothing about how an individual dimension is judged changes.** What changes is how the five scores combine into the total: the two dimensions that capture reliability (does the agent misbehave, duplicate a side effect, or crash) count for more; the two judgment-quality dimensions stay close to even weight; architecture taste counts for less.

| Dimension | What it captures | Weight |
|---|---|---|
| 1 — Problem framing & architecture fit | Design taste, not correctness or safety | ×0.5 |
| 2 — Agentic design, tools & guardrails | **Reliability** — does it gate risky actions and survive a retry without duplicating or corrupting anything | ×1.5 |
| 3 — Handling of ambiguity | Judgment quality | ×1.0 |
| 4 — AI-output verification | Judgment quality | ×0.75 |
| 5 — Production readiness | **Reliability** — does it crash or silently corrupt data on messy/adversarial input | ×1.25 |

Weights sum to 5.0, so `Total = Σ(dimension score × weight)` stays on a 0–20 scale — directly comparable to every score produced before this weighting was introduced; no rescaling of past results is needed. **Always report both the raw 0–4 score and the weighted contribution for each dimension** — never collapse straight to a weighted total without showing the underlying raw score, since the raw score is what the anchors below actually describe and what a reviewer needs in order to sanity-check a finding.

**Revision note (dimension weighting, 2026-09-14):** prior to this, all five dimensions weighted equally (×1 each). The user identified that "is the agent well-designed" and "is the agent reliable" are different questions with different stakes — a beautifully-structured agent that duplicates a payment on retry is a worse outcome than a plainly-structured one that never does — and equal weighting didn't reflect that. Dimensions 2 and 5 were identified as the two that actually carry reliability signal (guardrail defeat/idempotency in Dimension 2; crashes and data corruption under stress in Dimension 5) — Dimensions 3 and 4 are judgment-quality, not reliability, and were left close to their original weight. This is implemented as a pure post-hoc multiplier on the existing 0–4 anchors, not a change to the anchors, the capping rules, or the take-the-lower rules within each dimension — all of that stays exactly as specified below. See `../design-rationale.md` for the full discussion.

**Revision note (expert tier, Addendum 21, extended by Addendum 23):** five further elements (a second AI-trap, coupled guardrails/ambiguities, an elevated idempotency requirement, adversarial tool responses, and a retry-safety-vs-stale-data collision) are now gradeable, but **only** for expert-tier instances (currently T04, T01, T02, and T03, none fully calibrated — see each template's own `-EXPERT-ADDENDUM.md` for status) — see the notes marked "Expert-tier (Addendum 21)" and "Expert-tier (Addendum 23)" under Dimensions 2, 3, 4, and 5 below. Nothing about how a standard or harder-tier instance is scored changes.

**Revision note (expert tier, Addendum 24):** a further, non-numbered construction rule — at expert tier, the two base-template ambiguities must each have a "no safe default" dataset row where plausible resolutions diverge — strengthens how Dimension 3's existing anchors get applied (see "Expert-tier note (Addendum 24)" under Dimension 3 below). Not a new element, dimension, or anchor; standard/harder-tier instances are unaffected.

**Revision note (this split):** Dimension 1 was originally a single "Problem framing & approach" dimension that also carried agentic/tool/guardrail quality and cost/efficiency awareness, bundled in via a capping rule. It has been split into two: Dimension 1 now covers only base architecture fit, and the new Dimension 2 covers agentic design, tool interface quality, guardrails, and cost/efficiency — carrying forward the same capping rule that used to live in Dimension 1. This changed the total from 0–16 to 0–20 and renumbered the former Dimensions 2/3/4 to 3/4/5. See `../design-rationale.md` Addendum 16 for why.

---

## Dimension 1 — Problem framing & architecture fit

*Did the candidate make deliberate architecture and decomposition choices, and can you tell why? Does the overall shape of the application — how ingest, core processing, review UI, and persistence relate to each other — actually fit this problem?*

**Maps to:** *Applications and Integration.*

| Score | Anchor |
|---|---|
| **0** | No discernible structure — logic dumped into one file/function, no separation of concerns. No rationale given for any choice. |
| **1** | Some structure, but arbitrary or inconsistent (e.g., one layer is cleanly separated, everything else is tangled). Rationale, if present, doesn't match what was actually built. |
| **2** | Reasonable, conventional structure (e.g., basic MVC-ish separation). Rationale present but generic — could apply to any project, doesn't reference this problem's actual constraints. |
| **3** | Structure clearly fits the problem's shape (e.g., a pipeline-shaped problem is built as a pipeline, not force-fit into a generic CRUD template). Rationale names at least one real trade-off and why it was made. |
| **4** | Structure anticipates the problem's actual failure modes and scaling concerns (not hypothetical ones — the ones this specific use case's stress point would trigger). Rationale is specific enough that a reviewer could disagree with a stated trade-off and debate it on its merits. |

This dimension is scored purely on architectural fit — it no longer carries a capping rule of its own. Agentic/tool/guardrail quality and cost/efficiency awareness are scored separately, in Dimension 2.

---

## Dimension 2 — Agentic design, tools & guardrails

*Every use case requires a genuine multi-step agentic loop, a designed tool interface for the LLM to call, and — strengthened from one to two, see `design-rationale.md` Addendum 20 — two independently-guardrailed consequential actions the AI can trigger itself, each with its own verified compounding-failure risk. Is that built the way a careful engineer would build it — or bolted on to satisfy the brief?*

**Maps to:** *Agents and Workflows, Tools and MCPs, Model Selection and Optimization (the efficiency half — model choice itself isn't a live decision, since candidates use one fixed in-house gateway), Security and Safety (the guardrail half — secrets/data handling is graded in Dimension 5).*

| Score | Anchor |
|---|---|
| **0** | Not genuinely agentic — a single LLM call dressed up as a loop, or "tools" defined but not actually called as part of the app's control flow. |
| **1** | A loop and tools exist, but at least one of: the loop is unbounded/ad hoc with no sensible stopping condition; there's a single do-everything tool with no structured failure reporting; or a consequential action fires with no gate at all. |
| **2** | Loop and tools are reasonably built, but the design is clearly, grossly wasteful at real volume (unbounded context re-sent every call, no batching where the task obviously needs it) — **or** a guardrail exists in name only and doesn't meaningfully check the action's own risk. |
| **3** | The loop has a sensible stopping condition (e.g., a bounded retry count), tools are clearly scoped with structured failure reporting (the caller can tell *why* something failed and whether it's worth retrying), and **both** guardrails genuinely gate their respective consequential actions against a real risk check. No gross inefficiency. |
| **4** | Same as 3, **and** the design is clearly efficient at real volume — sensible batching/chunking, trimming context instead of resending it whole, matching call pattern (responsive vs. bulk) to how the feature is actually used, and avoiding redoing identical AI work when a prior result could be reused. |

**Capping rule (not an average) — carried forward from the pre-split Dimension 1:** loop quality, tool design, guardrail quality, and cost/efficiency are graded together as one 0–4 score, but a strong showing on one does not buy back a severe failure on another:
- An unbounded or ad hoc agentic loop, a single do-everything tool with no structured failure reporting, or a consequential action with no gate at all **caps this dimension at 1**, regardless of how clean the rest of the design is.
- A design that is clearly, grossly wasteful at real volume **caps this dimension at 2** — real, but one level less severe than an ungated agentic action.
- Absent either capping condition, score the base anchor as normal, and let genuinely strong tool/guardrail design or genuinely strong cost-awareness lift a borderline score — never let either force a strong base score down in the absence of a capping failure.

**Guardrail-default flaws are graded here, not under Dimension 4.** A template's agentic build can itself have a naive first-draft guardrail — e.g., "auto-send once classification confidence clears a threshold," with no separate check on the *action's* own risk. That is an architecture/guardrail-design defect, scored under this dimension's capping rule above like any other ungated consequential action. It is **not** a second AI-trap subject to Dimension 4's evidence-discipline rules (code-as-ground-truth, rationale-must-cite-a-checkable-mechanism) — those rules apply specifically to the template's planted classification/extraction-style trap. Grade the guardrail's quality directly from the code as a design decision; no rationale-matching is required to score it.

**Check specifically for a recurring pattern found across template calibration runs: a missing or failed field defaulting to whatever value makes the guardrail *more* permissive.** Confirmed 3 of 4 times on the **first** guardrail across the template set (Calibration Runs #1/#2, pre-Addendum-20: a `.get(key, True)`-style default on a missing confidence/grounded flag, or a missing price defaulting to zero and making an order look cheaper) — common enough to check for directly. **The second guardrail's dry-run pass (Calibration Run #3) found a more mixed picture**, not a repeat of the same exact shape: T02 and T03 confirmed a similar missing-data-defaults-permissive pattern, but T01 and T04's confirmed mechanisms were different (an omitted boundary check; a compound check where only one of two conditions was actually implemented) — still capping-rule violations, just not the identical "field defaults permissively" shape. The underlying question to ask either way: does a missing, malformed, or failed piece of data — or an incompletely-implemented check — make the submission *more* likely to auto-act, rather than less? If so, that's a capping-rule violation (an ungated consequential action) even if no single line of code looks obviously wrong in isolation — see `grading/calibration-runs/` for the specific instances this was found in.

**A related distinction, confirmed necessary during the post-split calibration re-validation (see `grading/calibration-runs/T03-calibration-run.md` and `grading/calibration-runs/T04-calibration-run.md`, Run #2 in each), and revised after human review: a guardrail can check *whether* to act correctly while leaving the action's actual executed parameters — the dollar amount, the item, the destination — completely unverified against real data.** Treat this as "guardrail exists in name only" (**cap at 2**), not "no gate at all" (**cap at 1**): the decision-level check is real and does meaningfully verify something (e.g., a genuine eligibility check that correctly fails closed) — the gap is that it doesn't also cover the parameter the action executes with, not that no check exists at all. Reserve the cap-at-1 anchor for a guardrail that is actually defeated or absent — e.g., a check that a failure-masked or hallucinated result can silently pass through as if genuine (the recurring missing-field-defaults-permissive pattern above), or no check of any kind on the consequential action.

**Every instance now plants two independently-guardrailed actions, not one. Check the capping conditions above against each guardrail separately, then apply the worse of the two caps to the whole dimension** — a well-built first guardrail never buys back a real defect (ungated, wasteful, or silently defeated by a missing-field default) in the second. This is the same rule as: where a template's naive code surfaces more than one Dimension 2 defect at once — whether on the same guardrail or one on each — apply the worse cap. Caps don't average, even across two distinct findings within the same dimension. (E.g., a guardrail that doesn't check an action's own idempotency-safety, combined separately with a missing-field-defaults-permissive bug elsewhere in the same guardrail: the permissive-default finding's cap-at-1 governs, even though the idempotency gap alone would only be cap-at-2.)

**Expert-tier note (Addendum 22) — the brief itself never asks for a gate.** Unlike standard/harder-tier briefs, an expert-tier brief states only the bare capability ("autonomously dispatch fulfillment via a tool call") — never that it should be gated, checked, or escalated on risk. This changes nothing about how to score a missing gate (still cap-1, per the rule above) — it changes what that finding means: not "didn't follow an instruction," but "didn't recognize the need unprompted." Don't read a lower average Dimension 2 score across expert-tier submissions as a sign something's wrong with the grading; it's the expected effect of removing the scaffolding.

**Expert-tier only (Addendum 21, extended by Addendum 23) — three further named defect flavors, graded through this same dimension's existing capping rule, not a new rule:** applies only where an instance's `INTERNAL-metadata.md` states it's an expert-tier instance (see `../design-rationale.md` Addendum 21 and the relevant template's `-EXPERT-ADDENDUM.md`). Standard and harder-tier instances are unaffected.
- **Guardrail/ambiguity coupling defect:** where an expert-tier instance requires one guardrail's risk computation to key off an already-resolved, related ambiguity (e.g., a back-order policy determining which line items a value-based guardrail should actually evaluate), a guardrail that still computes on the pre-ambiguity, uncoupled basis is "a real check, computed on the wrong basis" — **cap at 2**, the same tier as "guardrail exists in name only," not a full cap-1.
- **Idempotency-unsafe consequential action:** where an expert-tier instance's `INTERNAL-metadata.md` specifies a forced-retry check (since the dispatch/action service is locally mocked, this is usually a review-time procedure — e.g. manually invoking the candidate's own dispatch function twice for a named order — not a literal dataset row; see the relevant `-EXPERT-ADDENDUM.md`), a submission with no protection against that retry duplicating the action is treated as severely as an ungated action — **cap at 1** — since a duplicated real-world side effect is not a lesser failure than an unchecked one.
- **Retry-safety-vs-stale-data collision (Addendum 23):** an expert-tier brief may pair the idempotency sentence with a second, independently-reasonable-looking requirement (e.g., "always re-confirm current stock before dispatching") that conflicts with it specifically on the retry-after-lost-response path. The correct resolution is that an idempotency-cache-hit returns the cached result untouched, never re-running the second requirement's check — the second requirement applies only to a genuinely fresh dispatch decision. A submission that lets the second requirement leak into the cache-hit path (so a retry can change an already-completed action's outcome) has silently given up the same guarantee as the plain idempotency-unsafe case above — **cap at 1**, the same severity, not a separate defect category. See the relevant `-EXPERT-ADDENDUM.md` for how this collision is constructed and reviewed.

---

## Dimension 3 — Handling of ambiguity / critical thinking

*Every generated use case now has two deliberately underspecified requirements, not one — this was strengthened from a single-ambiguity default; see `design-rationale.md` Addendum 20. What did the candidate do with each?*

| Score | Anchor |
|---|---|
| **0** | The ambiguity isn't addressed at all — the submission silently assumes one interpretation with no sign the candidate noticed there was a choice to make. |
| **1** | The ambiguity is silently resolved, and the resolution is defensible, but nothing in the code or rationale shows it was a deliberate decision rather than luck. |
| **2** | The rationale names the ambiguity and states an assumption, but doesn't explain why that assumption over an alternative. |
| **3** | The rationale names the ambiguity, states the assumption made, and gives a reason tied to the actual business scenario (not a generic justification). |
| **4** | Same as 3, **and** the candidate did something to reduce the risk of guessing wrong — e.g., built the resolution behind a config flag, isolated it so it's a one-line change if the assumption is wrong, or explicitly flagged it as the single riskiest assumption in the submission. |

**Score each of the two planted ambiguities independently against this scale, then take the lower of the two as the dimension score — this is a non-averaging rule, the same principle used elsewhere in this rubric for combining multiple findings within one dimension.** Noticing and reasoning through *both* judgment calls is the thing being tested; a "4" on one ambiguity and silence on the other is a "0" on this dimension, not a "2."

**Expert-tier note (Addendum 21):** an expert-tier instance may additionally require **one specific** ambiguity's resolution to feed into a guardrail's computation (see the relevant template's `-EXPERT-ADDENDUM.md`) — not that both ambiguities and both guardrails are all mutually coupled. Where that's the case, grade the coupling-awareness itself under Dimension 2's expert-tier note, not here. This dimension still just grades whether each of the two ambiguities is independently named, resolved, and justified, exactly as the anchors above describe — a candidate's rationale doesn't need to mention the coupling to score well *here*, even though missing the coupling itself costs them under Dimension 2.

**Expert-tier note (Addendum 24) — the two ambiguities must each have a "no safe default" data point.** At expert tier, `INTERNAL-metadata.md` names at least one dataset row per ambiguity where two independently-defensible resolutions produce different outcomes (see the relevant template's `-EXPERT-ADDENDUM.md`). Use that row to ground the anchor above with more confidence than a standard-tier instance allows: an anchor-0/1 finding ("silently assumed one interpretation") is checkable directly against whether the candidate's chosen resolution gets that specific row's outcome demonstrably wrong, not inferred only from an absent rationale paragraph. This doesn't change the anchor scale or the non-averaging rule — it just means an expert-tier "0" should usually cite the specific divergent case, not just the absence of discussion.

**Grading note:** a candidate who describes, in the rationale, having asked an AI assistant to help reason through an ambiguity — and whose final resolution reflects that reasoning — should score at least as well as one who reasoned alone. This dimension is about the quality of the thinking, not whether a human or an AI helped produce it, and not about which one gets credited in the rationale.

---

## Dimension 4 — AI-output verification ("bias handling")

*Every template plants one "AI will get this wrong by default" trap — a subtly wrong-by-default implementation an AI coding assistant is likely to produce unprompted. **There is no AI-interaction log and no commit history** — no server-side capture exists, a self-exported log would be trivially curated, and the repository arrives as a single final snapshot (see `../design-rationale.md`). This dimension is scored from two things only: the final shipped code, and the written rationale.*

**Maps to:** *Prompt and Context Engineering (the app's own runtime prompts, see the note below).*

**What this means for scoring:** with neither a log nor a commit history, the grader has **no timing signal whatsoever** — there is no way to distinguish "never considered it," "considered it and got lucky," "caught it reactively after a failure," and "caught it proactively before it ever surfaced." All the grader can observe is a single point in time: what the final code looks like, and what the rationale says about it. The anchors below are rebuilt entirely around that: whether the flaw is present in the final code, whether the code demonstrates a deliberate safeguard at the trap point (a distinguishing status field, a validation check, a test targeting exactly this failure mode), and whether the rationale names the risk and the safeguard specifically enough to be checked against the code — not whether it merely claims verification happened, and not any notion of *when* it happened.

| Score | Anchor |
|---|---|
| **0** | The shipped code contains the flawed default unmodified (the case the trap describes is not distinguished from a genuine result). The rationale doesn't mention this risk at all. |
| **1** | The shipped code still contains the flaw, **but** the rationale claims the candidate checked for it — a claim with no code to back it up. Treat an unsupported claim as worse than silence: it's a specific, checkable red flag for dimension 3's decision-trail honesty as well as a 1 here. |
| **2** | The shipped code avoids the flaw (a distinguishing field, a check, a test that would catch it), but nothing in the rationale connects this to the planted risk specifically — it's indistinguishable from a fix arrived at some other way (a lucky default choice, a fix made for an unrelated reason). This is the ceiling for "flaw avoided with no supporting explanation," regardless of how the flaw came to be avoided. |
| **3** | The shipped code avoids the flaw, **and** the rationale explicitly names this exact risk and describes the specific safeguard added for it, in enough detail that a reviewer can go find that safeguard in the code and confirm the description matches what's actually there. |
| **4** | Same as 3, **and** either the code or the rationale shows the candidate generalized the catch — applied the same class of safeguard to other, similar risk points in the AI-generated code beyond just the one planted trap, not only the specific spot the template targets. |

**Grading note — evidence discipline is the whole safeguard here.** Because self-reported claims (in the rationale) are cheap to write and impossible to disprove from text alone, **never let dimension 4 score above what the code independently demonstrates.** A rationale that describes catching the trap is worth nothing at this dimension unless the cited code actually shows it — score 0 or 1 (per the anchors above) for a claim unsupported by code, never round up because the writing sounds convincing. This replaces the old "the log is a hard blocker without it" framing: the dimension is no longer blocked, but it is capped by what's checkable, and that cap is enforced by treating the code as the ground truth and the rationale as, at best, a pointer to where to look.

**Expert-tier note (Addendum 21) — a second, independent AI-trap:** where an instance's `INTERNAL-metadata.md` states an expert-tier second trap is planted (see the relevant template's `-EXPERT-ADDENDUM.md`), score each of the two traps independently against the anchors above, then take the **lower** of the two as the dimension score — the same non-averaging principle Dimension 3 already uses for two ambiguities. Catching one planted trap and missing the other is a "0"/"1" on this dimension for the missed one, not an average with the caught one. Standard and harder-tier instances plant one trap only and are unaffected by this note.

**Expert-tier cross-reference (Addendum 23) — the retry-safety-vs-stale-data collision is not a third Dimension 4 trap.** Even though it depends on the candidate's build noticing and resolving a tension between two brief sentences (which can look trap-like), it's graded entirely under Dimension 2's capping rule, alongside the base idempotency requirement — see that dimension's note. Don't score it here and don't count it as this instance's "second trap" for the take-the-lower rule above; that rule still applies only to the genuine second AI-trap (element 1).

**Note on prompt engineering:** applies to every submission (`testing-principles.md` category 14) — every app has some prompt it sends the LLM at its core. This is separate from, but related to, the trap check above: a strong "3" or "4" submission's shipped prompt is often specific and constrained (explicit instructions for the exact edge case that trips up a naive prompt, output-format enforcement, examples where needed) — frequently the actual mechanism by which the candidate avoided or corrected the planted trap. A "0" or "1" submission's prompt is vague or generic, doesn't separate instructions from the data being processed, and doesn't enforce the output shape the rest of the app expects. Cite the specific prompt text as it appears in the final submission as evidence, the same way you'd cite any other piece of code — there's no earlier version to compare it against, since only the final snapshot is available.

---

## Dimension 5 — Production readiness

*Every template plants one stress point — a plausible edge case or failure mode. How does the submission behave there, and more generally?*

**Maps to:** *Prompt and Context Engineering (the context-management half), Security and Safety (the secrets/sensitive-data half), Eval, Testing, and Debugging (test coverage is graded here, and only partially: candidates aren't asked to build their own eval suite, only to show basic tests of their own core logic).*

**Two of the 8 named areas are only partly exercised by this design, not just this one:** Eval/Testing/Debugging, as just noted, and **Model Selection and Optimization** (§2 above) — candidates all use one fixed in-house LLM gateway, so the "selection" half of that area (choosing among models/providers for a task) isn't something any submission can demonstrate at all; only its optimization/efficiency half is graded. Don't read either dimension's "Maps to" line as full coverage of the named area.

**One of those 8 named areas, "Claude Code," is never mapped to any dimension above — deliberately, not by oversight.** The assessment is explicitly vendor-neutral (`testing-principles.md`'s ground rule: candidates may use any LLM/tool, and nothing may be phrased in a way that only makes sense for one vendor's product). A skill area named after one specific CLI tool has no natural home in a rubric built to be scored the same way regardless of which tool a candidate used — so it's out of scope by design, the same way this rubric never asks which model a candidate chose.

**Grading is static-only — the AI grader and the human reviewers both assess this from the submitted code (schema, migrations, models, query/persistence logic included), not from running the application.** No execution environment is assumed or provisioned for the 300+ initial screens. The one exception is a **live demonstration requested only from candidates who clear the cutoff**, at the human-review stage — see `grading/cutoff-and-aggregation.md`. That check confirms the app actually behaves as the static code implies; it doesn't change how this dimension is scored during AI grading.

| Score | Anchor |
|---|---|
| **0** | The submission crashes or produces silently wrong output at the planted stress point. No error handling anywhere beyond what a framework provides by default. |
| **1** | The stress point doesn't crash the app, but fails ungracefully (unhandled exception surfaces to the user, or a generic 500). No tests. |
| **2** | The stress point is handled explicitly (a caught exception, a validation check), but handling is local and ad hoc — no evidence of a broader pattern. Little to no test coverage. |
| **3** | The stress point is handled well, and the same defensive pattern is applied consistently elsewhere. At least minimal tests exist covering the core logic. |
| **4** | Same as 3, **and** the candidate's rationale shows awareness of what they *didn't* have time to harden — an honest scoping statement, not a claim of completeness. |

**Note on context management — now mandatory on every use case:** every template involves enough context volume (from its required multi-step agentic loop and tool use) that this dimension also covers whether the submission loses or garbles information from partway through, lets accumulated intermediate output balloon unmanageably, or drops facts that mattered by the next step (`testing-principles.md` category 10). Treat this the same as any other stress point — a submission that handles it deliberately scores well here; one that visibly loses track of earlier context does not. No exemption applies — every submission has context to manage, by construction of the mandatory agentic/tool-using shape.

**Note on multimodal input (conditional, `testing-principles.md` category 15):** only applies where a template's dataset includes something beyond plain text — a scanned document, an image, a screenshot. Where it does, this dimension covers whether the candidate handled that input type appropriately and accounted for its realistic failure mode (poor scan quality, an unreadable image), the same way any other stress point is graded. No current template requires this — leave it unscored (not penalized) for submissions where it doesn't apply.

**Expert-tier note (Addendum 21) — adversarial tool responses, conditional the same way multimodal input is:** where an instance's dataset plants a tool response that is internally inconsistent (a negative count, contradicting fields — see the relevant template's `-EXPERT-ADDENDUM.md`), grade whether the submission validates a tool's own response before acting on it the same way any other stress point is graded here — a submission that computes a consequential decision straight from an inconsistent tool response, with no validation, scores anchor 0/1 ("crashes or silently wrong at the tricky moment") for this specific check. Not a separate cap tier — this is an additional stress-point category, scored the same way the existing malformed-input-data category already is. Leave unscored (not penalized) for standard/harder-tier instances, which don't plant this.

**Note on security and sensitive-data handling:** applies to **every** submission, not just a subset of templates (`testing-principles.md` category 11). Every template's dataset carries realistic-looking sensitive fields (names, contact details, case/claim content). A "3" or "4" submission keeps credentials out of code/logs, scopes backend access to what its tools actually need, and doesn't expose or forward sensitive fields further than the task requires. A "0" or "1" submission hard-codes a secret, logs sensitive data in plaintext without reason, or gives the app broader standing access than the scenario calls for. Grade this as a baseline production-readiness expectation, independent of which template the candidate drew.

**How these interact — capping rule (not an average):** stress-point handling, context management, and security/sensitive-data handling are graded together as one 0–4 score, with the same non-averaging principle as Dimension 2:
- A hard security failure — a hard-coded secret, sensitive data logged in plaintext without reason, or standing backend access clearly broader than the app's tools require — **caps this dimension at 1**, regardless of how well the stress point or context management is otherwise handled. Security is a baseline expectation on every submission; excellent stress-point handling should not be able to average a clear failure here away.
- Losing or garbling context partway through the mandatory multi-step loop **caps this dimension at 2** — real, but one level less severe than a security failure, since garbled context is recoverable/debuggable in a way a leaked credential is not.
- Absent either capping condition, score the base stress-point anchor as normal. Multimodal handling, where applicable, is additive evidence toward a 4 — never a separate cap of its own.
- **If a submission trips both capping conditions at once (e.g., a hard-coded secret *and* lost/garbled context), the worse cap governs — cap at 1, not 2.** Caps don't average even across two distinct findings within the same dimension; same rule as Dimension 2's, stated here explicitly rather than only by cross-reference.

---

## How the AI grader should use this document

For each submission, evaluate all five dimensions independently using:
1. The repository — a single final snapshot, not a commit history
2. The written rationale

**No AI-interaction log exists for any candidate, and no commit history exists either — do not ask for either, do not treat their absence as a missing-evidence flag, and do not infer anything from a candidate not mentioning one.** This applies uniformly to every submission, so it carries no signal either way. There is no "when did this happen" evidence available at all; don't imply one in your output (no "caught it early/late" language) — only "present in the final submission" or "not present."

Score each 0–4 against the anchors above. Do not average or round to a "gut feel" score — if a submission sits between two anchors, pick the lower one and note why in the grading output, so a human reviewer can see the judgment call rather than an opaque number. For Dimension 4 specifically: never let a claim in the rationale push the score above what the code itself demonstrates — see that dimension's grading note.

**Then apply the weights from the table above to get the total:** multiply each dimension's raw 0–4 score by its weight, sum the five results for the 0–20 total. Do this after every raw score is finalized against its anchors — never let the weighting influence which raw anchor a dimension gets scored against.

Output, per candidate: the five **raw** 0–4 scores, each one's weighted contribution, the weighted total out of 20, and one sentence per dimension citing the specific evidence (a file or a rationale line) that justified the raw score. **A score with no cited evidence should be treated as unreliable** — this is the primary sanity check available to a human skimming AI-grading output before trusting the cutoff. Never report only the weighted total without the raw scores next to it — the raw scores are what the evidence and the anchors actually support; the weighted total is a derived summary, not a replacement for them.
