"""
Agent orchestration loop.

For each order this walks through: reconcile -> check inventory -> check alt
yard / reroute -> assess risk -> dispatch (only if low risk), logging every
tool call into a reasoning trace and persisting it. This is deliberately a
plain Python control loop rather than a model free-loop emitting tool calls,
because the "LLM" here (llm_interpreter.py) is a deterministic stand-in with a
fixed contract -- but the *shape* is the agentic one the brief asks for: the
agent decides which tool to call next based on the previous tool's result, and
only decides how to proceed (dispatch vs. hold for review) after gathering
that information, rather than doing it all in one shot.

Risk policy (documented here since it's the one genuinely underspecified
judgment call in the brief -- see RATIONALE.md for the fuller writeup):

  An order is LOW RISK (eligible for autonomous dispatch) iff ALL of:
    1. Every line item reconciled with high confidence (not ambiguous) --
       an order the agent had to guess on should get a human's eyes before
       equipment goes out the door.
    2. Every line item is fully fulfillable right now, from primary stock
       and/or an autonomous alt-yard reroute -- no backordered quantity left
       over. Partial fulfillment is a judgment call (which items? partial
       ship now or wait for the rest?) that a human should make.
    3. NOT a high-value one-off (non-recurring) client order. One-off event
       clients have no order history with us, so a large-value one-off order
       carries more exposure if something is wrong with it than the same
       order from an established recurring corporate account. Threshold:
       estimated order value > $1500/day for a one-off event client.

  Everything else is flagged 'needs_review' with the full reasoning trace
  shown in the UI, and a human can approve, override the reconciliation, or
  dispatch manually.
"""
from __future__ import annotations

from dataclasses import asdict

import db
import tools
from llm_interpreter import split_line_items

ONE_OFF_VALUE_THRESHOLD = 1500.0


def process_order(order_id: str) -> dict:
    order = db.get_order(order_id)
    if order is None:
        raise ValueError(f"Unknown order {order_id}")

    trace: list[dict] = []

    def log(call: tools.ToolCall):
        trace.append({"tool": call.tool, "input": call.input, "output": call.output, "note": call.note})
        return call

    trace.append({"tool": None, "input": None, "output": None,
                  "note": f"Starting agent run for {order_id} ({order['client_name']}, "
                          f"{order['client_type']}). Raw request: \"{order['raw_description']}\""})

    # Step 1: split the free-text request into line items (in-house LLM step)
    raw_items = split_line_items(order["raw_description"])
    trace.append({"tool": "split_line_items", "input": {"raw_description": order["raw_description"]},
                  "output": {"items": raw_items},
                  "note": f"Parsed request into {len(raw_items)} line item(s)."})

    db.clear_line_items(order_id)
    resolved_line_items = []
    any_ambiguous = False
    any_backorder = False
    estimated_value = 0.0

    for line_no, (qty, raw_text) in enumerate(raw_items, start=1):
        # Step 2: reconcile against catalog
        recon_call = log(tools.reconcile_line_item(raw_text))
        resolved_sku = recon_call.output["resolved_sku"]
        resolved_name = recon_call.output["resolved_name"]
        confidence = recon_call.output["confidence"]
        ambiguous = recon_call.output["ambiguous"]
        candidates = recon_call.output["candidates"]

        catalog_row = db.get_catalog_sku(resolved_sku) if resolved_sku else None
        unit_price = catalog_row["price_per_day"] if catalog_row else None

        li_id = db.insert_line_item(
            order_id=order_id, line_no=line_no, raw_text=raw_text, requested_qty=qty,
            resolved_sku=resolved_sku, resolved_name=resolved_name, unit_price=unit_price,
            confidence=confidence, ambiguous=ambiguous, candidates=candidates,
        )
        db.log_reconciliation(
            order_id=order_id, line_item_id=li_id, method="deterministic_llm_stub",
            input_text=raw_text, resolved_sku=resolved_sku, confidence=confidence,
            candidates=candidates, reasoning=recon_call.note,
        )

        if ambiguous:
            any_ambiguous = True

        fulfill_primary = 0
        fulfill_alt = 0
        backorder = 0

        if resolved_sku is None:
            # Could not reconcile at all -- entire quantity is effectively
            # unfulfillable until a human resolves what item was meant.
            backorder = qty
            any_backorder = True
            trace.append({"tool": None, "input": None, "output": None,
                          "note": f"Line {line_no}: could not resolve '{raw_text}' to any "
                                  f"catalog item -- treating all {qty} unit(s) as unfulfillable "
                                  f"pending human input."})
        else:
            if unit_price:
                estimated_value += unit_price * qty

            # Step 3: check primary inventory
            inv_call = log(tools.check_inventory(resolved_sku, qty))
            fulfill_primary = inv_call.output["available"]
            shortfall = inv_call.output["shortfall"]

            if shortfall > 0:
                # Step 4: check alt yard, and if it has stock, autonomously reroute
                alt_call = log(tools.check_alt_yard(resolved_sku, shortfall))
                alt_available = alt_call.output["alt_available"]
                if alt_available > 0:
                    ship_cost = alt_call.output.get("ship_cost", 0.0)
                    reroute_reason = (
                        f"Primary yard short {shortfall}x {resolved_sku} for order "
                        f"{order_id}; alternate yard has {alt_available} available, "
                        f"autonomously rerouting per fulfillment policy."
                    )
                    reroute_call = log(tools.reroute_to_alt_yard(
                        order_id, resolved_sku, alt_available, ship_cost, reroute_reason,
                    ))
                    fulfill_alt = reroute_call.output["rerouted_qty"]

                backorder = shortfall - fulfill_alt
                if backorder > 0:
                    any_backorder = True
                    trace.append({"tool": None, "input": None, "output": None,
                                  "note": f"Line {line_no}: {backorder}x {resolved_sku} remains "
                                          f"BACKORDERED after primary + alt yard "
                                          f"({fulfill_primary} primary + {fulfill_alt} alt "
                                          f"of {qty} requested)."})

        db.update_line_item_fulfillment(li_id, fulfill_primary, fulfill_alt, backorder)
        resolved_line_items.append({
            "id": li_id, "line_no": line_no, "raw_text": raw_text, "requested_qty": qty,
            "resolved_sku": resolved_sku, "resolved_name": resolved_name,
            "confidence": confidence, "ambiguous": ambiguous,
            "fulfill_primary_qty": fulfill_primary, "fulfill_alt_qty": fulfill_alt,
            "backorder_qty": backorder,
        })

    db.set_order_value(order_id, round(estimated_value, 2))

    # Step 5: risk assessment
    risk_reasons = []
    if any_ambiguous:
        risk_reasons.append("One or more line items could not be reconciled with high "
                             "confidence and need human confirmation.")
    if any_backorder:
        risk_reasons.append("One or more line items have unresolved backordered quantity "
                             "after checking both yards.")
    is_high_value_one_off = (
        order["client_type"].strip().lower() == "one-off event"
        and estimated_value > ONE_OFF_VALUE_THRESHOLD
    )
    if is_high_value_one_off:
        risk_reasons.append(
            f"One-off event client with estimated order value ${estimated_value:,.2f}/day "
            f"exceeds the ${ONE_OFF_VALUE_THRESHOLD:,.2f}/day auto-dispatch threshold for "
            f"non-recurring clients."
        )

    low_risk = len(risk_reasons) == 0
    risk_level = "low" if low_risk else "high"

    trace.append({"tool": "risk_assessment", "input": {
                    "any_ambiguous": any_ambiguous, "any_backorder": any_backorder,
                    "estimated_value": round(estimated_value, 2), "client_type": order["client_type"],
                  },
                  "output": {"risk_level": risk_level, "auto_dispatch_eligible": low_risk},
                  "note": "Order assessed LOW RISK -- eligible for autonomous dispatch."
                          if low_risk else
                          "Order assessed HIGH RISK -- routed to human review. Reasons: "
                          + "; ".join(risk_reasons)})

    # Step 6: dispatch, only if low risk
    if low_risk:
        dispatch_reason = f"Order {order_id} fully reconciled and fully fulfillable " \
                           f"(primary stock and/or autonomous alt-yard reroutes); " \
                           f"auto-dispatch policy conditions met."
        log(tools.dispatch_order(order_id, resolved_line_items, dispatch_reason))
    else:
        db.set_order_status(order_id, "processed_needs_review")

    db.log_agent_run(order_id, trace, risk_level, risk_reasons, low_risk)

    return {
        "order_id": order_id, "risk_level": risk_level, "risk_reasons": risk_reasons,
        "auto_dispatch_eligible": low_risk, "trace": trace, "line_items": resolved_line_items,
    }


def process_all_pending() -> list[dict]:
    results = []
    for order in db.get_all_orders():
        if order["status"] in ("ingested",):
            results.append(process_order(order["order_id"]))
    return results
