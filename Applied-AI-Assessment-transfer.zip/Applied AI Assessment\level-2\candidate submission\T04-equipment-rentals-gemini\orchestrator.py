import re
import pandas as pd
from app.db.database import get_connection
from app.services.dispatch_client import FulfillmentDispatchClient

class RentalFulfillmentAgent:
    def __init__(self):
        self.dispatch_client = FulfillmentDispatchClient()

    def process_order(self, order_row: dict) -> dict:
        conn = get_connection()
        cursor = conn.cursor()

        order_id = order_row["order_id"]
        client_name = order_row["client_name"]
        client_type = order_row["client_type"]
        submitted_at = order_row["submitted_at"]
        raw_items_str = order_row["line_items_description"]

        catalog_df = pd.read_sql_query("SELECT * FROM catalog", conn)
        alt_df = pd.read_sql_query("SELECT * FROM alt_inventory", conn)

        raw_items = [item.strip() for item in raw_items_str.split(",")]

        reconciliation_notes = []
        dispatch_notes = []
        line_item_results = []

        total_face_value = 0.0
        total_dispatchable_value = 0.0
        has_ambiguity = False
        has_invalid_data = False
        has_excessive_shipping = False

        for raw_item in raw_items:
            match = re.match(r"(\d+)x\s+(.*)", raw_item)
            if not match:
                qty = 1
                desc = raw_item
            else:
                qty = int(match.group(1))
                desc = match.group(2)

            # Reconcile SKU
            matches = []
            for _, c_row in catalog_df.iterrows():
                if desc.lower() == c_row["description"].lower():
                    matches = [c_row]
                    break
                elif desc.lower() in c_row["description"].lower() or c_row["description"].lower() in desc.lower():
                    matches.append(c_row)

            if len(matches) > 1:
                has_ambiguity = True
                reconciliation_notes.append(f"AMBIGUOUS: '{desc}' matches {[m['sku'] for m in matches]}")
                line_item_results.append({
                    "raw_desc": desc, "requested_qty": qty, "status": "AMBIGUOUS",
                    "sku": None, "unit_price": 0.0, "fulfilled_qty": 0, "backordered_qty": qty,
                    "source": "UNRESOLVED", "ship_cost": 0.0
                })
                continue
            elif len(matches) == 0:
                has_ambiguity = True
                reconciliation_notes.append(f"UNMATCHED: '{desc}' could not be mapped to catalog.")
                line_item_results.append({
                    "raw_desc": desc, "requested_qty": qty, "status": "UNMATCHED",
                    "sku": None, "unit_price": 0.0, "fulfilled_qty": 0, "backordered_qty": qty,
                    "source": "UNRESOLVED", "ship_cost": 0.0
                })
                continue

            matched_item = matches[0]
            sku = matched_item["sku"]
            unit_price = float(matched_item["unit_price"])
            primary_stock = int(matched_item["in_stock"])
            item_face_val = unit_price * qty
            total_face_value += item_face_val

            alt_row = alt_df[alt_df["sku"] == sku]
            alt_stock = 0
            ship_cost = 0.0
            if not alt_row.empty:
                alt_stock = int(alt_row.iloc[0]["alt_stock"])
                ship_cost = float(alt_row.iloc[0]["ship_cost_from_alt"])

            # Check invalid data guardrail (e.g. negative stock)
            if alt_stock < 0:
                has_invalid_data = True
                reconciliation_notes.append(f"INVALID DATA: '{sku}' reported negative alt_stock ({alt_stock})")

            # Determine fulfillment source
            fulfilled_qty = 0
            backordered_qty = 0
            source = "PRIMARY"
            line_ship_cost = 0.0

            if primary_stock >= qty:
                fulfilled_qty = qty
                source = "PRIMARY"
            else:
                # Primary out of stock or partial
                primary_avail = max(0, primary_stock)
                remaining = qty - primary_avail
                fulfilled_qty = primary_avail

                if alt_stock > 0:
                    # Reroute check
                    item_val = unit_price * remaining
                    # Shipping threshold: max 50% of item value
                    if ship_cost <= (item_val * 0.5):
                        alt_fulfilled = min(remaining, alt_stock)
                        fulfilled_qty += alt_fulfilled
                        source = "ALT_YARD_REROUTE"
                        line_ship_cost = ship_cost
                        remaining -= alt_fulfilled
                    else:
                        has_excessive_shipping = True
                        dispatch_notes.append(f"REROUTE ESCALATED: Alternate shipping (${ship_cost}) exceeds 50% threshold for '{sku}' (${item_val})")

                if remaining > 0:
                    backordered_qty = remaining
                    if primary_avail == 0 and fulfilled_qty == 0:
                        source = "BACKORDERED"

            dispatchable_val = unit_price * fulfilled_qty
            total_dispatchable_value += dispatchable_val

            line_item_results.append({
                "raw_desc": desc, "requested_qty": qty, "status": "RECONCILED",
                "sku": sku, "matched_desc": matched_item["description"],
                "unit_price": unit_price, "fulfilled_qty": fulfilled_qty,
                "backordered_qty": backordered_qty, "source": source,
                "ship_cost": line_ship_cost, "primary_stock": primary_stock
            })

        # Gating Decision based on Coupled Value Gating ($1000 limit)
        RISK_LIMIT = 1000.00
        is_high_risk = total_dispatchable_value > RISK_LIMIT

        final_status = "AUTO_DISPATCHED"
        if has_ambiguity:
            final_status = "ESCALATED_AMBIGUOUS_RECONCILIATION"
        elif has_invalid_data:
            final_status = "ESCALATED_INVALID_DATA"
        elif has_excessive_shipping:
            final_status = "ESCALATED_SHIPPING_COST"
        elif is_high_risk:
            final_status = "ESCALATED_HIGH_VALUE"
        elif total_dispatchable_value == 0 and total_face_value > 0:
            final_status = "ESCALATED_NO_STOCK"

        # Execute Auto-Dispatch tool calls if status is AUTO_DISPATCHED
        if final_status == "AUTO_DISPATCHED":
            for line in line_item_results:
                if line["fulfilled_qty"] > 0:
                    idem_key = f"IDEM-{order_id}-{line['sku']}-{line['source']}"
                    action_type = "PRIMARY_DISPATCH" if line["source"] == "PRIMARY" else "ALT_YARD_REROUTE"
                    res = self.dispatch_client.dispatch_fulfillment(
                        order_id=order_id,
                        idempotency_key=idem_key,
                        action_type=action_type,
                        sku=line["sku"],
                        quantity=line["fulfilled_qty"],
                        shipping_cost=line["ship_cost"]
                    )
                    dispatch_notes.append(f"{action_type} executed: {res['message']}")

        # Persist to DB
        cursor.execute(
            '''INSERT INTO orders (order_id, client_name, client_type, submitted_at, raw_line_items, status, total_face_value, total_dispatchable_value, reconciliation_notes, dispatch_notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(order_id) DO UPDATE SET status=excluded.status, total_face_value=excluded.total_face_value, total_dispatchable_value=excluded.total_dispatchable_value''',
            (order_id, client_name, client_type, submitted_at, raw_items_str, final_status, total_face_value, total_dispatchable_value, "; ".join(reconciliation_notes), "; ".join(dispatch_notes))
        )

        for line in line_item_results:
            cursor.execute(
                '''INSERT INTO order_line_items (order_id, requested_desc, matched_sku, matched_desc, quantity, unit_price, reconciliation_status, primary_stock_available, fulfillment_source, fulfilled_qty, backordered_qty, alt_ship_cost)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (order_id, line["raw_desc"], line.get("sku"), line.get("matched_desc"), line["requested_qty"], line["unit_price"], line["status"], line.get("primary_stock", 0), line["source"], line["fulfilled_qty"], line["backordered_qty"], line["ship_cost"])
            )

        conn.commit()
        conn.close()

        return {
            "order_id": order_id,
            "status": final_status,
            "face_value": total_face_value,
            "dispatchable_value": total_dispatchable_value,
            "reconciliation_notes": reconciliation_notes,
            "dispatch_notes": dispatch_notes
        }