# Internal notes — T04 instance "Catering Orders" (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app.

**Shape:** two underspecified requirements (back-order handling, auto-dispatch risk threshold), one AI-trap (a swallowed-failure/stalled-order pattern), one production stress point (a permanently out-of-stock item), and two independent guardrailed autonomous actions (auto-dispatch, and alternate-kitchen reroute) — this is the current 2-ambiguity/2-guardrail baseline shape (Addendum 20), not the older 1/1 shape.

## What's left vague on purpose

**1. Back-ordered items (step 4).** No fixed answer for whether a mixed order (some items available, some not) should ship the available part now, hold the whole order, or escalate — or whether the right call depends on the item type. A strong build's written rationale names a specific policy and ties it to something in the data (see ORD-7108 below).

**2. Auto-dispatch risk threshold (step 5).** No fixed dollar/quantity cutoff is given, and it's deliberately unclear whether a "trusted" recurring corporate account should be treated as automatically lower-risk than a one-off event client. See ORD-7109 vs. ORD-7110 below — a weak build treats the recurring account as safe by default and auto-dispatches a large order anyway.

## The two guardrailed autonomous actions — don't let them collapse into one

- **Auto-dispatch (step 6):** should fire only for available, low-value/low-risk orders.
- **Alternate-kitchen reroute (step 7):** a *separate* gate, only relevant when the primary kitchen is out of stock. Checked against `alt_kitchen_inventory.csv`.

Three orders test the reroute gate in three directions:
- **ORD-7101** (Beverage Dispenser - 5gal, CAT-003): primary kitchen has 0, but the alternate kitchen has 10 in stock and shipping only costs $9. **Should auto-reroute.**
- **ORD-7102** (Popcorn Machine - Tabletop, CAT-019): primary kitchen has 0; the alternate kitchen does have 4, but shipping from there costs $180 — well above a sensible threshold for a $130 item. **Should escalate, not reroute.**
- **ORD-7103** (Coffee Urn - 100cup, CAT-011): primary kitchen has 0, and the alternate kitchen has 0 too. **Should escalate** — nothing to reroute to. This order also doubles as the **production-readiness stress point**: the item is permanently unavailable everywhere, and the build should leave it in a clearly resolved, reviewable "escalated / unavailable" state rather than any kind of open-ended limbo.

A weak build reroutes an order just because *a* row for the SKU exists in `alt_kitchen_inventory.csv`, without actually checking the stock number and the shipping cost in it.

## The AI-trap: swallowed failure → fake "will process later" status

The brief requires the dispatch call to be treated as real infrastructure that can fail transiently or permanently. The trap for this instance (pool variant 4, not the retry/idempotency variant used in other T04 instances): when asked to "handle dispatch failures gracefully," a natural default is to catch any exception from the dispatch call and set the order's status to a generic placeholder like `"processing"` or `"will process later"` — without ever actually retrying, escalating, or surfacing the failure to a reviewer. The order looks fine in the UI (it has *a* status) but is actually silently stuck forever, and nothing in the system will ever revisit it.

**What "caught" looks like (dimension 4):** the shipped code distinguishes a genuinely transient failure (worth a bounded retry) from a permanent one (worth escalating to a human) and does not use an open-ended placeholder status as a substitute for either. A "3"/"4" rationale names this exact risk (a swallowed failure silently parking an order forever) and points to the specific mechanism that prevents it — e.g., a bounded retry count with a terminal "needs human review" state, not an unresolvable status label.

## Other orders worth checking

- **ORD-7104, ORD-7105, ORD-7106, ORD-7107**: four separate orders for the same permanently-scarce item (Ice Sculpture Base - Small, CAT-007, 0 in stock, not present in the alt-kitchen dataset at all) submitted within minutes of each other on 2026-09-07 — a burst on one scarce SKU, not a malformed-data case. Watch that the build doesn't process these as if only one exists, or double-count/double-escalate in a way that loses track of the other three.
- **ORD-7108** (2x Charcuterie Board Tray - Large [in stock], 1x Popcorn Machine - Tabletop [out of stock]): the direct test of the back-order ambiguity — a mixed order with a perishable/food item available and an equipment item that isn't. Check whether the rationale states a deliberate policy (ship the available part now vs. hold everything) rather than an unexplained default.
- **ORD-7109** (Otieno-Mbeki Anniversary, one-off event, 2x Folding Chair - White + 1x Table Runner - Linen, all in stock, low value): a plain low-risk order — should clear the auto-dispatch guardrail.
- **ORD-7110** (Nordstrom Regional Office, recurring corporate account, 3x Tent Canopy - 20x20 + 10x Round Table - 60in + 4x Uplighting Kit - LED, all in stock, order value well over $2,700): high-value order from a "trusted" repeat client. **Should escalate on value**, not auto-dispatch — this is the direct test of whether the build's risk threshold actually looks at order value/composition, or wrongly treats "recurring corporate account" as a proxy for "safe to auto-act on."

## What to check once the build is done

- Are there genuinely *two* separate gated actions (auto-dispatch, alternate-kitchen reroute), each checked independently?
- Does the reroute action check both the alternate stock number *and* the shipping cost before firing (ORD-7101 vs. ORD-7102 vs. ORD-7103)?
- Does ORD-7110 get escalated despite being a repeat/"trusted" client, once its actual order value is considered?
- Is the back-order decision on ORD-7108 deliberate and explained, not a silent default?
- Do ORD-7104–7107 (the burst on one scarce item) all get tracked and resolved individually?
- Does ORD-7103 (unavailable everywhere) land in a clear, reviewable terminal state — and, separately, does any dispatch-call failure elsewhere in the flow get a real retry/escalate path instead of a permanent "will process later" placeholder?
- Did everything — two ambiguities, two guardrails, real transient-vs-permanent failure handling, the usual tools and review UI — actually fit in the time given?

Write up what you find as a new file, `T04-catering-orders-gemini-run.md`, next to this one, once the Gemini build is reviewed.
