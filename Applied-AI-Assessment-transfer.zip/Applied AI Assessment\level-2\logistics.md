# Level 2 — Logistics

Operational items needed to actually run this at 300-candidate scale, separate from the content/grading design covered elsewhere in `level-2/`.

## Per-candidate provisioning

- **Instance assignment**: each candidate gets one generated instance (see `generator/`), tracked via the internal manifest — the manifest is never shared with candidates, only the rendered brief.
- **No per-candidate repo to provision.** Submission is a zip upload (see Submission mechanism below), not a hosted repository — this removes the earlier "provision 300 Bitbucket repos" task entirely. Candidates may use whatever version control they like locally during the build; only the final zip is submitted, so no repo hosting, access control, or history-stripping is needed on our end.
- **In-house LLM/MCP access**: credentials or session tokens provisioned per candidate. No known capacity constraint at 300 concurrent-ish users, but **provisioning 300 individual credentials in time is itself a task** — start this in parallel with template authoring, not after. (Note: this access does not need to support server-side interaction logging — see below — so it can be provisioned as ordinary tool access, not a special logged/audited tier.)
- **Clock start**: staggered per candidate as they begin, not one simultaneous cohort start — confirm the submission platform can track individual 24–48hr windows rather than a single fixed deadline for everyone.

## Candidate-facing communication

Must state explicitly, before the candidate starts:

*(Window/start-time mechanics and LLM/MCP credential access are handled operationally — via account activation and the portal itself — rather than as written disclosure items here.)*

1. What to submit and how: **a single zip file** containing their complete project — whatever folder structure they naturally built, no required layout — plus a written rationale (~half page). No repository link, no commit history collected or graded (a zip has none by construction, so candidates should not be told or led to believe their process is being tracked). Grading works from the final code and the rationale only — there is no server-side interaction log either (see `dependencies/llm-gateway-logging.md`, now closed/answered), so nothing about the candidate's process is captured beyond what they choose to write in the rationale.
   - **Required at the zip root: a short `MANIFEST.md`** (a few lines, not a document) pointing to where the key pieces live — the agentic/orchestration logic, the tool definitions, the guardrail check, the persistence code. Folder structure is otherwise entirely up to the candidate; this is the one required signpost so the grader isn't hunting through an unfamiliar layout. The written rationale can serve this purpose instead if it already covers the same ground — don't require both.
   - **Excluded from the zip**: dependency directories (`node_modules`, `venv`/`.venv`, vendored packages), build output, and other generated artifacts — candidates should `.gitignore`-style exclude these before zipping. **Maximum zip size: 10MB.** State this upfront alongside the exclusion list, since a cap this tight only works if candidates know to exclude dependency trees before hitting it — this keeps the grader's context budget spent on the candidate's actual code, not noise.
2. That this round is deliberately difficult and evaluates practitioner-level judgment, not just working code — sets expectations honestly given the "no need to go easy" design intent
3. **That initial grading is done from the submitted code and rationale alone — the application itself is not run during that pass — but candidates who clear that screen will be asked for a short live demonstration of their working application before human review.** State this upfront, not as a surprise sprung on shortlisted candidates later: it's a fair expectation that gives candidates a reason to keep their submission actually runnable, not just plausible-looking on paper.

## Submission mechanism

- **A single upload point per candidate**: the zip (code + `MANIFEST.md`) and the written rationale, submitted together as one bundle — a form/portal accepting one zip upload plus a text/file field for the rationale is simplest; avoid making these two separate submissions that could be mismatched or arrive at different times.
- How "submission closed" is enforced per candidate given staggered start times — the upload portal needs to reject or flag late submissions per-candidate, not on one shared deadline.
- Basic upload hygiene: virus/malware-scan zips before anything (including the AI grader) opens them, and enforce the size cap from above at upload time, not after the fact.
- Confirm the AI grader has direct access to pull each candidate's zip and rationale from the upload store — this needs to be one retrievable bundle per candidate before grading can run, not two separate manual lookups per person at 300-candidate scale. (No LLM-gateway log to retrieve either — see `dependencies/llm-gateway-logging.md`.)
- **No execution environment is provisioned for the 300+ initial screen** — grading is static-only (see `grading/rubric.md` §4), so there's nothing to run or host at that scale; the zip is read, never unpacked-and-run, by the AI grader.
- **Scheduling for the live demonstration** (`grading/cutoff-and-aggregation.md`) only needs to cover the ~100–150 candidates who clear the cutoff, not all 300+ — coordinate this alongside the 3 reviewers' scheduling, not as a separate 300-candidate logistics item. At that stage the candidate runs their own zip's contents live (from wherever they built it), since a live demo requires an actually-running instance, not the static archive.

## Sequencing against the rest of Level 2

This can proceed in parallel with template authoring and grader calibration — it doesn't block on either. The earlier LLM-gateway logging dependency (`dependencies/llm-gateway-logging.md`) is now closed: confirmed no server-side interaction logging is available, so credential provisioning for candidates is ordinary tool access with no logging/audit requirement attached, and this workstream no longer waits on that answer.
