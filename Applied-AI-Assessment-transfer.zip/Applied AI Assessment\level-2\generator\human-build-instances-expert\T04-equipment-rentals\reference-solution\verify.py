"""
Calibration script for the T04-equipment-rentals expert-tier reference
solution. Confirms every planted element actually reproduces/resolves as
INTERNAL-metadata.md describes. Run: python verify.py
"""
import pandas as pd
import db_models
import dispatch_client
from orchestrator import process_order

orders_df = pd.read_csv("rental_orders.csv")
orders_by_id = {row["order_id"]: row for _, row in orders_df.iterrows()}

passed = 0
failed = 0


def check(label, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"[PASS] {label}")
    else:
        failed += 1
        print(f"[FAIL] {label} -- {detail}")


db_models.init_db()

# --- Element 1: ambiguous catalog match (ORD-9001) ---------------------
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9001"])
db_models.save_order("ORD-9001", orders_by_id["ORD-9001"]["client_name"],
                      orders_by_id["ORD-9001"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9001 mixer order flagged AMBIGUOUS, not silently resolved",
      any(it["status"] == "AMBIGUOUS_RECONCILIATION" for it in items),
      f"items={items}")

# --- Element 2: guardrail/ambiguity coupling (ORD-9002) -----------------
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9002"])
db_models.save_order("ORD-9002", orders_by_id["ORD-9002"]["client_name"],
                      orders_by_id["ORD-9002"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9002 face value is $1161 (full order)", face == 1161.0, f"face={face}")
check("ORD-9002 dispatchable value is $36 (tables only, coupled correctly)",
      dispatchable == 36.0, f"dispatchable={dispatchable}")
check("ORD-9002 skid steers held as back-ordered (alt yard genuinely empty)",
      any(it["sku"] == "EQ-103" and it["status"] == "ESCALATED_BACKORDER" for it in items),
      f"items={items}")
check("ORD-9002 clears auto-dispatch on the $36 coupled value, not escalated on $1161",
      status == "PARTIALLY_DISPATCHED", f"status={status}")

# --- Element 4 + stress point: adversarial tool response (ORD-9004) -----
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9004"])
db_models.save_order("ORD-9004", orders_by_id["ORD-9004"]["client_name"],
                      orders_by_id["ORD-9004"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9004 does not trust the alt yard's negative stock reading for EQ-110",
      any(it["sku"] == "EQ-110" and it["status"] == "ESCALATED_INVALID_ALT_DATA" for it in items),
      f"items={items}")
check("ORD-9004 fencing panels still ship despite the light-tower trap",
      any(it["sku"] == "EQ-111" and it["status"] == "AVAILABLE" for it in items),
      f"items={items}")

# --- Three normal reroute directions ------------------------------------
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9005"])
db_models.save_order("ORD-9005", orders_by_id["ORD-9005"]["client_name"],
                      orders_by_id["ORD-9005"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9005 (cheap alt-yard shipping) reroutes automatically",
      any(it["sku"] == "EQ-102" and it["status"] == "REROUTED" for it in items), f"items={items}")

status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9006"])
db_models.save_order("ORD-9006", orders_by_id["ORD-9006"]["client_name"],
                      orders_by_id["ORD-9006"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9006 (expensive alt-yard shipping) escalates, does not reroute",
      any(it["sku"] == "EQ-107" and it["status"] == "ESCALATED_COST" for it in items), f"items={items}")

status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9007"])
db_models.save_order("ORD-9007", orders_by_id["ORD-9007"]["client_name"],
                      orders_by_id["ORD-9007"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9007 (nothing available anywhere) escalates as back-order",
      any(it["sku"] == "EQ-108" and it["status"] == "ESCALATED_BACKORDER" for it in items), f"items={items}")

# --- Sanity check: plain order judged purely on price -------------------
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9008"])
db_models.save_order("ORD-9008", orders_by_id["ORD-9008"]["client_name"],
                      orders_by_id["ORD-9008"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9008 ($1070, one-off event) held for review purely on price",
      status.startswith("ESCALATED"), f"status={status}, dispatchable={dispatchable}")

# --- Addendum 24, back-order divergence: Row A (trivial back-order) -----
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9009"])
db_models.save_order("ORD-9009", orders_by_id["ORD-9009"]["client_name"],
                      orders_by_id["ORD-9009"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9009: $760 of independent, in-stock equipment ships despite vest shortfall",
      dispatchable == 760.0, f"dispatchable={dispatchable}, items={items}")
check("ORD-9009: vests held back-ordered, not blocking the rest",
      any(it["sku"] == "EQ-117" and it["status"] == "ESCALATED_BACKORDER" for it in items),
      f"items={items}")

# --- Addendum 24, back-order divergence: Row B (core item back-ordered) -
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9010"])
db_models.save_order("ORD-9010", orders_by_id["ORD-9010"]["client_name"],
                      orders_by_id["ORD-9010"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9010: dispatchable value is $0 -- accessories held with their back-ordered parent, not shipped alone",
      dispatchable == 0.0, f"dispatchable={dispatchable}, items={items}")
check("ORD-9010: skirting/handrail marked ESCALATED_DEPENDENT, not AVAILABLE",
      all(it["status"] == "ESCALATED_DEPENDENT" for it in items if it["sku"] in ("EQ-114", "EQ-115")),
      f"items={items}")
check("ORD-9010 status is a full escalation, not a partial dispatch",
      status == "ESCALATED_BACKORDER", f"status={status}")

# --- Addendum 24, low-risk divergence: near-identical $ value, --------
# --- different client_type -- both must resolve THE SAME WAY here, ------
# --- since this reference solution deliberately excludes client_type ----
# --- from the risk score (see orchestrator.py / README.md). -------------
status_8, face_8, dispatchable_8, logs_8, items_8 = process_order(orders_by_id["ORD-9008"])
status_11, face_11, dispatchable_11, logs_11, items_11 = process_order(orders_by_id["ORD-9011"])
db_models.save_order("ORD-9011", orders_by_id["ORD-9011"]["client_name"],
                      orders_by_id["ORD-9011"]["client_type"], status_11, face_11, dispatchable_11, logs_11, items_11)
check("ORD-9008 (one-off event, $1070) and ORD-9011 (recurring account, $1060) "
      "resolve to the same outcome class, per this solution's documented policy",
      status_8.startswith("ESCALATED") and status_11.startswith("ESCALATED"),
      f"status_8={status_8}, status_11={status_11}")
check("ORD-9011's log explicitly names client_type as considered-and-excluded, not silently ignored",
      any("client_type" in l and "deliberately excluded" in l for l in logs_11),
      f"logs_11={logs_11}")

# --- Element 3: idempotency / retry-safety (ORD-9003, forced lost response) --
db_models.init_db()
status, face, dispatchable, logs, items = process_order(orders_by_id["ORD-9003"], force_lost_response_for_order="ORD-9003")
db_models.save_order("ORD-9003", orders_by_id["ORD-9003"]["client_name"],
                      orders_by_id["ORD-9003"]["client_type"], status, face, dispatchable, logs, items)
check("ORD-9003 first pass: forced lost-response still resolves to DISPATCHED via retry",
      status == "DISPATCHED", f"status={status}, logs={logs}")
check("ORD-9003 exactly one dispatch record after a forced lost-response retry",
      db_models.count_dispatch_records("ORD-9003") == 1,
      f"count={db_models.count_dispatch_records('ORD-9003')}")

# Explicit double-invoke of the same idempotency key, simulating a retried
# call after a lost response (the review-time procedure from INTERNAL-metadata.md).
dispatchable_skus = sorted(
    f"{it['sku']}:{it['qty']}" for it in items if it["status"] in ("AVAILABLE", "REROUTED")
)
import hashlib
idem_key = hashlib.sha256(f"ORD-9003|dispatch|{'|'.join(dispatchable_skus)}".encode()).hexdigest()
result_a = dispatch_client.dispatch_fulfillment(
    "ORD-9003", [it for it in items if it["status"] == "AVAILABLE"], idem_key,
)
result_b = dispatch_client.dispatch_fulfillment(
    "ORD-9003", [it for it in items if it["status"] == "AVAILABLE"], idem_key,
)
check("ORD-9003 manual double-invoke with the same idempotency key returns identical cached result",
      result_a == result_b, f"a={result_a}, b={result_b}")

# --- Element 5: stale-stock-vs-idempotency collision --------------------
dispatch_client.set_live_primary_stock("EQ-109", 0)
retry_result = dispatch_client.dispatch_fulfillment(
    "ORD-9003", [it for it in items if it["status"] == "AVAILABLE"], idem_key,
)
check("Idempotency-cache-hit retry ignores the now-zeroed stock and returns the original cached SUCCESS",
      retry_result.get("status") == "success", f"retry_result={retry_result}")

print(f"\n{passed}/{passed + failed} checks passed")
if failed:
    raise SystemExit(1)
