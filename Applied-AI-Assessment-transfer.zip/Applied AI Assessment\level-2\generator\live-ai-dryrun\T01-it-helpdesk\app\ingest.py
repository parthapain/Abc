"""
CSV ingestion. Loads the two seed files into SQLite and runs the agent pipeline over
every ticket that doesn't already have a classification (so re-running ingest is safe
and idempotent -- it won't re-process or duplicate actions for tickets already seen).
"""
import csv
import os

from app import database as db
from app import agent

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TICKETS_CSV = os.path.join(BASE_DIR, "helpdesk_tickets.csv")
BILLING_CSV = os.path.join(BASE_DIR, "license_billing_records.csv")


def load_billing_records(path=BILLING_CSV):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            db.load_billing_record(row["requester_name"], float(row["verified_discrepancy"]))


def load_tickets(path=TICKETS_CSV):
    """Load ticket rows into the DB in submitted_at order (so duplicate-history checks
    only ever see genuinely prior tickets), running the agent on any incoming ('new')
    ticket not yet processed.

    Tickets seeded with status 'open' or 'closed' are treated as already-triaged
    history (e.g. HD-3001/HD-3007 in the sample data) -- they're loaded so the
    duplicate/related-history tool can see them, but the agent pipeline only runs on
    'new' tickets, which is what an incoming request stream actually looks like.
    Running auto-triage on a ticket that's already open with a human-escalated
    hardware case, or already closed, would just be wrong.
    """
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    rows.sort(key=lambda r: r["submitted_at"])

    processed = []
    for row in rows:
        db.upsert_ticket(
            row["ticket_id"], row["requester_name"], row["requester_tier"],
            row["status"], row["submitted_at"], row["body_text"],
        )
        already_classified = db.latest_classification(row["ticket_id"]) is not None
        if row["status"] == "new" and not already_classified:
            summary = agent.process_ticket(db.get_ticket(row["ticket_id"]))
            processed.append(summary)
    return processed


def run(reset=False):
    db.init_db(reset=reset)
    load_billing_records()
    return load_tickets()


if __name__ == "__main__":
    results = run(reset=True)
    for r in results:
        print(r)
