# P24 — Budget reconciliation

| Field | Value |
|---|---|
| **ID** | P24 |
| **Difficulty** | High |
| **Bug pattern** | Exact equality on accumulated floating-point values |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A reconciliation job checks whether each account's charges add up to its allocated budget.

Accounts that visibly balance are being reported as mismatched. The pattern is that accounts made up of **many small charges** fail, while accounts with one or two large charges reconcile correctly.

### Required behaviour

For every account in `budgets`, return `(account, matches)` ordered by `account` ascending, where `matches` is true when the account's total charges equal its budget.

Amounts are currency values. Treat a difference of **less than 0.01** as equal.

### Schema

```sql
CREATE TABLE budgets (
    account TEXT PRIMARY KEY,
    budget  REAL NOT NULL
);
CREATE TABLE charges (
    id      INTEGER PRIMARY KEY,
    account TEXT NOT NULL REFERENCES budgets(account),
    amount  REAL NOT NULL
);
```

---

## Fixture — `P24.sql`

```sql
CREATE TABLE budgets (
    account TEXT PRIMARY KEY,
    budget  REAL NOT NULL
);
CREATE TABLE charges (
    id      INTEGER PRIMARY KEY,
    account TEXT NOT NULL REFERENCES budgets(account),
    amount  REAL NOT NULL
);

INSERT INTO budgets (account, budget) VALUES ('A', 1.0);
INSERT INTO charges (id, account, amount) VALUES
    (1,'A',0.1),(2,'A',0.1),(3,'A',0.1),(4,'A',0.1),(5,'A',0.1),
    (6,'A',0.1),(7,'A',0.1),(8,'A',0.1),(9,'A',0.1),(10,'A',0.1);
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

TOLERANCE = 0.01

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def reconcile(db_path: str) -> List[Tuple[str, bool]]:
    """
    Return (account, matches) ordered by account ascending.
    A difference of less than TOLERANCE counts as equal.
    """
    conn = _connect(db_path)
    try:
        totals = {}
        for account, amount in conn.execute(
            "SELECT account, amount FROM charges ORDER BY id"
        ).fetchall():
            totals[account] = totals.get(account, 0.0) + amount

        budgets = conn.execute(
            "SELECT account, budget FROM budgets ORDER BY account"
        ).fetchall()
    finally:
        conn.close()

    return [(account, totals.get(account, 0.0) == budget) for account, budget in budgets]
```

### Java

```java
import java.sql.*;
import java.util.*;

public class Reconciler {

    public static final double TOLERANCE = 0.01;

    // --- boilerplate: do not modify ---
    public static class AccountResult {
        public final String account;
        public final boolean matches;

        public AccountResult(String account, boolean matches) {
            this.account = account;
            this.matches = matches;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (account, matches) ordered by account ascending.
     * A difference of less than TOLERANCE counts as equal.
     */
    public static List<AccountResult> reconcile(String dbPath) throws SQLException {
        Map<String, Double> totals = new HashMap<>();
        List<AccountResult> out = new ArrayList<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement()) {

            try (ResultSet rs = stmt.executeQuery(
                     "SELECT account, amount FROM charges ORDER BY id")) {
                while (rs.next()) {
                    totals.merge(rs.getString("account"), rs.getDouble("amount"), Double::sum);
                }
            }

            try (ResultSet rs = stmt.executeQuery(
                     "SELECT account, budget FROM budgets ORDER BY account")) {
                while (rs.next()) {
                    String account = rs.getString("account");
                    double budget = rs.getDouble("budget");
                    double total = totals.getOrDefault(account, 0.0);
                    out.add(new AccountResult(account, total == budget));
                }
            }
        }
        return out;
    }
}
```

### C#

```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record AccountResult(string Account, bool Matches);

public static class Reconciler
{
    public const double Tolerance = 0.01;

    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Account, Matches) ordered by Account ascending.
    /// A difference of less than Tolerance counts as equal.
    /// </summary>
    public static List<AccountResult> Reconcile(string dbPath)
    {
        using var conn = Connect(dbPath);

        var totals = new Dictionary<string, double>();
        foreach (var (account, amount) in conn.Query<(string Account, double Amount)>(
                     "SELECT account, amount FROM charges ORDER BY id"))
        {
            totals[account] = totals.GetValueOrDefault(account) + amount;
        }

        var budgets = conn.Query<(string Account, double Budget)>(
            "SELECT account, budget FROM budgets ORDER BY account").ToList();

        return budgets
            .Select(b => new AccountResult(
                b.Account, totals.GetValueOrDefault(b.Account) == b.Budget))
            .ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `A`: ten charges of `0.1`, budget `1.0` | `[("A", true)]` | **Discriminator** — broken returns `false` |
| T2 | `B`: two charges of `0.5`, budget `1.0` | `[("B", true)]` | Guard — `0.5 + 0.5` is exact in binary |
| T3 | `C`: three charges of `0.1`, budget `0.3` | `[("C", true)]` | **Discriminator** — broken returns `false` |
| T4 | `D`: one charge of `5.0`, budget `10.0` | `[("D", false)]` | Guard — genuinely mismatched |
| T5 | No budgets | `[]` | Guard |
| T6 | `E`: one charge of `1.6`, budget `2.0` | `[("E", false)]` | Guard — a 0.4 gap, outside tolerance but inside whole-unit rounding |

### Fixtures

```sql
-- T2
INSERT INTO budgets (account, budget) VALUES ('B', 1.0);
INSERT INTO charges (id, account, amount) VALUES (1,'B',0.5),(2,'B',0.5);
-- T3
INSERT INTO budgets (account, budget) VALUES ('C', 0.3);
INSERT INTO charges (id, account, amount) VALUES (1,'C',0.1),(2,'C',0.1),(3,'C',0.1);
-- T4
INSERT INTO budgets (account, budget) VALUES ('D', 10.0);
INSERT INTO charges (id, account, amount) VALUES (1,'D',5.0);
-- T6
INSERT INTO budgets (account, budget) VALUES ('E', 2.0);
INSERT INTO charges (id, account, amount) VALUES (1,'E',1.6);
```

---

## Reference solution

Compare within the stated tolerance rather than exactly.

**Python:**

```diff
- return [(account, totals.get(account, 0.0) == budget) for account, budget in budgets]
+ return [(account, abs(totals.get(account, 0.0) - budget) < TOLERANCE)
+         for account, budget in budgets]
```

**Java:**

```diff
- out.add(new AccountResult(account, total == budget));
+ out.add(new AccountResult(account, Math.abs(total - budget) < TOLERANCE));
```

**C#:**

```diff
- b.Account, totals.GetValueOrDefault(b.Account) == b.Budget))
+ b.Account, Math.Abs(totals.GetValueOrDefault(b.Account) - b.Budget) < Tolerance))
```

### Why

`0.1` has no exact binary representation, so each addition carries a small rounding error. Adding it ten times gives `0.9999999999999999`, not `1.0`. The values are equal to fifteen significant figures and still compare unequal, because `==` on doubles asks for bit-for-bit identity.

This explains the reported pattern exactly. Accounts built from many small charges accumulate error across many additions; accounts with one or two large charges have almost none. `0.5 + 0.5` is exact because `0.5` is a power of two, which is why T2 reconciles correctly and hides the bug.

The specification already anticipated this by defining equality as a difference below `0.01` — the requirement was written correctly and the implementation ignored it. Note that the tolerance also has to be *appropriate*: too tight and accumulated error still fails, too loose and genuinely different amounts are declared equal. T6 pins this down with a 0.4 gap, which must be reported as a mismatch.

For real currency work the deeper fix is not to use binary floating point at all — store minor units as integers, or use `Decimal` / `BigDecimal` / `decimal`. That is the right answer in production and worth crediting if a candidate raises it, but it is out of scope for a fix to this function.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Rounding both sides to whole units before comparing | T6 — a 0.4 gap rounds away and is wrongly declared a match |
| Comparing formatted strings | Passes here, but fails on differing precision — flag in review |
| Widening the tolerance to `1.0` | T6 — masks a genuine mismatch |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T6
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5, T6**
- [ ] Failure is a wrong boolean, not a crash
- [ ] Confirm the sandbox stores `REAL` as IEEE-754 double so the drift reproduces — an engine using exact decimals would eliminate the bug entirely
- [ ] **T6 is present** — without it, "round both sides to whole units" passes and the tolerance is untested
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
