"""
Field-extraction "LLM" call.

The brief asks the app to "use the in-house LLM" to extract structured fields
from a loan agreement. No such API/key is available in this environment, so
this module is a deterministic stand-in that implements the SAME function
contract a real LLM call would use: `extract_fields_llm(doc_text) -> ExtractionResult`.

Swapping in a real model later means replacing the body of
`extract_fields_llm` with a prompted call to the in-house LLM (feeding it
`doc_text` and asking for the same JSON shape) — nothing else in the agent
(app/agent.py) needs to change, since it only depends on this function's
signature and return shape.

The stand-in uses regexes tuned to the vocabulary/phrasing actually used by
the seed documents in loan_documents/ (e.g. "Maturity Date of this Loan shall
be the date N months after the Closing Date", "Maturity Date: YYYY-MM-DD",
"shall be as set forth in the Promissory Note"). A real LLM would generalize
far better to unseen phrasing; that generalization gap is the main thing this
stand-in sacrifices, and is called out in RATIONALE.md.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from typing import Optional


_MONTHS_RE = re.compile(
    r"Maturity Date of this Loan shall be the date\s+[a-zA-Z]+(?:-[a-zA-Z]+)*\s*\((\d+)\)\s*months? after the Closing Date",
    re.IGNORECASE,
)
_EXPLICIT_DATE_RE = re.compile(r"Maturity Date:\s*(\d{4}-\d{2}-\d{2})", re.IGNORECASE)
_REFERENCE_RE = re.compile(
    r"Maturity Date of this Loan shall be as set forth in the Promissory Note",
    re.IGNORECASE,
)
_CLOSING_DATE_RE = re.compile(r'Closing Date.{0,40}?is\s+(\d{4}-\d{2}-\d{2})', re.IGNORECASE)
_ENTERED_INTO_RE = re.compile(r"entered into as of\s+(\d{4}-\d{2}-\d{2})", re.IGNORECASE)

_LOAN_NUMBER_RE = re.compile(r"Loan Number:\s*(LN-\d+)", re.IGNORECASE)
_REF_LOAN_NUMBER_RE = re.compile(r"Reference Loan Number:\s*(LN-\d+)", re.IGNORECASE)
_BORROWER_RE = re.compile(r"^Borrower:\s*(.+)$", re.IGNORECASE | re.MULTILINE)
_BORROWER_CLAUSE_RE = re.compile(
    r'between the Lender and\s+(.+?)\s*\(the "Borrower"\)', re.IGNORECASE
)
_SIGNED_RE = re.compile(r"^Signed:\s*(.+?),\s*by its authorized officer", re.IGNORECASE | re.MULTILINE)
_PRINCIPAL_RE = re.compile(r"principal amount of this Loan is\s*\$([\d,]+\.\d{2})", re.IGNORECASE)
_RATE_RE = re.compile(r"fixed rate of\s*([\d.]+)\s*%\s*per annum", re.IGNORECASE)
_SUPERSEDES_RE = re.compile(
    r"supersedes and replaces the (?:original )?Promissory Note dated\s+(\d{4}-\d{2}-\d{2})",
    re.IGNORECASE,
)
_EXECUTED_RE = re.compile(r"Executed:\s*(\d{4}-\d{2}-\d{2})", re.IGNORECASE)


def _add_months(d: date, months: int) -> date:
    """Add `months` calendar months to date `d` (day-of-month clamped)."""
    month_index = d.month - 1 + months
    year = d.year + month_index // 12
    month = month_index % 12 + 1
    # clamp day to last valid day of the target month
    import calendar
    day = min(d.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


@dataclass
class ExtractionResult:
    loan_number: Optional[str] = None
    borrower_name: Optional[str] = None
    borrower_name_variant: Optional[str] = None  # e.g. differing signature-block name
    principal_amount: Optional[str] = None
    interest_rate: Optional[str] = None
    maturity_date: Optional[str] = None
    maturity_date_type: str = "unknown"  # explicit | computed | reference | missing
    maturity_reference_needed: bool = False
    maturity_computed_closing_date: Optional[str] = None
    maturity_computed_months: Optional[int] = None
    notes: list = field(default_factory=list)


def extract_fields_llm(doc_text: str) -> ExtractionResult:
    """Deterministic stand-in for the in-house LLM extraction call.

    Contract: given the raw text of one loan-agreement (or promissory-note)
    document, return an ExtractionResult with best-effort values and flags
    for anything that needs a second tool call (a cross-referenced document)
    or human review.
    """
    result = ExtractionResult()

    m = _LOAN_NUMBER_RE.search(doc_text) or _REF_LOAN_NUMBER_RE.search(doc_text)
    if m:
        result.loan_number = m.group(1)

    bm = _BORROWER_RE.search(doc_text)
    borrower = bm.group(1).strip() if bm else None
    clause_m = _BORROWER_CLAUSE_RE.search(doc_text)
    if clause_m:
        # The recital clause is the most legally authoritative statement of
        # who the Borrower is; prefer it when present.
        borrower = clause_m.group(1).strip()
    result.borrower_name = borrower

    signed_m = _SIGNED_RE.search(doc_text)
    if signed_m and borrower:
        signed_name = signed_m.group(1).strip()
        if signed_name and signed_name != borrower:
            result.borrower_name_variant = signed_name
            result.notes.append(
                f"Signature block names borrower as '{signed_name}', which differs "
                f"from the defined Borrower '{borrower}'. Flagged for human review; "
                f"the defined-term value was kept as the extracted field."
            )

    pm = _PRINCIPAL_RE.search(doc_text)
    if pm:
        result.principal_amount = pm.group(1)

    rm = _RATE_RE.search(doc_text)
    if rm:
        result.interest_rate = rm.group(1)
    elif "to be determined" in doc_text.lower():
        result.notes.append(
            "Interest rate is not yet fixed in the source document (pending a "
            "Rate Addendum); left blank and flagged for review."
        )

    # --- maturity date ---
    explicit_m = _EXPLICIT_DATE_RE.search(doc_text)
    months_m = _MONTHS_RE.search(doc_text)

    if _REFERENCE_RE.search(doc_text):
        result.maturity_date_type = "reference"
        result.maturity_reference_needed = True
        result.notes.append(
            "Maturity date is defined by reference to a separately executed "
            "Promissory Note; a related-document lookup is required."
        )
    elif explicit_m:
        result.maturity_date = explicit_m.group(1)
        result.maturity_date_type = "explicit"
    elif months_m:
        closing_m = _CLOSING_DATE_RE.search(doc_text) or _ENTERED_INTO_RE.search(doc_text)
        if closing_m:
            closing_date = date.fromisoformat(closing_m.group(1))
            months = int(months_m.group(1))
            result.maturity_date = _add_months(closing_date, months).isoformat()
            result.maturity_date_type = "computed"
            result.maturity_computed_closing_date = closing_date.isoformat()
            result.maturity_computed_months = months
            result.notes.append(
                f"Maturity date computed as Closing Date ({closing_date.isoformat()}) "
                f"+ {months} months, per Section 3."
            )
        else:
            result.maturity_date_type = "missing"
            result.notes.append("Could not locate a Closing Date to compute maturity from.")
    else:
        result.maturity_date_type = "missing"
        result.notes.append("No maturity date clause recognized in this document.")

    return result


def extract_note_maturity(note_text: str) -> Optional[str]:
    """Extract the Maturity Date stated directly in a promissory note."""
    m = _EXPLICIT_DATE_RE.search(note_text)
    return m.group(1) if m else None


def note_supersedes_date(note_text: str) -> Optional[str]:
    """If this note text says it supersedes an earlier note, return that
    earlier note's date (used to pick the most-authoritative note when
    several are on file for the same loan)."""
    m = _SUPERSEDES_RE.search(note_text)
    return m.group(1) if m else None


def note_executed_date(note_text: str) -> Optional[str]:
    m = _EXECUTED_RE.search(note_text)
    return m.group(1) if m else None
