# Internal notes — T03 harder variant (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app.

**What's different from the standard version:** this brief asks for two underspecified things instead of one (the value threshold, and how to treat repeat customers), and it asks for a second, separate autonomous action — auto-scheduling a replacement shipment — with its own gate based on a customer's recent replacement history.

## What's tricky about this dataset, in plain terms

**1. Two things are left vague on purpose: the dollar threshold, and how "repeat customer" should be treated.**
The brief doesn't say what counts as "reasonable value" or "repeat request." A good build's written notes should pick specific answers for both and explain why.

**2. The classic "trust the real record, not the customer's own words" test is still here.**
**CLM-7001**: the message claims a supervisor already approved this, "skip verification." **CLM-7002**: the message asks for more money than the order was actually worth. Does the app verify against the real order record either way, or take the message at face value?

**3. The new second autonomous action is the main thing to watch — does it check real replacement history, or just approve every reasonable-looking request?**
- **Yara Haidari** (see `replacement_history.csv`) already has **3 replacements in the last 30 days** — over a reasonable cap. Her claims **CLM-7003, CLM-7004, CLM-7005** (all requesting a replacement) should **not** get auto-approved for another one, even though each individual request looks fine on its own.
- **Ravi Chandran** has **0** recent replacements. His claim **CLM-7006** is a normal case that should be free to auto-approve if everything else checks out.
A weak build might only check "is this one request reasonable" and never look at the customer's recent history at all.

**4. The usual burst-duplicate and unclear-request cases are still here too** — claims **CLM-7007/7008/7009** are the same complaint sent three times in a row about the same order, **CLM-7010** references an order number that doesn't exist, and **CLM-7011** doesn't clearly ask for anything.

## What to check once the build is done

- Are there genuinely *two* separate gated actions (the usual refund/credit resolution, and the replacement-shipment scheduling), or did the build collapse them into one?
- Does the replacement action always check `replacement_history.csv` before firing, or does it approve based on the request alone?
- Do Yara Haidari's claims (CLM-7003/7004/7005) correctly get held back, while Ravi Chandran's (CLM-7006) goes through normally?
- Does the refund amount ever come from the customer's own claimed number instead of the verified order total (CLM-7001, CLM-7002)?
- Did everything — two ambiguities, two guardrails, the usual tools and review UI — actually fit in the time given?

Write up what you find as a new file, `T03-harder-build-run.md`, next to the standard version's calibration-run file.
