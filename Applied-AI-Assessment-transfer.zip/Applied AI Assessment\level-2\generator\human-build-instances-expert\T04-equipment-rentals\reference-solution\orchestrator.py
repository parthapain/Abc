import hashlib
import pandas as pd
from dispatch_client import dispatch_fulfillment, TransientDispatchError, PermanentDispatchError
import db_models

catalog_df = pd.read_csv("equipment_catalog.csv").set_index("sku")
alt_df = pd.read_csv("alt_yard_inventory.csv").set_index("sku")

AUTO_DISPATCH_MAX_VALUE = 1000.00
MAX_SHIP_COST_RATIO = 0.30  # shipping must not exceed 30% of the item's own unit price

# Ambiguity #2 ("what counts as low-risk") -- deliberate resolution, isolated
# behind a single flag so it's a one-line change if this assumption is wrong.
# `client_type` ("recurring corporate account" vs. "one-off event") is present
# in the ingested order data, but a repeat business relationship doesn't
# change the physical/logistical risk of a dispatch action -- it's a
# relationship signal, not a fulfillment-risk signal. Risk here is judged
# purely on dispatchable order value. See README.md "Key decisions".
USE_CLIENT_TYPE_IN_RISK = False

# Ambiguity #1 ("what to do with back-ordered items") -- resolution: ship the
# dispatchable remainder now, hold the rest for review, UNLESS a currently-
# shippable item is functionally an accessory of a back-ordered item (useless
# on its own) -- in that case, hold the accessory with its parent rather than
# shipping garnish with no entree. This mapping is this reference solution's
# own judgment call about which catalog items are accessory-of which; a real
# candidate would have to make the same kind of call from the item names.
ACCESSORY_OF = {
    "EQ-114": "EQ-113",  # Stage Skirting -- Event Stage Platform
    "EQ-115": "EQ-113",  # Stage Handrail Kit -- Event Stage Platform
}

# Catalog rows grouped by "base name" (the part before " - "), so we can
# tell whether an incoming description that omits the qualifier (size,
# color, capacity...) is actually ambiguous between more than one real item.
_by_base_name = {}
for sku, row in catalog_df.iterrows():
    base = row["name"].split(" - ")[0].strip().lower()
    _by_base_name.setdefault(base, []).append(sku)


def reconcile_line_item(raw_desc):
    """
    Returns one of:
      {"status": "RESOLVED", "sku": ...}
      {"status": "AMBIGUOUS", "candidates": [sku, ...]}
      {"status": "UNRESOLVED"}
    Never silently picks one of several equally-plausible catalog items.
    """
    desc_lower = raw_desc.strip().lower()

    # 1) exact/substring match against a specific catalog name first (handles
    #    line items that already name the qualifier, e.g.
    #    "Concrete Mixer - 6cu ft" or "Scissor Lift - 32ft")
    exact_matches = [sku for sku, row in catalog_df.iterrows()
                     if row["name"].lower() == desc_lower]
    if len(exact_matches) == 1:
        return {"status": "RESOLVED", "sku": exact_matches[0]}

    contains_matches = [sku for sku, row in catalog_df.iterrows()
                         if desc_lower in row["name"].lower()]
    if len(contains_matches) == 1:
        return {"status": "RESOLVED", "sku": contains_matches[0]}

    # 2) bare base-name match (no qualifier given) -- check ambiguity
    #    against how many real catalog items share that base name.
    if desc_lower in _by_base_name:
        candidates = _by_base_name[desc_lower]
        if len(candidates) == 1:
            return {"status": "RESOLVED", "sku": candidates[0]}
        return {"status": "AMBIGUOUS", "candidates": candidates}

    if len(contains_matches) > 1:
        return {"status": "AMBIGUOUS", "candidates": contains_matches}

    return {"status": "UNRESOLVED"}


def check_alt_yard(sku):
    """
    Returns (alt_stock, ship_cost, valid) -- 'valid' is False when the tool's
    own response doesn't make sense (e.g. a negative stock count) and must
    not be trusted as real availability.
    """
    if sku not in alt_df.index:
        return None, None, True  # no row at all -- legitimately nothing to check
    alt_stock = alt_df.loc[sku, "alt_stock"]
    ship_cost = alt_df.loc[sku, "ship_cost"]
    if alt_stock < 0 or ship_cost < 0:
        return alt_stock, ship_cost, False
    return alt_stock, ship_cost, True


def _parse_line_items(line_items_description):
    raw_items = [i.strip() for i in line_items_description.split(",")]
    parsed = []
    for raw in raw_items:
        qty_str, _, desc = raw.partition("x")
        qty = int(qty_str.strip()) if qty_str.strip().isdigit() else 1
        parsed.append({"desc": desc.strip(), "qty": qty})
    return parsed


def process_order(order_row, force_lost_response_for_order=None):
    order_id = order_row["order_id"]
    client_type = order_row["client_type"]
    logs = [f"Started processing {order_id} (client_type='{client_type}')"]
    raw_items = _parse_line_items(order_row["line_items_description"])

    resolved_items = []
    order_face_value = 0.0
    any_needs_review = False

    for raw in raw_items:
        logs.append(f"Reconciling: '{raw['qty']}x {raw['desc']}'")
        rec = reconcile_line_item(raw["desc"])

        if rec["status"] == "AMBIGUOUS":
            logs.append(
                f"AMBIGUOUS: '{raw['desc']}' matches more than one catalog item "
                f"({', '.join(rec['candidates'])}) -- escalating for human reconciliation, not guessing."
            )
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": "AMBIGUOUS", "qty": raw["qty"],
                "status": "AMBIGUOUS_RECONCILIATION", "source": "NONE", "value": 0.0,
            })
            continue

        if rec["status"] == "UNRESOLVED":
            logs.append(f"Could not match '{raw['desc']}' to any catalog item -- escalating.")
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": "UNKNOWN", "qty": raw["qty"],
                "status": "UNRESOLVED", "source": "NONE", "value": 0.0,
            })
            continue

        sku = rec["sku"]
        unit_price = float(catalog_df.loc[sku, "price_per_day"])
        primary_stock = int(catalog_df.loc[sku, "in_stock"])
        line_value = unit_price * raw["qty"]
        order_face_value += line_value

        if raw["qty"] <= primary_stock:
            logs.append(f"{sku}: available at primary yard.")
            resolved_items.append({
                "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
                "status": "AVAILABLE", "source": "PRIMARY", "value": line_value,
            })
            continue

        # Primary yard can't cover it -- second guardrail: alternate-yard reroute
        logs.append(f"{sku}: insufficient primary stock ({primary_stock} < {raw['qty']}). Checking alt yard.")
        alt_stock, ship_cost, valid = check_alt_yard(sku)

        if alt_stock is None:
            logs.append(f"{sku}: not carried at the alt yard either -- back-ordered, escalating for review.")
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
                "status": "ESCALATED_BACKORDER", "source": "NONE", "value": line_value,
            })
            continue

        if not valid:
            logs.append(
                f"{sku}: alt-yard response is invalid (alt_stock={alt_stock}, ship_cost={ship_cost}) "
                f"-- not trusting this data, treating as no usable alt stock, escalating."
            )
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
                "status": "ESCALATED_INVALID_ALT_DATA", "source": "NONE", "value": line_value,
            })
            continue

        if alt_stock < raw["qty"]:
            logs.append(f"{sku}: alt yard only has {alt_stock}, need {raw['qty']} -- escalating.")
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
                "status": "ESCALATED_BACKORDER", "source": "NONE", "value": line_value,
            })
            continue

        if ship_cost > unit_price * MAX_SHIP_COST_RATIO:
            logs.append(
                f"{sku}: alt yard has stock, but shipping (${ship_cost}) exceeds the reasonable "
                f"threshold for a ${unit_price} item -- escalating, not rerouting."
            )
            any_needs_review = True
            resolved_items.append({
                "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
                "status": "ESCALATED_COST", "source": "NONE", "value": line_value,
            })
            continue

        logs.append(f"{sku}: alt yard confirms real stock and shipping (${ship_cost}) is reasonable -- rerouting.")
        resolved_items.append({
            "desc": raw["desc"], "sku": sku, "qty": raw["qty"],
            "status": "REROUTED", "source": "ALT_YARD", "value": line_value,
        })

    # Back-order policy (ambiguity #1): ship whatever's dispatchable now, hold
    # everything else for review -- UNLESS an item that's currently
    # dispatchable is functionally an accessory of an item that ISN'T (its
    # parent is back-ordered/escalated). Shipping accessories alone isn't a
    # sensible partial fulfillment, so pull them into the held set too.
    dispatchable_skus_now = {it["sku"] for it in resolved_items if it["status"] in ("AVAILABLE", "REROUTED")}
    for it in resolved_items:
        parent = ACCESSORY_OF.get(it["sku"])
        if parent and it["status"] in ("AVAILABLE", "REROUTED") and parent not in dispatchable_skus_now:
            logs.append(
                f"{it['sku']} is an accessory of {parent}, which isn't shipping this round -- "
                f"holding it with its parent rather than shipping it alone."
            )
            it["status"] = "ESCALATED_DEPENDENT"
            it["source"] = "NONE"
            any_needs_review = True

    dispatchable_value = sum(
        it["value"] for it in resolved_items if it["status"] in ("AVAILABLE", "REROUTED")
    )

    if not USE_CLIENT_TYPE_IN_RISK:
        logs.append(
            f"client_type='{client_type}' noted but deliberately excluded from the auto-dispatch "
            f"risk score -- a repeat business relationship doesn't change the physical/logistical "
            f"risk of a dispatch action. Risk is judged on dispatchable order value alone."
        )

    if not resolved_items:
        return "ESCALATED_EMPTY", order_face_value, dispatchable_value, logs, resolved_items

    if dispatchable_value == 0.0:
        logs.append("Nothing in this order is dispatchable right now -- holding entirely for review.")
        return "ESCALATED_BACKORDER", order_face_value, dispatchable_value, logs, resolved_items

    if dispatchable_value > AUTO_DISPATCH_MAX_VALUE:
        final_status = "ESCALATED_VALUE" if not any_needs_review else "ESCALATED_PARTIAL"
        logs.append(
            f"Dispatchable portion (${dispatchable_value}) exceeds the auto-dispatch threshold "
            f"(${AUTO_DISPATCH_MAX_VALUE}) -- escalating for review."
        )
        return final_status, order_face_value, dispatchable_value, logs, resolved_items

    logs.append(
        f"Dispatchable portion (${dispatchable_value}) clears the auto-dispatch threshold "
        f"-- attempting dispatch for the available/rerouted items only."
    )

    dispatchable_skus = sorted(
        f"{it['sku']}:{it['qty']}" for it in resolved_items
        if it["status"] in ("AVAILABLE", "REROUTED")
    )
    idempotency_key = hashlib.sha256(
        f"{order_id}|dispatch|{'|'.join(dispatchable_skus)}".encode()
    ).hexdigest()

    force_lost_response = (order_id == force_lost_response_for_order)

    dispatch_success = False
    final_status = "PENDING"
    for attempt in range(3):
        try:
            result = dispatch_fulfillment(
                order_id,
                [it for it in resolved_items if it["status"] in ("AVAILABLE", "REROUTED")],
                idempotency_key,
                force_lost_response=(force_lost_response and attempt == 0),
            )
            is_new = db_models.record_dispatch(order_id, idempotency_key, result["dispatch_id"])
            logs.append(
                f"Dispatch call succeeded (dispatch_id={result['dispatch_id']}); "
                f"{'new fulfillment record created' if is_new else 'already recorded -- retry correctly did not duplicate'}."
            )
            dispatch_success = True
            final_status = "DISPATCHED" if not any_needs_review else "PARTIALLY_DISPATCHED"
            break
        except TransientDispatchError as e:
            logs.append(f"Transient failure on attempt {attempt + 1}: {e}")
        except PermanentDispatchError as e:
            logs.append(f"Permanent failure: {e}")
            final_status = "ESCALATED_UNAVAILABLE"
            break

    if not dispatch_success and final_status == "PENDING":
        logs.append("Max retries reached without success -- escalating to a human.")
        final_status = "ESCALATED_NETWORK"

    return final_status, order_face_value, dispatchable_value, logs, resolved_items
