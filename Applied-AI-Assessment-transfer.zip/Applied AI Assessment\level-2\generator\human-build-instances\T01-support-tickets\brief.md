# Build Brief — Support Ticket Triage & Classification

Your organization receives a continuous stream of support tickets — customer-submitted requests describing a problem or question. Build an application that:

1. Ingests support tickets (a seed dataset is provided — `support_tickets_seed.csv`)
2. Uses the in-house LLM to classify each one into the categories: **Billing, Technical Issue, Account Access, Feature Request, Complaint**
3. Works as an agent, not a single call: after classifying, check for duplicate or related history on the ticket via a tool, and pull additional context via a second tool if the classification is uncertain — then decide how to proceed
4. **Prioritize support tickets appropriately so urgent ones surface first.**
5. For tickets that are low-risk and high-confidence, autonomously acknowledge, auto-close (if a genuine duplicate), or auto-route the ticket — gated by an explicit confidence/policy threshold; anything above that threshold, or anything the tools couldn't resolve, is escalated to a human
6. Provides a UI where a human can review classifications, any automatic actions taken, see the LLM's reasoning, and override them
7. Persists tickets, their classifications, actions taken, and any human overrides to a database

The dataset includes some tickets that are blank or empty in their body text — your solution should handle these sensibly rather than crashing or producing silently wrong output.

**Submit:** a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, guardrail check, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

**Target build time:** 24–48 hours.
