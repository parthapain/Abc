# Rationale

## Architecture
Flask + SQLite, no JS framework. `interpreter.py` (LLM stand-in) produces a structured
intent; `tools.py` holds the discrete, auditable operations (lookup booking, verify
support, issue refund, look up rebooking history, schedule rebooking); `agent.py` is the
only thing that calls tools and makes decisions, and it logs every step to `reasoning_log`
so the UI can render the full trace, not just the outcome. This keeps the "agent, not a
single call" requirement concrete: interpretation never triggers an action by itself.

## No LLM API key available
I checked the environment for `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `LLM_API_KEY`, and
`AZURE_OPENAI_*` — none were set. Per the brief's allowance for this case, `interpreter.py`
implements a deterministic, keyword/regex-based stand-in behind the exact function
signature (`interpret_request(text, booking_ref_field) -> dict`) a real model call would
use. Swapping in a real LLM later is a one-file change.

## Key judgment calls on underspecified points

**"Reasonable value threshold" (req #4):** set to $500. The seed data splits cleanly
around it — routine domestic-scale disruptions ($150–$450) auto-resolve, high-value
international ones ($1180–$1500) go to a human even when clearly supported. This is a
config constant (`agent.REFUND_VALUE_THRESHOLD`), not a hardcoded branch, so it's easy to
tune.

**"Reasonable cap" for rebooking (req #7):** set to 2 rebookings in the trailing 30-day
window (`agent.REBOOKING_CAP`), based on the same instinct: one rebooking is routine, three
(as in the seed data) suggests a pattern worth a human's judgment. A customer absent from
`rebooking_history.csv` is treated as 0, not as missing/blocked — the CSV only lists
customers with a nonzero count, so absence is the normal case, not an error.

**Refund amount is always the booking record's `credit_value`, never the dollar figure the
customer typed.** One seed request states a specific self-reported amount that's well
above what the record authorizes. I treat the structured record as the system of truth and
the free-text amount as informational only, logging the discrepancy for the reviewer. The
alternative — trusting customer-stated dollar amounts — is a resolvable-any-day incentive
problem I wasn't willing to build in.

**Untrusted free text is never parsed as an instruction.** One seed request embeds a line
addressed to "processing team" asking to skip verification. `interpreter.py`'s docstring
calls this out explicitly: the function extracts only `action` / `stated_reason` /
`stated_amount` / `referenced_booking_ref` — there is no field, anywhere in the pipeline,
that a request's free text could populate to alter agent behavior. `test_agent.py::test_
customer_name_mismatch_flagged_despite_injection_attempt` exercises this directly (that
request also has a genuine name mismatch against the booking record, which is a second,
independent reason it's correctly flagged rather than auto-resolved).

**Booking not found, and customer-name mismatch, both block auto-resolution.** Neither is
explicitly named in the brief, but "check whether the request is actually supported by
that record" (req #3) implies both: a missing booking can't support anything, and a record
belonging to a different customer doesn't support this customer's claim.

**Negative/invalid `credit_value` is treated as unsupported, not as $0 owed or an error to
crash on.** One seed booking has `credit_eligible=True` but `credit_value=-75.00`, a data
integrity issue a real system could plausibly produce (refund minus a fee, computed
wrong). I chose to fail safe — flag for review — rather than guess.

## Where I overrode what I'd have otherwise done reflexively
My first instinct was to make `verify_request_supported` also hard-require the
interpreter's guessed `stated_reason` to exactly equal the booking's `verified_category`.
I backed off that: the deterministic classifier's reason-guessing is the weakest link in
the pipeline (a real LLM would do much better), and making a brittle keyword match a hard
gate would produce false "unsupported" flags on phrasing the classifier just didn't
recognize. Instead the hard gates are on facts a rule-based check can get right
every time: does the booking exist, does the name match, is it credit-eligible, is the
credit value positive. `stated_reason` still gets logged and shown to the reviewer.

## Limitations / what I'd do with more time
- The rebooking "replacement flight" is a stub description string, not a real inventory
  lookup — there's no flight-availability data in the seed set to schedule against.
- The interpreter's category/action detection is keyword-based and would misclassify
  phrasing outside the seed set's style; a real LLM call would need eval'ing against a
  broader, adversarial set of request phrasings (including more injection attempts) before
  I'd trust it in the hard gates above.
- No auth on the review UI — any visitor can override. A real version needs reviewer
  identity tied to session/login, not a free-text name field.
- Override "approve" re-derives the original intent from the reasoning log rather than
  storing a first-class "pending action" object; that's a reasonable simplification for
  this scope but I'd formalize it as its own table if this grew.
- Concurrency: SQLite with no locking strategy beyond its defaults; fine for this scale,
  not for a production multi-worker deployment.
