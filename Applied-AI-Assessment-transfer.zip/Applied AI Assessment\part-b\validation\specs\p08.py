"""P08 — Per-model token totals. Medium · host-located · accumulator not reset per group."""

META = {"difficulty": "Medium", "location": "host", "pattern": "accumulator reset in wrong scope"}

SCHEMA = """
CREATE TABLE usage_log (
    id      INTEGER PRIMARY KEY,
    model   TEXT NOT NULL,
    tokens  INTEGER NOT NULL
);
"""

_QUERY = "SELECT model, tokens FROM usage_log ORDER BY model, id"


def broken(conn):
    rows = conn.execute(_QUERY).fetchall()
    totals, running, current = [], 0, None
    for model, tokens in rows:
        if model != current:
            if current is not None:
                totals.append((current, running))
            current = model
            # BUG: running is never reset, so each group inherits the previous total
        running += tokens
    if current is not None:
        totals.append((current, running))
    return totals


def fixed(conn):
    rows = conn.execute(_QUERY).fetchall()
    totals, running, current = [], 0, None
    for model, tokens in rows:
        if model != current:
            if current is not None:
                totals.append((current, running))
            current = model
            running = 0
        running += tokens
    if current is not None:
        totals.append((current, running))
    return totals


def _drops_final_group(conn):
    rows = conn.execute(_QUERY).fetchall()
    totals, running, current = [], 0, None
    for model, tokens in rows:
        if model != current:
            if current is not None:
                totals.append((current, running))
            current = model
            running = 0
        running += tokens
    return totals  # forgot to flush the last group


WRONG_FIXES = {"reset added but final group not flushed": _drops_final_group}

CASES = {
    "T1": {
        "role": "discriminator",
        "seed": """
            INSERT INTO usage_log (id, model, tokens) VALUES
                (1,'ada-002',100),(2,'ada-002',200),
                (3,'text-3-large',50);
        """,
        "expected": [("ada-002", 300), ("text-3-large", 50)],
    },
    "T2": {
        "role": "guard",
        "seed": """
            INSERT INTO usage_log (id, model, tokens) VALUES
                (1,'ada-002',100),(2,'ada-002',200),(3,'ada-002',300);
        """,
        "expected": [("ada-002", 600)],
    },
    "T3": {
        "role": "discriminator",
        "seed": """
            INSERT INTO usage_log (id, model, tokens) VALUES
                (1,'alpha',10),(2,'beta',20),(3,'gamma',30);
        """,
        "expected": [("alpha", 10), ("beta", 20), ("gamma", 30)],
    },
    "T4": {
        "role": "guard",
        "seed": "INSERT INTO usage_log (id, model, tokens) VALUES (1,'solo',42);",
        "expected": [("solo", 42)],
    },
    "T5": {"role": "guard", "seed": "", "expected": []},
}
