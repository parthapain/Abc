"""
Calibration script for the T01-it-helpdesk expert-tier reference solution.
Confirms every planted element actually reproduces/resolves as
INTERNAL-metadata.md describes. Run: python verify.py
"""
import hashlib
import pandas as pd
import db_models
import resolution_client
from orchestrator import process_ticket

tickets_df = pd.read_csv("helpdesk_tickets.csv").fillna("")
tickets_by_id = {row["ticket_id"]: row for _, row in tickets_df.iterrows()}

passed = 0
failed = 0


def check(label, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"[PASS] {label}")
    else:
        failed += 1
        print(f"[FAIL] {label} -- {detail}")


db_models.init_db()

# --- Element 1: ambiguous duplicate match (HD-3010) ---------------------
status, category, logs = process_ticket(tickets_by_id["HD-3010"])
check("HD-3010 flagged as an ambiguous duplicate match, not silently closed against one prior ticket",
      status == "ESCALATED_AMBIGUOUS_DUPLICATE", f"status={status}, logs={logs}")

# --- Element 2: coupling (HD-3015) ---------------------------------------
status, category, logs = process_ticket(tickets_by_id["HD-3015"])
check("HD-3015 escalated for urgency despite clearing every other check",
      status == "ESCALATED_URGENT", f"status={status}, logs={logs}")

# --- Stress point: blank body (HD-3040) ----------------------------------
status, category, logs = process_ticket(tickets_by_id["HD-3040"])
check("HD-3040 (blank body) escalated as a classification failure, not silently classified",
      status == "ESCALATED_CLASSIFICATION_FAILED", f"status={status}, logs={logs}")

# --- Addendum 24, priority/urgency divergence: HD-3025 vs HD-3030 -------
status_25, cat_25, logs_25 = process_ticket(tickets_by_id["HD-3025"])
status_30, cat_30, logs_30 = process_ticket(tickets_by_id["HD-3030"])
check("HD-3025 (VIP, trivial request) is NOT flagged urgent under this solution's severity-based policy",
      status_25 != "ESCALATED_URGENT", f"status_25={status_25}")
check("HD-3030 (regular requester, severe request) IS flagged urgent",
      status_30 == "ESCALATED_URGENT", f"status_30={status_30}")
check("HD-3025's log explicitly names requester_tier as considered-and-excluded, not silently ignored",
      any("requester_tier" in l and "deliberately excluded" in l for l in logs_25),
      f"logs_25={logs_25}")

# --- Addendum 24, routing divergence: HD-3035 ----------------------------
status, category, logs = process_ticket(tickets_by_id["HD-3035"])
check("HD-3035 (spans Network/VPN and Security Incident) escalated for a person to triage, not silently routed to one team",
      status == "ESCALATED_AMBIGUOUS_ROUTING", f"status={status}, logs={logs}")

# --- Second-guardrail three directions -----------------------------------
status, category, logs = process_ticket(tickets_by_id["HD-3050"])
check("HD-3050 ($0 verified, claim not corroborated) escalates, does not resolve",
      status == "ESCALATED_UNCORROBORATED", f"status={status}")

status, category, logs = process_ticket(tickets_by_id["HD-3055"])
check("HD-3055 ($200 verified, over threshold) escalates, does not resolve",
      status == "ESCALATED_VALUE", f"status={status}")

# --- Addendum 31: the two guardrails are independent (HD-3060) -----------
status, category, logs = process_ticket(tickets_by_id["HD-3060"])
check("HD-3060 (Licensing & Reimbursement, also reads as urgent) still gets its courtesy resolution evaluated -- urgency doesn't block it, though it does still surface as urgent",
      status == "PARTIALLY_RESOLVED", f"status={status}, logs={logs}")

# --- Element 4: adversarial tool response (HD-3045) ----------------------
status, category, logs = process_ticket(tickets_by_id["HD-3045"])
check("HD-3045 (invalid -999 billing record) escalated as invalid data, not treated as real",
      status == "ESCALATED_INVALID_BILLING_DATA", f"status={status}, logs={logs}")

# --- Element 3: idempotency / retry-safety (HD-3020, forced lost response) --
db_models.init_db()
status, category, logs = process_ticket(tickets_by_id["HD-3020"], force_lost_response_for_ticket="HD-3020")
check("HD-3020 first pass: forced lost-response still resolves via retry",
      status == "RESOLVED", f"status={status}, logs={logs}")
check("HD-3020 exactly one resolution record after a forced lost-response retry",
      db_models.count_resolution_records("HD-3020") == 1,
      f"count={db_models.count_resolution_records('HD-3020')}")

idem_key = hashlib.sha256("HD-3020|resolution|Priya Anand|15.0".encode()).hexdigest()
result_a = resolution_client.issue_resolution("HD-3020", "Priya Anand", 15.0, idem_key)
result_b = resolution_client.issue_resolution("HD-3020", "Priya Anand", 15.0, idem_key)
check("HD-3020 manual double-invoke with the same idempotency key returns identical cached result",
      result_a == result_b, f"a={result_a}, b={result_b}")

# --- Element 5: stale-data-vs-idempotency collision ----------------------
resolution_client.set_live_discrepancy("Priya Anand", 0.0)
retry_result = resolution_client.issue_resolution("HD-3020", "Priya Anand", 15.0, idem_key)
check("Idempotency-cache-hit retry ignores the now-changed discrepancy and returns the original cached SUCCESS",
      retry_result.get("status") == "success", f"retry_result={retry_result}")

print(f"\n{passed}/{passed + failed} checks passed")
if failed:
    raise SystemExit(1)
