# Template T04 — Expert-tier addendum (Addendum 21)

**Applies on top of `T04-order-fulfillment-reliability.md`, not instead of it.** Every element of the base template (two ambiguities, the existing reliability-engineering trap, the existing stress point, the two guardrails) still applies unchanged. This file adds five further elements, used **only** for instances generated into `level-2/generator/human-build-instances-expert/`. Standard and harder-tier instances are untouched by anything in this file — see `../design-rationale.md` Addendum 21 (elements 1-4), Addendum 23 (element 5), and Addendum 24 (a construction rule for the base template's two ambiguities, not a numbered element).

**Status:** not yet calibrated. No reference solution authored, no dry-run, no live-AI test. This file exists to be dry-run and live-AI-tested before any timed human build uses it.

---

## Framing rule — expert-tier briefs never state that the two consequential actions need a gate (Addendum 22)

**This applies across the whole expert tier, not just T04 — carry it into every future template's expert-tier instance.** Every other tier's brief (standard and harder) states outright that each consequential action is "gated by an explicit check" and that uncertain/risky cases are "escalated to a human" — this is deliberate scaffolding, stated openly as part of the mandatory shape. Expert-tier briefs remove that scaffolding entirely: they describe **only the capability** ("autonomously dispatch fulfillment via a tool call," "autonomously reroute a line item... via a tool call"), never that it should be checked, gated, or conditioned on risk before firing.

**Why:** the earlier phrasing was, in effect, telling every candidate the answer to the single most important judgment call in the whole assessment — that an AI-triggered, real-world, hard-to-reverse action needs a safety check before it fires. Recognizing that unprompted is arguably a stronger signal of engineering judgment than any of the planted ambiguities. Removing the scaffolding turns "did they gate it at all" from a followed instruction into a genuine test.

**What does NOT change:** the two ambiguity phrasings (e.g. "Only auto-dispatch low-risk orders") stay exactly as worded in the base template's pool — they are the ambiguity being tested, not guardrail-mechanism scaffolding, and removing them would remove the ambiguity slot itself, which is a different (and unwanted) change. Only the *added* clauses that turn "low-risk" into an explicit build instruction ("gated by an explicit check," "escalated to a human," "it needs its own gate," "within a reasonable threshold") are removed. The **Submit** section's `MANIFEST.md` pointer also drops any reference to "guardrail checks" specifically, for the same reason — don't tell candidates in the submission checklist that this is a section reviewers expect to see.

**Scoring implication — none.** `rubric.md`'s Dimension 2 capping rule already grades purely from what's in the shipped code (a consequential action with no gate at all caps at 1) regardless of what the brief asked for — no rubric change was needed for this. What changes is only the brief's wording, and therefore what a "no gate at all" finding actually reveals: previously it meant "didn't build a good enough check despite being told to"; now it means "didn't think to add one at all." Expect Dimension 2 scores to compress lower across expert-tier submissions as a result — this is intended, not a defect, per `design-rationale.md` Addendum 22.

**Every existing expert-tier instance's `INTERNAL-metadata.md` must be checked and updated** when this rule is applied to it — specifically, any "what a naive build does" description that assumed the candidate was *told* to gate (and therefore predicted a subtler guardrail-quality bug) should be revised to also name "doesn't gate the action at all" as the more likely, more basic failure mode now in play.

---

## Framing rule — expert-tier briefs never state the base template's stress-point sentence either (Addendum 27)

**Every other tier's brief states the production-readiness stress point outright** — a sentence naming the exact edge case (e.g. "some equipment is permanently out of stock — handle these sensibly") and telling the candidate not to crash or corrupt data on it. Expert tier removes this sentence entirely. The stress-point row itself (a permanently-out-of-stock item) stays in the seed dataset; only the sentence announcing it is dropped.

**Why:** the same logic as Addendum 22 — naming the exact thing being tested turns "did they notice and handle this edge case" from a genuine engineering-judgment signal into a followed instruction. This particular sentence had been carried unchanged through the T04 regeneration and the T01 build even after Addendum 22 removed the analogous guardrail-existence scaffolding; a peer review of T01 against T04 caught the inconsistency.

**Scoring implication — none.** Dimension 5 already grades from what the shipped code does with the stress-point row, regardless of whether the brief announced it.

---

## Framing rule — expert-tier briefs never state that the two guardrails are independent actions (Addendum 31)

Every other tier's brief adds "This is a second, independent autonomous action from step 6" after describing the second guardrail. Expert tier drops it — stating outright that the two actions are independent removes a real, defensible judgment call (a candidate could reasonably chain the second action off the first's success instead). See `T02-structured-extraction-EXPERT-ADDENDUM.md`'s equivalent section for the construction-rule requirement this creates; T04 is the one template where no new dataset row was needed — see Addendum 31's note on why dispatch and reroute aren't structurally independent here the way the other three templates' second guardrails are.

---

## Construction rule — the two base ambiguities need a "no safe default" data point too (Addendum 24)

**This applies across the whole expert tier, not just T04 — carry it into every future template's expert-tier instance.** The base template's two open judgment calls (e.g. back-order policy, "low-risk" threshold) are stated as ambiguities at every tier, but nothing in the standard dataset guarantees that an unreasoned default ever produces a visibly wrong outcome — a candidate (or the LLM writing their code) can silently pick any answer and never be shown to be wrong. **At expert tier, each of the two base ambiguities must include at least one dataset row where two independently-defensible resolutions produce different outcomes.**

**Why:** the point isn't to make an ambiguity harder to *read* — it's to remove the safe default so that whichever way it's resolved is a real, attributable, checkable decision rather than a guess that happened not to be contradicted. This is the same mechanism Expert element 1 (two ambiguous catalog matches — no default match is "just correct") and Expert element 5 (idempotency vs. stale-stock — no code satisfies both readings on the retry path) already use for the *added* expert-tier elements; this rule generalizes it to the base template's own two ambiguities when they're used in an expert-tier instance.

**What this looks like concretely:** pick one dataset row where a plausible single-axis rule (the one an LLM will reach for by default, usually whichever signal is most concrete/numeric) disagrees with a second, equally reasonable axis that's also present in the brief or data but easy to overlook. E.g., for a "low-risk" threshold ambiguity: one order priced *above* a plausible dollar cutoff, but flagged as a repeat/trusted customer — forcing a choice between a threshold-only rule and a trust-inclusive one, rather than letting the dollar figure silently win by being the only concrete number in play.

**Spoiler discipline — this data point is planted silently, like every other trap/ambiguity variant.** The dataset row must read as an ordinary row, not a flagged special case; the brief must not hint that this specific order is the interesting one, and `INTERNAL-metadata.md` documents the row and the divergence for the reviewer, never for the candidate.

**Scoring implication:** no new rubric dimension or anchor. This makes the *existing* Dimension 3 anchors easier to apply with confidence — an anchor-0/1 finding ("silently assumed one interpretation") is now checkable against a specific case the candidate's code gets wrong, not inferred from the absence of a rationale paragraph alone. See `../rubric.md` Dimension 3's expert-tier note.

---

## Expert element 1 — a second, independent AI-trap

**Where it lives:** the reconciliation step (`reconcile_catalog_item(description)`), not the dispatch/retry step the base template's trap already covers. Deliberately a different code path, so a submission can catch one trap and miss the other — the two are scored independently (see rubric note below), the same non-averaging principle already used for the two ambiguities.

**The trap:** when asked to "fuzzy-match a line-item description against the catalog," a natural AI-assistant default is to match on lowest edit-distance or substring containment and **return exactly one match, with no signal that more than one catalog item was a plausible fit.** When two catalog SKUs have overlapping descriptions (e.g. two sizes or two colors of the same base item) and an incoming line item's description is genuinely ambiguous between them (e.g. it names the base item but omits the size/color), this silently resolves to whichever SKU happens to sort first, appear first in the catalog file, or win an arbitrary tie-break — never surfaced to the candidate's own guardrail logic as an unresolved case, and never escalated for human review.

**What "caught" looks like (dimension 4, scored as trap #2):** the reconciliation tool detects when a description plausibly matches more than one catalog item (not just whether it matches at least one) and returns an explicit "ambiguous — needs review" result in that case, rather than always returning exactly one confident-looking SKU. A "3"/"4" rationale names this exact risk (a fuzzy-match tool silently picking one of several equally-plausible catalog items) and points to the specific mechanism that catches it, checkably against the code.

**Trap variants (pool, pick 1 per instance):**
1. Substring-containment match; first catalog row (by file order) wins on a tie, with no signal a tie occurred.
2. Lowest-edit-distance match; ties broken by whatever a dict/map's default iteration order happens to produce, with no signal a tie occurred.
3. Match narrowed further by an incidental numeric field (e.g. treats two items as the same if their prices happen to be close) that has nothing to do with actual identity.

**Dataset requirement:** the catalog must contain at least one genuinely ambiguous pair (two SKUs whose descriptions differ only in a qualifier an order might omit), and at least one incoming order whose line-item description is written the way a real customer would actually omit that qualifier — not an artificially contrived string.

---

## Expert element 2 — coupling the two guardrails/ambiguities together

**The base template's two ambiguities and two guardrails are currently independent** — a candidate can resolve the back-order ambiguity, build the auto-dispatch guardrail, build the reroute guardrail, and never have to revisit any of the three once written. Expert tier removes that independence for one specific pair:

**The coupling:** whichever back-order policy the candidate chooses (ship the available portion now, hold the whole order, escalate the whole order) must be what the auto-dispatch value/risk guardrail (base template step 6) actually evaluates. If the chosen policy ships available items now while holding back-ordered ones separately, the guardrail's risk computation must be based on **the value of only the line items that will actually be dispatched in this action** — not the order's full original face value, which may include items that were never going to ship in this step at all.

**Why this is a genuine engineering coupling, not just "compute a different number":** a candidate who designs back-order handling and auto-dispatch risk as two separate, independently-built checks (the natural result of building against the brief's two numbered requirements one at a time) will, by default, compute order value once from the incoming order and never revisit it once the back-order policy is added — because nothing in either requirement, read in isolation, tells them to. Only a candidate who's actually thinking about how the two decisions interact will notice the guardrail needs to key off "what's shipping in this specific action," not "what the customer originally asked for."

**What "caught" looks like (dimension 2, new capping-rule flavor):** the guardrail's risk/value computation explicitly reflects the already-applied back-order policy — computed on the actually-dispatching line items, not the order's unconditional total. **Grading treatment:** a guardrail that still computes on the order's full face value regardless of the back-order decision is "a guardrail that exists and does check something real, but on the wrong basis" — cap Dimension 2 at 2, the same tier as the existing "guardrail exists in name only" language, not a full cap-1 ungated-action failure (a real, if misscoped, check still exists).

**Dataset requirement:** at least one order where a naive, uncoupled implementation and a properly-coupled implementation would produce **different** auto-dispatch outcomes — e.g. a large order where most of the value is in a back-ordered item and the actually-shippable remainder is comfortably low-value/low-risk (a naive full-face-value computation wrongly escalates it; a coupled one correctly clears it), or the reverse (a naive computation wrongly clears a large order because it never re-evaluates after removing a cheap back-ordered line item, when the *remaining* shippable items are themselves risky).

---

## Expert element 3 — idempotency elevated from buried trap variant to explicit, tested requirement

The base template already lists "blind retry with no idempotency key" as trap variants 1–3 of its existing trap pool (`T04-order-fulfillment-reliability.md` §"AI-trap slot"). For expert-tier instances:

1. **Always use trap variant 1, 2, or 3 from the base template's pool — never variant 4** (the swallowed-failure/limbo variant, reserved for standard/harder tier instances). This guarantees idempotency is the actual mechanism under test, not an alternative that happens to avoid it entirely.
2. **Never state the requirement in the brief (Addendum 30).** Earlier versions of this addendum added a sentence spelling out that the dispatch call could report a false failure and that retries must not duplicate it — reasoned at the time as a stated requirement, not a spoiler. That carve-out is gone: recognizing unprompted that a real, autonomous, hard-to-reverse tool call needs idempotent retry handling is the same kind of foundational judgment Addendum 22 already expects candidates to supply on their own for the guardrail gate itself. The brief states only the bare capability ("autonomously dispatch fulfillment via a tool call"), nothing about failure modes or duplication risk. Whether the candidate builds it *well* (dimension 2 — is there a real idempotency mechanism, not just a comment claiming one) and whether the AI-generated first draft gets it wrong by default and whether that got caught (dimension 4 — the trap) are still graded separately, from the same unstated requirement.
3. **A retry must be confirmed to actually happen** — not left untestable by chance the way the base template's random-failure-rate trap currently can be. Since the dispatch/action service is normally a local mock the candidate writes themselves, not a real external system, there is usually no dataset row that can force this by itself: instead, `INTERNAL-metadata.md` must name a specific, otherwise-unremarkable order and document a review-time procedure — invoking the candidate's own dispatch function twice in a row for that order, simulating a retried call after a lost response — so a reviewer can check directly whether exactly one fulfillment record resulted, or two. Never state this procedure in the candidate-facing brief.

**What "caught" looks like (dimension 2, base anchor plus this specific check):** an idempotency key or equivalent dedup mechanism travels with the dispatch call, and the named review-time double-invoke produces exactly one fulfillment record, not two. **Grading treatment:** a consequential action with no protection against being duplicated by a retry is treated as severely as "a consequential action with no gate at all" — cap Dimension 2 at 1, since a duplicated real-world dispatch is a genuine duplicate side effect, not merely a missed check.

---

## Expert element 4 — adversarial tool responses

Every stress point in every template so far is about messy *input data*. Nothing tests whether a submission defends against one of its **own tools** returning something internally inconsistent. Expert tier adds this as a new, template-wide category (not specific to T04's domain, reusable when other templates get an expert tier).

**The trap:** on one specific SKU, the alternate-warehouse check tool (`check_alt_warehouse(sku)`) returns a response that is internally inconsistent — e.g. a negative stock count, or a stock count paired with a staleness/confidence flag indicating the number shouldn't be trusted, or two fields that contradict each other (a boolean "in stock" flag that disagrees with a numeric count of zero). A naive build passes whatever the tool returns straight into the reroute guardrail's arithmetic without ever checking whether the response itself makes sense.

**What "caught" looks like (dimension 5, new stress-point category alongside the existing malformed-input-data one):** the submission validates a tool's own response for basic internal consistency before acting on it — and when a response fails that check, treats it the same as "the tool couldn't tell me," i.e. escalates rather than silently computing with a nonsensical number. **Grading treatment:** a submission that computes a reroute/dispatch decision directly from an internally-inconsistent tool response, without any validation, is graded exactly like the existing anchor-0/1 "crashes or silently wrong at the tricky moment" language — this is a stress point like any other, not a separate cap tier.

**Dataset requirement:** the second reference dataset (`alt_warehouse_inventory.csv`-equivalent) must carry exactly one row whose fields are internally inconsistent in a way a human glancing at the CSV would immediately notice, but a naive parser reading it programmatically would not.

---

## Expert element 5 — retry-safety vs. stale-data collision (Addendum 23)

**Where it lives:** the dispatch/retry mechanism (element 3), not a separate part of the pipeline — this is a deliberate collision *between* two brief sentences placed side by side, not a new code path of its own.

**The trap:** neither requirement is stated in the brief (Addendum 30) — a candidate who builds idempotent retry handling at all is already demonstrating unprompted judgment, and a candidate who also thinks to re-confirm stock freshness before dispatching is demonstrating it twice over. The two requirements conflict specifically on the retry-after-lost-response path: "don't duplicate a fulfillment action on retry" implies returning the cached result; "always re-confirm current data before dispatching" implies re-evaluating rather than trusting a cached answer. A build that arrives at both requirements independently often resolves the tension by re-checking the fresh data *inside* the idempotency-cache-hit branch — which quietly breaks the "no duplicate/no side-effect on retry" guarantee, without the build ever surfacing that it traded one requirement for the other. Since this collision now depends entirely on a candidate independently discovering *both* unstated requirements, it will naturally reach fewer submissions than under the old, brief-stated version — see Addendum 30's calibration caveat.

**What "caught" looks like (dimension 2, same severity as element 3):** the shipped code applies the freshness/robustness check only to a genuinely new dispatch decision, never to an idempotency-cache-hit — a cache hit isn't a new decision, so it returns the original cached result untouched regardless of what the fresh data now says. A candidate whose rationale explicitly names this tension and states which requirement wins on the retry path (rather than never noticing there was a conflict) is the strongest possible response.

**How to actually test this:** `INTERNAL-metadata.md` must name a specific, review-time procedure — the same named order used for element 3's forced-retry check works here too: dispatch it successfully, then simulate the freshness-relevant data (e.g. stock) changing before manually re-invoking the candidate's own dispatch function with the same idempotency key. The retry should still return the original cached result, unaffected by the simulated change. Never state this procedure in the candidate-facing brief.

**Grading treatment:** treated exactly as severely as element 3's plain idempotency-unsafe case — **cap Dimension 2 at 1** if the retry can change outcome, since a retry that changes an already-completed action's result is functionally the same failure as one that duplicates it. Not a new defect category — see `../rubric.md` Dimension 2's expert-tier note.

**Dataset requirement:** no new dataset field is required — reuse element 3's forced-retry test order and its existing data (stock, price, etc.); the collision is constructed entirely from brief wording plus a review-time procedure, not from a new CSV row.

---

## Rubric/scoring cross-reference

See `../rubric.md` for the exact anchor language — all five elements above are graded through Dimensions 2, 4, and 5's **existing** anchors and capping rules, conditioned on "expert-tier instance" per Addendum 21 (elements 1-4) and Addendum 23 (element 5), not through new dimensions or a separate scoring pass.

## Spoiler-discipline note for the generator agent

All five elements above are subject to the same spoiler-discipline rule as every other trap/ambiguity/stress-point in this project (`.claude/agents/level2-use-case-generator.md`): the candidate-facing brief states none of them (Addendum 30 removed elements 3 and 5's former carve-out) — it never hints that element 2's coupling exists, never names which tool is adversarial or how (element 4), never describes the second trap's specific failure mechanism (element 1), and says nothing at all about retry-safety, duplication risk, or data freshness (elements 3 and 5). The brief for an expert-tier instance should read as "one paragraph harder version of the base brief" — the bare capability sentences for both autonomous actions, and nothing else — not as a document that hands over any of the five things being tested.
