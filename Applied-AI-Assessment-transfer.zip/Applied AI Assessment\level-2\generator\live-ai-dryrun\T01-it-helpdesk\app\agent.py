"""
Agent orchestration: classify -> gather context/history via tools -> decide -> act.

This is deliberately a plain Python control-flow "agent" rather than a framework-driven
tool-calling loop -- the brief asks for agent *behavior* (classify, then use tools to
check duplicates/context, then decide, then act autonomously via tools), and a
transparent, testable decision function demonstrates that behavior more clearly than
routing everything through an LLM tool-call loop we'd then have to stub out anyway.
The `llm_stub` module is the one piece that stands in for a real model call; everything
downstream of it (tool selection, thresholds, routing) is the agent's own logic, which
is exactly what would stay in place if `llm_stub.classify` were swapped for a real
model call.

process_ticket() is the entry point: it runs the full pipeline for one ticket and
persists every step (classification, tool calls, actions, flags) to the database.
"""
from app import database as db
from app import llm_stub
from app import tools

URGENT_KEYWORDS = [
    "urgent", "asap", "as soon as possible", "immediately", "production",
    "blocked", "entire team", "right now", "emergency",
]


def _detect_urgency(body_text: str) -> list:
    lowered = (body_text or "").lower()
    return [kw for kw in URGENT_KEYWORDS if kw in lowered]


def process_ticket(ticket: dict) -> dict:
    """Run the full agent pipeline for a single ticket row (dict from the tickets table).

    Returns a summary dict for logging/inspection; all durable state lands in the DB.
    """
    ticket_id = ticket["ticket_id"]
    requester_name = ticket["requester_name"]
    requester_tier = ticket["requester_tier"]
    body_text = ticket["body_text"]

    # 1. Classify (LLM stand-in).
    result = llm_stub.classify(body_text, requester_tier=requester_tier)
    uncertain = llm_stub.is_uncertain(result)
    context_pulled = None

    # 2. If uncertain and there's *something* to reason about, pull additional
    #    context via a second tool and re-classify with it in hand.
    if uncertain and body_text.strip():
        ctx = tools.get_additional_context(ticket_id, body_text)
        context_pulled = ctx["context"]
        refined = llm_stub.classify(body_text, requester_tier=requester_tier,
                                     extra_context=context_pulled)
        if refined.category is not None:
            result = refined
            uncertain = llm_stub.is_uncertain(result)

    db.add_classification(ticket_id, result.category, result.confidence, result.reasoning,
                           uncertain, context_pulled)

    # 3. Check for duplicate/related history (tool call, always -- this is the
    #    "after classifying, check for duplicate or related history" step from the brief).
    history = tools.search_related_history(ticket_id, requester_name, body_text)

    # 4. Flags for human attention. These are independent of what action gets taken.
    flags = []
    urgent_hits = _detect_urgency(body_text)
    if urgent_hits:
        flags.append(("urgent_language", f"Urgent language detected: {', '.join(urgent_hits)}."))
    if requester_tier == "VIP":
        flags.append(("vip_requester", "Requester is a VIP-tier account; prioritize human review."))
    if result.category == "Security Incident":
        flags.append(("security_incident", "Classified as a security incident; always routed to human review."))
    if result.category is None:
        flags.append(("insufficient_info", "Ticket body has no usable content for classification."))
    if uncertain and result.category is not None:
        flags.append(("low_confidence", f"Classification confidence ({result.confidence}) remained "
                                         f"below threshold even after pulling additional context."))

    # 5. Decide + act.
    action_summary = None

    if history["is_genuine_duplicate"]:
        match = history["best_open_match"]
        tools.auto_close_ticket(ticket_id, match["ticket_id"], match["similarity"])
        action_summary = f"auto_closed_duplicate(of={match['ticket_id']})"

    elif result.category == "Licensing & Reimbursement":
        claimed = tools.extract_claimed_amount(body_text)
        if claimed is not None:
            billing = tools.check_billing_record(ticket_id, requester_name, claimed)
            if billing["confirmed"] and billing["verified_discrepancy"] <= tools.COURTESY_RESOLUTION_THRESHOLD:
                tools.issue_courtesy_resolution(ticket_id, billing["verified_discrepancy"])
                action_summary = f"courtesy_resolution(${billing['verified_discrepancy']:.2f})"
            else:
                tools.acknowledge_ticket(ticket_id, result.category)
                tools.route_ticket(ticket_id, result.category)
                if not billing["confirmed"]:
                    if billing["found"]:
                        shown = f"${billing['verified_discrepancy']:.2f}"
                    else:
                        shown = "no record"
                    flags.append(("billing_mismatch",
                                  f"Requester claimed ${claimed:.2f} but billing system shows "
                                  f"{shown} -- needs human review before any refund."))
                else:
                    flags.append(("billing_above_threshold",
                                  f"Confirmed discrepancy of ${billing['verified_discrepancy']:.2f} exceeds the "
                                  f"${tools.COURTESY_RESOLUTION_THRESHOLD:.2f} autonomous-resolution threshold "
                                  f"-- routed for human approval."))
                action_summary = "routed_for_billing_review"
        else:
            # Vague billing complaint with no specific, checkable figure -- brief says
            # the auto-resolution path only applies to specific, checkable discrepancies.
            tools.acknowledge_ticket(ticket_id, result.category)
            tools.route_ticket(ticket_id, result.category)
            flags.append(("unspecified_billing_claim",
                          "Requester did not state a specific dollar amount, so the claim isn't "
                          "independently checkable -- routed to Billing for manual follow-up."))
            action_summary = "routed_unspecified_billing_claim"

    elif result.category is None:
        # Nothing to route confidently; leave fully to a human.
        action_summary = "needs_human_triage"

    else:
        tools.acknowledge_ticket(ticket_id, result.category)
        route_result = tools.route_ticket(ticket_id, result.category)
        action_summary = f"acknowledged_and_routed(team={route_result['team']})"

    for flag_type, reason in flags:
        db.add_flag(ticket_id, flag_type, reason)

    return {
        "ticket_id": ticket_id,
        "category": result.category,
        "confidence": result.confidence,
        "uncertain": uncertain,
        "action_summary": action_summary,
        "flags": [f[0] for f in flags],
    }
