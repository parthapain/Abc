# Rationale / Design Decisions

## Architecture

`run_pipeline.py` (ingest + agent) writes to `loans.db` (SQLite); `app/web.py`
(Flask) reads/writes the same DB for human review. Splitting ingestion from
review means the agent's autonomous pass and the human review pass are
independent and can be re-run separately, which matches how a real system
would operate (batch extraction job, always-on review UI).

The agent is not a single LLM call: `app/agent.py:process_document` calls
`extract_fields_llm` once, then makes further tool calls — `cross_check_field`
against the source text, and conditionally `lookup_related_document` when a
field defers to another document — before deciding whether the record needs
review, and commits regardless (see "commit vs. review" below). A separate
pass, `run_maturity_followups`, calls `lookup_loan_status` and only generates
a follow-up record if that tool confirms `active`. Every tool call and
decision is written to `agent_log` so the review UI can show the reasoning
trail, not just the final numbers.

## No in-house LLM available

No API key was present in this environment. `app/extraction.py` implements a
deterministic stand-in behind the exact function contract a real model call
would use: `extract_fields_llm(doc_text) -> ExtractionResult`. It's
regex-based and tuned to the phrasing actually used in `loan_documents/`
(e.g. "Maturity Date of this Loan shall be the date N months after the
Closing Date"). This is the biggest known limitation: a real LLM would
generalize to differently-worded agreements; this stand-in would not without
new regexes. Swapping in a real model means replacing the body of that one
function — nothing else in the agent depends on how the extraction happens.

## Key judgment calls on underspecified points

- **"Cross-check via a tool"**: interpreted literally as a substring
  containment check of the extracted value against its source document text
  (`cross_check_field`). For a *computed* maturity date (closing date + N
  months), the derived date won't appear verbatim in the text, so the
  cross-check instead verifies the two inputs the computation used (the
  closing date and the "(N) months" clause) are both actually present —
  checking the derivation's inputs rather than string-matching its output.
- **"Look up a related document when a field references another document"**:
  several agreements (LN-7002, LN-7004) say the maturity date is "as set
  forth in the Promissory Note" rather than stating it inline. The
  `lookup_related_document` tool finds files named `<loan_number>-note*.txt`.
  LN-7004 has *two* notes on file (an original and an "Amended and Restated"
  one that says it supersedes the original) — the agent parses the
  supersession language and prefers the amendment, logging that decision so
  a reviewer can see why the original was ignored, rather than silently
  picking one.
- **Borrower name inconsistency** (LN-7003: defined as "...Inc." in the
  recital, signed as "...LLC"): treated as a soft flag, not a hard error.
  The recital's defined term is kept as the extracted value (it's the
  legally operative definition), but the discrepancy is surfaced in
  `review_notes` and the signature-block variant is stored alongside it so a
  human can confirm which entity is actually correct.
- **Missing interest rate** (LN-7005, "to be determined pursuant to a
  forthcoming Rate Addendum"): left as `null` rather than guessed, and
  flagged `needs_review`. Fabricating a plausible-looking rate would be
  worse than an honest gap.
- **Multi-agreement document** (`LN-7006-7007.txt` contains two full
  agreements separated by a rule of `=` characters): the loader
  (`load_all_agreements`) splits on that delimiter and treats each chunk as
  an independent agreement, rather than assuming one file = one loan.
- **Commit vs. review, and what "autonomous" means**: the brief says commit
  autonomously (step 6) and *separately* provide human review (step 8). I
  read these as two different gates on the same record: every extracted
  record is committed to the system of record regardless of confidence
  (that's what "autonomous" means here), and `needs_review` is a
  UI-visibility flag, not a commit blocker. An alternative reading — only
  commit when the cross-check fully passes — seemed less faithful to
  "autonomously commit... [and] separately... generate a follow-up," which
  implies the pipeline keeps moving even when a field is uncertain, with
  humans catching problems downstream.
- **"Approaching maturity"**: not defined by the brief. Made it a
  configurable parameter (`--horizon-months`, default 12) rather than
  hardcoding a date. Against the seed data and the sandbox's current date
  (2026-09-14), a 12-month horizon is exactly wide enough to catch LN-7008
  (matures ~4 months out, registry says active → follow-up generated) and
  LN-7009 (matures ~10 months out, **absent** from the registry → tool
  lookup returns "not found," which the agent treats as "cannot confirm
  active" and correctly declines to generate a follow-up, rather than
  defaulting to generate-on-uncertainty).
- **Loan not in the status registry** (LN-7009): rather than erroring or
  silently skipping, the agent still runs the check, logs the tool call and
  its `None` result, and records a `followups` row with
  `status_checked='not_found', generated=0` so the omission is visible in
  the UI and in the DB, not just absent.

## What an AI assistant suggested that I corrected

While drafting the maturity-date regex I initially wrote
`\w+\s*\((\d+)\)\s*months?` to match phrases like "sixty (60) months". That
silently failed on hyphenated number words — "forty-eight (48)",
"thirty-six (36)", "twenty-four (24)" — because `\w` doesn't match hyphens,
so four of the eleven seed agreements fell through to "no maturity date
found." Running the pipeline against the real seed data caught this
immediately (a spike in `needs_review` flags), and it's now covered by
`test_hyphenated_month_word_parses`. Also caught in the same run: an early
cross-check implementation string-matched the *computed* maturity date
against the source text, which can never succeed (the date is derived, not
quoted) — fixed by checking the computation's inputs instead, as described
above.

## What I'd do with more time

- Replace the regex extractor with an actual LLM call (structured-output /
  JSON-mode prompt), keeping the same `ExtractionResult` contract, and add a
  confidence score per field instead of a single boolean.
- Track document versioning more generally (LN-7004's amended note is one
  instance of a pattern — amendments, allonges, and modification agreements
  are common in real loan files) instead of a hand-rolled "supersedes"
  regex.
- Add authentication/audit-trail (who made each correction) to the review
  UI instead of an anonymous edit history.
- Add a small reconciliation view showing loans present in the registry but
  never extracted, and vice versa, since that mismatch (LN-7009) is exactly
  the kind of data-quality issue a real ops team would want surfaced
  proactively rather than discovered loan-by-loan.
