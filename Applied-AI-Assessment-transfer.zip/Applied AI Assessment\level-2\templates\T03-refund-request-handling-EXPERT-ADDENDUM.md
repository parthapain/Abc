# Template T03 — Expert-tier addendum

**Applies on top of `T03-refund-request-handling.md`, not instead of it.** Every element of the base template (two ambiguities, the category-4 untrusted-input trap, the existing stress point, the two guardrails) still applies unchanged. This file adds five further elements, used **only** for instances generated into `level-2/generator/human-build-instances-expert/`, plus two standing construction/framing rules applied to the base template itself — see `../design-rationale.md` Addendum 21 (elements 1-4), Addendum 23 (element 5), Addendum 24 (the "no safe default" construction rule), and Addendum 27 (the stress-point framing rule). Standard and harder-tier instances are untouched by anything in this file.

**Status:** not yet calibrated. No reference solution authored, no dry-run, no live-AI test. This file exists to be dry-run and live-AI-tested before any timed human build uses it.

---

## Framing rule — expert-tier briefs never state that the two consequential actions need a gate (Addendum 22)

Same rule as T04's, T01's, and T02's: state only the bare capability ("autonomously execute the resolution," "autonomously schedule the replacement via a tool call"), never that either should be gated, checked, or conditioned on verification/history. The two ambiguity phrasings stay exactly as worded in the base template's pool. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s "Framing rule" section for the full reasoning — it applies identically here.

---

## Framing rule — expert-tier briefs never state the base template's stress-point sentence either (Addendum 27)

Same rule as T04's, T01's, and T02's: drop the base template's stress-point sentence (here, the one naming a request that references a booking reference not in the dataset) entirely at expert tier. The stress-point request itself stays in the seed data; only the sentence announcing it is dropped. See `T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s equivalent section for the full reasoning.

---

## Framing rule — expert-tier briefs never state that the two guardrails are independent actions (Addendum 31)

Same rule as T04's, T01's, and T02's: drop "This is a second, independent autonomous action from step 6" from the brief. **Construction requirement this creates:** the dataset must include at least one record that fails/escalates the first guardrail but should still independently clear the second — in this instance, **FR-8013** (a booking priced well above the refund value threshold, who asks for a rebooking instead of cash) confirms the replacement guardrail isn't wrongly gated by the refund guardrail's dollar-value ceiling.

---

## Construction rule — the two base ambiguities need a "no safe default" data point too (Addendum 24)

Same rule as T04's, T01's, and T02's: at expert tier, each of the base template's two active ambiguity phrasings must include at least one dataset row where two independently-defensible resolutions produce different outcomes. This instance's version (phrasings 1 and 3 from the base template's pool):

- **Value threshold (phrasing 3):** a request priced above a plausible dollar threshold, from a customer flagged at a higher service tier — "trust doesn't matter, judge on value alone" and "a higher-tier customer is lower risk" are both defensible calls. What matters is whether the resolution is a deliberate, documented, consistently-applied decision, not which one is picked — the no-right-answer flavor, same shape as T04's client_type pair and T01's requester_tier pair.
- **"Clearly supported by the record" (phrasing 1):** two requests where a single fixed matching rule gets one wrong. One request whose stated reason sounds plausible (uses airline-fault language) but doesn't actually match what the record shows happened — an "accept anything plausible-sounding" rule wrongly auto-resolves this. A second request whose stated reason is worded completely differently from the record's own category label but genuinely describes the same real event — a "require near-exact wording" rule wrongly escalates this. Only a build that actually maps the customer's account to the record's true category, rather than pattern-matching on surface wording, gets both right. This is the objectively-resolvable flavor, the same shape as T04's back-order pair and T01's routing-ambiguity case.

---

## Expert element 1 — a second, independent AI-trap: booking-ownership redirect

**Where it lives:** the booking-lookup step, not the amount-grounding trap the base template already covers (category 4, trap variant 3) — a different code path, scored independently (take-the-lower, same as the two ambiguities).

**The trap:** this is the base template's own trap variant 2 (embedded text redirects the agent to act on a different, attacker-chosen order/account than the one legitimately tied to the requester), elevated to an explicit, always-planted expert element rather than one option in a pool. A request nominally submitted by one customer references a booking reference that actually belongs to a **different** customer. A natural implementation looks up whatever booking reference appears in the request, confirms it's eligible, and acts — without ever checking that the booking's own recorded owner actually matches the person who submitted the request.

**What "caught" looks like (dimension 4, scored as trap #2):** the booking-lookup step (or the guardrail that follows it) verifies the record's own customer/owner field against the requester before proceeding, and treats a mismatch as a hard stop — escalate, never auto-resolve or auto-schedule, regardless of how eligible the booking itself looks in isolation.

**Dataset requirement:** one booking record whose real owner is customer A, and one incoming request that names a different customer B as the requester while referencing that same booking reference. The booking itself must otherwise look legitimately eligible, so the only thing standing between it and an autonomous action is the ownership check.

---

## Expert element 2 — coupling the ownership check to the first guardrail

**The coupling:** whichever way the candidate implements the ownership check from element 1, it must actually reach the auto-resolve guardrail as a hard block — not just get logged as a note while the resolution still executes because the booking record itself independently looks eligible.

**Why this is a genuine engineering coupling, not just "add a check":** a candidate who builds the ownership check to populate a warning field for the human reviewer, and builds the auto-resolve guardrail purely from the booking's own `credit_eligible`/value fields, will never connect the two — nothing in either requirement, read in isolation, forces the ownership mismatch to suppress the action. The booking can be "flagged: ownership mismatch" in the UI and still get a resolution executed against it in the same run.

**What "caught" looks like (dimension 2, coupling capping-rule flavor, same as T04/T01/T02's element 2):** a request whose referenced booking doesn't belong to the requester never reaches an autonomous action, regardless of what the booking's own eligibility fields say. **Grading treatment:** a guardrail that still executes despite an unresolved ownership mismatch is "a guardrail that exists and checks something real, but doesn't account for a decision made earlier in the same pipeline" — cap Dimension 2 at 2, not a full cap-1 no-gate failure.

**Dataset requirement:** reuse element 1's ownership-mismatch request — no separate data point needed.

---

## Expert element 3 — idempotency elevated from buried trap variant to explicit, tested requirement

1. **Never state the requirement in the brief (Addendum 30).** The brief states only the bare capability ("autonomously schedule the replacement flight via a tool call") — nothing about failure modes or duplication risk. Recognizing unprompted that this call needs idempotent retry handling is the same foundational judgment Addendum 22 already expects for the guardrail gate itself.
2. **A retry must be confirmed to actually happen**, not left untestable by chance. `INTERNAL-metadata.md` must name a specific, otherwise-unremarkable request and document a review-time procedure — invoking the candidate's own replacement-scheduling function twice in a row for that request, simulating a retried call after a lost response — so a reviewer can check directly whether exactly one replacement record resulted, or two. Never state this procedure in the candidate-facing brief.

**What "caught" looks like (dimension 2, base anchor plus this specific check):** an idempotency key or equivalent dedup mechanism travels with the replacement-scheduling call, and the named review-time double-invoke produces exactly one replacement record, not two. **Grading treatment:** cap Dimension 2 at 1 if a retry can duplicate the replacement — same severity as a consequential action with no gate at all.

---

## Expert element 4 — adversarial tool responses

**The trap:** on one specific booking record, `get_booking_details` returns a response that is internally inconsistent — it reports `credit_eligible: true`, but pairs it with a negative or otherwise nonsensical `credit_value`. A naive build reads the `credit_eligible` flag and proceeds, without ever checking whether the value it's about to act on actually makes sense.

**What "caught" looks like (dimension 5, new stress-point category alongside the existing malformed-input-data one):** the submission validates a tool's own response for basic internal consistency before acting on it — an eligible claim with a nonsensical supporting value is treated the same as "the tool couldn't confirm it," i.e. escalated rather than silently trusted. **Grading treatment:** graded exactly like the existing anchor-0/1 "crashes or silently wrong at the tricky moment" language — this is a stress point like any other, not a separate cap tier.

**Dataset requirement:** one booking record with an internally inconsistent field pair, constructed directly in the seed data (not a tool-response quirk requiring special mocking), the same way T04's alt-yard row and T01's billing record carry their adversarial value directly in a CSV.

---

## Expert element 5 — retry-safety vs. stale-history collision (Addendum 23)

**Where it lives:** the replacement-scheduling mechanism (element 3), not a separate part of the pipeline — a deliberate collision between two brief sentences placed side by side, not a new code path of its own.

**The trap:** neither requirement is stated in the brief (Addendum 30) — the base template's own second-guardrail requirement (the replacement fires only when the customer's recent-request history, checked via a tool, clears a reasonable cap) still applies as a design requirement, it's just never spelled out in prose. The two requirements conflict specifically on the retry-after-lost-response path: "don't duplicate a replacement on retry" implies returning the cached result; "always re-confirm the customer's recent history before scheduling" implies re-checking rather than trusting a cached answer. A build that arrives at both requirements independently often resolves this by re-checking history *inside* the idempotency-cache-hit branch — which quietly breaks the "no duplicate on retry" guarantee.

**What "caught" looks like (dimension 2, same severity as element 3):** the shipped code applies the history re-check only to a genuinely new scheduling decision, never to an idempotency-cache-hit — a cache hit isn't a new decision, so it returns the original cached result untouched regardless of what the history check would now say.

**How to actually test this:** `INTERNAL-metadata.md` names the same request used for element 3's forced-retry check: schedule the replacement successfully, then change that customer's recent-request count in the second reference dataset before manually re-invoking the scheduling function with the same idempotency key. The retry should still return the original cached result, unaffected by the changed count. Never state this procedure in the candidate-facing brief.

**Grading treatment:** cap Dimension 2 at 1 if the retry can change outcome — same severity as element 3's plain idempotency-unsafe case.

**Dataset requirement:** no new dataset field required — reuse element 3's forced-retry test request and the existing second dataset (recent-request-history registry); the collision is constructed entirely from brief wording plus a review-time procedure.

---

## Rubric/scoring cross-reference

See `../rubric.md` for the exact anchor language — all five elements above are graded through Dimensions 2, 4, and 5's **existing** anchors and capping rules, conditioned on "expert-tier instance" per Addendum 21 (elements 1-4) and Addendum 23 (element 5), not through new dimensions or a separate scoring pass.

## Spoiler-discipline note for the generator agent

The brief states none of the five elements (Addendum 30 removed elements 3 and 5's former carve-out — nothing about retry-safety, duplication risk, or history freshness appears anywhere), never hints that element 2's coupling exists, and never names which booking record is adversarial or how (element 4), or describes the second trap's specific failure mechanism (element 1). The brief for an expert-tier instance should read as "one paragraph harder version of the base brief" — the bare capability sentences for both autonomous actions, and nothing else — not as a document that hands over any of the five things being tested.
