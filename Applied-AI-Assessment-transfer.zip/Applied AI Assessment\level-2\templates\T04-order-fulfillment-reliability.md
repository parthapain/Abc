# Template T04 — Order Fulfillment & Inventory Reconciliation (Reliability Engineering)

| Field | Value |
|---|---|
| **ID** | T04 |
| **Scenario shape** | Incoming orders arrive continuously; the app must reconcile each against inventory using an LLM-assisted agent that calls downstream tools (inventory check, fulfillment dispatch), correctly distinguishing transient from permanent failures, and autonomously dispatch fulfillment for low-risk orders gated by a guardrail |
| **Target build time** | 24–48 hrs |
| **Status** | **Shape strengthened (Addendum 20) — two ambiguities and two independently-guardrailed actions now required.** Run #1/#2 (old 1/1 shape) and **Run #3 (new second guardrail, dry-run confirmed and sharpened against real data — `../grading/calibration-runs/T04-calibration-run.md`)** are both done. **Still not verified against a live AI assistant, and T04's own timed build is still pending** — both required before this template counts as officially calibrated. |
| **Trap category** | **Category 5 — reliability engineering**, not category 3. This is the second template assigned to close the coverage gap alongside T03 (`../testing-principles.md`'s coverage check; pinned in `../generator/architecture.md`'s Open Item). |

---

## Candidate-facing brief (template — `{{...}}` filled per instance)

> Your organization processes a continuous stream of {{item_noun}} — {{item_description}}. Build an application that:
>
> 1. Ingests {{item_noun}} (seed datasets are provided — `{{dataset_file}}` and `{{second_dataset_file}}`)
> 2. Uses the in-house LLM to interpret each one — including reconciling line items that don't map cleanly onto the catalog
> 3. Works as an agent, not a single call: check inventory availability via a tool, reconcile ambiguous items against the catalog via a tool, and only then decide how to proceed
> 4. **{{ambiguity_requirement_1}}**
> 5. **{{ambiguity_requirement_2}}**
> 6. For fully-available, low-risk orders, autonomously dispatch fulfillment via a tool call — gated by an explicit check; anything uncertain, back-ordered, or above a value/risk threshold is escalated to a human
> 7. **Separately, for orders where the primary warehouse is out of stock on an item: look up alternate-warehouse stock via a tool, and if the alternate warehouse confirms availability within a reasonable shipping-cost threshold, autonomously reroute that line item to ship from the alternate warehouse via a tool call.** This is a second, independent autonomous action from step 6 — it needs its own gate.
> 8. Provides a UI showing the agent's reasoning, any autonomous action taken (dispatches *and* any alternate-warehouse reroutes), and lets a human review and override
> 9. Persists orders, reconciliation decisions, dispatch actions (including any reroutes), and any overrides to a database
>
> The fulfillment-dispatch call is realistic infrastructure: it can fail **transiently** (a timeout, a temporary service hiccup) or **permanently** (the item is genuinely unavailable, the destination is invalid) — your system needs to tell these apart and behave accordingly, rather than treating every failure the same way.
>
> Some {{item_noun}} in the seed dataset {{stress_point_description}} — your solution should handle these sensibly rather than crashing or silently corrupting the fulfillment record.
>
> Submit: a single zip of your complete project (any folder structure — commit history is not collected or graded, **10MB max, exclude dependency directories and build output**), including a short `MANIFEST.md` at the zip root pointing to where your agent/orchestration logic, tool definitions, both guardrail checks, and persistence code live; and a short written rationale (≈half a page) covering your key decisions, how you resolved anything underspecified above, any places you questioned or corrected something an AI assistant suggested, and what you'd do with more time.

---

## Fixed elements (do not vary per instance)

### Ambiguity slot

`{{ambiguity_requirement_1}}` / `{{ambiguity_requirement_2}}` — **every instance now plants two distinct phrasings from this pool, not one** (strengthened per `../design-rationale.md` Addendum 20). Pool of phrasings, all sharing the same underlying ambiguity: **what to do when reconciliation or availability isn't clean**:

1. *"Reconcile line items against the catalog when they don't match exactly."* — what fuzzy-match threshold or process counts as "reconciled" versus genuinely unresolvable?
2. *"Handle back-ordered items sensibly."* — does this mean partial fulfillment of the order, holding the whole order until available, or escalating for a human to decide, and does the answer depend on the item?
3. *"Only auto-dispatch low-risk orders."* — what value/quantity threshold, and does it vary by customer or item category?

Pick any 2 of the 3 above per instance. **What "handled well" looks like (dimension 3):** the rationale names each reading chosen and why, tied to something actually present in the dataset, and — for the top score on either — isolates the decision (a config value, a named policy function) so it's cheap to revise. Scored at the lower of the two — see `../rubric.md` §3's non-averaging rule.

### AI-trap slot — category 5 (reliability engineering), not category 3

**The trap:** the brief requires calling a fulfillment-dispatch service that can fail. When a coding assistant is asked to "add error handling and retry around the dispatch call" — a completely natural, expected request — a very common default is to **retry on any failure with no distinction between transient and permanent, and no idempotency key**, so a request that actually succeeded server-side but whose response was lost to a timeout gets retried and dispatched a second time. This is the canonical reliability-engineering failure: **distinguishing a transient failure (worth retrying) from a permanent one (not worth retrying), and not silently duplicating work on retry** (`../testing-principles.md` category 5).

**What "caught" looks like (dimension 4):** the shipped code distinguishes failure types (e.g., a typed/coded error response, a timeout treated differently from an explicit "item unavailable" response) and uses an idempotency key or equivalent so a retried dispatch call can't duplicate a fulfillment that already succeeded. There's no AI-interaction log and no commit history — only the final code plus the rationale: a "3"/"4" submission's rationale names this exact risk (a retried call after a lost response duplicating a shipment) and points to the specific mechanism that prevents it, checkably against the code.

**Trap variants** (pool):
1. Blind retry-on-any-failure with no idempotency key, risking duplicate fulfillment dispatch (as above). **Calibration note (run #1): confirmed cleanly** — a naturally-built retry wrapper calls `dispatch_fulfillment` with no idempotency token anywhere.
2. Retry logic treats a permanent failure (item genuinely unavailable) the same as a transient one, retrying indefinitely and never surfacing the real problem to a reviewer. **Calibration note: confirmed** — a single undifferentiated `except Exception` retries an out-of-stock failure exactly like a network timeout.
3. No distinction between "the dispatch call failed to send" and "the dispatch call succeeded but the response was lost" — the lost-response case is silently treated as a failure and retried, risking duplication. **Calibration note: confirmed** — this is the actual mechanism behind variant #1 reproducing; all three variants came from the same single naive response to one natural prompt, the strongest reproduction of any template's trap so far.
4. A failure is swallowed and replaced with a generic "will process later" placeholder status that never actually resolves, silently stalling the order with no visible failure state.

### Stress-point slot

`{{stress_point_description}}` — pool of variants:
1. A fulfillment-dispatch call that times out (a marked test path in the dataset/mock service)
2. An item that is permanently out of stock
3. A burst of orders referencing the same limited-stock item arriving simultaneously (a race condition on inventory, not just a data-malformation case)
4. A malformed or incomplete order (missing a required field)

**What "handled well" looks like (dimension 4):** the planted variant is handled as a recognized, named case (e.g., a distinguishable "out of stock — permanent" state vs. a "temporarily unavailable, retry scheduled" state) rather than crashing, silently duplicating a dispatch, or leaving the order in an unresolved limbo state.

---

## Mandatory agentic/tool/guardrail shape (built in, not a rework layer)

- **Agentic loop:** interpret order → call an inventory/reconciliation tool → call a dispatch tool → observe the result (success / transient failure / permanent failure) → decide next step (retry, escalate, or complete) — a genuine multi-step loop with a sensible stopping condition (e.g., a bounded retry count with backoff, not unbounded).
- **Tools:** e.g., `check_inventory(sku)`, `reconcile_catalog_item(description)`, `dispatch_fulfillment(order_id, items, idempotency_key)` — clearly scoped, structured failure reporting that distinguishes failure types (not a bare error string), not a single do-everything function.
- **Context management:** the agent carries forward what it already knows about an order's reconciliation and dispatch attempts across steps (so a retry doesn't re-derive or re-guess information already established), relevant to category 10.
- **Guardrail:** the autonomous dispatch fires only when inventory is confirmed available **and** the order is below the value/risk threshold; anything else escalates. **Guardrail-trap candidate** (graded under rubric Dimension 2, not Dimension 4 — see `../testing-principles.md` category 12 and `../rubric.md` §2): a naive first draft is likely to gate the auto-dispatch on the LLM's own confidence in its reconciliation, without a corresponding safeguard on the dispatch action itself (no idempotency, no bounded retry) — this is an architecture defect, not a second instance of the category-5 trap above, since the trap above is about the dispatch call's own failure handling and this is about what gates the decision to dispatch at all.
  - **Confirmed exactly as worded (calibration run #1, `../grading/calibration-runs/T04-calibration-run.md`):** a naturally-built guardrail checks availability and order value, with zero awareness of whether the dispatch action it's about to fire is itself safe to retry — it gates the decision to dispatch, not the safety of dispatching.
  - **Bonus finding — fourth confirmed instance of the cross-template missing-data-defaults-permissive pattern:** `item.get("price", 0)` silently treats a line item with missing/malformed price data as **free**, which *lowers* the computed order value and makes an order with incomplete data **more** likely to clear the auto-dispatch threshold, not less. Same family as T01's `confidence` default and T02's `grounded` default (T03 was the one honest miss) — now confirmed 3 of 4 times across the template set. Worth checking for explicitly on every template's guardrail math, not just assuming or dropping it after one negative result.
  - **Cap level resolved (calibration run #2, post-split re-validation):** T04's naive code actually carries **two separate Dimension 2 defects**, at two different cap severities — apply the worse one. (1) The guardrail checking availability + order value with zero awareness of dispatch-idempotency-safety is, on its own, a cap-2 finding ("guardrail exists but doesn't meaningfully check the action's own risk"). (2) The `item.get("price", 0)` permissive default is the recurring missing-data pattern, which caps at 1. **Because (2) is present, the overall Dimension 2 score for this naive shape is capped at 1**, not 2 — do not let the presence of a legitimate (if incomplete) availability/value check buy back the more severe permissive-default failure. See `../rubric.md` §2's note on not averaging across multiple findings in the same dimension.
- **Second guardrail (new, Addendum 20) — a reroute only when the alternate warehouse's real stock *and* shipping cost both clear their own checks, not just because an alternate-warehouse row exists:** for orders where the primary warehouse is out of stock, the agent must call a tool (e.g., `check_alt_warehouse(sku)`) that returns the *actual*, tool-verified alternate stock count and shipping cost from a second reference dataset (`{{second_dataset_file}}`) — never rerouting just because a row for the SKU exists in that dataset. If the alternate warehouse confirms real availability **and** the shipping cost is within a reasonable threshold, autonomously reroute; otherwise escalate. This is a separate gate from step 6's dispatch guardrail — a submission that reuses the same availability/value check for both, or reroutes based on row-existence alone, fails this requirement.
  - **Compounding-failure risk — confirmed via dry-run (calibration run #3, `../grading/calibration-runs/T04-calibration-run.md`), sharper than the original guess:** a natural implementation that emphasizes the brief's cost-threshold language can check `ship_cost <= threshold` while silently never checking `alt_stock > 0` at all — not a missing-field default, but a compound check where only half actually gets implemented. Confirmed directly against the real dataset: SKU-9008 (ORD-9013's item) has `alt_stock=0` but a valid, low `ship_cost_from_alt=0.00` — a cost-only check would incorrectly reroute an order to a warehouse with nothing to ship. **Still not tested against a live AI assistant** (dry-run only) — see Status above.
  - **Design the second dataset so this guardrail is testable in more than one direction:** at least one SKU where the alternate warehouse has real, affordable stock (should reroute), one where alternate stock exists but shipping costs too much (should escalate, not reroute), and one where the alternate warehouse also has none (should escalate — nothing to reroute to).

---

## Per-instance parameters

| Parameter | Example pool |
|---|---|
| `item_noun` / `item_description` | retail orders / purchase orders / pharmacy refill requests / equipment-rental requests / catering orders / spare-parts orders / subscription-box shipments / grocery-delivery orders / print-shop orders |
| `dataset_file` | a generated seed set per instance (catalog/inventory records + incoming orders), structurally comparable across instances, different content, including the planted stress-point and trap-carrying entries |
| `second_dataset_file` | a second, independent reference dataset per instance (e.g. `alt_warehouse_inventory.csv`) mapping SKUs to real, tool-checkable alternate stock and shipping cost — testable in all 3 directions described in the second-guardrail note above |
| Ambiguity phrasings | 2 distinct of 3 above (not 1) |
| Trap variant | 1 of 4 above |
| Stress-point variant | 1 of 4 above |

---

## Reference solution outline (author before generating any instance)

1. **Framing:** ingest → reconcile (tool) → check availability (tool) → dispatch (tool) → review UI → persist, with the dispatch step isolated enough to test independently under simulated transient/permanent failure conditions.
2. **Ambiguity:** state the chosen reading of each of the two active phrasings, why, and how each is isolated for cheap revision.
3. **Trap:** show the naive retry behavior (duplicate-dispatch risk — all three variants reproduce together, see calibration run) versus the corrected version (typed failures + idempotency), side by side.
4. **First guardrail:** show the naive first-draft guardrail (availability + order value only) versus the corrected version (also verifying the dispatch action itself is idempotency-safe) — **and explicitly show the `item.get("price", 0)` finding**, since missing price data making an order look cheaper (and thus more likely to auto-dispatch) is a specific, checkable instance of the guardrail math itself being exploitable by incomplete data.
5. **Second guardrail:** show the naive first draft (an alternate-warehouse check that defaults a missing stock/shipping-cost field permissively) versus the corrected version, and confirm the second reference dataset actually exercises all 3 test directions.
6. **Stress point:** the specific order that exercises it and the expected reviewable state.

## Calibration — reset by Addendum 20 (shape strengthened to 2 ambiguities / 2 guardrails)

Steps 1–3 below were confirmed against the **old, superseded 1-ambiguity/1-guardrail shape** — see `../grading/calibration-runs/T04-calibration-run.md` for that historical dry-run (including Run #2's post-rubric-split re-validation, which resolved T04's two Dimension 2 defects to an overall cap-1). None of it has been re-verified against the new second ambiguity or the new second guardrail's compounding-failure risk. Sequenced last, behind T01, T02, and T03's own resets (see `../generator/architecture.md`'s sequencing note). Results so far:
1. ✅ *(old shape)* **Confirmed, strongly.** All three trap variants (blind retry, permanent-vs-transient conflation, no send/lost-response distinction) reproduced simultaneously from a single natural response to one prompt — the cleanest reproduction across all four templates.
2. ✅ *(old shape)* **Confirmed.** Phrasing 2's back-order handling is genuinely two-way using realistic sample data. **Not yet re-tested** with a second phrasing active alongside it.
3. ✅ *(old shape)* **Confirmed as worded, plus a bonus finding.** The guardrail gates on availability/value alone with no dispatch-side safeguard — and `item.get("price", 0)` was found to make incomplete pricing data *more* likely to auto-dispatch, the fourth instance of the recurring missing-data-defaults-permissive pattern seen across T01/T02/T04 (T03 was the one honest miss).
3b. ✅ **Dry-run confirmed (calibration run #3), sharper than the original guess.** A cost-only check that never verifies stock would reroute ORD-9013 (SKU-9008, 0 alt stock, $0.00 alt shipping cost) to an empty warehouse — confirmed directly against the real dataset. **Not yet posed to a live AI assistant.**
4. ⏳ **Not attempted** — last in the queue, behind T01, T02, and T03's resets.
