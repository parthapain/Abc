from app import database as db
from app import tools


def _seed_ticket(ticket_id, requester, status, submitted_at, body):
    db.upsert_ticket(ticket_id, requester, "Standard", status, submitted_at, body)


def test_search_related_history_flags_open_duplicate(temp_db):
    _seed_ticket("HD-1", "Marcus", "open", "2026-09-01T00:00:00Z",
                 "Laptop won't turn on, tried multiple outlets, still escalated to hardware team, unresolved.")
    _seed_ticket("HD-2", "Marcus", "new", "2026-09-02T00:00:00Z", "Laptop won't turn on.")

    result = tools.search_related_history("HD-2", "Marcus", "Laptop won't turn on.")
    assert result["is_genuine_duplicate"] is True
    assert result["best_open_match"]["ticket_id"] == "HD-1"


def test_search_related_history_ignores_closed_tickets_for_duplicate_flag(temp_db):
    _seed_ticket("HD-1", "Marcus", "closed", "2026-08-01T00:00:00Z",
                 "Laptop won't turn on after firmware update. IT reimaged it and it's working now.")
    _seed_ticket("HD-2", "Marcus", "new", "2026-09-02T00:00:00Z", "Laptop won't turn on.")

    result = tools.search_related_history("HD-2", "Marcus", "Laptop won't turn on.")
    assert result["is_genuine_duplicate"] is False
    assert result["best_match"]["ticket_id"] == "HD-1"  # still surfaced as related history


def test_search_related_history_no_match_for_unrelated_requester(temp_db):
    _seed_ticket("HD-1", "Someone Else", "open", "2026-09-01T00:00:00Z", "VPN is down.")
    _seed_ticket("HD-2", "Marcus", "new", "2026-09-02T00:00:00Z", "Laptop won't turn on.")
    result = tools.search_related_history("HD-2", "Marcus", "Laptop won't turn on.")
    assert result["candidates"] == []
    assert result["is_genuine_duplicate"] is False


def test_extract_claimed_amount():
    assert tools.extract_claimed_amount("I was overcharged $40 on renewal") == 40.0
    assert tools.extract_claimed_amount("charged $200.50 extra") == 200.50
    assert tools.extract_claimed_amount("there was a billing error") is None


def test_check_billing_record_confirms_matching_claim(temp_db):
    _seed_ticket("HD-3020", "Priya Anand", "new", "2026-09-14T09:30:00Z", "Charged $15.")
    db.load_billing_record("Priya Anand", 15.00)
    result = tools.check_billing_record("HD-3020", "Priya Anand", 15.00)
    assert result["confirmed"] is True
    assert result["verified_discrepancy"] == 15.00


def test_check_billing_record_rejects_mismatched_claim(temp_db):
    _seed_ticket("HD-3050", "Noah Kim", "new", "2026-09-14T10:30:00Z", "Overcharged $40.")
    db.load_billing_record("Noah Kim", 0.00)
    result = tools.check_billing_record("HD-3050", "Noah Kim", 40.00)
    assert result["confirmed"] is False


def test_check_billing_record_handles_missing_record(temp_db):
    _seed_ticket("HD-9999", "Nobody", "new", "2026-09-14T10:30:00Z", "Charged $10.")
    result = tools.check_billing_record("HD-9999", "Nobody", 10.00)
    assert result["found"] is False
    assert result["confirmed"] is False


def test_auto_close_ticket_updates_status_and_logs_action(temp_db):
    _seed_ticket("HD-1", "Marcus", "open", "2026-09-01T00:00:00Z", "Laptop issue")
    _seed_ticket("HD-2", "Marcus", "new", "2026-09-02T00:00:00Z", "Laptop issue")
    tools.auto_close_ticket("HD-2", "HD-1", 0.9)
    assert db.get_ticket("HD-2")["status"] == "closed"
    actions = db.list_actions("HD-2")
    assert any(a["action_type"] == "auto_closed_duplicate" for a in actions)


def test_issue_courtesy_resolution_updates_status_and_logs_action(temp_db):
    _seed_ticket("HD-1", "Priya", "new", "2026-09-01T00:00:00Z", "Overcharged $15")
    tools.issue_courtesy_resolution("HD-1", 15.00)
    assert db.get_ticket("HD-1")["status"] == "resolved"
    actions = db.list_actions("HD-1")
    assert actions[-1]["action_type"] == "courtesy_resolution"


def test_route_ticket_picks_correct_team(temp_db):
    _seed_ticket("HD-1", "Someone", "new", "2026-09-01T00:00:00Z", "VPN issue")
    result = tools.route_ticket("HD-1", "Network/VPN")
    assert result["team"] == "Network & Infrastructure"
    assert db.get_ticket("HD-1")["status"] == "routed"
