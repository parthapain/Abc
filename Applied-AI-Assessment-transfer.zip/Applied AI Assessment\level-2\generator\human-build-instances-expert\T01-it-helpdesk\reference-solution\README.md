# Reference solution — T01 expert-tier "IT Helpdesk"

This is the reference solution for the T01-it-helpdesk expert-tier instance, authored as the required calibration step before any dry-run or live-AI test (see `../INTERNAL-metadata.md`, `../../templates/T01-triage-classification-EXPERT-ADDENDUM.md`, and `../../../design-rationale.md` Addendum 21, extended by Addendum 23 and Addendum 24).

**Scope note:** this reference solution focuses on the classification/dedup/guardrail logic the expert-tier elements actually depend on — `orchestrator.py`, `resolution_client.py`, `db_models.py` — not a full candidate-style review UI, and `classify_ticket` is a deterministic keyword-based stand-in for the in-house LLM (good enough to prove the mechanisms are real and correctly resolvable; not meant to demonstrate NLU quality).

## What `verify.py` confirms (run it: `python verify.py`)

All 15 checks pass, covering:
- **Expert element 1 (ambiguous duplicate match):** HD-3010 is correctly flagged as an ambiguous match against two prior tickets (HD-3001 closed, HD-3007 open) with different implications, not silently closed against one.
- **Expert element 2 (guardrail/ambiguity coupling):** HD-3015 clears classification confidence and the dedup check, but is still escalated because the urgency policy catches its real deadline signal.
- **Expert element 3 (idempotency):** a forced lost-response retry on HD-3020 still produces exactly one resolution record; a manual double-invoke with the same idempotency key returns an identical cached result.
- **Expert element 5 (stale-data vs. idempotency collision):** after HD-3020 resolves successfully, the verified discrepancy for Priya Anand is changed, then the same resolution call is retried with the same idempotency key. The retry still returns the original cached success untouched.
- **Expert element 4 (adversarial tool response):** HD-3045's billing record (`verified_discrepancy=-999.00`) is escalated as invalid data, not treated as a real number.
- **Addendum 24, priority/urgency divergence:** HD-3025 (VIP, trivial request) and HD-3030 (regular requester, severe request) resolve consistently with this solution's documented policy (severity-based, not tier-based), and the log explicitly names `requester_tier` as considered-and-excluded, not silently ignored.
- **Addendum 24, routing divergence:** HD-3035 (genuinely spans Network/VPN and Security Incident) is escalated for a person to triage, not silently routed to one team.
- **The two other second-guardrail directions:** HD-3050 (claim not corroborated by the real record) and HD-3055 (corroborated but over threshold) both escalate rather than auto-resolving.
- **The stress point:** HD-3040 (blank body) is escalated as a classification failure, distinctly from a genuine low-confidence result.
- **Addendum 31, guardrail independence:** HD-3060 (Licensing & Reimbursement, verified $20 discrepancy, also worded urgently) still gets its courtesy resolution evaluated and issued — urgency doesn't block or skip it.

## Key decisions (matching what a candidate's own rationale would cover)

- **Priority/urgency (ambiguity 1):** judged on objective severity language in the request body (deadlines, outage scope, "production," "blocked"), not on `requester_tier`. A VIP label is a status signal, not an operational-risk signal. This exclusion is isolated behind a single `USE_REQUESTER_TIER_IN_URGENCY` flag in `orchestrator.py`, and every ticket's log explicitly states the field was seen and excluded, not overlooked.
- **Routing (ambiguity 2):** a request that hits both network-access and security-incident signal words is flagged `AMBIGUOUS_ROUTING` and escalated, rather than picking whichever category scores higher — a naive keyword-priority router would arbitrarily favor one team and never surface the tension.
- **Duplicate detection:** a word-overlap heuristic that can return more than one plausible prior match; more than one match with different implications (one closed, one open) is flagged ambiguous rather than resolved to the highest-scoring one.
- **Idempotency:** the resolution idempotency key is derived from the ticket id, requester, and verified discrepancy amount, so retries of the same action reuse it; `resolution_client.py`'s server-side record (independent of what the caller heard back) is what makes "already happened, tell the truth" possible even after a simulated lost response.
- **Stale-data re-check placement:** the brief's "always re-confirm the current verified discrepancy" applies only to a fresh resolution decision, never to an idempotency-cache-hit — the cache check runs first and returns immediately, so a discrepancy that changes *after* a resolution already succeeded can never leak in and overturn it on retry.
- **Adversarial tool response:** the billing-record check treats a negative verified discrepancy as invalid data, not a real number to compute with — same escalation path as "no record on file."
