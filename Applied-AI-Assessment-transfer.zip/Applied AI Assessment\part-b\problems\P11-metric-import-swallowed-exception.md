# P11 — Token count import

| Field | Value |
|---|---|
| **ID** | P11 |
| **Difficulty** | Medium |
| **Bug pattern** | Caught exception silently skips a row |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 10–13 min |
| **Set** | Contingency |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

An upstream system exports metrics as free text, so the `tokens` column sometimes holds values like `unknown` or `pending` instead of a number.

The importer is losing rows. Downstream counts do not match the source, and the missing entries are exactly the ones with non-numeric values — they vanish rather than being flagged.

### Required behaviour

Return `(name, tokens)` for **every** row, in `id` order.

- Rows whose `tokens` value parses as an integer use that value.
- Rows whose value does not parse are recorded with `0` — but they still appear in the output.

### Schema

```sql
CREATE TABLE raw_metrics (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    tokens TEXT NOT NULL     -- free text from an upstream export; may be non-numeric
);
```

---

## Fixture — `P11.sql`

```sql
CREATE TABLE raw_metrics (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    tokens TEXT NOT NULL
);

INSERT INTO raw_metrics (id, name, tokens) VALUES
    (1,'alpha','100'),
    (2,'beta','unknown'),   -- unparseable: must appear with 0, not disappear
    (3,'gamma','50');
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)
# --- end boilerplate ---


def import_metrics(db_path: str) -> List[Tuple[str, int]]:
    """
    Return (name, tokens) for every row in id order.
    Unparseable values are recorded as 0 but the row must still appear.
    """
    conn = _connect(db_path)
    try:
        rows = conn.execute("SELECT name, tokens FROM raw_metrics ORDER BY id").fetchall()
    finally:
        conn.close()

    out: List[Tuple[str, int]] = []
    for name, raw in rows:
        try:
            out.append((name, int(raw)))
        except ValueError:
            continue
    return out
```

### Java

```java
import java.sql.*;
import java.util.*;

public class MetricImporter {

    // --- boilerplate: do not modify ---
    public static class Metric {
        public final String name;
        public final int tokens;

        public Metric(String name, int tokens) {
            this.name = name;
            this.tokens = tokens;
        }
    }

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return (name, tokens) for every row in id order.
     * Unparseable values are recorded as 0 but the row must still appear.
     */
    public static List<Metric> importMetrics(String dbPath) throws SQLException {
        List<Metric> out = new ArrayList<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name, tokens FROM raw_metrics ORDER BY id")) {
            while (rs.next()) {
                String name = rs.getString("name");
                String raw = rs.getString("tokens");
                try {
                    out.add(new Metric(name, Integer.parseInt(raw)));
                } catch (NumberFormatException e) {
                    continue;
                }
            }
        }
        return out;
    }
}
```

### C#

```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record Metric(string Name, int Tokens);

public static class MetricImporter
{
    // --- boilerplate: do not modify ---
    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return (Name, Tokens) for every row in id order.
    /// Unparseable values are recorded as 0 but the row must still appear.
    /// </summary>
    public static List<Metric> Import(string dbPath)
    {
        using var conn = Connect(dbPath);
        var rows = conn.Query<(string Name, string Raw)>(
            "SELECT name, tokens FROM raw_metrics ORDER BY id").ToList();

        var output = new List<Metric>();
        foreach (var (name, raw) in rows)
        {
            try
            {
                output.Add(new Metric(name, int.Parse(raw)));
            }
            catch (FormatException)
            {
                continue;
            }
        }
        return output;
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `100`, `unknown`, `50` | `[("alpha",100), ("beta",0), ("gamma",50)]` | **Discriminator** — broken drops `beta` |
| T2 | `100`, `200` | `[("alpha",100), ("beta",200)]` | Guard — everything parses |
| T3 | `n/a`, `pending` | `[("alpha",0), ("beta",0)]` | **Discriminator** — broken returns `[]` |
| T4 | Single row, `7` | `[("solo",7)]` | Guard |
| T5 | Empty table | `[]` | Guard |

### Fixtures

```sql
-- T2
INSERT INTO raw_metrics (id, name, tokens) VALUES (1,'alpha','100'),(2,'beta','200');
-- T3
INSERT INTO raw_metrics (id, name, tokens) VALUES (1,'alpha','n/a'),(2,'beta','pending');
-- T4
INSERT INTO raw_metrics (id, name, tokens) VALUES (1,'solo','7');
```

---

## Reference solution

Record the row with a zero instead of abandoning it.

**Python:**

```diff
  except ValueError:
-     continue
+     out.append((name, 0))
```

**Java:**

```diff
  } catch (NumberFormatException e) {
-     continue;
+     out.add(new Metric(name, 0));
  }
```

**C#:**

```diff
  catch (FormatException)
  {
-     continue;
+     output.Add(new Metric(name, 0));
  }
```

### Why

The `catch` is doing two jobs at once and only one of them is wanted. Preventing the exception from propagating is correct — a single bad row should not abort the import. Discarding the row is not: the specification says unparseable values become `0`, which means the row is *recorded*, just with no measured value.

`continue` conflates "I have handled this" with "this never happened". No error surfaces, no count is logged, and the row is gone. This is why the discrepancy only shows up downstream as a mismatched total rather than as a failure at import time.

The general shape is worth naming: a `catch` block whose entire body is `continue`, `pass`, or `{}` is almost always hiding a decision that was never actually made.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Removing the `try`/`catch` entirely so bad rows raise | T1, T3 — the whole import fails |
| Skipping the row but logging a warning | T1, T3 — the row is still missing from the output |
| Defaulting to `-1` rather than `0` | T1, T3 |

---

## Reviewer validation checklist

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is missing rows, not an unhandled exception
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Confirm the exception type caught in each language matches what the parse actually throws (`ValueError` / `NumberFormatException` / `FormatException`)
- [ ] C#: if `int.TryParse` is used in a candidate's fix, confirm the grader accepts it
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
