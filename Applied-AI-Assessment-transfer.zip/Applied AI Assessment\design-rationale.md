# Applied AI Developer Assessment — Level 1 Content Design

## Context

The organization is hiring **Applied AI developers** ("AI practitioners") across mixed seniority — fresh graduates through senior. Stated principle: *talent can reside anywhere*, so the assessment must surface capable people from Java, .NET, and database backgrounds, not just Python developers.

**Level 1** — ~1 hour, proctored on HirePro, run across **2 days × 3 slots = 6 unique question papers**:
- **Part A** (30 min): 21 MCQs pulled from HirePro's existing bank. We specify topic + complexity only; HirePro supplies the questions. Their standard contract excludes prompt-engineering and "vibe coding" modules.
- **Part B** (30 min): 2 debugging problems — small data-pipeline functions (SQL fetch + host-language processing). Candidate chooses Python, Java, or C#/.NET. Auto-graded via hidden test cases.
- An **absolute cutoff** on Part A gates access to Part B.

**Level 2** (~1 month later): 24–48hr take-home use case built with org tooling (in-house LLMs, MCP, Bitbucket, standard IDEs). Use cases not yet formulated; this plan sets its evaluation principles only.

**Volume:** 200–500 candidates. **Timeline:** Level 1 live in 2 weeks.

**Authoring model:** Part B content is AI-authored (Claude) with mandatory human peer review by 3+ reviewers. Authoring hours are therefore not the constraint — **validation quality is**.

### What Level 1 is and isn't

Level 1 is an **unassisted competence floor**: can this person read unfamiliar code, reason about data flow, and fix a real defect under time pressure. It deliberately does *not* measure AI-collaboration skill — that is Level 2's job. Naming this honestly matters, because industry benchmarking (below) shows AI-collaboration behaviour is the strongest differentiating signal, and Level 1 contains none of it by design, not by oversight.

### Industry benchmarking

Research across investment banks, IT services firms, and big tech/assessment vendors (2024–2026 public sources):

- **88% of AI job postings in financial services are "AI user" roles vs. 12% "AI developer"** (Evident Insights) — confirms an applied-skill target is correct, not a compromise.
- **The clearest 2025–2026 trend** (Google, Meta, Shopify, HackerRank, Karat) is scoring *observed AI-collaboration behaviour* — prompt quality, verification of output, judgment to override bad AI code — rather than banning AI tools. HackerRank's own guidance recommends project-based evaluation over isolated challenges.
- **Hackathon/challenge formats** are the most common talent-identification mechanism disclosed by banks and IT services (UBS Agentic AI Challenge, Wipro/Topcoder GenAI hackathons, Morgan Stanley's hackathon-originated DevGen.AI).
- **No organization publicly discloses a formal AI-practitioner assessment rubric.** This is an absence of evidence, not evidence of correctness — it means there is no external benchmark to validate this design against, and internal pilot data matters more as a result.

Implication applied here: the AI-collaboration signal is captured at **Level 2**, and its scoring is designed in now (Deliverable 3) rather than retrofitted.

---

## Deliverable 1: Part A topic/complexity spec

`part-a-complexity-mix.md` — the spec handed to HirePro. **21 questions / 30 min.**

| Section | Subtopics | # Qs | L/M/H |
|---|---|---|---|
| DSA | Arrays/hashing, Big-O reasoning, tree/graph traversal, sorting/searching trade-offs | 3 | 1/1/1 |
| Python | OOP + decorators, comprehensions/functional, exception handling & context managers, iterators/generators, async basics | 5 | 1/3/1 |
| AI/ML Fundamentals — LLM/GenAI | Tokenization/context window, prompting techniques (zero/few-shot, CoT), embeddings & vector search, RAG, agents/tool-calling (incl. MCP) | 5 | 1/3/1 |
| AI/ML Fundamentals — ML & Statistics | Supervised vs. unsupervised + eval metrics (precision/recall/F1), overfitting/bias-variance, probability & correlation vs. causation | 3 | 1/1/1 |
| PostgreSQL | Joins/aggregation/subqueries, indexing & EXPLAIN, JSONB, pgvector awareness | 3 | 1/2/0 |
| API/Backend | REST principles, statelessness, basic caching | 1 | 0/1/0 |
| Data wrangling | Pandas-style ops (groupby/merge), missing-data handling, basic cleaning | 1 | 0/1/0 |
| **Total** | | **21** | **5/12/4** |

**Timing:** 4 High × ~2 min + 12 Medium × ~1.3 min + 5 Low × ~0.8 min ≈ **28 min**, inside the 30-min window. The earlier 25-item version was ~30–50% over budget and would have measured reading speed rather than knowledge.

**Design decisions:**
- "Gen AI Basics" renamed **AI/ML Fundamentals**, split into LLM/GenAI vs. ML & Statistics so statistics is visible rather than buried.
- **Kubernetes and streaming excluded** — this screens Applied AI developers, not platform engineers; infra trivia risks false-negatives on strong candidates from non-DevOps backgrounds.
- **Python kept at 5 items** (decision taken deliberately): Python is the org's actual AI stack, so it is job-relevant, not arbitrary. Accepted trade-off — non-Python candidates face Python content *before* the gate. Mitigated by holding Python to **1 High item** (down from 2), so the pre-gate Python content is not the hardest material on the paper.
- **Absolute cutoff, set pre-test** from HirePro's historical item difficulty data (p-values). A percentile cutoff is **not viable**: Part B must unlock ~30 min into a live session, before any distribution exists; and percentiles across 6 different bank draws confound paper difficulty with candidate ability.
- **Optional rigor upgrade:** embed ~5 identical anchor items across all 6 papers to statistically equate difficulty between slots. Recommended if HirePro supports it.

---

## Deliverable 2: Part B — 24-problem bank, 3 language variants, SQL embedded

### Bank structure

**24 problems: 12 Medium + 12 High**, each authored in **3 language variants** (Python, Java, C#/.NET).

- **Launch uses 12** — 6 papers × 2 problems, **one Medium + one High per paper**.
- **Remaining 12 held as contingency** — replacement for a leaked or broken problem mid-run, and rotation stock for future cycles (the real long-term leakage defence).

> Note on difficulty: a strict "identical difficulty mix across all 6 papers" with 2 problems per paper permits only two difficulty levels. Hence **Medium + High per paper**, with Low dropped entirely — appropriate anyway, since these candidates have already cleared Part A.

### Equal-playing-field design

Each problem is designed as a **language-agnostic logic pattern first**, then expressed identically across all three languages. Language-specific gotchas (Python mutable defaults, Java checked-exception quirks) are deliberately avoided so no variant is inadvertently harder.

**≥10 distinct bug patterns across the bank**, e.g.:

| # | Pattern | Typical location |
|---|---|---|
| 1 | Paginated fetch loop drops the last page | SQL + host |
| 2 | Incorrect null/None handling in a cleaning step | Host |
| 3 | Off-by-one in a batching/windowing function | Host |
| 4 | Shared mutable state corrupts aggregation across iterations | Host |
| 5 | `INNER JOIN` silently drops rows that need `LEFT JOIN` | SQL |
| 6 | `GROUP BY` at the wrong grain | SQL |
| 7 | Deduplication on the wrong key | SQL or host |
| 8 | Sort applied after truncation, so top-N is wrong | SQL or host |
| 9 | Integer division / rounding error in a computed metric | Host |
| 10 | Date-boundary or timezone error in a range filter | SQL |
| 11 | Accumulator reset in the wrong scope | Host |
| 12 | Swallowed exception masking partial failure | Host |

### SQL embedded, not a separate track

Each problem is a small pipeline: SQL query → process/aggregate results. This mirrors real Applied AI work and gives DB-strength candidates a genuine foothold.

**Per-paper balance rule (required for comparability):** each paper contains **one SQL-located bug and one host-logic-located bug**. Without this, papers are not equivalent, and mandatory-SQL-everywhere would become a new gate against candidates strong in AI but weak in SQL.

**Pinned DB idiom — one per language, no ambiguity:**

| Language | Idiom |
|---|---|
| Python | `psycopg2` |
| Java | JDBC |
| C#/.NET | Dapper |

Connection/boilerplate code is marked **`// do not modify`** — JDBC is several times more verbose than psycopg2, and unmarked boilerplate would penalize Java candidates on reading time alone.

### Grading

**Primary:** a small seeded **SQLite** fixture per problem; the candidate's fixed code runs against it; hidden test cases compare output end-to-end.

**Fallback** (if HirePro's sandbox cannot seed a DB across all three languages): query results supplied as fixed in-memory data, SQL shown as read-only context, bug scoped to host-language logic only. **Under the fallback all SQL-located problems cease to exist** — which is why this dependency is resolved before authoring (see Dependencies).

### Per-problem deliverable (×3 language variants)

- Problem statement + function signature
- Broken code — host logic + embedded SQL, boilerplate marked do-not-modify
- Seeded DB fixture (or in-memory data under fallback)
- Hidden test cases
- Reference solution
- Tags: bug pattern, bug location (SQL/host), difficulty

### Validation gate — mandatory before any problem ships

AI-authored broken code has characteristic failure modes: ambiguous bugs with several valid fixes, accidental second bugs, and test cases that fail to discriminate. Reading the code is not sufficient review. For **every problem × every language variant**:

1. Reference solution **passes** all test cases.
2. Broken version **fails** — and fails on the *intended* test, not incidentally.
3. Exactly one intended fix; no unintended second defect.
4. Bug is neither trivially visible on a skim nor findable only by guessing.
5. **Language-parity pilot:** 2–3 engineers per language attempt each problem; reject or rework any variant >25% off the mean solve time.

### Paper assembly rules

- 12 launch problems partitioned across 6 papers, 2 each, no sharing.
- Each paper: 1 Medium + 1 High; 1 SQL-located + 1 host-located.
- No repeated bug pattern within a paper.
- Prefer **per-candidate** problem randomization over per-slot where HirePro supports it — per-slot assignment staggers leakage rather than preventing it and systematically advantages Day 2, and does nothing about in-room collusion.

Mapping documented in `part-b-paper-mapping.md`.

---

## Deliverable 3: Level 2 design principles

`level-2-design-principles.md` — principles only; use cases are a separate later effort.

- **AI-tool usage as an explicit scoring dimension**, alongside functional correctness: prompt quality and iteration, verification of AI output, judgment on when to override or discard AI-generated code. This is the industry's strongest differentiating signal and the thing Level 1 structurally cannot capture.
- **Server-side evidence capture.** Log prompts/interactions from the org's own LLM gateway. Candidate-exported chat logs are self-reported and trivially curated — they cannot be the basis of scoring.
- **Optional hackathon framing** — shared kickoff, showcase or leaderboard — following the UBS/Wipro pattern. A suggestion for the team, not a requirement.

---

## Program infrastructure (must exist before Day 1)

| Item | Detail |
|---|---|
| **AI-tool policy** | Level 1 is unassisted, enforced by HirePro's standard controls: screen lockdown, copy-paste block, camera monitoring, face detection, second-device detection. Stated explicitly to candidates. |
| **Scoring model** | Part A absolute cutoff value; Part B partial credit (finding 1 of 2 bugs); Part A:Part B weighting for the final shortlist. |
| **Funnel math** | Derive cutoffs *backwards from Level 2 review capacity* — how many of 200–500 can actually be reviewed on a 24–48hr use case, and by whom. |
| **Background reporting** | Pass-rate broken out by candidate background (Python / Java / .NET / DB). This is the only metric that proves the "talent can reside anywhere" objective was met. |
| **Dress rehearsal** | Full timed run with internal engineers on the real HirePro configuration before Day 1. |
| **Candidate policies** | Retakes, mid-test disconnects, and appeals — written before launch, not improvised during it. |
| **Leak detection** | Post-hoc per-item p-value comparison across the 6 slots; a Day-2 spike flags a leaked problem for replacement from the contingency bank. |

---

## Dependencies — written go/no-go by Day 3

All six sit on the critical path and change *what gets authored*, not just how it's packaged. If unanswered by Day 3, commit to the fallback design and proceed.

1. Custom-question **import format** (starter code fields, test-case schema, runtime config).
2. Can the sandbox **seed a SQLite DB** and let submitted code query it — in Python, Java, *and* C#?
3. Is **C#/.NET a supported runtime** at all?
4. Does the MCQ bank hold **enough items per topic × complexity cell** to build 6 low-overlap papers?
5. Will HirePro share **historical item p-values** for setting the absolute cutoff?
6. Does the platform support **per-candidate** randomization, and **anchor items** across papers?

---

## Verification

- Confirm all six dependencies in writing before authoring begins.
- Run the full validation gate (5 checks above) on all 24 problems × 3 variants; no problem ships un-piloted.
- Language-parity pilot: reject any variant >25% off the mean solve time for its problem.
- Timed dry run of a complete paper (Part A + Part B) end-to-end on the real HirePro configuration.
- Confirm the absolute cutoff against HirePro's item data before Day 1; sanity-check the implied pass rate against Level 2 review capacity.
- After Day 1, run the per-item leak check across slots before Day 2 opens.

---
---

# Level 2 Assessment — Design (from scratch, post-Level-1)

*The section below supersedes the original Level 2 principles referenced earlier in this document. It was written after Level 1 concluded (1,000+ participants, 300 cleared) and reflects the actual scale and constraints of Level 2, not the assumptions made before Level 1 results were known.*

## Context

Level 1 is complete: 1,000+ participants, 300 cleared the cutoff. Those 300 now face Level 2 — a 24–48hr take-home build using in-house LLMs, MCP, Bitbucket and standard IDEs, producing an application with a UI, backend, and typically a database.

The previous Level 2 design-principles document is **discarded entirely** and replaced by this plan. The basic shape of Level 2 (timeframe, tooling, app type) is unchanged — what's being rebuilt from scratch is how it's structured, generated, and graded.

**Why this is a harder design problem than Level 1:** Level 1's Part B graded deterministic code fixes against hidden test cases — an AI or a script can check pass/fail unambiguously. Level 2 asks an AI to judge open-ended, structurally unique submissions against qualitative criteria (design quality, critical thinking, judgment) with no single correct answer. That's a fundamentally less reliable grading problem, and the design below treats it as the central risk to manage, not an afterthought.

**Operating constraints, as given:**
- **300+ distinct use cases**, generated from a smaller set of templates sharing consistent underlying principles — not one shared case, not 300 hand-authored ones.
- **Only 3 human reviewers.** Every submission gets an AI-based rubric evaluation first; only those clearing a minimum score reach the 3 humans.
- **Difficulty: high, deliberately.** The goal is finding real practitioners, not maximizing pass-through. No obligation to hit any particular headcount at the human-review stage.
- **"Bias handling"** in the rubric means over-trusting AI output — verifying/overriding AI-generated code rather than accepting it uncritically — not fairness-in-data.
- **Timeline:** candidates start within 1 week; AI + human grading completes within the week after that. Roughly a 2-week total runway.

## The central risk, named up front

An AI grading 300+ unique, creative submissions against subjective criteria can be inconsistent, gameable (rewarded for confident/verbose output over substance), or simply wrong in ways a human wouldn't be. Because the AI evaluation is the **only** gate — nothing reaches a human unless the AI passes it — an ungrounded or unvalidated rubric doesn't just under-perform, it silently discards the exact "real experts" this exercise exists to find.

Everything in `level-2/` is designed around de-risking that single point of failure: giving the AI grader concrete evidence to work with (not just a diff to vibe-judge), anchoring every rubric dimension to observable behavior, and validating the grader against known-good/known-bad samples before it ever touches a real candidate.

## Deliverable 1: Use-case generator (produces 300+ instances from ~6–8 templates)

**Mechanism:** a small number of base templates, each parameterized along independent axes, so instances are structurally unique but the underlying skill being tested — and therefore the rubric — stays constant.

**Per template, fix in advance:**
- The business scenario shape (e.g., triage/classification, extraction from unstructured text, a dashboard over noisy data, a summarization + action-item pipeline)
- **One deliberately underspecified requirement** — candidates must notice and resolve the ambiguity
- **One planted "AI will get this wrong by default" trap** — a subtly wrong-by-default approach an AI coding assistant is likely to produce unprompted, catchable only by a candidate who verifies the output
- **One production-readiness stress point** — a plausible edge case or failure mode a rushed solution will mishandle

**Per instance, vary:** surface domain/flavor text, the specific dataset seed, and which pool variant of the ambiguity/trap/stress-point is used.

**Why this and not fully bespoke cases:** hand-authoring 300+ genuinely distinct, well-formed briefs in a week isn't achievable. A generator makes volume and uniqueness compatible with the timeline, and makes cross-candidate comparison valid, since every instance of a template tests the same three signal categories regardless of surface domain.

**Calibration requirement before mass-generating:** author one full reference solution per template and confirm the traps are genuinely non-obvious before generating the full instance set. See `level-2/generator/architecture.md` and the "Calibration" section of each `level-2/templates/*.md`.

## Deliverable 2: Rubric

Four dimensions, each with concrete behavioral anchors per score level: problem framing & approach, handling of ambiguity/critical thinking, AI-output verification ("bias handling"), production readiness. Full anchors in `level-2/rubric.md`.

Required candidate evidence per submission: the repo, a server-side-captured AI-interaction log (not self-exported — see `level-2/dependencies/llm-gateway-logging.md`), and a short written rationale.

## Deliverable 3: AI-grading pipeline

Structured grading prompt (`level-2/grading/grading-prompt.md`) applying the rubric with cited evidence per dimension; a mandatory calibration process (`level-2/grading/calibration-process.md`) against known-good/known-bad/confidently-wrong/correct-by-luck sample submissions before the grader runs on real candidates; an absolute-bar cutoff mechanism, not a percentile or fixed headcount, reconciled against actual 3-reviewer bandwidth (`level-2/grading/cutoff-and-aggregation.md`).

## Deliverable 4: Logistics

Per-candidate provisioning, staggered clock starts, candidate-facing disclosure requirements, submission mechanics — `level-2/logistics.md`.

## Timeline (2 weeks total)

**Week 1 — build:** rubric anchors + LLM-gateway dependency confirmed (days 1–2) → templates authored, calibrated, instances generated (days 2–3) → grading prompt built and calibrated (days 3–4) → light-touch dry run (days 4–5) → logistics finalized, launch (days 5–7).

**Week 2 — candidates + grading:** rolling 24–48hr submission windows → AI grading → score distribution reviewed, absolute cutoff applied → 3 reviewers assess everyone who cleared it → final shortlist.

## Verification

Confirm the LLM-gateway dependency before generating instances at scale; run the calibration set and check agreement before grading real submissions; dry-run at least one instance per template to confirm traps are real; sanity-check the score distribution against reviewer bandwidth before finalizing the cutoff.

### Addendum — closing the agentic/tool-design/context-management gap

After the rubric, generator, and first two templates (T01, T02) were drafted, a review of the testing scope against publicly known AI-practitioner skill areas (agentic architecture, tool/function design, prompt & structured-output engineering, context management) found that T01 and T02 — both single-shot, single-LLM-call scenarios — gave candidates no way to demonstrate three of those skills: agentic-loop design, tool/function interface design, and context management across multi-step or multi-source interactions.

**Why this was worth fixing rather than accepting as scope:** these are named, industry-recognized applied-AI skills, not edge cases. Leaving them untested wouldn't just be an incomplete rubric — for a candidate whose main strength is exactly this kind of design work, it would mean the assessment structurally couldn't surface their strongest skill, no matter how the rubric scored what was submitted.

**Resolution:**
- `level-2/testing-principles.md` gained three new categories (8–10: agentic architecture & orchestration, tool/function interface design, context management), each stated in vendor-neutral terms and marked as scenario-shape-dependent (only assessable when the use case actually requires it).
- T01 and T02 were **not** retrofitted — reworking either would invalidate already-drafted ambiguity/trap/stress-point content for no real gain. Instead, the requirement was placed on the template set as a whole: **at least 2 of the remaining 4–6 templates (T03 onward) must require a multi-step agentic loop, a designed tool interface, or meaningful context volume** — one well-designed template can satisfy all three at once.
- The rubric itself didn't need new dimensions — "problem framing & approach" (dimension 1) and "production readiness" (dimension 4) already had room to score agentic/tool-design/context-handling quality once the anchors called it out explicitly; both were annotated accordingly rather than adding a 5th/6th dimension.
- The main real-world impact lands on template authoring and calibration effort, not on scope size (still 6–8 templates) or on the rubric: an agentic/tool-using template is closer to a small system design than a single function, and its calibration has to confirm a loop terminates sensibly and a trap survives across multiple steps, not just that a single response reproduces a flaw. `level-2/generator/architecture.md` now documents this explicitly and recommends sequencing at least one such template early enough to leave rework time if its calibration fails.

### Addendum 2 — closing the security, safety, and optimization gaps

A follow-up review asked directly whether the assessment tests for security, safety, and optimization. It did not, fully: only the injection-style slice of security (treating untrusted input as data, not instructions) was covered. Broader security (secrets/credential handling, sensitive-data exposure), safety (guardrails on the AI taking a real, hard-to-reverse action on its own), and optimization (cost/latency/efficiency awareness) were all gaps.

**Resolution — three new categories added to `level-2/testing-principles.md`:**
- **Category 11 (Security — secrets, credentials, sensitive data):** distinct from the existing untrusted-input category. Assessable on **any** submission — every template's dataset already carries realistic sensitive-looking fields, so no template rework was needed. Folded into rubric Dimension 4 as a baseline production-readiness expectation.
- **Category 12 (Safety — guardrails on AI-initiated actions):** scenario-shape-dependent, like the agentic/tool/context categories from the previous addendum. T01 and T02 only ever let the AI produce a *suggestion* a human reviews — neither gives the AI the ability to trigger a real action itself, so neither can test whether a candidate gates that action appropriately. Added to the same mandatory template-set requirement as before: at least one of the remaining templates (T03+) must give the AI the ability to trigger a consequential, hard-to-reverse action, so this is gradable. Folded into rubric Dimension 1 alongside the existing agentic/tool-design note.
- **Category 13 (Optimization — cost, latency, efficiency):** assessable on any submission's overall architecture (a design that's clearly wasteful or wouldn't hold up at real volume is a legitimate finding regardless of template) and reinforced concretely wherever a stress point includes a volume/scale variant — T01 already has one, so no template change was required there either. Folded into rubric Dimension 1.

**Net impact:** the mandatory "at least 2 of the remaining templates must be agentic/tool-using/context-heavy" requirement from the previous addendum now also carries a fourth condition — at least one such template must let the AI trigger a real action, so the safety-guardrail category has something to grade. Security and optimization added no new authoring requirement at all; they were absorbed as grading-expectation notes on the existing rubric dimensions, since the existing templates and datasets already provide enough surface to assess them.

### Addendum 3 — no server-side evidence exists; Dimension 3 rebuilt around submission-only evidence

**This supersedes the "Server-side evidence capture" plan and the "Required candidate evidence" statement from the original Level 2 design section above** (which required a server-side-captured AI-interaction log as one of three mandatory evidence artifacts). Confirmed: there is no server-side interaction log, and none is planned. Grading works from exactly two things per candidate — the submitted repository (code, and commit history where the candidate preserves it) and the written rationale.

**Why this couldn't just be dropped as a nice-to-have:** Dimension 3 (AI-output verification / "bias handling") was explicitly the rubric's most load-bearing dimension — the whole point of Level 2 is finding candidates who verify AI output rather than trust it blindly, and the log was the mechanism for telling "verified before it broke" apart from "verified after it broke" apart from "never verified, got lucky." Losing that evidence source doesn't remove the question, it just removes the clean way to answer it — so every design principle stays in place; only the mechanics of scoring Dimension 3 changed.

**What actually changed:**
- `level-2/rubric.md` Dimension 3's anchors were rewritten around what's checkable without a log: is the planted flaw present or absent in the shipped code, and — if absent — does the written rationale name the specific risk and point to a specific, verifiable mechanism in the code (not just claim verification happened). A new grading-note rule was added: a rationale's claims may never push the score above what the code independently demonstrates, since an unsupported claim is otherwise indistinguishable from a true one without a log to check it against.
- Dimension 2's grading note and Dimension 3's prompt-engineering note were both lightly adjusted (references to "the log shows..." became "commit history, if preserved, shows...").
- `level-2/grading/grading-prompt.md` and `level-2/grading/calibration-process.md` had every log-dependent instruction rewritten; the calibration set's "missing/incomplete log" archetype was replaced with an "unsupported claim" archetype, since that's the actual failure mode the new design has to guard against.
- Both templates (`level-2/templates/T01-*.md`, `T02-*.md`) had their candidate-facing disclosure line removed (it falsely promised server-side logging) and their "what caught looks like" guidance rewritten around code + rationale evidence.
- `level-2/logistics.md` now explicitly instructs candidates to preserve normal commit history (not squash it before submitting) — this is the one piece of candidate behavior that meaningfully affects how much evidence graders have for Dimensions 2 and 3, so it's called out as an instruction, not left implicit.
- `level-2/dependencies/llm-gateway-logging.md` is kept as a closed record of the question and its answer, rather than deleted, since the reasoning behind the original design (why a log was wanted, why self-exported ones were rejected) is still relevant context for understanding why Dimension 3 looks the way it does now.

**The honest residual cost, carried forward rather than hidden:** Dimension 3 is a weaker signal than the original design achieved. It can still tell whether a candidate's final submission handles the planted risk correctly, and it can still reward a candidate whose rationale demonstrates specific, checkable awareness of that risk over one who shows none — but it can no longer reliably separate "caught it proactively" from "caught it reactively" from "correct by accident" the way turn-by-turn log evidence would have. This is treated as an accepted trade-off, not a hidden one — it's stated plainly in the rubric itself so no one downstream mistakes the current Dimension 3 score for the fidelity the original design assumed.

### Addendum 4 — commit history is also unavailable; grading works from a final snapshot only

**Supersedes the commit-history assumption made throughout Addendum 3.** That addendum assumed the submitted repository would include its normal incremental commit history, and used it as a partial (weaker) substitute for the missing server-side log — e.g., "a safeguard added in a later commit than the initial implementation is suggestive of a reactive catch." Confirmed: **this assumption was wrong.** Submissions arrive as a single final code snapshot. There is no commit history, in addition to no interaction log.

**Net effect:** every place in the rubric, grading prompt, calibration process, and templates that treated commit history as optional-but-useful supporting evidence has had that language removed — not softened, removed, since it doesn't exist for any candidate and can't provide even weak signal. Concretely:
- `level-2/rubric.md` Dimension 3's anchors no longer mention a "later commit" as suggestive of a reactive catch — evidence is now binary: is the flaw present in the final code, and does the rationale name the risk and a checkable mechanism, full stop. Dimension 2's anchor and grading note dropped their commit-history references similarly.
- `level-2/grading/grading-prompt.md` dropped every step that told the grader to check commit history, and now states plainly that there is no timing evidence of any kind available for any dimension.
- `level-2/grading/calibration-process.md`'s "correct by luck" archetype description was adjusted to not lean on absent commit-history evidence.
- Both templates (`level-2/templates/T01-*.md`, `T02-*.md`) and `level-2/logistics.md` were corrected to stop asking candidates to preserve commit history — that instruction is now moot, since only the final snapshot is collected regardless of what the candidate does locally.
- `level-2/dependencies/llm-gateway-logging.md` was updated to record both confirmed absences (log and history) together, since they compound: the rubric's original design had two independent evidence sources for "did they verify or blindly trust," and both turned out to be unavailable.

**What this means practically, stated once and referenced everywhere else:** Dimension 3 (and the timing-sensitive parts of Dimension 2) now operate on a **single point in time** — the final submission — with no way to observe the process that produced it beyond what the candidate chooses to describe in their rationale, and no way to verify that description except by checking it against the code that exists. This is the floor of what the design can support given the actual evidence available; every testing principle in `level-2/testing-principles.md` is still tested, but the confidence and granularity of Dimension 3's score specifically is now lower than either the original design or Addendum 3 assumed, and this is stated plainly wherever Dimension 3 is discussed rather than glossed over.

### Addendum 5 — agentic architecture, tool design, context management, and safety guardrails are now mandatory for every template (reverses Addendum 1's "at least 2 of the set" decision)

**Explicit instruction driving this change:** these four skills should be tested on every submission, not just some — full stop, no exemption for simpler templates. This directly reverses the decision recorded in Addendum 1, which deliberately kept T01 and T02 single-shot and pushed the requirement onto "at least 2 of the remaining 4–6 templates," specifically to avoid re-doing already-drafted work.

**What changed:**
- `level-2/testing-principles.md` categories 8, 9, 10, and 12 are relabeled from "scenario-shape-dependent, satisfied by some templates" to "mandatory, every template" — the same footing as categories 1–7. The template-authoring section was rewritten around a single non-negotiable floor: every template's brief must require a multi-step agentic loop, expose tools to the LLM, involve real context volume, and give the AI a consequential action gated by a candidate-designed guardrail.
- `level-2/rubric.md` Dimension 1's note dropped the "T01/T02 are exempt" carve-out entirely — every submission is now expected to show this.
- `level-2/generator/architecture.md` was rewritten to state plainly that **T01 and T02 no longer meet the bar and need reworking**, not just leaving alone while later templates cover the gap. A concrete (directional, unfinished) rework sketch was added for both: T01 becomes a multi-step triage agent with lookup/context tools and a gated auto-acknowledge/auto-route action; T02 becomes a multi-step extraction agent with cross-referencing tools and a gated auto-commit action. Both templates' own files were updated with a "needs rework" status flag.

**The honest cost, stated rather than absorbed silently:** the earlier design deliberately budgeted uneven authoring effort — 2 "expensive" agentic templates, the rest "cheap" single-shot ones — specifically to fit 6–8 templates into a 1-week build window. That asymmetry is gone. Every template is now an "expensive" one: full agentic loop, tool interfaces, failure propagation across steps, and a guardrail-trap that itself needs calibration (confirming a naive AI-assisted build actually produces an under-gated action by default, the same discipline as any other planted trap). This is a **genuine increase in total authoring and calibration effort across the whole template set**, and it puts the original "6–8 templates within a 1-week build" plan in real tension — flagged explicitly in `level-2/generator/architecture.md` rather than assumed to still be fine, since discovering this on day 5 of a 1-week build would be far more costly than surfacing it now.

### Addendum 6 — template count cut from 6–8 to 4, once authoring vs. calibration were correctly separated

Addendum 5 flagged a timeline risk from making categories 8/9/10/12 mandatory on every template, but initially framed it as an authoring-effort problem. On questioning, that framing was corrected: **authoring a template (the brief, tool definitions, reference solution) is not the bottleneck** — it's drafted by an AI and human-reviewed, exactly the same low-friction process used for Level 1's 24 problems, and doesn't meaningfully slow down regardless of template count.

**The actual, irreducible bottleneck is calibration** — for every template, someone has to run the scenario past a live AI assistant and observe real behavior: does it produce the planted flaw, does a naive agentic build really skip or under-gate the consequential action, does the loop terminate sensibly. This is empirical testing, not writing, and it can't be sped up by better drafting. If a trap doesn't reproduce, the template needs rework and re-testing — the same lesson Level 1's P06 already taught (a plausible-sounding bug that the query planner silently defeated, caught only by actually running the harness, not by re-reading the spec more carefully).

**Resolution:** rather than accept the risk or extend the 1-week timeline, the template count was cut from 6–8 to **4** — directly trading template/scenario variety for a calibration workload that fits the original schedule, since every template now requires the full (not partial) calibration checklist. To compensate for fewer templates, `level-2/generator/architecture.md`'s parameter-pool arithmetic was revised upward (roughly 9 domain flavors instead of 6, 4 dataset seeds instead of 3) so 4 templates still comfortably clear 300+ genuinely distinct instances. T01 and T02's rework (per Addendum 5) plus 2 new templates now completes the set, instead of the previously planned 4–6 additional templates.

## Addendum 7 — peer review: dimension overload, guardrail ownership, timebox sequencing, trap-coverage gap

An independent peer review of the Level 2 design (post-Addendum 6) surfaced four issues, all now fixed:

1. **Dimensions 1 and 4 each bundled 3–4 independent scoring criteria into one 0–4 number with no rule for how they combine** — e.g., Dimension 1 covers base architecture fit, agentic/tool/guardrail quality, and cost/efficiency; nothing said what happens when a submission is strong on one and badly fails another. Fixed by adding explicit capping rules (not averages) to `level-2/rubric.md` §1 and §4 and to `level-2/grading/grading-prompt.md`: an ungated consequential action or a hard security failure caps its dimension at 1 regardless of surrounding quality; grossly wasteful design or lost/garbled context caps at 2.
2. **A naive agentic guardrail's own default behavior (e.g., "auto-fire past a confidence threshold" with no check on the action's own risk) had no assigned owner between Dimension 1 and Dimension 3.** Decided: it's an architecture/guardrail-design defect, scored under Dimension 1's capping rule — not a second AI-trap subject to Dimension 3's code-must-match-rationale evidence discipline. Recorded in `level-2/testing-principles.md` category 12, `level-2/rubric.md` §1, `level-2/grading/grading-prompt.md`, and `level-2/generator/architecture.md`.
3. **The mandatory agentic/tool/context/guardrail scope (Addendum 5/6) was never re-timeboxed against the original 24–48hr build estimate.** Fixed by sequencing: T01 is reworked, calibrated, and internally timeboxed as a full instance *first*, before T02's rework or either new template starts — so a scope/timeline mismatch is caught after one template, not four. See `level-2/generator/architecture.md`'s sequencing note and both templates' updated Calibration sections.
4. **`testing-principles.md`'s coverage check (at least one template's trap must come from category 4 or 5, not just category 3) was never assigned to a specific template** — T01 and T02 are both category 3, and the requirement was at risk of being forgotten once the 2 new templates are actually authored. Pinned in `level-2/generator/architecture.md`'s Open Item: one of the 2 new templates must cover category 4 or 5.

A new calibration case (#7, `level-2/grading/calibration-process.md`) — "strong architecture, capped by a hard failure" — was added specifically to test whether the AI grader applies the new capping rules or averages a hard failure away against otherwise-strong work. None of this changes the four-dimension, 0–16 structure or any prior decision; it closes gaps in how the existing dimensions are meant to combine multiple signals, and sequences already-planned work more safely.

## Addendum 8 — static-only grading, plus a live demonstration gate for shortlisted candidates

A direct question surfaced a real gap: templates require candidates to "persist to a database," but nothing specified how a grader working from a static final-code snapshot (no server-side log, no commit history, no execution environment at 300-candidate scale) would actually verify that behavior — or whether running each submission was ever assumed. `grading-prompt.md`'s Dimension 4 procedure had briefly implied execution access might be available ("or by actually running it if you have execution access"), which was never actually provisioned for anywhere near 300+ candidates.

**Decision: grading is static-only for the full 300+ initial screen.** The AI grader (and, at the human-review stage, the 3 reviewers) assess persistence/DB behavior — and every other dimension — by reading the submitted code (schema, migrations, ORM models, query/persistence logic) as written, never by running the application. This is now explicit in `level-2/rubric.md` §4 and `level-2/grading/grading-prompt.md`'s Dimension 4 procedure, which no longer implies execution access.

**To close the resulting gap — nothing before the cutoff confirms a submission actually works — candidates who clear the absolute cutoff and reach the 3 human reviewers are asked for a short live demonstration of their working application**, scheduled alongside their review slot. This is a verification gate, not a new scored dimension: the AI-graded rubric scores stand as computed from static code; the demo confirms the app behaves as that code implied. A demo that reveals the app doesn't actually run, or contradicts what static grading credited, is a strong red flag a reviewer weighs directly — not folded back into the AI score.

**Why this shape and not full execution-based grading for everyone:** provisioning a runnable execution environment for 300+ candidates' heterogeneous stacks (whatever DB, whatever framework, whatever local setup each one used) is a real, unplanned infrastructure dependency at that scale. Bounding the live check to the ~100–150 candidates who reach reviewer bandwidth (per `cutoff-and-aggregation.md`'s existing headroom math) keeps the cost proportionate to where it matters — final hiring decisions — without adding a 300-candidate infrastructure item to an already tight one-week build.

Recorded in `level-2/rubric.md`, `level-2/grading/grading-prompt.md`, `level-2/grading/cutoff-and-aggregation.md` (new section), `level-2/logistics.md` (disclosed to candidates upfront, plus a scheduling note), and `level-2/testing-principles.md`'s evidence-constraint note (scoped so the "no timing evidence at all" statement doesn't contradict this one narrow exception).

## Addendum 9 — diagnostic-agent idea rejected; submission moves from Bitbucket repo to zip upload

Two related ideas were explored and resolved:

**A candidate-run "diagnostic agent" that scans the candidate's own setup and reports back a score was rejected.** The proposal was to hand every candidate a scanning agent, run it against whatever they built, and grade the diagnostic it returns. Rejected because the agent would run entirely on hardware the candidate controls (root/admin access, their OS, their choice of what's actually running) — an execution-integrity problem, not a confidentiality one. Encrypting or obfuscating the report (a follow-up idea, "only a key at our end unlocks the contents") doesn't fix this: it stops the candidate from editing the ciphertext, but not from tampering with what's being measured before it's ever encrypted, or reverse-engineering an obfuscated agent to learn exactly which checks it performs. This is the standard, practically-unsolved anti-cheat/DRM problem, and the candidate population (skilled developers) is exactly the population best equipped to defeat it. The self-run-and-self-report shape is also the same trust failure already rejected once for self-exported AI-interaction logs. **Where this idea remains useful:** as an unscored self-check tool candidates can optionally run to confirm their build hits the mandatory shape requirements before submitting — never as graded evidence.

**A related idea — dropping the built-application requirement so the entire use case happens inside an LLM session (prompt + tool-calling, no app)** — was raised and not pursued further once its cost was named: most of the 15 testing categories (architecture fit, persistence, security-in-code, reliability engineering, production readiness) presuppose an actual application exists to inspect. Removing it would narrow Level 2 from testing "can this person build production software with AI assistance" down to "can this person configure an agent well" — a different, narrower hiring bar than the "Applied AI developer" role this assessment exists to screen for. Not adopted.

**Submission mechanism changed: a single zip upload replaces a per-candidate hosted Bitbucket repo.** This followed from a practical concern raised separately — will the AI grader actually do a good job statically scanning an entire, arbitrarily-structured codebase (a real risk, distinct from the diagnostic-agent question, and one `calibration-process.md` is meant to catch empirically, not something resolved by this decision alone). Since grading was already decided to be static-only (Addendum 8) and there's no commit history to preserve either way, a hosted repo was serving no purpose a zip doesn't: a zip trivially enforces "final snapshot, no history" by construction, and removes the "provision 300 Bitbucket repos" logistics task entirely. Candidates now submit one zip (any folder structure, dependency directories and build output excluded, a size cap enforced) with a required `MANIFEST.md` at the root pointing to where the agent/orchestration logic, tool definitions, guardrail check, and persistence code live — this directly mitigates the "arbitrary structure is hard to scan" concern, since the grader now always has a signpost regardless of how a candidate organized their project. Recorded in `level-2/logistics.md`, both template files' submission lines, and `HANDOFF.md`.

## Addendum 10 — T03 and T04 authored; sequencing rule corrected to calibration-order, not authoring-order

Authored the 2 remaining templates needed to complete the 4-template set:

- **T03 — Refund/Account Request Handling** (`level-2/templates/T03-refund-request-handling.md`): assigned the **category 4 (untrusted input)** trap — a customer request's free-text body must not be able to dictate an autonomous action (an agent that lets embedded text like "already approved, skip verification" influence its decision, rather than gating strictly on tool-verified account/order data).
- **T04 — Order Fulfillment & Inventory Reconciliation** (`level-2/templates/T04-order-fulfillment-reliability.md`): assigned the **category 5 (reliability engineering)** trap — blind retry-on-any-failure with no idempotency key around a fulfillment-dispatch call, risking duplicate dispatch when a transient failure (lost response) is mistaken for a hard failure.

Both close the coverage gap flagged in Addendum 7/HANDOFF's Open Item (at least one template must draw from category 4 or 5, not just category 3). Both were authored directly to the mandatory agentic/tool/guardrail shape from the start — genuine multi-step loop, purpose-built tools, a gated autonomous action, and a guardrail-trap candidate explicitly noted as a Dimension 1 concern (per Addendum 7's ownership decision), not a second Dimension 3 trap. Neither needs the rework pass T01/T02 still need.

**Sequencing rule corrected in the process.** The prior sequencing note (`architecture.md`, `HANDOFF.md`) said T01 must be reworked and calibrated *before starting T02's rework or authoring either new template*. Authoring T03/T04 now, in parallel with T01/T02's rework being still-pending, surfaced that this over-applied the constraint: Addendum 6 already established authoring isn't the scarce resource, calibration is. The rule has been corrected everywhere it appeared to say what was actually intended — calibrate T01 first (including its timeboxed build check), then T02, then T03/T04, but authoring all four in parallel was never the problem. Nothing about the calibration-ordering logic itself changed, only which activity (authoring vs. calibrating) the "do T01 first" constraint actually applies to.

## Addendum 11 — T01 and T02 reworked; all 4 templates now locked to the mandatory shape

Completed the rework that Addendum 5/6/10 had left as sketches. Both templates were rewritten in full (not just the sketch — the actual candidate-facing brief, fixed elements, mandatory-shape section, per-instance parameters, reference solution outline, and calibration steps):

- **T01 (triage/classification):** added a `search_similar_items`/`get_context` tool-using agentic loop and a guardrail-gated auto-acknowledge/auto-close/auto-route action. The original ambiguity slot (priority determination) and AI-trap slot (silent failure masking) were preserved unchanged, with one addition: a trap-triggered failure must never reach the guardrail as "safe to auto-act on" — this closes a real gap the sketch hadn't fully worked through (a masked failure being auto-acted on is worse than the pre-rework version's "a human eventually notices").
- **T02 (structured extraction):** added a `verify_against_source`/`lookup_related_document` tool-using agentic loop and a guardrail-gated auto-commit action. The original ambiguity slot (field-mapping ambiguity, including the date-reference phrasing that now ties directly to the new lookup tool) and AI-trap slot (hallucination-on-absence) were preserved unchanged, with the same addition: an ungrounded/hallucinated extraction must never reach auto-commit as "verified."

Both templates' Status lines now read "Reworked," matching T03/T04's "drafted to the mandatory shape" status — **all 4 templates are authored and structurally equivalent** in terms of what they require of a candidate (agentic loop, tool interface, context management, gated consequential action), differing only in domain and which trap category they draw from (T01/T02: category 3; T03: category 4; T04: category 5).

**Nothing about the calibration sequencing changed.** T01 is still first in the calibration queue, and its timeboxed build check is still the thing that determines whether the mandatory scope fits the 24–48hr window for all four templates — that determination has not been made yet. Authoring all 4 templates does not substitute for calibrating any of them.

Recorded in `level-2/generator/architecture.md` (Open Item, "T01 and T02 — reworked, no longer an open gap" section, Impact section), `HANDOFF.md` (decisions table, state-of-play, what-must-happen-next, known limitations), and `README.md` (status table, known limitations).

## Addendum 12 — T01 calibration run #1: trap, ambiguity, and guardrail-default confirmed; timeboxed build still pending

Ran T01's calibration procedure for real rather than treating it as a checkbox — simulated the natural, incremental way a candidate would prompt a coding assistant (classify → add error handling → make it agentic with tools and a guardrail), without ever mentioning the trap, and inspected what came out. Full record: `level-2/grading/calibration-runs/T01-calibration-run.md`.

**Findings:**
- **Step 1 (trap reproduces):** confirmed — the natural "add error handling" request produces exactly the silent-fallback-classification pattern the template describes.
- **Step 2 (ambiguity genuinely two-way):** confirmed — tested against realistic sample tickets, a tier-first vs. signal-first reading of "prioritize appropriately" are both defensible.
- **Step 3 (guardrail-default trap reproduces):** confirmed, and **sharper than the template originally anticipated.** The naive guardrail reads `result.get("confidence", 1.0)` — since the step-1 failure-masked fallback dict carries no `confidence` key, a *failed* classification defaults to reading as **maximum confidence**, sailing straight through the guardrail into auto-acknowledge. The two traps compound: fixing either one in isolation (adding a status flag to the fallback, or tightening the guardrail's threshold) is not enough on its own — a candidate has to notice that the guardrail's confidence check must also verify the classification wasn't itself a failure. This is a genuinely useful finding: it's a stronger, more concrete failure mode than "a trap-triggered failure must never reach the guardrail," stated only as a principle before this run. It has been folded into T01's AI-trap/guardrail notes and reference solution outline.
- **Step 4 (timeboxed build):** **not done.** A complexity-based estimate was given (48hrs realistic, 24hrs tight, given the full mandatory scope now required) but explicitly flagged as not a substitute for an actual timed human build — consistent with the project's standing rule (from Level 1's P06 lesson) never to claim something reproduces or holds without actually verifying it.

**Consequence:** T01 is not yet fully calibrated. The remaining step — an actual timed human build, not a complexity estimate — still gates calibrating T02, T03, and T04, per the existing sequencing rule. When T02 is calibrated next, this run's compounding-failure pattern (a shared default-value gap between a trap and its guardrail) should specifically be checked for there too, since T02's structure (extraction trap + auto-commit guardrail) is analogous.

Recorded in `level-2/templates/T01-triage-classification.md` (Status line, guardrail note, reference solution, Calibration section), `level-2/generator/architecture.md` (Open Item), `HANDOFF.md` (decisions table, state-of-play, what-must-happen-next, known limitations), and `README.md`.

## Addendum 13 — T02 dry-run calibration: same trap/ambiguity/guardrail pattern confirmed, including an analogous compounding failure

Ran the same real calibration exercise for T02 that Addendum 12 ran for T01 — simulating the natural, unprompted-about-the-trap build process. Full record: `level-2/grading/calibration-runs/T02-calibration-run.md`.

**Findings:**
- **Trap (hallucination-on-absence):** confirmed — a naturally-written extraction prompt invents a plausible value for a genuinely absent field rather than reporting it missing, exactly as described.
- **Ambiguity (phrasing 3, relative date reference):** confirmed genuinely two-way.
- **Guardrail-default trap:** confirmed, with **the same class of compounding bug found in T01, one layer deeper.** T01's compounding failure lived in the classification call's own error handling (a failure-masked fallback with no `confidence` key reading as maximum confidence). T02's lives in the *verification tool's* error handling: a naturally-built `verify_against_source` returns an empty dict on its own internal exception, and the guardrail's `v.get("grounded", True)` reads that as verified — so a field can get auto-committed specifically *because* its verification failed to run, which is the opposite of what "verified" is supposed to mean.

**This is a useful pattern recognition, not a coincidence:** both templates independently produced a guardrail that trusts a missing key as a safe default, on two structurally analogous designs (a call that can fail silently, feeding a guardrail that reads an optional field with a permissive default). This is now flagged as something to specifically check for in T03 and T04 as well, since both have an analogous shape (T03's `check_request_eligibility`, T04's `dispatch_fulfillment`).

**This run is explicitly a dry-run, not an official calibration.** T02's official status — and its own step 4 (timed build) — still wait on T01's step 4 clearing first, per the existing sequencing rule. Running T02's steps 1–3 in parallel was judged acceptable using the same reasoning as authoring T03/T04 in parallel (Addendum 10): cheap to check now, doesn't consume the scarce resource, and doesn't substitute for the real gate.

Recorded in `level-2/templates/T02-structured-extraction.md` (Status line, guardrail note, reference solution, Calibration section), `level-2/generator/architecture.md` (Open Item), `HANDOFF.md` (decisions table, state-of-play, what-must-happen-next, known limitations), and `README.md`.

## Addendum 14 — T03 dry-run calibration: mixed result, reported honestly rather than forced to match T01/T02

Ran the same calibration exercise for T03. Full record: `level-2/grading/calibration-runs/T03-calibration-run.md`. This one came back genuinely different from T01/T02, and that difference is reported as-is rather than papered over for narrative consistency — the whole point of actually running these checks (versus assuming) is that some of them will legitimately come back negative.

**Findings:**
- **Trap (category 4, untrusted input):** confirmed, but through a different mechanism than expected. A hard-coded orchestration (Python code always calls the eligibility tool, regardless of request text) doesn't let embedded text skip that tool call — trap variant #1 ("skip verification") did not reproduce under this implementation style. What did reproduce cleanly: the dollar amount used to execute the resolution is parsed from the customer's untrusted text and never cross-checked against the verified order record (variant #3), even when the eligibility gate itself works correctly. Variant #1 remains plausible under a genuine function-calling agent style (the LLM itself choosing which tools to invoke, potentially swayed by embedded text) but wasn't directly testable by hand-simulating code — it needs a live model. **Consequence: the reference solution and grading notes now recognize either manifestation as "the trap is present," rather than assuming one specific code shape.**
- **Ambiguity:** confirmed genuinely two-way (value threshold vs. recent-claim-history).
- **Guardrail:** **the T01/T02 compounding null-default bug was specifically checked for and did not reproduce.** T03's natural `.get("eligible")` call (no default supplied) fails closed in Python when the key is missing — a real, honest negative result, not every template repeats the same bug shape. What *did* reproduce is a distinct, T03-specific gap: a guardrail can correctly gate the *decision* (eligible/not eligible) while the *action's parameters* (the amount) still leak unverified data through to execution. This is arguably the more precise, more useful finding for this template specifically, since T03's whole point is untrusted input controlling actions — "the decision is gated but the parameters aren't" is a sharper articulation of exactly that risk than the original guardrail-trap wording had.

**Why the negative result matters:** it would have been easy to just report "compounding bug confirmed again" for consistency with T01/T02. Doing so would have been dishonest and would have taught the wrong lesson to whoever authors T04 next (that this exact bug shape is universal). Calibration only has value if a genuine negative result is reported as one — this is the same discipline as Level 1's P06, just running in the other direction (confirming a hypothesized failure does *not* reproduce, rather than confirming one that seemed too good to be true actually didn't hold up).

Recorded in `level-2/templates/T03-refund-request-handling.md` (Status line, trap-variant notes, guardrail note, reference solution, Calibration section), `level-2/generator/architecture.md` (Open Item), `HANDOFF.md` (decisions table, state-of-play, what-must-happen-next, known limitations), and `README.md`.

## Addendum 15 — T04 dry-run calibration: strongest confirmation of the four, plus a fourth instance of the cross-template pattern; all 4 templates now dry-run complete

Ran the same exercise for T04, the last of the four templates. Full record: `level-2/grading/calibration-runs/T04-calibration-run.md`.

**Findings:**
- **Trap (category 5, reliability):** the strongest reproduction across all four templates — a single natural response to one prompt ("add error handling and retry so a temporary failure doesn't lose the order") simultaneously produced all three planted trap variants: blind retry with no idempotency key, permanent failures retried identically to transient ones, and no distinction between "call failed to send" and "call succeeded but the response was lost." Unlike T01/T02/T03, which each needed a specific follow-up scenario to expose their flaw, this one fell out directly and completely from the single most natural way to answer the prompt.
- **Ambiguity:** confirmed genuinely two-way (ship-partial vs. hold-whole-order on a back-ordered item).
- **Guardrail:** confirmed exactly as the template's guardrail-trap-candidate predicted (gates on availability/value, no awareness of the dispatch action's own safety) — **plus a fourth instance of the recurring missing-data-defaults-permissive pattern**: `item.get("price", 0)` treats a line item with missing price data as free, which *lowers* the computed order value and makes an incompletely-priced order **more** likely to clear the auto-dispatch threshold, not less.

**Cross-template pattern now confirmed 3 of 4 times** (T01's `confidence` default, T02's `grounded` default, T04's `price` default) **with one honest negative** (T03, where the analogous check happened to fail closed instead). This crossed the threshold from "template-specific curiosity" to "general thing worth checking for" — added directly to `level-2/grading/grading-prompt.md`'s Dimension 1 guidance: check whether missing/failed data makes a submission *more* likely to auto-act, not less, as a specific instance of the capping rule, rather than relying on each template's own notes to catch it independently.

**All 4 templates now have a completed dry-run calibration pass.** What is genuinely, uniformly outstanding across the whole set is step 4 — an actual timed human build — which has not been attempted for any of them. T01 remains first in the queue; the dry-run findings across all four don't change that sequencing, since scope-fit is a question only a real timed build answers.

Recorded in `level-2/templates/T04-order-fulfillment-reliability.md` (Status line, trap-variant notes, guardrail note, reference solution, Calibration section), `level-2/grading/grading-prompt.md` (new Dimension 1 cross-template guidance), `level-2/generator/architecture.md` (Open Item), `HANDOFF.md` (decisions table, state-of-play, what-must-happen-next, known limitations), and `README.md`.

### Addendum 16 — Dimension 1 split into two; rubric moves from 0–16 to 0–20

**Trigger:** asked to map the rubric's four dimensions against 8 named applied-AI skill areas (Agents and Workflows, Applications and Integration, Claude Code, Eval/Testing/Debugging, Model Selection and Optimization, Prompt and Context Engineering, Security and Safety, Tools and MCPs). The exercise showed Dimension 1 alone was standing in for 4 of the 8 — architecture fit, the mandatory agentic loop, tool/function interface design, and most of cost/efficiency — while carrying only one capping rule to keep them from being averaged together.

**Decision:** split Dimension 1 into two dimensions rather than continue bundling them:
- **Dimension 1 — Problem framing & architecture fit**: unchanged base architecture-fit anchors, no capping rule of its own.
- **Dimension 2 — Agentic design, tools & guardrails** (new): agentic loop quality, tool/function interface design, the guardrail on consequential actions, and cost/efficiency awareness — carrying forward the exact capping rule that used to live in Dimension 1 (ungated action → cap 1; grossly wasteful → cap 2).

The former Dimensions 2 (ambiguity), 3 (AI-output verification), and 4 (production readiness) are renumbered to 3, 4, and 5. Total moves from 0–16 to 0–20 — equal weighting by default, unchanged in principle.

**Why split rather than leave it bundled:** the capping rule already prevented one failure from being averaged away, so this isn't a correctness fix — it's a legibility fix. With one dimension standing in for 4 of 8 named skill areas, a human skimming per-dimension scores couldn't tell, from the score alone, whether a weak "Dimension 1" reflected bad architecture, a badly-designed tool interface, a missing guardrail, or wasteful AI-call patterns — four meaningfully different things to tell a reviewer to look at. Splitting makes each of those visible as its own number.

**What this touches:** every reference to "Dimension 1" for agentic/tool/guardrail/cost content across `level-2/rubric.md`, `level-2/grading/grading-prompt.md`, `level-2/testing-principles.md`, `level-2/generator/architecture.md`, all 4 templates (`level-2/templates/T0{1,2,3,4}-*.md`), the calibration-run write-ups (`level-2/grading/calibration-runs/`), `level-2/grading/calibration-process.md` (case #7), `level-2/grading/cutoff-and-aggregation.md`, `level-2/dependencies/llm-gateway-logging.md`, `HANDOFF.md`, and `README.md` was renumbered to Dimension 2; former Dimensions 2/3/4 (ambiguity/verification/production) were renumbered to 3/4/5 throughout the same set.

**What this does not touch:** the underlying anchors, capping thresholds, and evidence-discipline rules are unchanged in substance — this is a renumbering and a split of what was one dimension into two, not a re-scoring of any prior calibration finding. The cross-template missing-data-defaults-permissive pattern (confirmed in T01, T02, T04; honest negative in T03) still lives in the same conceptual place, now cited as Dimension 2 instead of Dimension 1.

**Historical note:** Addenda 1–15 above use the pre-split numbering (Dimension 1 = architecture + agentic/tool/guardrail + cost-efficiency combined; Dimensions 2/3/4 = ambiguity/verification/production). Read them with that mapping in mind rather than assuming today's numbering applies retroactively — they are an accurate record of the reasoning at the time, not a live-updated reference.

**Not yet done:** this split hasn't been exercised against the calibration set, since that calibration set hasn't been built or run yet regardless (see `level-2/grading/calibration-process.md`). The split is a documentation-and-legibility change made ahead of that step, not a change validated by it.

### Addendum 17 — Post-split calibration re-validation across all 4 templates; gated-decision-vs-gated-parameter cap resolved

**Trigger:** after Addendum 16's split, asked to re-run the dry-run calibration exercise for all four templates against the new 5-dimension/0–20 rubric, to confirm the split didn't quietly change any finding's severity or create a scoring gap between the two halves of what used to be one dimension.

**Method:** re-ran the same simulated candidate-to-coding-assistant prompts used in calibration runs #1 (`level-2/grading/calibration-runs/T0{1,2,3,4}-calibration-run.md`) for each template, verbatim. Output was identical in every case — the split changes grading structure, not the brief, the trap, or what a naturally-prompted coding assistant produces — so this was a mapping-and-resolution exercise, not a re-derivation of new code.

**Findings:**
- **T01, T02:** every finding renumbers cleanly onto the new dimensions with no change in severity. Both templates' guardrail-compounding bugs (a missing `confidence`/`grounded` key defaulting to a permissive value) confirm as Dimension 2 cap-1 ("no gate at all") under the new split, same conclusion run #1 already reached.
- **T03 and T04 surfaced a real gap the pre-split, single-dimension design had no way to expose:** the rubric's Dimension 2 anchors state two distinct cap severities (cap-1 "no gate at all" vs. cap-2 "guardrail exists in name only, doesn't check the action's own risk"), but neither T03's nor T04's existing calibration notes said which one applied to their specific findings.
  - **T03:** the eligibility gate genuinely works and fails closed, but `execute_resolution`'s dollar amount is never checked against verified order data at all. **Resolved as cap-1** — an unconditionally unverified executed parameter is functionally an ungated action, even though a real (and passing) decision-level check exists elsewhere.
  - **T04:** two independent Dimension 2 defects coexist — a guardrail that checks availability/value but not dispatch-idempotency-safety (cap-2 in isolation), plus the already-known `item.get("price", 0)` permissive default (cap-1). **Resolved: the worse cap governs** — overall Dimension 2 caps at 1, not 2, when both are present in the same submission.

**Decision:** write both resolutions into the rubric and grading prompt as general rules, not template-specific footnotes, since "a gate exists for the decision but not for the executed parameter" and "multiple cap-triggering findings in one dimension" are shapes any future template (or any real candidate submission) could reproduce, not quirks of T03/T04 specifically. Also added calibration-set case #8 ("gated decision, ungated parameter") to `level-2/grading/calibration-process.md`, since case #7 (ungated action vs. hard security failure) didn't cover this specific confusion.

**What this touches:** `level-2/rubric.md` §2 (two new clarifying paragraphs), `level-2/grading/grading-prompt.md` §2 (mirrored clarification), `level-2/grading/calibration-process.md` (new case #8, a new "if calibration fails" bullet, a new running-calibration check), `level-2/templates/T03-refund-request-handling.md` and `T04-order-fulfillment-reliability.md` (cap level now stated explicitly in the guardrail-trap-candidate note), and all four `level-2/grading/calibration-runs/T0{1,2,3,4}-calibration-run.md` files (a new "Calibration Run #2 — post-split re-validation" section each).

**What this does not touch:** no template's trap, ambiguity, or stress-point content changed; no dimension's base anchors changed; the total score stays 0–20. This is a grading-consistency clarification discovered by deliberately re-checking the split against real (simulated) code, not a further restructuring of the rubric.

**Not yet done:** none of this — the split, or this addendum's cap-level clarification — has been exercised against an actual calibration set, since that set still hasn't been built (`level-2/grading/calibration-process.md`). Case #8 is designed into the calibration-set spec ahead of that step, the same way the split was; both remain unvalidated by a real grading run until calibration itself happens. The outstanding step-4 timed human builds for all four templates (T01 first) are also untouched by this addendum.

### Addendum 18 — Correction to Addendum 17: "gated decision, ungated parameter" resolved as cap-2, not cap-1

**Trigger:** Addendum 17 resolved T03's guardrail finding (a real, correctly-failing-closed eligibility check, but an unverified action parameter) as Dimension 2 cap-1 ("no gate at all"). Flagged to the user as a genuine judgment call this session made unilaterally, with no human sign-off, as part of the same peer-review pass that produced Addendum 17. Asked for a decision; the answer was cap-2.

**Correction:** T03's finding (and the structurally identical "checks something real, not the actual risk" half of T04's dual finding) is now resolved as **cap-2** ("guardrail exists in name only"), not cap-1. Reasoning, as confirmed: T03's eligibility check is genuine and correctly fails closed — that's a real, working check, not an absent or defeated one. Cap-1 is reserved for a guardrail that's actually defeated or missing, like T01/T02's compounding bug, where a failure-masked result silently reads as a genuine, high-confidence one. T03's gate isn't defeated; it's incomplete in scope. This also has a side benefit Addendum 17 didn't have: it now puts T03's finding and T04's "checks availability/value but not dispatch-safety" finding at the *same* cap severity, rather than two similar-looking findings landing at different numbers for reasons that weren't obviously principled.

**What this touches:** `level-2/rubric.md` §2, `level-2/grading/grading-prompt.md` §2, `level-2/grading/calibration-process.md` (case #8, its "if calibration fails" bullet, its running-calibration check), `level-2/templates/T03-refund-request-handling.md` (both the guardrail-trap-candidate note and the Calibration section pointer), and `level-2/grading/calibration-runs/T03-calibration-run.md`'s Run #2 section — all changed from cap-1 to cap-2 for this specific finding. T04's files are unaffected: T04's overall Dimension 2 cap stays at 1, because that's driven by the separate, unrelated `item.get("price", 0)` permissive-default finding (still correctly cap-1), not by the dispatch-safety-awareness gap (which was already cap-2 and remains so).

**Why this is recorded as its own addendum rather than an edit to Addendum 17:** consistent with how Addendum 16 treated Addenda 1–15 — a past addendum is an accurate record of the reasoning at the time, not a live-updated reference. Addendum 17's cap-1 call was a genuine, reasoned judgment call, flagged honestly as needing sign-off, and then corrected once a human weighed in. That's worth preserving as its own record, not silently overwritten.

**Not yet done:** like Addendum 17, this correction is still unvalidated against a real calibration set or a live AI assistant — it's a second hand-derived judgment call layered on the first, now with human confirmation on the specific severity level, but still not empirically tested.

## Addendum 19 — Two plain-language companion documents added: `rubric.html` and `presentation.html`

**Trigger:** the rubric and the overall Level 2 design are both dense, technical markdown documents — fine for whoever is building this, harder to hand to someone (a non-technical reviewer, a manager) who just needs to understand how scoring or the whole system works without reading the source docs.

**What was added:**
- **`level-2/rubric.html`** — a plain-language HTML mirror of `level-2/rubric.md`: same 5 dimensions, same behavioral anchors, same capping rules, restated for a non-technical reader. Meant to stay in sync with `rubric.md` — it was already caught drifting once (missing the "worse cap governs" rule from Addenda 17–18) and corrected; any future rubric change should be checked against this file too.
- **`level-2/presentation.html`** — a short, manager-facing slide deck (~2 minute read) explaining the whole Level 2 design end to end: why the assessment exists, the template → instance generation approach, the four locked ingredients of every use case (ambiguity, AI trap, stress point, the mandatory agentic/guardrail shape), where the testing categories were sanity-checked against outside benchmarks, the rubric and its model-agnostic grading philosophy (engineering judgment is scored, not raw AI-output accuracy or which model was used), the QC/calibration steps taken before anything ships, and an appendix showing both a fictional sample scorecard and a real graded result from an actual internal test build.

**Why HTML, not more markdown:** both documents are meant to be opened and read directly by someone who isn't going to clone the repo or navigate a docs folder — a single self-contained file that renders in any browser fits that better than another `.md` file.

**Maintenance note:** neither file is auto-generated from its markdown counterpart — both were hand-authored and have already needed at least one correction each to stay accurate (rubric.html's cap-rule drift; presentation.html's funnel-arithmetic and missing-4th-ingredient errors, caught by an independent peer review — see the generator agent's own coverage-check fix from that same review). Whoever edits `rubric.md` or the core design docs going forward should re-check both HTML files rather than assume they'll stay current on their own.

## Addendum 20 — Ambiguity and guardrail count doubled (1 → 2 each), triggered by how easily a rushed test build still scored non-trivially

**Trigger:** to sanity-check the whole pipeline, the user built and submitted a solution to the T01 harder instance themselves — using Gemini Pro, not Claude, in about 15 minutes, nowhere near the real 24–48hr window. It scored **9/20**. The grading correctly caught the real problems (a billing-verification tool broken by a column-name mismatch that silently defaulted to "$0 discrepancy" every time; no real LLM call anywhere, a rule-based mock standing in for it; a "pull more context" tool call that never actually changed the outcome; no tests). The grading pipeline worked exactly as designed. But the user's reaction was that the *bar itself* — one ambiguity, one guardrailed action — wasn't demanding enough for what this assessment needs to filter for, independent of whether any given submission passes or fails it.

**Options considered (asked directly, user picked from this list):**
1. Make the existing "harder" variant (2 ambiguities, 2 independently-guardrailed actions — previously an opt-in stacked/parallel-timing track, see the harder-set README files) the standing default for all future instances, not an optional extra.
2. Raise the absolute score cutoff for reaching human review — a pure grading-policy lever, no template changes, since no cutoff number has actually been set yet (`level-2/grading/cutoff-and-aggregation.md` only ever specified the *mechanism*, with an illustrative, non-binding example number).
3. Deepen the AI-trap/guardrail compounding — require the naive-build "missing/failed field defaults permissive" failure pattern (already confirmed 3 of 4 times across T01/T02/T04's calibration runs) to be independently plantable and verifiable on **both** guardrailed actions, not concentrated on just the first.
4. Shrink the 24–48hr build window — considered and explicitly rejected: the 15-minute test build already showed fundamental gaps with *no* time pressure at all, so less time would make a rushed, sloppy submission noisier to grade, not more discriminating.
5. Add a 5th mandatory ambiguity/trap axis, or a 3rd stacked action — flagged as a further lever to revisit later, not decided in this addendum.

**Decision: apply options 1 and 3 together, defer option 5, table option 2 for a separate decision.** Every template now requires two ambiguity slots (each independently scored, worse of the two governs — not averaged) and two independently-guardrailed consequential actions (each with its own reference dataset and its own verified compounding-failure risk, worse cap across both guardrails governs). This is a genuine strengthening of what's mandatory, not a rename of the existing harder-set folders.

**What this touches:** `.claude/agents/level2-use-case-generator.md` (the non-negotiable shape, the "harder variant" section folded in as the historical baseline), `.claude/agents/level2-use-case-evaluator.md` (Dimension 3 and Dimension 2's scoring procedure updated for two ambiguities/two guardrails), `level-2/rubric.md` §2/§3, `level-2/testing-principles.md` categories 2/12 and the "How this feeds template authoring" section, and `level-2/generator/architecture.md` (the Layer 1 template definition and a new note explaining the T01/T02 rework history above it now describes the superseded single-guardrail shape).

**Update — per-template authoring is done, and all 4 templates now have a Calibration Run #3 dry-run for their second guardrail.** The second ambiguity and second guardrail (mechanism, second reference dataset, and a drafted compounding-failure risk) have since been authored into all 4 templates' briefs, each generalized directly from that template's already-built, already-instance-tested "harder" folder rather than invented fresh. `rubric.html` and `presentation.html` have also since been synced to the new 2/2 shape.

**Dry-run results, honestly reported (matching this project's own precedent — not every hypothesis survives contact with a simulated build):** T02 and T03's originally-written compounding-failure guesses reproduced exactly as hypothesized. T01's did not — the guessed mechanism (falling back to the customer's claimed number) never appeared; what actually reproduced was a different, real bug (an omitted lower-bound check on the credit threshold, confirmed directly against T-2005's real $0 discrepancy in the harder-instance dataset), and the template was corrected to describe it. T04's reproduced in a sharper, more specific form than guessed — a cost-only check that skips the stock check entirely, confirmed against a real dataset row (SKU-9008: 0 alt stock, $0.00 shipping cost) that would fool exactly that shape of bug. All 4 templates' compounding-risk notes and calibration-run files now reflect what was actually confirmed, not the original guesses.

**What genuinely remains:** all 4 templates are still "not yet officially calibrated" at this shape, on the same footing as every prior mandatory-shape change in this project (see Addenda 5/6) — a dry-run (hand-simulated reasoning, consistent with how this project's very first calibration runs were done) is not the same as an actual live AI assistant confirming the same behavior, and neither is a substitute for the still-pending timed human build (step 4) for any of the four templates.

**A subsequent independent peer review of this authoring pass found and fixed real drift**, most notably: T03's second-guardrail description referenced a `customer_id`/`count` schema that didn't match the actual `replacement_history.csv` (keyed by `customer_name`, column `replacements_last_30_days`) — corrected to match the real dataset; T03 and T04's AI-trap sections were mislabeled "(dimension 3)" instead of "(dimension 4)" — corrected; and the T02 harder instance's brief.md had drifted from neutral ambiguity phrasing into stating a resolution directly (a spoiler, by this project's own rule) — reverted to the neutral pool wording, matching how T01/T03/T04's harder instances handled the same phrasings correctly.

**Option 2 (raising the cutoff) was discussed but deliberately left for a separate decision** — the user asked to apply options 1 and 3 first and revisit option 5 afterward; option 2 remains available as an independent, zero-template-risk lever whenever a cutoff number is actually chosen.

---

## Addendum 21 — Option 5 revisited: a new "expert" tier, kept fully segregated from the standing 2/2 default

**Trigger:** the user built and ran a solution to the T04 "catering orders" instance through Gemini (see `level-2/generator/gemini-test-instances/T04-catering-orders/`) — the same live-AI-assistant check Addendum 20 flagged as still-pending. It scored 13/20 and the grading caught a real, concrete defect (a rationale claim about permanent-failure handling that didn't match the actual database output). The pipeline worked as designed. But the user's reaction, same shape as Addendum 20's trigger: solved *too quickly* and not challenging enough at the current 2-ambiguity/2-guardrail bar, even before the build-time window (already being cut from 24–48hrs to a flat 24hrs) tightens further.

**This is Addendum 20's deferred option 5, revisited** — but instead of one generic "5th axis," four specific, independently-motivated elements were proposed and all four accepted:

1. **A second, independently-scored AI-trap** — not a repeat of the existing trap's mechanism, planted somewhere else in the pipeline, so a rushed build has two independent chances to ship something unverified instead of one.
2. **Coupling between the two guardrails/ambiguities** — the correct resolution of one judgment call changes what the other guardrail must actually check, so the two can't be solved as independent, bolt-on pieces the way the current shape allows.
3. **Idempotency/retry-safety elevated from a buried trap variant to an explicit, adversarially-tested requirement** — T04's template already had this as one of four *possible* trap variants (variant 1–3 in the existing trap pool); this makes it mandatory, states it openly in the brief, and adds a named review-time test (usually a manual forced-retry check against the candidate's own mocked dispatch service, documented in `INTERNAL-metadata.md`, since there's no real external service a dataset row can script) so a retry is actually confirmed to happen, rather than leaving it as something a coding assistant might simply happen to get right by habit.
4. **Adversarial tool responses** — up to now every template's "stress point" is about messy *input data*; nothing tests whether a submission defends against one of its own tools returning an internally-inconsistent or malformed result. New, not a variant of anything already in any template.

**Decision: build this as a new, fully segregated "expert" tier, calibrated on one template before any further rollout.**

- **Segregation, mirroring the existing `human-build-instances` / `human-build-instances-harder` split:** a new `level-2/generator/human-build-instances-expert/` folder. Nothing in the existing standard or harder tiers is touched — same reasoning as Addendum 6/20's own precedent of not rewriting what's already calibrated out from under itself.
- **Template changes are additive, not edits to the base template.** Each template's expert-tier elements live in a separate companion file (e.g. `level-2/templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`), not inline changes to the base template — so nothing about the standing 2/2 default shape (Addendum 20) is at risk of drifting while the expert tier is designed and dry-run tested.
- **Calibrate on one template first, T04** — chosen because it's the template with a live-AI test result already in hand and the freshest working context, matching this project's own established practice of authoring one reference solution and confirming a shape works before propagating it (see the original Deliverable 1 methodology, and Addendum 20's own T01-first sequencing). T02/T03/T01 get the same treatment only after T04's expert tier is dry-run confirmed.
- **Rubric change is additive, per-dimension, not a new dimension.** All four new elements are graded through the existing 5 dimensions' existing anchors and capping rules, explicitly scoped to expert-tier instances only:
  - The second AI-trap scores under Dimension 4 using the same non-averaging principle Dimension 3 already uses for two ambiguities — score each trap independently, take the lower.
  - Guardrail/ambiguity coupling and the elevated idempotency requirement are new named defect flavors under Dimension 2's existing capping rule (a guardrail computed on a basis inconsistent with an already-resolved, related ambiguity; a consequential action with no protection against being duplicated by a retry). Dimension 3 gets a short cross-reference note only (don't score the coupling itself there — that's Dimension 2's job; Dimension 3 still just grades whether each ambiguity's own resolution is named and justified).
  - Adversarial tool responses are a new stress-point category under Dimension 5, alongside the existing malformed-input-data category.
  - None of this changes how a standard or harder-tier submission is scored — the added language in `rubric.md` is explicitly conditioned on "where an instance's `INTERNAL-metadata.md` states an expert-tier element is in play," the same conditioning pattern multimodal input already uses in Dimension 5.
- **Not yet a standing default**, unlike Addendum 20's 2/2 shape (which only became default after its own live-AI confirmation). The expert tier stays opt-in, dry-run-then-live-tested on T04 alone, until a decision is made to roll it out further — same sequencing discipline as every prior mandatory-shape change in this project.

**What this touches:** `level-2/templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md` (new), `level-2/rubric.md` §2/§3/§4/§5 (additive, expert-tier-conditioned notes), `level-2/testing-principles.md` (new short section naming the four elements), `.claude/agents/level2-use-case-generator.md` and `.claude/agents/level2-use-case-evaluator.md` (both updated to know the expert tier exists, and the generator's spoiler-discipline rule extended to cover the four new elements — never leak which tool is adversarial, never leak the coupling mechanism, never leak the idempotency scenario's specific trigger), and a new calibration instance under `level-2/generator/human-build-instances-expert/`.

**Build-time window:** the user is separately tightening every instance's build window to a flat 24hrs (down from 24–48hrs), independent of this addendum — noted here since it compounds with the expert tier's added difficulty, but it's a scheduling/logistics decision, not a template or rubric change, and applies uniformly rather than only to expert-tier instances.

---

## Addendum 22 — Expert tier: guardrails are no longer stated as a requirement in the brief

**Trigger:** before posing the T04-equipment-rentals expert instance to Gemini, the user suggested removing all reference to a "gate" from the brief — the reasoning being that a genuine expert should recognize, unprompted, that an AI-triggered, real-world, hard-to-reverse action needs a safety check before it fires; stating it outright is coaching the candidate past the exact judgment call worth testing.

**Initial pushback, and why it didn't hold once scoped correctly:** the first concern raised was that dropping this for one instance only would test a materially different skill for whoever draws that instance versus every other candidate, breaking cross-candidate comparability, and that it risked compressing Dimension 2 scores toward the low end across the board, reducing the AI-grading cutoff's discriminating power. The user clarified the intent was never instance-specific — this is a standing rule for the **whole expert tier**, applied consistently to every template that gets one. That resolves the comparability concern (every expert-tier candidate is tested the same way) and reframes the compression concern as an accepted, deliberate consequence of raising the bar, not an accident to avoid — consistent with this whole addendum's and Addendum 21's shared premise that the standing 2/2 shape wasn't challenging enough.

**A related question, resolved along the way:** whether a missing gate should map straight to **0** rather than the current cap-1. Decision: **no** — cap-1 stays. Dimension 2's anchor-0 is reserved for "not genuinely agentic at all" (no real loop, tools never actually called), a more fundamental failure than an otherwise well-built agent that fails to gate one action. Collapsing both to 0 would erase the signal a human reviewer actually wants — whether the rest of the build (loop, tools, reconciliation) was competent — and isn't required to make the guardrail-recognition test meaningful; the cap-1 ceiling already prevents a strong build from buying back an ungated action via averaging.

**Decision: strip all guardrail/gating language from expert-tier briefs, fully, not partially.** Two options were on the table — remove only the words "gate"/"gated by an explicit check" while keeping the outcome framing ("for low-risk orders," "escalated to a human"), versus removing that framing entirely and stating only the bare capability ("autonomously dispatch fulfillment via a tool call"). The user chose the full strip: an expert-tier brief describes what the AI can do, never that doing so should be conditioned on risk or checked at all.

**What does NOT change:** the ambiguity phrasing itself (e.g. "Only auto-dispatch low-risk orders") stays — it's the judgment call being tested, not guardrail scaffolding. Only the *added* clauses that turned that ambiguity into an explicit build instruction are removed. See `templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md`'s new "Framing rule" section for the exact before/after wording and the line drawn between the two.

**No rubric change required.** `rubric.md`'s Dimension 2 capping rule already grades from the shipped code alone, regardless of what the brief asked for. What changes is only what a "no gate at all" finding means: previously, evidence of not following an explicit instruction; now, evidence of not recognizing the need unprompted — arguably a more informative signal, not a different one requiring new anchors.

**What this touches:** `templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md` (new "Framing rule" section, to carry into every future template's expert tier), `generator/human-build-instances-expert/T04-equipment-rentals/brief.md` (steps 6/7 and the `MANIFEST.md` pointer reworded to the full-strip form), and that instance's `INTERNAL-metadata.md` (updated to name "no gate built at all" as the more likely failure mode now in play, ahead of the subtler guardrail-quality bugs it previously focused on exclusively). The reference solution's own correctness is unaffected — it already builds real guardrails as a matter of good engineering, independent of whether the brief asked for them.

## Addendum 23 — a fifth expert-tier element (retry-safety-vs-stale-data collision), elevated from instance-only to a standing element after an independent peer review flagged it had no footprint outside T04-equipment-rentals

**Trigger:** while exploring ways to make expert-tier briefs harder for an AI coding assistant to solve cleanly (including options that could make an assistant loop or thrash, not just produce a subtly-wrong default), a specific pattern was identified and wired directly into the T04-equipment-rentals instance: pair the existing idempotency sentence (element 3) with a second, independently-reasonable-looking requirement — "always re-confirm current stock before dispatching" — that conflicts with it specifically on the retry-after-lost-response path. The correct resolution: a freshness/robustness check applies only to a genuinely new dispatch decision, never to an idempotency-cache-hit, since a cache hit isn't a new decision at all. This was added to that one instance's `brief.md`, `INTERNAL-metadata.md`, reference solution (`dispatch_client.py`, ordered so the cache check runs before the stock check), `verify.py` (new passing check, 13/13 total), and `README.md` — but, at that point, nowhere else.

**What the peer review found:** a subsequent independent peer review of the whole expert-tier body of work (design-rationale addenda, the template addendum, the rubric, testing-principles, both `.claude/agents/level2-use-case-*.md` files, and the T04-equipment-rentals instance itself) flagged this as a real gap, not a false alarm: every other addition in this project's history got a design-rationale addendum, a rubric note, a testing-principles entry, and agent-file awareness — this one had none of that. A future reviewer or template author working only from the standing docs (not this one instance's files) would have no way to know this element exists or how to score it.

**Decision, asked directly and confirmed: elevate this from an instance-only addition to a standing, fifth expert-tier element** — applicable to every future template's expert tier, the same footing as elements 1-4 from Addendum 21, not scoped to T04-equipment-rentals alone.

**What changed to reflect that:**
- `level-2/templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md` gained a new "Expert element 5" section (mechanism, what "caught" looks like, how to test it, grading treatment, dataset requirement — same structure as elements 1-4), and its header/cross-reference/spoiler-discipline sections were updated from "four elements" to "five elements."
- `level-2/rubric.md` Dimension 2's expert-tier note gained a third bullet for this element (same cap-1 severity as the plain idempotency case), and Dimension 4's expert-tier note gained a cross-reference clarifying this is not a third Dimension-4 trap — it's graded entirely under Dimension 2, the same way Dimension 3 already cross-references the coupling element (2) back to Dimension 2.
- `level-2/testing-principles.md`'s expert-tier section gained a fifth numbered element, added after the original four rather than renumbering them, with a note that it was added later once T04's other elements were already working.
- `.claude/agents/level2-use-case-generator.md` and `.claude/agents/level2-use-case-evaluator.md` both gained the fifth element in their expert-tier sections, including the spoiler-discipline rule that elements 3 and 5 are both stated as bare requirements in the brief but must never be hinted at as related to each other — the same discipline already applied to element 2's coupling.

**Also fixed in the same pass:** `generator/human-build-instances-expert/T04-equipment-rentals/INTERNAL-metadata.md`'s header still read "Status: not yet calibrated... no reference solution yet, no dry-run" — stale, since both existed by that point. Corrected to match the accurate status already recorded in that instance's own `T04-equipment-rentals-dryrun.md`.

**Not yet done:** like elements 1-4, this fifth element is confirmed only by a hand-authored reference solution and a passing `verify.py` — it has not yet been posed to a live AI assistant or exercised in a timed human build. The same outstanding calibration steps noted in Addendum 21 apply to element 5 as well.

## Addendum 24 — "no safe default" as a standing construction rule for expert-tier judgment calls

**Trigger:** reviewing the T04-equipment-rentals expert brief's dispatch-reliability paragraph raised a question about whether stacking several fully-explicit requirement sentences was over-clarifying — spoon-feeding an expert candidate rather than testing them. Working through it surfaced that the sentences in question (idempotency, the stale-stock collision) are deliberately explicit by design (elements 3 and 5 — their difficulty lives entirely in the *collision*, not in parsing the English), so softening them would just swap an engineering-judgment test for a reading-comprehension one. But the exercise also surfaced a real, separate gap: the two **base-template open judgment calls** (back-order policy, "low-risk" threshold) — present at every tier, not just expert — are comparatively soft even at expert tier. Nothing in the dataset currently guarantees that picking an unreasoned default ever produces a visibly wrong outcome; a candidate (or the LLM writing their code) can silently pick any answer and never be shown to be wrong.

**The underlying goal, and what's actually achievable:** the ask that prompted this was to make an AI coding assistant "get confused" and defer a design decision back to the developer, rather than resolving it autonomously. That specific mechanism isn't reliably buildable or checkable — different LLMs (including the in-house ones this assessment targets) don't react identically to ambiguous prompts, some will confidently guess regardless of wording, and this project has no interaction log to confirm whether an assistant asked a question even if it did (Addenda 3/4/8 — static-only grading, no log, no commit history). Trying to engineer "the LLM asks a question" is unverifiable by construction.

**The buildable version: remove the safe default, not the LLM's confidence.** If a judgment call has one interpretation that's obviously reasonable and nothing in the data ever contradicts it, an LLM (and a rushed candidate) will pick it and move on — no decision is ever visibly made. If instead the dataset contains at least one concrete case where two independently-defensible resolutions produce **different outcomes**, no implementation can satisfy both by accident — whichever way it's built, that's a real, attributable choice, checkable against the specific case rather than against generic policy prose. This is the same mechanism elements 1 (two ambiguous catalog matches, no default match is "just correct") and 5 (idempotency vs. stale-stock, no code satisfies both readings on the retry path) already use — this addendum generalizes it explicitly to the two base judgment calls, for expert-tier instances only.

**Decision: at expert tier, each of the two base-template ambiguities must include at least one dataset row where the plausible resolutions diverge in outcome** — not just a stated ambiguity with no teeth. This is a **construction rule for existing ambiguity elements**, not a sixth expert-tier element and not a new rubric dimension — it strengthens how elements that already exist (the two base ambiguities, at expert tier) get built and graded, the same way Addendum 22 added a standing rule ("no gate language") without adding a numbered element.

**Concrete example, T04-equipment-rentals' "low-risk" judgment call:** currently has no dataset teeth (`INTERNAL-metadata.md`: *"this instance doesn't have a dedicated order testing that specific bias"*). Adding one order priced above whatever dollar threshold a candidate would plausibly pick, but flagged as a repeat/trusted customer, would force an explicit choice between a threshold-only rule and a trust-inclusive one — an LLM asked to "auto-dispatch low-risk orders" will default to whichever axis is most concrete in the data (the dollar figure) and never surface trust as a live variable unless a human notices the tension.

**What changed to reflect this:**
- `level-2/templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md` gained a new construction-rule section (placed alongside Addendum 22's framing rule, before the numbered elements), naming this requirement and giving the worked example above.
- `level-2/rubric.md` Dimension 3's expert-tier note gained a clause: at expert tier, anchor 0/1 findings should be checkable against a specific dataset row, not just "no rationale paragraph exists" — grading has firmer footing when a candidate's chosen default demonstrably gets a specific case wrong.
- `level-2/testing-principles.md`'s expert-tier section gained this as a standing note, following the same pattern as Addendum 22's inline callout.
- `.claude/agents/level2-use-case-generator.md` gained an explicit construction instruction, and a spoiler-discipline reminder that the divergent data point must be planted silently (an ordinary-looking row), never flagged or commented on in the brief or dataset.
- `.claude/agents/level2-use-case-evaluator.md` gained a grading note under Dimension 3's expert-tier guidance.

**Scoping:** applies only to expert-tier instances going forward. Existing expert-tier instances (T04-equipment-rentals) are not required to retrofit this immediately — the example above is a proposed follow-up, not yet applied to that instance's actual dataset.

**Not yet done:** no instance has yet had this construction rule applied to its actual dataset — this addendum establishes the standing principle only.

## Addendum 25 — `INTERNAL-metadata.md` house style corrected: plain text at every tier, expert included

**Trigger:** reviewing T04-equipment-rentals' regenerated `INTERNAL-metadata.md`, the user noticed it no longer read like the plain-text cheat sheet every other instance's internal notes use (e.g. `generator/human-build-instances/T04-spare-parts-orders/INTERNAL-metadata.md`) — it had drifted into the same labeled-subsection style (`**How to actually test this:**`, `**What "caught" looks like:**`, `**Grading treatment:**`, repeated per element) that the standing `-EXPERT-ADDENDUM.md`/`rubric.md` specification documents use.

**Cause:** that labeled style is correct in the standing docs, which are specifications meant to be cross-referenced precisely. It was carried over near-verbatim into the instance-level file instead of being translated back into the project's established plain-prose convention — and it compounds badly once an expert-tier instance has 5+ elements each wanting their own labeled block, which standard-tier instances (2-4 short items) never had to contend with.

**Fix:** `T04-equipment-rentals/INTERNAL-metadata.md` rewritten in the plain style (numbered "what's tricky" list, minimal bold, closing checklist) — same content, no labeled scaffolding. A standing house-style note was added to `.claude/agents/level2-use-case-generator.md`'s "Style notes" section, naming the failure pattern explicitly and pointing at the T04-spare-parts-orders file as the reference example, so future expert-tier instances don't drift the same way. `T01-it-helpdesk/INTERNAL-metadata.md` (Addendum 26, below) was authored in the plain style from the start as a direct result.

## Addendum 26 — expert tier extended to a second template (T01), applying Addendum 24's construction rule from the start

**Trigger:** with T04's expert tier calibrated (reference solution + `verify.py`), the next step was confirming the whole expert-tier design (elements 1-5, the no-gate-language rule, and the no-safe-default construction rule) actually generalizes to a different scenario shape, not just T04's dispatch/reliability pipeline. T01 (triage & classification) was chosen first, one template at a time, per the user's explicit sequencing choice — full spec + full instance before moving to T02/T03.

**What was authored:** `templates/T01-triage-classification-EXPERT-ADDENDUM.md` (mirroring T04's file structure — framing rule, construction rule, five elements, rubric cross-reference, spoiler-discipline note, each translated into T01's classify → dedup/context-lookup → auto-act/courtesy-resolution shape) and a full instance, `generator/human-build-instances-expert/T01-it-helpdesk/` (brief, `INTERNAL-metadata.md` — written in the plain house style from the start, per Addendum 25 — dataset, reference solution, `verify.py` passing 14/14).

**How the five elements mapped onto T01:**
1. Second AI-trap → an ambiguous duplicate-ticket match (two prior tickets, one resolved and one still open, both plausible matches with different implications) — the direct analog of T04's two-catalog-items trap.
2. Guardrail/ambiguity coupling → the "immediate attention" ambiguity's resolution must reach the auto-acknowledge guardrail, so a ticket with a real deadline signal can't sail through on classification confidence alone.
3/5. Idempotency + stale-data collision → moved onto this template's own consequential, retryable action (the courtesy-resolution call), same mechanism and same correct resolution (cache-hit check runs first) as T04's dispatch call.
4. Adversarial tool response → the billing-record check tool returns an invalid (negative) verified discrepancy for one account.

**How Addendum 24's construction rule mapped onto T01's two base ambiguities:** the "immediate attention" ambiguity got a trust/tier-style divergence pair (a VIP requester's trivial request vs. a regular requester's genuinely severe request) — same shape as T04's low-risk/client_type pair, not a right-answer trap, testing whether the resolution is deliberate and consistent rather than an artifact of the LLM's own read of status language. The "route to the right team" ambiguity got a genuinely-spans-two-categories case (a VPN lockout that's also a plausible account-compromise signal) instead — no single keyword-priority rule handles it, so this one *is* closer to an objectively-resolvable case, more like T04's back-order composition trap than its trust trap. Both patterns from Addendum 24 turned out to be reusable, just not always mapped onto the same ambiguity slot.

**Standing docs updated:** `rubric.md` and `testing-principles.md`'s "currently T04 only" language corrected to name both templates; both stay otherwise unchanged since Addendum 21/23/24's notes were already written to generalize across templates, not naming T04 specifically in the anchors themselves.

**Not yet done:** same as T04 — not yet posed to a live AI assistant, no timed human build. T02 and T03 are next, one at a time, per the same process.

## Addendum 27 — Expert tier: the base template's stress-point sentence is no longer stated in the brief

**Trigger:** peer-reviewing T01's expert instance against T04's for complexity parity, the user flagged the brief's stress-point sentence directly — *"The dataset includes some requests with blank body text — your solution should handle these sensibly rather than crashing or producing silently wrong output."* An expert candidate should notice a blank row in their own seed data without being told it's there.

**Cause:** this sentence isn't instance-specific text — it's the base template's own `{{stress_point_description}}` placeholder (`level-2/templates/T04-order-fulfillment-reliability.md` and the T01 equivalent), stated at every tier including expert. Addendum 22 already removed the equivalent guardrail-existence scaffolding ("gated by an explicit check," "escalated to a human") from expert-tier briefs for exactly this reason — naming the thing being tested defeats the test. This same reasoning was never applied to the base template's *other* piece of explicit scaffolding, the stress-point sentence, so it slipped through the T04 regeneration and into T01 unchanged. The generator agent's own pre-publish check ("does this tell the candidate the answer to the thing I'm trying to measure?") should have caught this but wasn't applied to this specific sentence.

**Decision: at expert tier only, drop the base template's stress-point sentence from the brief entirely.** The stress point itself (a blank/malformed row, a permanently-zero-stock item) stays in the dataset — an expert candidate is expected to find it by looking at their own data, the same way they're expected to find the ambiguities and traps without being pointed at them. Standard and harder tiers are unchanged: that sentence remains deliberate, stated scaffolding there, consistent with those tiers still stating the guardrails openly too.

**Scoring implication: none.** The rubric already grades Dimension 5 (production readiness) from what the shipped code actually does with the stress-point row, regardless of whether the brief announced it — same reasoning as Addendum 22's "no rubric change needed" note. What changes is only the brief's wording, and therefore what a "mishandled it" finding reveals: previously it could mean "didn't build a good-enough check despite being told exactly what to check for"; now it means "didn't notice the edge case in their own data at all" — a stronger signal, same as Addendum 22 predicted for the guardrail scaffolding.

**What changed to reflect this:**
- `level-2/templates/T04-order-fulfillment-reliability-EXPERT-ADDENDUM.md` and `level-2/templates/T01-triage-classification-EXPERT-ADDENDUM.md` both gained a new framing-rule paragraph (alongside Addendum 22's), naming this rule.
- `.claude/agents/level2-use-case-generator.md` gained an explicit instruction under the expert-tier framing rules: omit the base template's stress-point sentence entirely for expert-tier instances.
- `generator/human-build-instances-expert/T04-equipment-rentals/brief.md` and `generator/human-build-instances-expert/T01-it-helpdesk/brief.md` both had the sentence removed.

**Scoping:** applies only to expert-tier instances. T02 and T03's expert tiers, not yet built, should never have this sentence in the first place.

## Addendum 28 — expert tier extended to a third template (T02), built with Addendum 27's stress-point framing rule from the start

**Trigger:** with T01's expert tier calibrated and peer-reviewed against T04, the next step in the "one template at a time" sequence was T02 (structured extraction). The user approved reusing T02's existing "commercial loan agreements" domain flavor (already used at the standard tier) for the expert instance as well, rather than requiring a third distinct flavor — domain novelty wasn't the point of this exercise, the tier's construction was.

**What was authored:** `templates/T02-structured-extraction-EXPERT-ADDENDUM.md` (mirroring T04/T01's structure — both framing rules, the construction rule, five elements, rubric cross-reference, spoiler-discipline note, translated into T02's extract → verify/lookup → auto-commit/status-gated-follow-up shape) and a full instance, `generator/human-build-instances-expert/T02-loan-agreements/` (brief, `INTERNAL-metadata.md` in the plain house style, 11 primary loan documents plus 3 referenced promissory-note documents, a second status-registry dataset, reference solution, `verify.py` passing 25/25).

**How the five elements mapped onto T02:**
1. Second AI-trap → an ambiguous cross-document reference: a borrower with two promissory notes on file (an original and a later amended-and-restated one), and a loan agreement whose maturity-date clause points at "the Promissory Note" without specifying which.
2. Guardrail/ambiguity coupling → that same ambiguous field must actually withhold the auto-commit guardrail, not just surface as a cosmetic review-UI flag while the record still gets written.
3/5. Idempotency + stale-data collision → moved onto this template's own consequential, retryable action (status-gated follow-up-record generation, the base template's "second guardrail"), same mechanism and same correct resolution (idempotency-cache check runs first, before any status re-check) as T04's dispatch call and T01's courtesy-resolution.
4. Adversarial tool response → `verify_against_source` reports a field as grounded with a high confidence score but no actual matched text backing the claim — an internally inconsistent tool response, not a hallucinated extraction.

**How Addendum 24's construction rule mapped onto T02's two base ambiguities:** the party-name-normalization ambiguity (extract `borrower_name`) got a no-right-answer divergence pair — a document naming its borrower one way in the recitals and a different, equally legitimate way in its own signature block, same shape as T04's client_type pair and T01's requester_tier pair. The relative-date-resolution ambiguity (extract `maturity_date`) got the objectively-resolvable flavor instead — one document whose relative date resolves entirely within the same text (no lookup needed) and one that genuinely requires the `lookup_related_document` tool, so a single fixed rule ("always look up" or "never look up") gets one of the two wrong. Same two flavors as T01, just distributed onto T02's two extraction-field ambiguities rather than a policy-threshold ambiguity — T02's base template doesn't have a back-order/immediate-attention-style policy ambiguity to draw on, so both of Addendum 24's patterns landed directly on the field-mapping ambiguities instead.

**Built with Addendum 27 from the start:** unlike T04 and T01 (which had the base template's stress-point sentence written in, then removed after the peer review that produced Addendum 27), T02's brief never stated the stress-point sentence (concatenated multi-document files) to begin with — the seed data still contains one (`LN-7006-7007.txt`), just never announced.

**Standing docs updated:** `rubric.md` and `testing-principles.md`'s "currently T04 and T01" language corrected to name all three templates.

**Not yet done:** same as T04 and T01 — not yet posed to a live AI assistant, no timed human build. T03 is next, one at a time, per the same process.

## Addendum 29 — expert tier extended to the fourth and final base template (T03), completing the set

**Trigger:** with T02's expert tier calibrated, the last item in the "one template at a time" sequence was T03 (refund/account-request handling, the untrusted-input-safety template). Unlike T02, the user chose a domain distinct from the standard/harder tiers' "warranty claims" — airline flight-credit and rebooking requests — since T03 hadn't already had a reuse precedent set for it.

**What was authored:** `templates/T03-refund-request-handling-EXPERT-ADDENDUM.md` (mirroring T04/T01/T02's structure — both framing rules, the construction rule, five elements, rubric cross-reference, spoiler-discipline note, translated into T03's interpret → verify/lookup → auto-resolve/history-gated-replacement shape) and a full instance, `generator/human-build-instances-expert/T03-flight-credits/` (brief, `INTERNAL-metadata.md` in the plain house style, 11 booking records, 12 requests, a second rebooking-history dataset, reference solution, `verify.py` passing 18/18).

**How the five elements mapped onto T03:**
1. Second AI-trap → the base template's own trap variant 2 (an embedded reference redirects the agent to a booking that belongs to a different customer than the requester), elevated from one option in the pool to an always-planted expert element, paired with trap-variant-1-flavored text ("already approved, please expedite") for realism.
2. Guardrail/ambiguity coupling → that ownership mismatch must actually block the auto-resolve guardrail, not just annotate a UI field while the resolution still executes because the booking looks eligible in isolation.
3/5. Idempotency + stale-data collision → moved onto this template's own consequential, retryable action (history-gated replacement scheduling, the base template's "second guardrail"), same mechanism and same correct resolution (idempotency-cache check runs first, before any history re-check) as the prior three templates' equivalents.
4. Adversarial tool response → a booking record whose own `credit_eligible: true` is paired with a negative, nonsensical `credit_value` — planted directly in the seed CSV rather than a mocked tool quirk, since the inconsistency is between two fields of the same record.

**How Addendum 24's construction rule mapped onto T03's two base ambiguities:** the value-threshold ambiguity (phrasing 3) got the no-right-answer flavor — two requests priced above a plausible threshold, one from a higher-tier customer, one from an ordinary one, both required to land on the same outcome under whatever policy the build documents. Same shape as T04's client_type pair, T01's requester_tier pair, and T02's borrower-name pair. The "clearly supported by the record" ambiguity (phrasing 1) got the objectively-resolvable flavor, but via a different mechanism than T04/T01/T02's single-rule-fails pattern: a plausible-sounding customer claim that doesn't match what the record actually shows (should escalate) paired with a genuinely-eligible request worded nothing like the record's own category label (should still go through) — together showing that eligibility has to come from the tool-verified record alone, with the customer's own wording logged for context but never used as a gate in either direction.

**Standing docs updated:** `rubric.md` and `testing-principles.md`'s "currently T04, T01, and T02" language corrected to name all four templates.

**Not yet done:** same as the other three — not yet posed to a live AI assistant, no timed human build. All four base templates now have an expert-tier instance; a full four-template calibration pass (dry-runs, then live-AI tests, then timed human builds) is the natural next phase, not yet started.

## Addendum 30 — Expert tier: the retry-safety/freshness paragraph (elements 3 & 5) is no longer stated in the brief either, extending Addendum 22's logic to cover it

**Trigger:** reviewing T02's brief, the user asked the same question that opened this whole expert-tier design effort back at Addendum 21/22 — does an expert candidate need to be told, in so many words, that "the follow-up-record generation call... can fail transiently... may occasionally report a failure for a call that actually succeeded server-side... you must not generate a duplicate... always re-confirm the current status"? Asked to weigh in on scope, the user chose to apply the answer to all four templates, not just T02, to keep the expert-tier briefs internally consistent.

**Why this was different from every other spoiler-discipline decision until now, and why that turns out not to hold up:** elements 3 and 5 were the sole exception to the project's otherwise-universal rule that expert-tier elements are never hinted at in the brief. The original justification (Addendum 23) was practical, not principled: an independent peer review found the retry-safety collision had "no footprint outside T04-equipment-rentals" unless candidates were told the call was unreliable in the first place — without that sentence, most submissions might never attempt retry logic at all, and the collision would go untested across the board. That's a real calibration concern, but it's the same shape of argument Addendum 22 explicitly rejected for the guardrail-gate requirement: "telling every candidate that an AI-triggered, real-world, hard-to-reverse action needs a safety check is coaching them past the single most important judgment call in the whole assessment... recognizing that unprompted is a stronger signal than any planted ambiguity." An expert candidate who doesn't independently think to build idempotent, retry-safe handling for a real external service call is missing the same kind of foundational judgment Addendum 22 already treats as disqualifying when it comes to gating a risky action at all. There was never a principled reason elements 3 and 5 should be exempt from that same logic — only a testability worry, and that worry is answered the same way Addendum 22 already answered it for the guardrails: accept that scores compress lower, because the compression itself is the signal, not a defect in the instrument.

**Decision: drop the retry-safety/freshness paragraph from all four expert-tier briefs.** The brief now states only the bare capability for the second guardrail's action (e.g. *"Separately, autonomously generate a follow-up record via a tool call when [condition]. This is a second, independent autonomous action from step 6."*) — nothing about transient/permanent failure modes, nothing about duplicate risk, nothing about re-confirming stale data. Elements 3 and 5 join elements 1, 2, and 4 as fully unhinted — the brief no longer says anything a candidate wouldn't already know is at stake merely from being told to "autonomously call a tool."

**What does NOT change:** the underlying mechanism, the review-time double-invoke procedure in each `INTERNAL-metadata.md`, and the Dimension 2 capping severity (cap 1 if a retry can duplicate the action or a stale re-check can change an already-decided outcome) are all unchanged — this is purely a brief-wording change, identical in kind to Addendum 22's.

**Scoring implication — same as Addendum 22's:** no rubric change needed. `rubric.md`'s existing capping rule already grades from the shipped code regardless of what the brief asked for. Expect Dimension 2 scores to compress further as a result, especially since two separate unhinted requirements (the guardrail gate, and now retry-safety) now stack — this is intended, and arguably the point of the expert tier: distinguishing candidates who build defensively by default from those who only build what's explicitly asked for.

**What changed to reflect this:**
- All four `*-EXPERT-ADDENDUM.md` files' "Expert element 3" section: removed the "state the requirement openly in the brief" instruction and its example sentence; kept the review-time double-invoke procedure (still `INTERNAL-metadata.md`-only) and the Dimension 2 cap-1 grading treatment unchanged.
- Each file's spoiler-discipline note: removed the carve-out that previously named elements 3 and 5 as the two elements stated as bare requirements — all five elements are now uniformly unhinted.
- `.claude/agents/level2-use-case-generator.md`: the general "Expert element 3" instruction updated the same way, for T02/T03's already-built instances and any future template.
- All four live briefs (`T04-equipment-rentals`, `T01-it-helpdesk`, `T02-loan-agreements`, `T03-flight-credits`) had their retry-safety/freshness paragraph removed, leaving only the bare second-guardrail capability sentence.
- Each instance's `INTERNAL-metadata.md` had the relevant "what's tricky" item reworded from "spelled out in the brief, and it's actually tested" to "never mentioned in the brief — this is a purely unprompted signal, the same way the guardrail-gate requirement itself is."

**Honest caveat:** the T04 (Gemini), T01 (human submission at `D:\PyPrograms\T01-IT Hepdesk`), and T02 (Gemini) submissions already scored in this project were built and graded against the **old** wording, which did state this paragraph openly. Their scorecards are not retroactively affected or re-scored — this change applies to briefs issued from this point forward, including any resubmission or new candidate against these instances.

**Update, 2026-09-14 — validated, 4/4.** See Addendum 32: every one of the four templates' live-AI dry runs shipped zero idempotency protection on its consequential retry-vulnerable action, unprompted. The hypothesis holds uniformly, not just for T04.

## Addendum 31 — Expert tier: the brief no longer states that the two guardrails are independent actions; this is now a real, dataset-backed construction requirement rather than stated fact

**Trigger:** reviewing T02's brief again after Addendum 30, the user asked the same question one level further in — is "This is a second, independent autonomous action from step 6" itself spoon-feeding an expert candidate?

**Why this one needed more care than Addendum 30's change:** the retry-safety paragraph stated the answer to a fixed, well-defined requirement — removing it just makes recognizing the need unprompted part of the signal, but "correct" never changes. This sentence is different: without it, a candidate could reasonably read the second guardrail's action as *chained* off the first ("only send a maturity follow-up for a loan I actually managed to commit") rather than independently triggered. That's not obviously wrong — it's a real, defensible design choice. Simply deleting the sentence would create an ambiguity with no dataset row able to tell a considered decision apart from an accident, which is exactly the gap Addendum 24 exists to close for the base template's own ambiguities. So this couldn't be handled by deletion alone the way Addendum 30's change was.

**Decision:** drop the sentence from all four expert-tier briefs, scoped to expert tier only (standard/harder tiers keep it as deliberate scaffolding, unchanged) — **and** require, as a standing construction rule, that each expert-tier instance's dataset include at least one record that fails/escalates the **first** guardrail but should still be independently evaluated (and clear) the **second** guardrail. This makes "did the submission wrongly couple the two actions" a checkable finding instead of an unscored guess.

**How this landed per template, since not every template's two guardrails have the same shape:**
- **T01 (it-helpdesk):** guardrail 1 (auto-route/close) and guardrail 2 (courtesy resolution) were already structurally disjoint by category in the reference solution — a Licensing & Reimbursement ticket never touches the routing guardrail at all. The real risk here is a naive build gating courtesy-resolution on *other* per-ticket signals (urgency, an ambiguous-duplicate flag) that have nothing to do with billing verification. Added **HD-3060** (Owen Castellan) — a Licensing & Reimbursement ticket that also reads as urgent ("ASAP") — to confirm courtesy resolution still fires correctly despite the urgency flag, since urgency has no bearing on whether a billing discrepancy is real.
- **T02 (loan-agreements):** already had a naturally-occurring case — **LN-7005** (missing interest_rate, fails the commit guardrail) has a cleanly-resolved local maturity date and an "active" verified status. No new dataset row was needed; `verify.py` gained a new assertion confirming the maturity-follow-up guardrail evaluates LN-7005 independently of its failed commit.
- **T03 (flight-credits):** added **FR-8013** (Priya Doshi) — a booking priced well above the refund value threshold (would fail guardrail 1 outright if requesting cash back) who instead asks for a straightforward rebooking. Confirms the replacement-scheduling guardrail isn't wrongly gated by the refund guardrail's dollar-value ceiling, since a replacement carries different risk than an autonomous payout.
- **T04 (equipment-rentals):** no change made. T04's two "guardrails" (dispatch, reroute) aren't structurally independent the way the other three templates' are — a rerouted line item still has to be dispatched to actually reach the customer, so reroute functions as an input to the dispatch decision rather than a fully parallel action. Forcing an artificial independent-guardrail test here would misrepresent the domain rather than test anything real; this is noted as a known, accepted asymmetry rather than a gap to fix.

**What changed to reflect this:**
- All four expert-tier briefs: the "independent action from step 6" sentence removed (T04's included, for consistency, even though its test coverage doesn't change).
- All four `-EXPERT-ADDENDUM.md` files: new framing-rule note alongside Addendum 22/27/30's, plus a construction-rule note for the three templates that needed one.
- `.claude/agents/level2-use-case-generator.md`: updated with the same standing rule for future templates.
- `T01-it-helpdesk`'s dataset gained HD-3060 and a matching billing record; `T03-flight-credits`'s dataset gained FR-8013 and a rebooking-history row. Both instances' `reference-solution/verify.py` and `INTERNAL-metadata.md` updated accordingly. `T02-loan-agreements`'s `verify.py` gained a new assertion using existing data, no new rows.

**Scoring implication:** no new rubric dimension. This is graded under the existing element-2-style coupling logic (Dimension 2, cap at 2 if a submission wrongly chains the two actions) — a naive coupling isn't "no gate at all" (a real, if over-scoped, check still exists), so it doesn't warrant the full cap-1 treatment.

**Update, 2026-09-14 — partially validated.** See Addendum 32: T01, T02, and T03's dry runs each confirmed the underlying guardrails genuinely are independent when built naturally (no wrongful chaining observed on HD-3060, LN-7005, or FR-8013). No naive-coupling failure of this specific kind has been observed yet in any of the three dry runs where it was constructionally possible to test — worth keeping in mind that absence of the failure across three runs is a reasonably strong signal, not just an open question anymore.

---

## Addendum 32 — Peer review, 2026-09-14: dry-run calibration pass across all four templates, and what didn't make it back into the review checklists

**Trigger:** the user asked for a peer review of the project's current state, specifically checking whether the findings from each template's live-AI dry run (see each `T0X-*-dryrun.md`) had actually been written back into that instance's `INTERNAL-metadata.md`.

**Finding: none of them had been.** All four dry runs' "what this means for the instance, not just this one build" sections proposed concrete checklist changes; none had been applied before this review — file modification timestamps confirmed every `INTERNAL-metadata.md` was untouched since before its own dry run completed. This addendum records what was found and applied as a result.

**Cross-template pattern confirmed by this pass (see Addendum 30's update above): idempotency failed in all four dry runs, independently and unprompted.** T01 (HD-3020, duplicate courtesy resolution), T02 (LN-7008, duplicate follow-up record), T03 (FR-8010, duplicate rebooking action), T04 (ORD-9003, duplicate dispatch plus a bonus FK-constraint crash on order-level retry) — every naive-but-competent build shipped zero retry protection on its consequential action. This is the strongest cross-template confirmation the project has produced for any single design principle; recorded here centrally rather than left scattered across four separate dry-run files.

**Per-template checklist gaps found and fixed in this pass:**

- **T01-it-helpdesk:** added a note to item 1 (HD-3010) flagging that filtering duplicate-candidates to open-only tickets can accidentally *remove* the near-tie ambiguity rather than resolve it; added a UI-surfacing check to item 2's "what to check" list (a flag has to actually render somewhere a reviewer would see it, not just exist as a DB row); reworded item 8's (HD-3045) check to ask whether the -999 record is ever *reached* at all before asking whether it's rejected correctly.
- **T02-loan-agreements:** broadened item 2's check from "does LN-7004 specifically commit despite being ambiguous" to "does *any* `needs_review=1` loan ever commit anyway" — the dry run showed this failure can be a blanket architectural policy, not scoped to the one planted case; added a note to item 1 distinguishing genuine evidence-based resolution (parsing a note's own supersession language) from blind first-found guessing, since a build can avoid the naive failure without ever setting the ambiguity flag; **added an explicit review-procedure fix for item 10** — the status-gating test loans (LN-7001/7002/7003) no longer fall inside a realistic "approaching maturity" horizon measured from the actual review date, so the procedure now says to test the status-gating logic via direct function invocation with an artificially wide horizon rather than trusting a live scan to surface these cases naturally. This one was time-sensitive: it would have silently produced false "not tested" results in every future review, including the upcoming timed human build, if left unfixed.
- **T03-flight-credits:** reworded item 6's (FR-8007) check to distinguish "executed using the customer's unverified figure" from "executed using the record's correct value but never escalated the mismatch" — the dry run showed a thoughtful build can land on the latter as a disclosed, reasoned design choice, materially different from blindly trusting untrusted text; added a note to item 11 (FR-8012) that the missing-history-defaults-to-0 outcome can be reached through genuine (if ultimately risky) reasoning about CSV semantics, not just carelessness.
- **T04-equipment-rentals:** item 5's (ORD-9004) fencing-panels-still-ship check was already incorporated from the earlier dry-run pass. Added in this pass: an order-level retry check to the "what to check" list (call `process_order()` twice, not just the tool-level dispatch function) — this is specifically what surfaced the FK-constraint crash bug in the dry run, and the tool-level-only check would never have caught it; added a note to item 4 (ORD-9008/9011) that this no-safe-default pair is sensitive to which reasonable threshold a candidate picks, and can go untested if their chosen threshold sits above both real order values.

**Scoring implication:** none — these are review-procedure and checklist corrections, not changes to any instance's dataset, brief, or grading treatment. No submission scored before this pass needs re-grading.

**Not yet done:** the same open items as before this pass — T01/T02/T03's live-AI dry runs are now complete and incorporated; T04's Addendum-31 status was already resolved as an accepted asymmetry. The timed human build phase (see each instance's dry-run status note) remains the next step for all four templates.
