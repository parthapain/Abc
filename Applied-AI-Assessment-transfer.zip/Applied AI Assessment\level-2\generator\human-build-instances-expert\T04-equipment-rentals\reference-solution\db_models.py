import sqlite3
import json

DB_FILE = "equipment_fulfillment.db"


def get_connection():
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                client_name TEXT,
                client_type TEXT,
                status TEXT,
                order_face_value REAL,
                dispatchable_value REAL,
                reasoning_log TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS line_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT,
                original_desc TEXT,
                sku TEXT,
                quantity INTEGER,
                status TEXT,
                fulfillment_source TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS dispatch_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT,
                idempotency_key TEXT UNIQUE,
                dispatch_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()


def save_order(order_id, client_name, client_type, status, order_face_value, dispatchable_value, logs, items):
    with get_connection() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO orders
                (order_id, client_name, client_type, status, order_face_value, dispatchable_value, reasoning_log)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (order_id, client_name, client_type, status, order_face_value, dispatchable_value, json.dumps(logs)))

        conn.execute("DELETE FROM line_items WHERE order_id = ?", (order_id,))
        for item in items:
            conn.execute("""
                INSERT INTO line_items (order_id, original_desc, sku, quantity, status, fulfillment_source)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (order_id, item["desc"], item["sku"], item["qty"], item["status"], item["source"]))
        conn.commit()


def record_dispatch(order_id, idempotency_key, dispatch_id):
    """Returns True if this created a NEW row, False if one already existed
    for this idempotency_key (i.e. a retry correctly did not duplicate)."""
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT id FROM dispatch_records WHERE idempotency_key = ?", (idempotency_key,)
        ).fetchone()
        if existing:
            return False
        conn.execute(
            "INSERT INTO dispatch_records (order_id, idempotency_key, dispatch_id) VALUES (?, ?, ?)",
            (order_id, idempotency_key, dispatch_id),
        )
        conn.commit()
        return True


def count_dispatch_records(order_id):
    with get_connection() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM dispatch_records WHERE order_id = ?", (order_id,)
        ).fetchone()[0]


def update_order_status(order_id, new_status):
    with get_connection() as conn:
        conn.execute("UPDATE orders SET status = ? WHERE order_id = ?", (new_status, order_id))
        conn.commit()
