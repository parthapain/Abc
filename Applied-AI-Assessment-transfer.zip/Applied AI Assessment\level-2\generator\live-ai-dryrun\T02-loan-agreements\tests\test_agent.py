from datetime import date

from app import db
from app.agent import process_document, run_maturity_followups
from app.tools import load_all_agreements


def _fresh_db(tmp_path):
    path = tmp_path / "test.db"
    db.init_db(path)
    return path


def test_full_pipeline_matches_expected_seed_outcomes(tmp_path):
    """End-to-end run over the real seed data, asserting the specific
    judgment-call outcomes the seed documents were designed to exercise."""
    db_path = _fresh_db(tmp_path)
    agreements = load_all_agreements()

    with db.get_conn(db_path) as conn:
        for a in agreements:
            process_document(conn, a)
        run_maturity_followups(conn, reference_date=date(2026, 9, 14), approaching_months=12)

    with db.get_conn(db_path) as conn:
        loans = {row["loan_number"]: row for row in db.all_loans(conn)}
        followups = {row["loan_number"]: row for row in db.all_followups(conn)}

    # every agreement was committed autonomously
    assert all(row["committed"] for row in loans.values())

    # LN-7002: maturity resolved via the single related promissory note
    assert loans["LN-7002"]["maturity_date"] == "2030-06-30"
    assert loans["LN-7002"]["maturity_source"] == "reference:LN-7002-note.txt"

    # LN-7004: two notes on file; the amended-and-restated one must win
    assert loans["LN-7004"]["maturity_date"] == "2032-08-01"
    assert "amended" in loans["LN-7004"]["maturity_source"]

    # LN-7003: borrower name variant between defined term and signature block
    assert loans["LN-7003"]["borrower_name"] == "Halloway Marine Holdings, Inc."
    assert loans["LN-7003"]["borrower_name_variant"] == "Halloway Marine Holdings LLC"
    assert loans["LN-7003"]["needs_review"] == 1

    # LN-7005: interest rate not yet fixed -> flagged, not fabricated
    assert loans["LN-7005"]["interest_rate"] is None
    assert loans["LN-7005"]["needs_review"] == 1

    # LN-7008: approaching maturity, registry says active -> follow-up generated
    assert followups["LN-7008"]["generated"] == 1
    assert followups["LN-7008"]["status_checked"] == "active"

    # LN-7009: approaching maturity but absent from the registry -> no follow-up
    assert followups["LN-7009"]["generated"] == 0
    assert followups["LN-7009"]["status_checked"] == "not_found"

    # a loan far from maturity should not even appear in the followups table
    assert "LN-7001" not in followups


def test_followup_skipped_for_non_active_status(tmp_path):
    db_path = _fresh_db(tmp_path)
    agreements = [a for a in load_all_agreements() if a["loan_number"] == "LN-7002"]
    with db.get_conn(db_path) as conn:
        for a in agreements:
            process_document(conn, a)
        # force LN-7002 (registry status: refinanced) to look "approaching maturity"
        conn.execute("UPDATE loans SET maturity_date='2026-10-01' WHERE loan_number='LN-7002'")
        run_maturity_followups(conn, reference_date=date(2026, 9, 14), approaching_months=12)

    with db.get_conn(db_path) as conn:
        row = db.followups_for(conn, "LN-7002")[0]
    assert row["generated"] == 0
    assert row["status_checked"] == "refinanced"


def test_human_correction_is_recorded(tmp_path):
    db_path = _fresh_db(tmp_path)
    agreements = [a for a in load_all_agreements() if a["loan_number"] == "LN-7005"]
    with db.get_conn(db_path) as conn:
        process_document(conn, agreements[0])
        db.apply_correction(conn, "LN-7005", "interest_rate", "6.00")

    with db.get_conn(db_path) as conn:
        loan = db.get_loan(conn, "LN-7005")
        corrections = db.corrections_for(conn, "LN-7005")

    assert loan["interest_rate"] == "6.00"
    assert len(corrections) == 1
    assert corrections[0]["old_value"] is None
    assert corrections[0]["new_value"] == "6.00"
