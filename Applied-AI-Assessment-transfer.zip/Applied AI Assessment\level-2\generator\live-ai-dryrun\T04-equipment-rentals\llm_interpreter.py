"""
Stand-in for the "in-house LLM".

No real LLM API key was available in this environment (checked ANTHROPIC_API_KEY),
so this module is a clearly-marked DETERMINISTIC stand-in that approximates what an
LLM call would do for the two jobs the brief assigns to it:

  1. split a free-text `line_items_description` field into individual line items
     ("3x Concrete Mixer, 2x Folding Table - 8ft" -> two items with qty + text)
  2. reconcile a line item's free-text description against the equipment catalog,
     the "doesn't map cleanly" step called out in the brief (e.g. "Concrete Mixer"
     on its own is a real product family name but doesn't specify which of two
     catalog SKUs -3.5cu ft or -6cu ft- is meant).

Design note: this is intentionally implemented as a single `interpret_line_item()`
function with a well-defined input/output contract (raw text -> {sku, confidence,
candidates, reasoning}), so swapping in a real LLM call later is a one-function
change -- the agent/tool layer above it never needs to know which implementation
answered the call. If ANTHROPIC_API_KEY (or another provider key) is present, this
module could be extended to route through it with the same signature.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

QTY_RE = re.compile(r"^\s*(\d+)\s*x\s*(.+?)\s*$", re.IGNORECASE)

# Confidence thresholds used to decide whether a reconciliation is trustworthy
# enough to act on without a human glancing at it.
CONFIDENT_THRESHOLD = 0.92
AMBIGUOUS_MARGIN = 0.05  # if top-2 scores are within this margin, treat as tied/ambiguous


@dataclass
class Candidate:
    sku: str
    name: str
    score: float


@dataclass
class ReconciliationResult:
    resolved_sku: str | None
    resolved_name: str | None
    confidence: float
    ambiguous: bool
    candidates: list[Candidate]
    reasoning: str


def split_line_items(raw_description: str) -> list[tuple[int, str]]:
    """
    Split a raw `line_items_description` cell into (qty, item_text) pairs.

    The seed data consistently uses a "<qty>x <name>" pattern joined by commas,
    e.g. "3x Skid Steer Loader - Standard, 2x Folding Table - 8ft". This is the
    "in-house LLM interprets each request" step -- in a real system this would be
    a model call over unstructured request text; here it's a small deterministic
    parser with a fallback for anything that doesn't match the expected pattern.
    """
    items: list[tuple[int, str]] = []
    for chunk in raw_description.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        m = QTY_RE.match(chunk)
        if m:
            qty = int(m.group(1))
            text = m.group(2).strip()
            items.append((qty, text))
        else:
            # Fallback: no explicit "<n>x" quantity found -- assume qty 1 and
            # pass the whole chunk through for reconciliation to sort out.
            items.append((1, chunk))
    return items


def _normalize(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def _score(query: str, candidate_name: str) -> float:
    """
    Similarity score in [0, 1] between a free-text item description and a
    catalog product name, combining:
      - exact match (after normalization) -> 1.0
      - whole-query-is-a-prefix-of-candidate (e.g. "Concrete Mixer" vs
        "Concrete Mixer - 3.5cu ft") -> high but not maximal, since it is
        missing the disambiguating suffix
      - general sequence similarity (difflib) as a fallback for typos / partial
        wording, e.g. "Skid Steer Loader" vs "Skid Steer Loader - Standard"
    """
    nq, nc = _normalize(query), _normalize(candidate_name)
    if nq == nc:
        return 1.0
    if nc.startswith(nq + " ") or nc.startswith(nq + "-"):
        # query names the product family but not the specific variant
        return 0.80
    if nq in nc:
        return 0.75
    return difflib.SequenceMatcher(None, nq, nc).ratio()


def interpret_line_item(raw_text: str, catalog: list[dict]) -> ReconciliationResult:
    """
    Reconcile one free-text line item against the catalog.

    catalog: list of dicts with keys sku, name, price_per_day, in_stock.
    """
    scored = sorted(
        (Candidate(sku=row["sku"], name=row["name"], score=_score(raw_text, row["name"]))
         for row in catalog),
        key=lambda c: c.score,
        reverse=True,
    )
    top_candidates = scored[:3]

    if not top_candidates or top_candidates[0].score < 0.55:
        return ReconciliationResult(
            resolved_sku=None,
            resolved_name=None,
            confidence=0.0,
            ambiguous=True,
            candidates=top_candidates,
            reasoning=f"No catalog item resembles '{raw_text}' closely enough to "
                      f"reconcile automatically (best score "
                      f"{top_candidates[0].score:.2f} for {top_candidates[0].name}).",
        )

    best = top_candidates[0]
    second = top_candidates[1] if len(top_candidates) > 1 else None

    tied = second is not None and (best.score - second.score) <= AMBIGUOUS_MARGIN
    confident = best.score >= CONFIDENT_THRESHOLD and not tied

    if confident:
        reasoning = (
            f"'{raw_text}' matches catalog item {best.sku} ({best.name}) with high "
            f"confidence ({best.score:.2f})."
        )
        return ReconciliationResult(
            resolved_sku=best.sku,
            resolved_name=best.name,
            confidence=best.score,
            ambiguous=False,
            candidates=top_candidates,
            reasoning=reasoning,
        )

    # Ambiguous: doesn't map cleanly. Apply a documented tie-break so the agent
    # can still propose a best guess, but flag it so it cannot silently
    # auto-dispatch -- a human should confirm the guess.
    tie_candidates = [c for c in top_candidates if (best.score - c.score) <= AMBIGUOUS_MARGIN]
    # Tie-break heuristic: prefer whichever tied candidate actually has stock,
    # since defaulting to a variant that's out of stock anyway is never useful.
    catalog_by_sku = {row["sku"]: row for row in catalog}
    tie_candidates_with_stock = [
        c for c in tie_candidates if catalog_by_sku.get(c.sku, {}).get("in_stock", 0) > 0
    ]
    guess = (tie_candidates_with_stock or tie_candidates)[0]

    names = ", ".join(f"{c.sku} ({c.name})" for c in tie_candidates)
    reasoning = (
        f"'{raw_text}' does not map cleanly onto a single catalog item -- "
        f"{len(tie_candidates)} candidates are near-equally plausible: {names}. "
        f"Best-guess default is {guess.sku} ({guess.name}) "
        f"{'because it is the only tied candidate with primary-yard stock' if tie_candidates_with_stock else '(first alphabetically; none of the tied candidates have primary-yard stock)'}, "
        f"but this line item is flagged for human confirmation rather than acted on blindly."
    )
    return ReconciliationResult(
        resolved_sku=guess.sku,
        resolved_name=guess.name,
        confidence=guess.score,
        ambiguous=True,
        candidates=top_candidates,
        reasoning=reasoning,
    )
