"""
Part B validation gate.

Executes the checks that the assessment plan requires before any problem ships:

  1. The reference solution passes every test case.
  2. The broken version FAILS every case marked "discriminator".
  3. The broken version PASSES every case marked "guard" — proving the failure
     is specific to the intended bug rather than incidental breakage.
  4. Every documented plausible-wrong-fix fails at least one case.

Scope: verifies SQL logic and the Python variant by execution. The Java and C#
variants are structurally parallel translations of the same query and algorithm;
they still require human review for compilation and translation fidelity.

Usage:
    python harness.py            # run every spec
    python harness.py p01 p07    # run selected specs
"""

from __future__ import annotations

import importlib.util
import sqlite3
import sys
import traceback
from pathlib import Path
from typing import Any, Callable

SPEC_DIR = Path(__file__).parent / "specs"

GREEN, RED, YELLOW, DIM, RESET = "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"


class SpecError(Exception):
    """The spec itself is malformed — distinct from a problem failing its gate."""


def load_specs(names: list[str] | None) -> list[tuple[str, Any]]:
    if not SPEC_DIR.exists():
        raise SpecError(f"spec directory not found: {SPEC_DIR}")

    paths = sorted(p for p in SPEC_DIR.glob("p*.py") if p.stem != "__init__")
    if names:
        wanted = {n.lower() for n in names}
        paths = [p for p in paths if p.stem.lower() in wanted]
        missing = wanted - {p.stem.lower() for p in paths}
        if missing:
            raise SpecError(f"no spec found for: {', '.join(sorted(missing))}")

    specs = []
    for path in paths:
        spec = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        specs.append((path.stem, module))
    return specs


def build_db(schema: str, seed: str) -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(schema)
    if seed and seed.strip():
        conn.executescript(seed)
    return conn


def run_variant(fn: Callable, schema: str, seed: str) -> tuple[Any, str | None]:
    """Return (result, error). A raised exception is a failure, not a crash."""
    conn = build_db(schema, seed)
    try:
        return fn(conn), None
    except Exception as exc:  # noqa: BLE001 - candidate code may raise anything
        return None, f"{type(exc).__name__}: {exc}"
    finally:
        conn.close()


def normalise(value: Any) -> Any:
    """Compare list-of-rows structurally, tolerating tuple/list mismatch."""
    if isinstance(value, list):
        return [tuple(v) if isinstance(v, (list, tuple)) else v for v in value]
    return value


def check_problem(name: str, mod: Any) -> tuple[bool, list[str]]:
    for attr in ("SCHEMA", "CASES", "broken", "fixed"):
        if not hasattr(mod, attr):
            raise SpecError(f"{name}: spec is missing required attribute '{attr}'")

    cases: dict[str, dict] = mod.CASES
    if not any(c.get("role") == "discriminator" for c in cases.values()):
        raise SpecError(f"{name}: spec defines no discriminator case")
    if not any(c.get("role") == "guard" for c in cases.values()):
        raise SpecError(f"{name}: spec defines no guard case")

    failures: list[str] = []

    def matches(fn, case) -> bool:
        actual, err = run_variant(fn, mod.SCHEMA, case.get("seed", ""))
        if err is not None:
            return False
        return normalise(actual) == normalise(case["expected"])

    # 1. Reference solution passes everything.
    for tid, case in cases.items():
        actual, err = run_variant(mod.fixed, mod.SCHEMA, case.get("seed", ""))
        if err is not None:
            failures.append(f"reference solution raised on {tid}: {err}")
        elif normalise(actual) != normalise(case["expected"]):
            failures.append(
                f"reference solution wrong on {tid}\n"
                f"      expected: {case['expected']}\n"
                f"      actual:   {actual}"
            )

    # 2 & 3. Broken version fails discriminators, passes guards.
    for tid, case in cases.items():
        ok = matches(mod.broken, case)
        role = case.get("role")
        if role == "discriminator" and ok:
            failures.append(
                f"{tid} is marked discriminator but the broken version PASSES it "
                f"— the bug is not exercised"
            )
        elif role == "guard" and not ok:
            failures.append(
                f"{tid} is marked guard but the broken version FAILS it "
                f"— breakage is not specific to the intended bug"
            )

    # 4. Documented wrong fixes are each caught by something.
    for label, fn in getattr(mod, "WRONG_FIXES", {}).items():
        if all(matches(fn, case) for case in cases.values()):
            failures.append(
                f"wrong fix '{label}' passes every case — the suite does not catch it"
            )

    return not failures, failures


def main(argv: list[str]) -> int:
    try:
        specs = load_specs(argv or None)
    except SpecError as exc:
        print(f"{RED}spec error:{RESET} {exc}")
        return 2

    if not specs:
        print(f"{YELLOW}no specs found in {SPEC_DIR}{RESET}")
        return 2

    print(f"Part B validation gate — {len(specs)} problem(s)\n")

    passed, failed, errored = [], [], []
    for name, mod in specs:
        meta = getattr(mod, "META", {})
        label = f"{name.upper():5} {meta.get('difficulty', '?'):6} {meta.get('location', '?'):5}"
        try:
            ok, failures = check_problem(name, mod)
        except SpecError as exc:
            errored.append(name)
            print(f"  {YELLOW}ERROR{RESET} {label}  {exc}")
            continue
        except Exception:  # noqa: BLE001
            errored.append(name)
            print(f"  {YELLOW}ERROR{RESET} {label}")
            traceback.print_exc()
            continue

        if ok:
            passed.append(name)
            n = len(mod.CASES)
            print(f"  {GREEN}PASS{RESET}  {label}  {DIM}{n} cases{RESET}")
        else:
            failed.append(name)
            print(f"  {RED}FAIL{RESET}  {label}")
            for f in failures:
                print(f"        {RED}-{RESET} {f}")

    total = len(specs)
    print(f"\n{'-' * 60}")
    print(f"  passed {len(passed)}/{total}", end="")
    if failed:
        print(f"   {RED}failed {len(failed)}{RESET} ({', '.join(failed)})", end="")
    if errored:
        print(f"   {YELLOW}errored {len(errored)}{RESET} ({', '.join(errored)})", end="")
    print()

    return 0 if not failed and not errored else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
