# Part A — Topic & Complexity Specification

**For:** HirePro question bank selection
**Assessment:** Applied AI Developer — Level 1, Part A
**Format:** 21 MCQs · 30 minutes · proctored
**Papers required:** 6 (2 days × 3 slots), minimal item overlap between papers

---

## Composition

| # | Section | Subtopics to draw from | Qs | Low | Med | High |
|---|---|---|---|---|---|---|
| 1 | Data Structures & Algorithms | Arrays & hashing; Big-O reasoning (read code → complexity); tree/graph traversal basics; sorting & searching trade-offs | 3 | 1 | 1 | 1 |
| 2 | Python | OOP & decorators; comprehensions and functional constructs (`map`/`filter`/`lambda`); exception handling & context managers; iterators & generators; `async`/`await` basics | 5 | 1 | 3 | 1 |
| 3 | AI/ML Fundamentals — LLM & Gen AI | Tokenization & context windows; prompting techniques (zero-shot, few-shot, chain-of-thought); embeddings & vector similarity search; retrieval-augmented generation (RAG); agents & tool-calling (incl. MCP concepts) | 5 | 1 | 3 | 1 |
| 4 | AI/ML Fundamentals — ML & Statistics | Supervised vs. unsupervised learning; evaluation metrics (precision, recall, F1, ROC-AUC); overfitting & the bias-variance trade-off; basic probability; correlation vs. causation | 3 | 1 | 1 | 1 |
| 5 | PostgreSQL | Joins, aggregation, subqueries; indexing & query plans (`EXPLAIN`); `JSONB` operations; `pgvector` / embedding storage awareness | 3 | 1 | 2 | — |
| 6 | API & Backend fundamentals | REST principles; statelessness; basic caching strategies | 1 | — | 1 | — |
| 7 | Data wrangling | Tabular operations (group-by, merge/join); missing-data handling; basic data cleaning | 1 | — | 1 | — |
| | **Total** | | **21** | **5** | **12** | **4** |

---

## Timing

| Band | Count | Budget each | Subtotal |
|---|---|---|---|
| High | 4 | ~2.0 min | 8.0 min |
| Medium | 12 | ~1.3 min | 15.6 min |
| Low | 5 | ~0.8 min | 4.0 min |
| | | **Total** | **~27.6 min** |

Fits the 30-minute window with ~2 minutes of slack for navigation and review.

> An earlier 25-item draft was rejected at ~30–50% over budget. At that density, High-complexity items consume the budget and leave under a minute each for the remainder — including code-reading and `EXPLAIN`-plan items. That measures reading speed rather than knowledge, and it does so precisely at the cutoff boundary where measurement error is most damaging.

---

## Cutoff — absolute, set before the test

**Part B unlocks in-session for candidates who meet a fixed pass mark on Part A.**

The pass mark is set **before Day 1** using HirePro's historical item difficulty data (p-values), or a per-complexity-band average if item-level data is unavailable.

**A percentile cutoff was considered and rejected as inoperable.** Part B must unlock roughly 30 minutes into a live 60-minute session — before any score distribution exists to compute a percentile against. Computing across slots is worse: the 6 papers are 6 different bank draws, so paper difficulty is confounded with candidate ability, and "top 45%" means something different in each room.

**If p-values are unavailable:** set a provisional mark from the dress rehearsal and accept a wider error margin on the first run. Record actual pass rates and move to a data-derived mark for the next cycle.

**Sanity check before locking the mark:** the implied pass rate must be consistent with Level 2 review capacity. Work backwards — if reviewers can assess *N* take-home submissions, the Part A + Part B funnel should deliver approximately *N*, not several times *N*.

---

## Anchor items (recommended)

Ask HirePro to embed **~5 identical items in all 6 papers**. These let us statistically equate difficulty across slots after the fact, so a score from Slot 1 means the same thing as a score from Slot 6. Without anchors there is no way to distinguish "harder paper" from "weaker room."

Anchors should span the complexity range (roughly 1 Low, 3 Medium, 1 High) and be drawn from the more stable topic areas — DSA and Python rather than Gen AI.

---

## Design decisions and rationale

**"Gen AI Basics" split into two named sections (3 and 4).** Statistics and ML fundamentals were previously folded into a single Gen AI bucket, which buried them. They are now visible and separately counted, so the spec cannot silently drift toward LLM trivia at the expense of ML/statistics depth.

**Kubernetes, containers, and streaming architecture are deliberately excluded.** This screens Applied AI *developers*, not platform or DevOps engineers. Infrastructure trivia produces false negatives on strong candidates who have never had to touch it — which cuts directly against the objective of surfacing talent regardless of background. Deployment tooling is an onboarding concern, not a selection filter. Data wrangling was added in preference to streaming: it is meaningfully testable at MCQ depth and far more broadly applicable to applied AI work.

**Python is retained at 5 items — a deliberate trade-off.** Python is the organization's actual AI stack, so it is genuinely job-relevant rather than an arbitrary gate. The accepted cost is that non-Python candidates encounter Python content *before* the cutoff, while Part B is deliberately language-neutral. This is mitigated by holding Python to **1 High item** (reduced from 2), so the pre-gate Python content is not the hardest material on the paper. Monitor this: if pass rates by candidate background (see below) show Java/.NET candidates failing Part A disproportionately, reduce Python to 2 items and move the DSA items to pseudocode for the next cycle.

**Complexity is weighted toward Medium (12 of 21) with deliberate Low and High tails.** Given mixed seniority — fresh graduates through senior engineers — a Medium-heavy paper keeps the assessment accessible while the 4 High items provide the discrimination needed at the top of the range.

---

## Required reporting

Report Part A pass rate **broken out by candidate background** — Python / Java / .NET / database / other.

This is the only metric that demonstrates whether the "talent can reside anywhere" objective was actually met. A large gap between Python and non-Python pass rates means the instrument is measuring background rather than capability, and the Python weighting above needs revisiting before the next cycle.

---

## Open items with HirePro

Tracked in [`hirepro-dependencies.md`](../hirepro-dependencies.md) — questions 4 (item p-values), 5 (bank depth per cell), 6 (randomization granularity), 7 (anchor items), and 9 (section gating mechanics) all bear on this specification.

Question 5 is the one most likely to force a revision: if the bank is thin in **Gen AI / LLM — Medium** or **Data wrangling**, counts must be redistributed to topics with real depth rather than accepting the same items appearing across multiple slots.
