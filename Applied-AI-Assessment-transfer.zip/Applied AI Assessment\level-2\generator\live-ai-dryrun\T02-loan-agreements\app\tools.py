"""Agent tools.

Each function here is a discrete "tool" the agent (app/agent.py) can invoke —
they are kept separate from the agent's control flow so each one has a single
clear responsibility and can be unit-tested (and, later, swapped for a real
API call — e.g. lookup_loan_status could become an HTTP call to a loan
servicing system) without touching the orchestration logic.
"""
from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Optional

BASE_DIR = Path(__file__).resolve().parent.parent
DOCS_DIR = BASE_DIR / "loan_documents"
REGISTRY_CSV = BASE_DIR / "loan_status_registry.csv"

_DELIM_RE = re.compile(r"^=+$", re.MULTILINE)
_LOAN_NUMBER_RE = re.compile(r"Loan Number:\s*(LN-\d+)")


def load_all_agreements() -> list[dict]:
    """Load every loan agreement from loan_documents/.

    A source file may contain more than one agreement back-to-back separated
    by a line of '=' characters (see LN-7006-7007.txt); each agreement is
    split out into its own record here. Promissory-note files (matched via
    lookup_related_document, not this function) are NOT included — they are
    supporting documents, not primary agreements.
    """
    agreements = []
    for path in sorted(DOCS_DIR.glob("*.txt")):
        if "-note" in path.stem:
            continue  # supporting document, fetched on demand via a tool call
        text = path.read_text(encoding="utf-8")
        chunks = _DELIM_RE.split(text)
        for chunk in chunks:
            chunk = chunk.strip()
            if not chunk or not _LOAN_NUMBER_RE.search(chunk):
                continue
            loan_number = _LOAN_NUMBER_RE.search(chunk).group(1)
            agreements.append(
                {"loan_number": loan_number, "source_file": path.name, "text": chunk}
            )
    return agreements


# --- Tool 1: cross-check an extracted value against its source document ----

def cross_check_field(doc_text: str, value: Optional[str]) -> bool:
    """Verify that `value` (as extracted) is actually present in `doc_text`.

    This is the agent's sanity check on its own extraction before it commits
    anything: a simple substring containment check against the source text
    the value was claimed to come from. Returns False (fails the check) for
    an empty/None value, which the agent treats as "needs review" rather than
    "verified".
    """
    if not value:
        return False
    return value in doc_text


# --- Tool 2: look up a related document (e.g. a promissory note) -----------

def lookup_related_document(loan_number: str) -> list[dict]:
    """Find supporting documents for `loan_number` (promissory notes etc.)

    Matches files named '<loan_number>-note*.txt'. Returns a list of
    {filename, text} dicts (there may be more than one on file, e.g. an
    original and an amended-and-restated note for LN-7004) — the agent
    decides which one governs.
    """
    results = []
    for path in sorted(DOCS_DIR.glob(f"{loan_number}-note*.txt")):
        results.append({"filename": path.name, "text": path.read_text(encoding="utf-8")})
    return results


# --- Tool 3: look up the current loan status from the system of record -----

def lookup_loan_status(loan_number: str) -> Optional[str]:
    """Look up `loan_number`'s current verified status in the loan status
    registry. Returns None if the loan is not present in the registry
    (the agent must not assume 'active' in that case)."""
    with open(REGISTRY_CSV, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["loan_number"] == loan_number:
                return row["verified_status"]
    return None


# --- Tool 4: commit the extracted record to the system of record -----------
# --- Tool 5: generate a maturity follow-up record ---------------------------
# (both implemented in app/db.py's upsert_loan/mark_committed/record_followup,
#  invoked from app/agent.py — kept in db.py since "commit" IS the persistence
#  write; duplicating it here would just be an indirection layer.)
