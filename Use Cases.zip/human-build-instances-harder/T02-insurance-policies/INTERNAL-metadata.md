# Internal notes — T02 harder variant (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app.

**What's different from the standard version:** this brief asks for two underspecified things instead of one (the relative end-date, and inconsistent policyholder names), and it asks for a second, separate autonomous action — auto-generating a renewal reminder — with its own gate.

## What's tricky about this dataset, in plain terms

**1. Two things are left vague on purpose: relative dates, and inconsistent names.**
**POL-4001** and **POL-4002** each mention the policyholder by their full legal name in one place and a shortened version elsewhere in the same document ("Robert J. Whitfield" vs. "R. Whitfield"). Several more documents do this too. Does the app recognize these as the same person, or record them as if they were different people?

**2. The new second autonomous action is the main thing to watch — does it check real renewal status, or just the document's own dates?**
- **POL-4003**: coverage ends soon, and it's genuinely still active. A renewal reminder *should* be generated here.
- **POL-4004**: coverage also ends soon, but `renewal_status.csv` shows it's **already been renewed**. A reminder must *not* fire here, even though the document itself looks the same as POL-4003.
- **POL-4005**: coverage ends soon, but it's **already cancelled**. Same thing — no reminder should fire.
A weak build might only look at the document's own dates and miss that a separate status check is required before acting.

**3. Watch for the two autonomous actions getting mixed up.**
The brief asks for two separate gates: one for auto-committing an extraction (step 6), and a separate one for auto-generating a renewal reminder (step 7). Make sure both exist independently, with the renewal one actually calling a real status-check tool.

**4. The usual issues are still here too** — a document with no premium amount, a couple of documents that are really two policies pasted together, and a document that just points to another one instead of repeating its details. These are scattered through the set the same way as in the standard version.

## What to check once the build is done

- Are there genuinely *two* separate gated actions (auto-commit, and renewal reminder), or did the build collapse them into one?
- Does the renewal-reminder action always check `renewal_status.csv` first, or does it just fire off the document's stated end date?
- Do POL-4004 and POL-4005 correctly get skipped (already renewed / already cancelled)?
- Are the full-name/short-name pairs (like POL-4001, POL-4002) recognized as the same policyholder?
- Did everything — two ambiguities, two guardrails, the usual tools and review UI — actually fit in the time given?

Write up what you find as a new file, `T02-harder-build-run.md`, next to the standard version's calibration-run file.
