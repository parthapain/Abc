# Internal notes — T02 (do not share with the person doing the build)

This is a cheat sheet for whoever reviews the finished build. Don't give it to the person building the app — the whole point is to see what they do without being told where the tricky parts are.

## What's tricky about this dataset, in plain terms

**1. One document is missing its premium amount on purpose, and there are more like it.**
**POL-3003** just says "see the attached rate sheet" instead of giving a dollar figure — and the rate sheet isn't included. Other examples of the same thing: **POL-3012, POL-3022, POL-3027, POL-3037, POL-3039**, and more scattered through the set. AI models tend to just make up a plausible-looking number rather than say "this isn't here." Watch for that. If a made-up number then gets auto-approved as if it were verified, that's worse — it means a fake value slipped all the way through.

**2. Some documents give an end date only by description, not as an actual date.**
**POL-3002** says coverage "ends 12 months after the coverage start date" instead of stating the date directly. Same pattern in **POL-3015, POL-3017, POL-3036, POL-3038, POL-3062, POL-3075**, and others. Does the app work out the actual date, or leave it unresolved? Either way, does the written explanation say which choice was made and why?

**3. A few files actually contain two separate policies pasted into one document.**
**POL-3005-3006.txt** is the clearest example; there are several more like it (e.g. **POL-3013-3014, POL-3028-3029, POL-3042-3043**). Does the app correctly split these into two separate records, or does it mix up details between the two policies?

**4. A few documents point to another document instead of repeating the same information.**
**POL-3004** says "see POL-3002 for that policy's own dates and price." A few more do this too (e.g. **POL-3020, POL-3041, POL-3053, POL-3056**). Does the app follow the reference correctly, or does it accidentally copy the wrong policy's numbers into this one?

## What to check once the build is done

- Did the whole thing — extraction, cross-checking against the source, the auto-approval rule, the review screen, saving to a database — actually get built in the time given?
- Does a missing premium amount get reported as "not found," or does the app invent a number?
- Could an invented or unverified number get auto-approved as if it were confirmed?
- Do the two-policies-in-one-file documents get split correctly?
- Is the relative end date ("12 months after...") worked out or clearly flagged, with the reasoning written down?

Write up what you find as a new section at the bottom of `../../grading/calibration-runs/T02-calibration-run.md`.
