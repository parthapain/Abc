# P20 — Usage summary

| Field | Value |
|---|---|
| **ID** | P20 |
| **Difficulty** | High |
| **Bug pattern** | Cursor iterated twice; the second pass is empty |
| **Bug location** | Host logic |
| **Languages** | Python · Java · C# |
| **Target solve time** | 14–18 min |
| **Paper** | 2 (with P02) |
| **Status** | Logic validated · Java/C# pending human review |

---

## Candidate-facing brief

### Scenario

A billing summary reads usage records, checks whether the account crossed a minimum billable total of 100 tokens, and if so returns the itemised records.

Accounts that cross the threshold come back with an **empty** itemised list. The threshold check itself is correct — accounts below 100 are correctly reported as empty, and accounts above it are correctly identified as billable. Only the items are missing.

### Required behaviour

Read all records ordered by `id`.

- If the total token count is **less than 100**, return an empty list.
- Otherwise return `(name, tokens)` for every record, in `id` order.

### Schema

```sql
CREATE TABLE records (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    tokens INTEGER NOT NULL
);
```

---

## Fixture — `P20.sql`

```sql
CREATE TABLE records (
    id     INTEGER PRIMARY KEY,
    name   TEXT NOT NULL,
    tokens INTEGER NOT NULL
);

INSERT INTO records (id, name, tokens) VALUES
    (1,'a',60),
    (2,'b',70);   -- total 130, above the threshold
```

---

## Broken code

### Python

```python
import sqlite3
from typing import List, Tuple

MIN_TOTAL = 100

# --- boilerplate: do not modify ---
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)

_QUERY = "SELECT name, tokens FROM records ORDER BY id"
# --- end boilerplate ---


def billable_items(db_path: str) -> List[Tuple[str, int]]:
    """
    Return [] if the total token count is below MIN_TOTAL.
    Otherwise return (name, tokens) for every record, in id order.
    """
    conn = _connect(db_path)
    try:
        cursor = conn.execute(_QUERY)

        total = sum(row[1] for row in cursor)
        if total < MIN_TOTAL:
            return []

        return [(row[0], row[1]) for row in cursor]
    finally:
        conn.close()
```

### Java

```java
import java.sql.*;
import java.util.*;

public class BillingSummary {

    public static final int MIN_TOTAL = 100;

    // --- boilerplate: do not modify ---
    public static class Item {
        public final String name;
        public final int tokens;

        public Item(String name, int tokens) {
            this.name = name;
            this.tokens = tokens;
        }
    }

    private static final String QUERY = "SELECT name, tokens FROM records ORDER BY id";

    private static Connection connect(String dbPath) throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
    // --- end boilerplate ---

    /**
     * Return an empty list if the total token count is below MIN_TOTAL.
     * Otherwise return (name, tokens) for every record, in id order.
     */
    public static List<Item> billableItems(String dbPath) throws SQLException {
        List<Item> items = new ArrayList<>();

        try (Connection conn = connect(dbPath);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(QUERY)) {

            int total = 0;
            while (rs.next()) {
                total += rs.getInt("tokens");
            }
            if (total < MIN_TOTAL) {
                return items;
            }

            while (rs.next()) {
                items.add(new Item(rs.getString("name"), rs.getInt("tokens")));
            }
        }
        return items;
    }
}
```

### C#

```csharp
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;
using Dapper;

public record Item(string Name, int Tokens);

public static class BillingSummary
{
    public const int MinTotal = 100;

    // --- boilerplate: do not modify ---
    private const string Query = "SELECT name, tokens FROM records ORDER BY id";

    private static SqliteConnection Connect(string dbPath) =>
        new SqliteConnection($"Data Source={dbPath}");
    // --- end boilerplate ---

    /// <summary>
    /// Return an empty list if the total token count is below MinTotal.
    /// Otherwise return (Name, Tokens) for every record, in id order.
    /// </summary>
    public static List<Item> BillableItems(string dbPath)
    {
        using var conn = Connect(dbPath);

        var rows = conn.Query<Item>(Query, buffered: false);

        int total = rows.Sum(r => r.Tokens);
        if (total < MinTotal)
        {
            return new List<Item>();
        }

        return rows.ToList();
    }
}
```

---

## Hidden test cases

| # | Setup | Expected | Role |
|---|---|---|---|
| T1 | `a` 60, `b` 70 — total 130 | `[("a",60), ("b",70)]` | **Discriminator** — broken returns `[]` |
| T2 | `a` 10, `b` 20 — total 30 | `[]` | Guard — below threshold, so the second pass is never reached |
| T3 | `x` 500 — total 500 | `[("x",500)]` | **Discriminator** — broken returns `[]` |
| T4 | `a` 40, `b` 50 — total 90 | `[]` | Guard — just below threshold |
| T5 | Empty table | `[]` | Guard |

> The two guard cases are what make this problem sound. The broken version returns `[]` for **every** input; without T2 and T4 proving that `[]` is sometimes the *correct* answer reached by the correct path, a candidate could "pass" by hard-coding an empty return.

### Fixtures

```sql
-- T2
INSERT INTO records (id, name, tokens) VALUES (1,'a',10),(2,'b',20);
-- T3
INSERT INTO records (id, name, tokens) VALUES (1,'x',500);
-- T4
INSERT INTO records (id, name, tokens) VALUES (1,'a',40),(2,'b',50);
```

---

## Reference solution

Read the rows into memory once, then use that collection for both passes.

**Python:**

```diff
- cursor = conn.execute(_QUERY)
+ rows = conn.execute(_QUERY).fetchall()

- total = sum(row[1] for row in cursor)
+ total = sum(row[1] for row in rows)
  if total < MIN_TOTAL:
      return []

- return [(row[0], row[1]) for row in cursor]
+ return [(row[0], row[1]) for row in rows]
```

**Java** — materialise into a list before summing:

```diff
+ List<Item> all = new ArrayList<>();
  while (rs.next()) {
-     total += rs.getInt("tokens");
+     all.add(new Item(rs.getString("name"), rs.getInt("tokens")));
  }
+ int total = all.stream().mapToInt(i -> i.tokens).sum();
  if (total < MIN_TOTAL) {
      return items;
  }
- while (rs.next()) {
-     items.add(new Item(rs.getString("name"), rs.getInt("tokens")));
- }
+ items.addAll(all);
```

**C#** — buffer the query:

```diff
- var rows = conn.Query<Item>(Query, buffered: false);
+ var rows = conn.Query<Item>(Query).ToList();
```

### Why

A database cursor is a **forward-only stream, not a collection**. Reading it to compute the total advances it to the end; the second traversal starts from there and yields nothing. No error is raised, because reaching the end of a result set is a normal condition rather than a fault.

This is why the symptom is so specific: the threshold check works perfectly — it is the pass that consumed the data — while everything downstream of it is empty. The correct branch is taken for the correct reason, and then returns nothing.

The same trap exists in all three languages with different surface syntax:

| Language | The stream | Why the second pass is empty |
|---|---|---|
| Python | `sqlite3.Cursor` | An iterator; exhausted after the first `for` |
| Java | `ResultSet` | Forward-only by default; `rs.next()` already returned `false` |
| C# | Dapper with `buffered: false` | Deferred enumeration over an open reader |

The fix is the same everywhere: decide once whether you need the rows more than once, and materialise them if you do.

### Plausible wrong fixes the tests catch

| Wrong fix | Caught by |
|---|---|
| Materialising the rows but dropping the threshold check | T2, T4 — below-threshold accounts now return items |
| Running the query a second time instead of buffering | Passes the tests, but doubles the query count — flag in review as acceptable-but-wasteful |
| Returning the items before the threshold check | T2, T4 |

---

## Reviewer validation checklist

Run for **each** language variant. Do not sign off from reading alone.

- [ ] Reference solution passes T1–T5
- [ ] Broken version **fails T1 and T3**, and **passes T2, T4, T5**
- [ ] Failure is a silently empty list, not an exception — if the runtime throws, the bug is too easy and the variant needs reworking
- [ ] **C#: confirm `buffered: false` is present.** With Dapper's default buffering the query is materialised eagerly and the bug does not reproduce
- [ ] **Java: confirm the driver's default forward-only `ResultSet`** — a scrollable result set would let the second loop succeed
- [ ] Exactly one intended change; no second defect introduced
- [ ] Boilerplate block compiles/runs untouched and is clearly marked
- [ ] Solve time within 25% of the 3-language mean (parity pilot)

**Reviewers:** _______________  **Date:** _______________
