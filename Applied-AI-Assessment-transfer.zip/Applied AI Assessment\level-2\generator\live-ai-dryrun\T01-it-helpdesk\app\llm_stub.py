"""
Deterministic stand-in for the "in-house LLM" referenced in the brief.

No API key was available in this environment (checked ANTHROPIC_API_KEY / OPENAI_API_KEY
at startup), so this module implements a rule-based classifier behind the exact function
contract a real model call would have: `classify(body_text, *, requester_tier=None,
extra_context=None) -> ClassificationResult`.

To swap in a real model later: keep this signature, replace the body of `classify()`
with a prompted call to the LLM (few-shot with the CATEGORIES below + an instruction to
return {category, confidence, reasoning} as JSON), and leave every caller (app/agent.py)
untouched.
"""
from dataclasses import dataclass, field
from typing import Optional

CATEGORIES = [
    "Hardware",
    "Software Access",
    "Network/VPN",
    "Licensing & Reimbursement",
    "Security Incident",
]

# Confidence below this means the agent treats the classification as uncertain and
# will pull additional context via a tool before deciding how to proceed.
UNCERTAIN_CONFIDENCE_THRESHOLD = 0.6

# Keyword signal table. Each hit adds its weight to that category's score. This is a
# deliberately simple bag-of-keywords model -- transparent and easy to reason about,
# which matters more here than raw accuracy since the whole point is a stand-in with
# an auditable, swappable contract.
_SIGNALS = {
    "Hardware": [
        ("laptop", 2), ("monitor", 2), ("keyboard", 2), ("mouse", 1),
        ("won't turn on", 3), ("wont turn on", 3), ("battery", 2), ("screen", 2),
        ("charger", 2), ("device", 1), ("printer", 2), ("firmware", 2), ("hardware", 3),
        ("reimag", 2), ("power button", 2), ("docking station", 2), ("dock", 1),
    ],
    "Software Access": [
        ("access", 2), ("login", 1), ("log in", 1), ("permission", 3), ("account setup", 2),
        ("password reset", 2), ("install", 2), ("software", 2), ("application", 1),
        ("wallpaper", 2), ("settings", 1), ("app", 1), ("can't open", 2), ("license key", 1),
    ],
    "Network/VPN": [
        ("vpn", 4), ("network", 2), ("wifi", 3), ("wi-fi", 3), ("connection", 1),
        ("dropping", 2), ("disconnect", 2), ("locked out", 2), ("can't log into the vpn", 3),
        ("remote", 1), ("production deploy", 2), ("latency", 1), ("firewall", 2),
    ],
    "Licensing & Reimbursement": [
        ("refund", 3), ("reimburse", 3), ("reimbursement", 3), ("overcharged", 3),
        ("charged", 2), ("billing", 3), ("subscription", 2), ("renewal", 2),
        ("license", 2), ("invoice", 2), ("$", 1), ("insurance add-on", 2),
    ],
    "Security Incident": [
        ("unauthorized", 4), ("breach", 4), ("phishing", 4), ("malware", 4), ("virus", 3),
        ("suspicious", 3), ("someone else", 3), ("compromised", 4), ("hacked", 4),
        ("failed login", 2), ("locked after repeated failed", 3),
    ],
}


@dataclass
class ClassificationResult:
    category: Optional[str]
    confidence: float
    reasoning: str
    scores: dict = field(default_factory=dict)


def _score_text(text: str) -> dict:
    lowered = text.lower()
    scores = {cat: 0.0 for cat in CATEGORIES}
    hits = {cat: [] for cat in CATEGORIES}
    for cat, signals in _SIGNALS.items():
        for phrase, weight in signals:
            if phrase in lowered:
                scores[cat] += weight
                hits[cat].append(phrase)
    return scores, hits


def classify(body_text: str, *, requester_tier: Optional[str] = None,
             extra_context: Optional[str] = None) -> ClassificationResult:
    """Classify a helpdesk ticket body into one of CATEGORIES.

    `extra_context` is appended to the scored text when the agent has pulled
    additional context to disambiguate an uncertain first pass (see app/agent.py).
    """
    text = (body_text or "").strip()
    if not text:
        return ClassificationResult(
            category=None,
            confidence=0.0,
            reasoning="Ticket body is empty -- no signal to classify on. Needs human triage.",
            scores={},
        )

    scored_text = text if not extra_context else f"{text}\n{extra_context}"
    scores, hits = _score_text(scored_text)

    total = sum(scores.values())
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    top_cat, top_score = ranked[0]
    second_cat, second_score = ranked[1] if len(ranked) > 1 else (None, 0.0)

    if total == 0:
        return ClassificationResult(
            category=None,
            confidence=0.0,
            reasoning="No recognizable category keywords found in the ticket body. Needs human triage.",
            scores=scores,
        )

    # Confidence: how dominant the top category is vs. the runner-up and the field.
    # 1.0 when it's the only signal present, lower as a second category closes in.
    margin = (top_score - second_score) / top_score if top_score else 0
    confidence = round(min(1.0, 0.5 + 0.5 * margin), 2)

    reason_bits = [f"matched signal(s) for '{top_cat}': {', '.join(hits[top_cat])}"]
    if second_score > 0:
        reason_bits.append(
            f"also saw weaker signal(s) for '{second_cat}': {', '.join(hits[second_cat])} "
            f"(score {second_score} vs {top_score})"
        )
    if extra_context:
        reason_bits.append(f"additional context considered: {extra_context}")
    reasoning = "; ".join(reason_bits) + "."

    return ClassificationResult(
        category=top_cat,
        confidence=confidence,
        reasoning=reasoning,
        scores=scores,
    )


def is_uncertain(result: ClassificationResult) -> bool:
    return result.category is None or result.confidence < UNCERTAIN_CONFIDENCE_THRESHOLD
